# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "b87c684f-6cc7-4782-9ed9-3030b3f58b71",
# META       "default_lakehouse_name": "FabricAdminAgent",
# META       "default_lakehouse_workspace_id": "1ea96d33-ced1-48f0-9098-ed7e13bdc625",
# META       "known_lakehouses": [
# META         {
# META           "id": "b87c684f-6cc7-4782-9ed9-3030b3f58b71"
# META         }
# META       ]
# META     }
# META   }
# META }

# MARKDOWN ********************

# # imports

# CELL ********************

from datetime import datetime, timedelta
from notebookutils import mssparkutils
import pyspark.sql.functions as F
from functools import reduce
from pyspark.sql import DataFrame
from pyspark.sql.window import Window
import sempy.fabric as fabric

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # configuration

# CELL ********************

kustoUri = mssparkutils.notebook.run("ConfigNotebook", 60)
print("Received kustoUri:", kustoUri)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

kustoQuery = "['ConfigTable'] | where ConfigCategory in ('FUAMConfig') and IsActive == true"
# kustoUri = "https://trd-zfmmx5us1trradc09u.z1.kusto.fabric.microsoft.com"
database = "FabricAdminAgentLogs"
accessToken = mssparkutils.credentials.getToken(kustoUri)

config_df = spark.read\
    .format("com.microsoft.kusto.spark.synapse.datasource")\
    .option("accessToken", accessToken)\
    .option("kustoCluster", kustoUri)\
    .option("kustoDatabase", database)\
    .option("kustoQuery", kustoQuery).load()

config_dict = {row['ConfigKey']: row['ConfigValue'] for row in config_df.collect()}
workspace_id = config_dict.get('WorkspaceId')  
dataset_name = config_dict.get('DatasetName')     
workspace_name = config_dict.get('WorkspaceName')  
lakehouse_name = config_dict.get('LakehouseName')    
lakehouse_id = config_dict.get('LakehouseId')

if not all([workspace_id, dataset_name, workspace_name, lakehouse_id]):
    raise ValueError("Missing required configuration values. Please check ConfigTable in Kusto.")

print(f"Configuration loaded")

# ==============================
# DEFINE TARGET LAKEHOUSE
# ==============================
# TARGET_LAKEHOUSE = "FabricAdminAgent"
TARGET_LAKEHOUSE = lakehouse_name 


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# ==============================
# CONSTRUCT ABFS PATHS
# ==============================
base_abfs_path = f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}/Tables"

# Define all ABFS paths for tables
abfs_paths = {
    "capacities": f"{base_abfs_path}/capacities",
    "workspaces": f"{base_abfs_path}/workspaces",
    "active_items": f"{base_abfs_path}/active_items",
    "capacity_metrics_by_item_by_operation_by_day": f"{base_abfs_path}/capacity_metrics_by_item_by_operation_by_day",
    "calendar": f"{base_abfs_path}/calendar"
}

# print("\n=== ABFS Paths ===")
# for table_name, path in abfs_paths.items():
#     print(f"{table_name}: {path}")
# print("==================\n")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # sku mapping

# CELL ********************

sku_to_cu_mapping = {
    "F2": 2, "F4": 4, "F8": 8, "F16": 16, "F32": 32, "F64": 64,
    "F128": 128, "F256": 256, "F512": 512, "F1024": 1024, "F2048": 2048,
    "FT1": 1, "FTL64": 64,
    "P1": 8, "P2": 16, "P3": 32, "P4": 64, "P5": 128,
    "PP1": 1, "PP2": 2, "PP3": 4,
    "A1": 1, "A2": 2, "A3": 4, "A4": 8, "A5": 16, "A6": 32
}

sku_mapping_expr = F.create_map([F.lit(x) for pair in sku_to_cu_mapping.items() for x in pair])

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # item level groupby

# CELL ********************

groupby_item = [
    "capacities[displayName]",
    "workspaces[WorkspaceName]",
    "calendar[Date2Key]",
    "capacity_metrics_by_item_by_operation_by_day[ItemKind]",
    "active_items[name]",
    "capacity_metrics_by_item_by_operation_by_day[OperationName]",
    "capacity_metrics_by_item_by_operation_by_day[ItemId]"
]

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # workspace level groupby

# CELL ********************

groupby_workspace = [
    "capacities[displayName]",
    "workspaces[WorkspaceName]",
    "calendar[Date2Key]",
    "capacity_metrics_by_item_by_operation_by_day[ItemKind]",
    "active_items[name]",
    "capacity_metrics_by_item_by_operation_by_day[ItemId]"
]

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

measures = {
    "Total CUs IOD": "Total_CUs"
}
print("\nFetching data from semantic model for item-level...")
df = fabric.evaluate_measure(
    dataset=dataset_name,
    measure="Total CUs IOD",
    groupby_columns=groupby_item,
    workspace=workspace_name
)
final_df_item = spark.createDataFrame(df)
final_df_item = final_df_item.withColumn("Total CUs IOD", F.coalesce(F.col("Total CUs IOD"), F.lit(0)))

print(f"Item-level data fetched successfully. Total records: {final_df_item.count()}")

print("\nFetching data from semantic model for workspace-level...")

df_ws = fabric.evaluate_measure(
    dataset=dataset_name,
    measure="Total CUs IOD",
    groupby_columns=groupby_workspace,
    workspace=workspace_name
)

final_df_workspace = spark.createDataFrame(df_ws)
final_df_workspace = final_df_workspace.withColumn("Total CUs IOD", F.coalesce(F.col("Total CUs IOD"), F.lit(0)))

print(f"Workspace-level data fetched successfully. Total records: {final_df_workspace.count()}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # Capacities and workspace info

# CELL ********************

# ==============================
# LOAD TABLES USING ABFS PATHS
# ==============================
print("\nLoading tables using ABFS paths...")

df_capacities = spark.read.format("delta").load(abfs_paths["capacities"]).select(
    F.col("displayName").alias("capacity_displayName"),
    F.col("sku").alias("capacity_sku")
)

df_workspaces = spark.read.format("delta").load(abfs_paths["workspaces"]).select(
    F.col("WorkspaceName").alias("workspace_name"),
    F.col("CapacityId").alias("capacity_id"),
    F.col("WorkspaceId").alias("workspace_id")
)

print(f"Capacities table loaded: {df_capacities.count()} records")
print(f"Workspaces table loaded: {df_workspaces.count()} records")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df_capacities = spark.read.format("delta").load(abfs_paths["capacities"]).select(
    F.col("displayName").alias("capacity_displayName"),
    F.col("sku").alias("capacity_sku")
)

df_workspaces = spark.read.format("delta").load(abfs_paths["workspaces"]).select(
    F.col("WorkspaceName").alias("workspace_name"),
    F.col("CapacityId").alias("capacity_id"),
    F.col("WorkspaceId").alias("workspace_id")
)

print(f"Capacities table loaded: {df_capacities.count()} records")
print(f"Workspaces table loaded: {df_workspaces.count()} records")

# ==============================
# CREATE ITEM_LEVEL_CU_CONSUMPTION TABLE
# ==============================
print("\nCreating item_level_cu_consumption table...")

# Aggregate by date, workspace, and item (sum across operations)
df_item_cu = (
    final_df_item
    .groupBy("displayName", "WorkspaceName", "Date2Key", "ItemKind", "name", "ItemId")
    .agg(
        F.sum("Total CUs IOD").alias("CuConsumed")
    )
)

# Join with capacity info to get SKU
df_item_cu = df_item_cu.join(
    df_capacities.select("capacity_displayName", "capacity_sku"),
    df_item_cu.displayName == df_capacities.capacity_displayName,
    "left"
).drop("capacity_displayName")

# Join with workspace info to get capacity_id and workspace_id
df_item_cu = df_item_cu.join(
    df_workspaces,
    df_item_cu.WorkspaceName == df_workspaces.workspace_name,
    "left"
).drop("workspace_name")

# Map SKU to numeric CU value
df_item_cu = df_item_cu.withColumn(
    "capacity_sku_numeric",
    sku_mapping_expr[F.col("capacity_sku")]
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # calculating item level cu consumption

# CELL ********************

# Calculate capacity CU seconds
seconds_in_14_days = 3600 * 24 
df_item_cu = df_item_cu.withColumn(
    "TotalCapacityCuSec",
    F.when(F.col("capacity_sku_numeric").isNotNull(),
           F.col("capacity_sku_numeric") * F.lit(seconds_in_14_days))
    .otherwise(None)
)

# Calculate consumption percentage
df_item_cu = df_item_cu.withColumn(
    "ConsumptionPercentage",
    F.when(F.col("TotalCapacityCuSec").isNotNull(),
           F.round((F.col("CuConsumed") / F.col("TotalCapacityCuSec")) * 100, 2))
    .otherwise(None)
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Select and rename columns with Pascal casing (final selection)
df_item_cu_final = df_item_cu.select(
    F.col("capacity_id").alias("CapacityId"),
    F.col("displayName").alias("CapacityDisplayName"),
    F.col("workspace_id").alias("WorkspaceId"),
    F.col("WorkspaceName"),
    F.col("ItemId"),
    F.col("name").alias("ItemName"),
    F.col("ItemKind"),
    F.col("Date2Key").alias("DateKey"),
    F.col("CuConsumed"),
    F.col("TotalCapacityCuSec"),
    F.col("ConsumptionPercentage")
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Save the table to the lakehouse
table_name = "item_level_cu_consumption"

# Try writing with lakehouse prefix
try:
    full_table_name = f"{TARGET_LAKEHOUSE}.{table_name}"
    df_item_cu_final.write.format("delta").mode("overwrite").saveAsTable(full_table_name)
    print(f"Table created successfully: {full_table_name}")
except Exception as e:
    print(f"Method 1 failed: {e}")
    print(f"Trying alternative method...")
    
    # Write directly to table name (will use default lakehouse)
    try:
        df_item_cu_final.write.format("delta").mode("overwrite").saveAsTable(table_name)
        print(f"Table created successfully: {table_name}")
    except Exception as e2:
        print(f"Method 2 also failed: {e2}")
        print(f"Trying to save to Tables folder...")
        
        # Write to lakehouse Tables folder directly
        output_path = f"Tables/{table_name}"
        df_item_cu_final.write.format("delta").mode("overwrite").save(output_path)
        print(f"Data saved to: {output_path}")
        print(f"  Now registering as table...")
        spark.sql(f"CREATE TABLE IF NOT EXISTS {table_name} USING DELTA LOCATION '{output_path}'")
        print(f"Table registered: {table_name}")

print(f"  Total records: {df_item_cu_final.count()}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # workspace level cu consumption 

# CELL ********************

# Use the pre-aggregated workspace data (without OperationName) to avoid double counting
df_workspace_cu = (
    final_df_workspace
    .groupBy("displayName", "WorkspaceName", "Date2Key")
    .agg(
        F.sum("Total CUs IOD").alias("TotalCUConsumed")
    )
)

# Join with capacity info to get SKU
df_workspace_cu = df_workspace_cu.join(
    df_capacities.select("capacity_displayName", "capacity_sku"),
    df_workspace_cu.displayName == df_capacities.capacity_displayName,
    "left"
).drop("capacity_displayName")

# Join with workspace info to get capacity_id and workspace_id
df_workspace_cu = df_workspace_cu.join(
    df_workspaces,
    df_workspace_cu.WorkspaceName == df_workspaces.workspace_name,
    "left"
).drop("workspace_name")

# Map SKU to numeric CU value
df_workspace_cu = df_workspace_cu.withColumn(
    "capacity_sku_numeric",
    sku_mapping_expr[F.col("capacity_sku")]
)

# Calculate 14-day capacity CU seconds
seconds_in_14_days = 3600 * 24
df_workspace_cu = df_workspace_cu.withColumn(
    "TotalCapacityCuSec",
    F.when(F.col("capacity_sku_numeric").isNotNull(),
           F.col("capacity_sku_numeric") * F.lit(seconds_in_14_days))
    .otherwise(None)
)

# Calculate ConsumptionPercentage at workspace level
df_workspace_cu = df_workspace_cu.withColumn(
    "ConsumptionPercentage",
    F.when(F.col("TotalCapacityCuSec").isNotNull(),
           F.round((F.col("TotalCUConsumed") / F.col("TotalCapacityCuSec")) * 100, 2))
    .otherwise(None)
)

# Calculate HighCUFlag
df_workspace_cu = df_workspace_cu.withColumn(
    "HighCUFlag",
    F.when(F.col("ConsumptionPercentage") > 30, 1).otherwise(0)
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Select and rename columns with Pascal casing
df_workspace_cu_final = df_workspace_cu.select(
    F.col("capacity_id").alias("CapacityId"),
    F.col("displayName").alias("CapacityDisplayName"),
    F.col("workspace_id").alias("WorkspaceId"),
    F.col("WorkspaceName"),
    F.col("Date2Key").alias("DateKey"),
    F.col("TotalCapacityCuSec"),
    F.col("TotalCUConsumed"),
    F.col("ConsumptionPercentage"),
    F.col("HighCUFlag")
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

workspace_table_name = "workspace_level_cu_consumption"

try:
    full_workspace_table_name = f"{TARGET_LAKEHOUSE}.{workspace_table_name}"
    df_workspace_cu_final.write.format("delta").mode("overwrite").saveAsTable(full_workspace_table_name)
    print(f"Table created successfully: {full_workspace_table_name}")
except Exception as e:
    print(f"Method 1 failed: {e}")
    print(f"Trying alternative method...")
    
    try:
        df_workspace_cu_final.write.format("delta").mode("overwrite").saveAsTable(workspace_table_name)
        print(f"Table created successfully: {workspace_table_name}")
    except Exception as e2:
        print(f"Method 2 also failed: {e2}")
        print(f"Trying to save to Tables folder...")
        
        output_path = f"Tables/{workspace_table_name}"
        df_workspace_cu_final.write.format("delta").mode("overwrite").save(output_path)
        print(f"Data saved to: {output_path}")
        print(f"  Now registering as table...")
        spark.sql(f"CREATE TABLE IF NOT EXISTS {workspace_table_name} USING DELTA LOCATION '{output_path}'")
        print(f"Table registered: {workspace_table_name}")

print(f"  Total records: {df_workspace_cu_final.count()}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # Outlier Items Data

# CELL ********************

# Get the date 14 days ago from today
forty_five_days_ago = datetime.now() - timedelta(days=14)
# Generate list of dates for the last 14 days (inclusive)
date_list = [
    (forty_five_days_ago + timedelta(days=i)).strftime("%Y-%m-%d")
    for i in range(15)  # 15 to include today as well
]
# Apply 14-day filter
filters = {
    "'calendar'[Date2Key]": date_list
}
# Evaluate measures with 14-day filters applied
df_total_cus_iod = fabric.evaluate_measure(
    dataset=dataset_name,
    measure="Total CUs IOD",
    groupby_columns=[
        "'calendar'[Date2Key]",
        "'workspaces'[WorkspaceName]",
        "'capacity_metrics_by_item_by_operation_by_day'[ItemKind]",
        "'active_items'[name]"
    ],
    filters=filters,
    workspace=workspace_name 
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Check if data exists before proceeding
if df_total_cus_iod.empty:
    print("No outlier data available for the last 14 days.")
else:
    df_daily_vs_avg_cu = fabric.evaluate_measure(
        dataset=dataset_name,
        measure="Daily CU vs Avg CU IOD OA",
        groupby_columns=[
            "'calendar'[Date2Key]",
            "'workspaces'[WorkspaceName]",
            "'capacity_metrics_by_item_by_operation_by_day'[ItemKind]",
            "'active_items'[name]"
        ],
        filters=filters,
        workspace=workspace_name   
    )
    df_cu_outlier = fabric.evaluate_measure(
        dataset=dataset_name,
        measure="CU Outlier Factor IOD OA",
        groupby_columns=[
            "'calendar'[Date2Key]",
            "'workspaces'[WorkspaceName]",
            "'capacity_metrics_by_item_by_operation_by_day'[ItemKind]",
            "'active_items'[name]"
        ],
        filters=filters,
        workspace=workspace_name  
    )
    
    # Convert to Spark DataFrames
    df_total_cus_iod = spark.createDataFrame(df_total_cus_iod)
    df_daily_vs_avg_cu = spark.createDataFrame(df_daily_vs_avg_cu)
    df_cu_outlier = spark.createDataFrame(df_cu_outlier)
    
    # Join the dataframes
    join_keys_outlier = ['Date2Key', 'WorkspaceName', 'ItemKind', 'name']
    df_outlier_final = df_total_cus_iod.join(df_daily_vs_avg_cu, on=join_keys_outlier, how='left') \
                                       .join(df_cu_outlier, on=join_keys_outlier, how='left')
    
    # Rename columns and order by outlier factor
    df_outlier_final = df_outlier_final.withColumnRenamed("Date2Key", "Date") \
                                       .withColumnRenamed("name", "ItemName") \
                                       .withColumnRenamed("Total CUs IOD", "Total_CUs") \
                                       .withColumnRenamed("Daily CU vs Avg CU IOD OA", "Daily_CU_vs_14d_Avg_CU") \
                                       .withColumnRenamed("CU Outlier Factor IOD OA", "Outlier_Factor") \
                                       .orderBy(F.col("Outlier_Factor").desc())
    
    # Save the table
    table_name = "outlier_items"
    df_outlier_final.write.format("delta").mode("overwrite").saveAsTable(f"{table_name}")
    
    print(f"Outlier data saved to table '{table_name}' successfully.")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# # Get the date 14 days ago from today
# forty_five_days_ago = datetime.now() - timedelta(days=14)

# # Generate list of dates for the last 14 days (inclusive)
# date_list = [
#     (forty_five_days_ago + timedelta(days=i)).strftime("%Y-%m-%d")
#     for i in range(15)  # 15 to include today as well
# ]

# # Apply 14-day filter
# filters = {
#     "'calendar'[Date2Key]": date_list
# }

# # Evaluate measures with 10-day filters applied
# df_total_cus_iod = fabric.evaluate_measure(
#     dataset=dataset_name,
#     measure="Total CUs IOD",
#     groupby_columns=[
#         "'calendar'[Date2Key]",
#         "'workspaces'[WorkspaceName]",
#         "'capacity_metrics_by_item_by_operation_by_day'[ItemKind]",
#         "'active_items'[name]"
#     ],
#     filters=filters,
#     workspace=workspace_name 
# )

# df_daily_vs_avg_cu = fabric.evaluate_measure(
#     dataset=dataset_name,
#     measure="Daily CU vs Avg CU IOD OA",
#     groupby_columns=[
#         "'calendar'[Date2Key]",
#         "'workspaces'[WorkspaceName]",
#         "'capacity_metrics_by_item_by_operation_by_day'[ItemKind]",
#         "'active_items'[name]"
#     ],
#     filters=filters,
#     workspace=workspace_name   
# )

# df_cu_outlier = fabric.evaluate_measure(
#     dataset=dataset_name,
#     measure="CU Outlier Factor IOD OA",
#     groupby_columns=[
#         "'calendar'[Date2Key]",
#         "'workspaces'[WorkspaceName]",
#         "'capacity_metrics_by_item_by_operation_by_day'[ItemKind]",
#         "'active_items'[name]"
#     ],
#     filters=filters,
#     workspace=workspace_name  
# )

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# df_total_cus_iod = spark.createDataFrame(df_total_cus_iod)
# df_daily_vs_avg_cu = spark.createDataFrame(df_daily_vs_avg_cu)
# df_cu_outlier = spark.createDataFrame(df_cu_outlier)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# join_keys_outlier = ['Date2Key', 'WorkspaceName', 'ItemKind', 'name']

# df_outlier_final = df_total_cus_iod.join(df_daily_vs_avg_cu, on=join_keys_outlier, how='left') \
#                                    .join(df_cu_outlier, on=join_keys_outlier, how='left')

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# df_outlier_final = df_outlier_final.withColumnRenamed("Date2Key", "Date") \
#                                    .withColumnRenamed("name", "ItemName") \
#                                    .withColumnRenamed("Total CUs IOD", "Total_CUs") \
#                                    .withColumnRenamed("Daily CU vs Avg CU IOD OA", "Daily_CU_vs_14d_Avg_CU") \
#                                    .withColumnRenamed("CU Outlier Factor IOD OA", "Outlier_Factor") \
#                                    .orderBy(F.col("CU Outlier Factor IOD OA").desc())

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# table_name = "outlier_items"
# df_outlier_final.write.format("delta").mode("overwrite").saveAsTable(f"{table_name}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # sample queries

# CELL ********************

df = spark.sql("SELECT * FROM FabricAdminAgent.dbo.workspace_level_cu_consumption")
display(df)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df = spark.sql("SELECT * FROM FabricAdminAgent.dbo.item_level_cu_consumption")
display(df)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# df = spark.sql("SELECT * FROM FabricAdminAgent.dbo.outlier_items")
# display(df)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

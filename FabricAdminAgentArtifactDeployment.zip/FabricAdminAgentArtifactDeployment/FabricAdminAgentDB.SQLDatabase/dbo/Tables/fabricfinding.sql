CREATE TABLE [dbo].[fabricfinding] (
    [Id]               INT            NOT NULL,
    [Category]         NVARCHAR (MAX) NOT NULL,
    [WorkspaceName]    NVARCHAR (MAX) NULL,
    [CapacityId]       NVARCHAR (MAX) NULL,
    [CapacityName]     NVARCHAR (MAX) NULL,
    [ArtifactName]     NVARCHAR (MAX) NULL,
    [ArtifactType]     NVARCHAR (MAX) NULL,
    [Finding]          NVARCHAR (MAX) NOT NULL,
    [SuggestedActions] NVARCHAR (MAX) NULL,
    [State]            NVARCHAR (MAX) NULL,
    [LastUpdatedAt]    NVARCHAR (MAX) NOT NULL,
    [IsNewFinding]     INT            NOT NULL
);


GO


# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# CELL ********************

from notebookutils import mssparkutils

kustoUri = "https://trd-zfmmx5us1trradc09u.z1.kusto.fabric.microsoft.com"

# return it to parent notebook
mssparkutils.notebook.exit(kustoUri)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

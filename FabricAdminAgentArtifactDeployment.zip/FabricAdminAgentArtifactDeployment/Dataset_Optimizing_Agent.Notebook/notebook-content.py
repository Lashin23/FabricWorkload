# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "b87c684f-6cc7-4782-9ed9-3030b3f58b71",
# META       "default_lakehouse_name": "FabricAdminAgent",
# META       "default_lakehouse_workspace_id": "1ea96d33-ced1-48f0-9098-ed7e13bdc625",
# META       "known_lakehouses": [
# META         {
# META           "id": "b87c684f-6cc7-4782-9ed9-3030b3f58b71"
# META         }
# META       ]
# META     }
# META   }
# META }

# MARKDOWN ********************

# # Imports

# CELL ********************

import requests
from datetime import datetime, timezone
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, lit, trim, lower
from pyspark.sql.types import StructType, StructField, StringType, DoubleType, IntegerType
from azure.keyvault.secrets import SecretClient
from azure.core.credentials import AccessToken
from notebookutils import mssparkutils
import time

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # reading secrets

# CELL ********************

kustoUri = mssparkutils.notebook.run("ConfigNotebook", 60)
print("Received kustoUri:", kustoUri)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark = SparkSession.builder.getOrCreate()
# KUSTO_URI = "https://trd-zfmmx5us1trradc09u.z1.kusto.fabric.microsoft.com"  
KUSTO_URI=kustoUri
KUSTO_DATABASE = "FabricAdminAgentLogs" 
CONFIG_TABLE = "ConfigTable"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# KEY VAULT INTEGRATION
class FabricTokenCredential:
    """Custom credential that uses Fabric's mssparkutils token"""
    def __init__(self):
        self.mssparkutils = mssparkutils
    
    def get_token(self, *scopes, **kwargs):
        """Get token from Fabric for Key Vault"""
        token_str = self.mssparkutils.credentials.getToken("https://vault.azure.net")
        expiry = int(time.time()) + 3600
        return AccessToken(token_str, expiry)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def read_config_from_eventhouse(config_category):
    """Read configuration values from Eventhouse config table"""
    print(f"\nReading configuration for category: {config_category}")
    
    # Query to get specific config category
    kustoQuery = f"['{CONFIG_TABLE}'] | where ConfigCategory == '{config_category}'"
    
    # Get access token for Kusto
    accessToken = mssparkutils.credentials.getToken(KUSTO_URI)
    
    # Read from Eventhouse
    kustoDf = spark.read\
        .format("com.microsoft.kusto.spark.synapse.datasource")\
        .option("accessToken", accessToken)\
        .option("kustoCluster", KUSTO_URI)\
        .option("kustoDatabase", KUSTO_DATABASE)\
        .option("kustoQuery", kustoQuery).load()
    
    # Convert to dictionary for easy lookup
    config_dict = {}
    for row in kustoDf.collect():
        config_key = row['ConfigKey']
        config_value = row['ConfigValue']
        config_dict[config_key] = config_value
        print(f"Found: {config_key} = {config_value}")
    
    return config_dict

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# READ LAKEHOUSE CONFIGURATION FROM EVENTHOUSE
lakehouse_config = read_config_from_eventhouse('FUAMConfig')
WORKSPACE_ID = lakehouse_config.get('WorkspaceId')
LAKEHOUSE_ID = lakehouse_config.get('LakehouseId')

if not all([WORKSPACE_ID, LAKEHOUSE_ID]):
    raise ValueError("WorkspaceId or LakehouseId not found in config table!")

# Construct ABFS paths for all FUAM Lakehouse tables
ABFS_BASE_PATH = f"abfss://{WORKSPACE_ID}@onelake.dfs.fabric.microsoft.com/{LAKEHOUSE_ID}/Tables"

# Define all table paths
TABLE_PATHS = {
    'workspaces': f"{ABFS_BASE_PATH}/workspaces",
    'active_items_history': f"{ABFS_BASE_PATH}/active_items_history",
    # Add other tables as needed
}

print("\n" + "=" * 80)
print("ABFS Paths Configured:")
print("=" * 80)
for table_name, path in TABLE_PATHS.items():
    print(f"{table_name}: {path}")
print("=" * 80)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def get_keyvault_client(vault_name: str) -> SecretClient:
    """Initialize Key Vault client with Fabric token"""
    vault_uri = f"https://{vault_name}.vault.azure.net"
    
    try:
        print(f"\nConnecting to Key Vault: {vault_uri}")
        credential = FabricTokenCredential()
        client = SecretClient(
            vault_url=vault_uri, 
            credential=credential,
            verify_challenge_resource=False)
        
        # Test connection
        secrets_list = list(client.list_properties_of_secrets())
        print(f"Key Vault connected successfully! Found {len(secrets_list)} secrets")
        return client
        
    except Exception as e:
        print(f"Error connecting to Key Vault: {e}")
        raise

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def load_credentials_from_keyvault(kv_client: SecretClient, secret_names: dict) -> dict:
    """Load credentials from Key Vault using secret names from config"""
    print("\n" + "=" * 80)
    print("Loading Credentials from Key Vault")
    print("=" * 80)
    
    credentials = {}
    
    # Map config keys to credential keys
    credential_mapping = {
        'PowerBITenantIdName': 'TENANT_ID',
        'PowerBIClientIdName': 'CLIENT_ID',
        'PowerBIClientSecretName': 'CLIENT_SECRET'
    }
    
    for config_key, credential_key in credential_mapping.items():
        secret_name = secret_names.get(config_key)
        if not secret_name:
            print(f"Secret name not found for {config_key}")
            continue
            
        try:
            print(f"Retrieving secret: {secret_name}")
            secret = kv_client.get_secret(secret_name)
            credentials[credential_key] = secret.value
            print(f"{credential_key} loaded successfully")
        except Exception as e:
            print(f"Error retrieving {secret_name}: {e}")
            raise
    
    print("=" * 80)
    print(f"All credentials loaded successfully ({len(credentials)}/{len(credential_mapping)})")
    print("=" * 80)
    
    return credentials

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# READ CONFIGURATION FROM EVENTHOUSE
print("=" * 80)
print("Reading Configuration from Eventhouse")
print("=" * 80)

# Get Key Vault name from config table
keyvault_config = read_config_from_eventhouse('KeyVault')
KEY_VAULT_NAME = keyvault_config.get('KeyVaultName')

if not KEY_VAULT_NAME:
    raise ValueError("KeyVaultName not found in config table!")

print(f"\nKey Vault Name: {KEY_VAULT_NAME}")

#  Get secret names from config table (also from KeyVault category)
# These are the names of the secrets in Key Vault, not the actual values
SECRET_NAMES = {
    'PowerBITenantIdName': keyvault_config.get('TenantId'),
    'PowerBIClientIdName': keyvault_config.get('ClientId'),
    'PowerBIClientSecretName': keyvault_config.get('ClientSecret')
}

print("\nSecret Names Retrieved:")
for key, value in SECRET_NAMES.items():
    print(f"  - {key}: {value}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# CONNECT TO KEY VAULT
print("\n" + "=" * 80)
print(" Connecting to Key Vault")
print("=" * 80)

kv_client = get_keyvault_client(KEY_VAULT_NAME)

# LOAD CREDENTIALS FROM KEY VAULT
print("\n" + "=" * 80)
print("Loading Credentials from Key Vault")
print("=" * 80)

credentials = load_credentials_from_keyvault(kv_client, SECRET_NAMES)

# Extract credentials
TENANT_ID = credentials.get('TENANT_ID')
CLIENT_ID = credentials.get('CLIENT_ID')
CLIENT_SECRET = credentials.get('CLIENT_SECRET')

# Validate that we have all required credentials
if not all([TENANT_ID, CLIENT_ID, CLIENT_SECRET]):
    raise ValueError("Missing required credentials from Key Vault. Please check configuration.")

print(f"\nConfiguration loaded successfully")
print(f"Tenant ID: {TENANT_ID[:8]}..." if TENANT_ID else "  - Tenant ID: Not found")
print(f"Client ID: {CLIENT_ID[:8]}..." if CLIENT_ID else "  - Client ID: Not found")
print(f"Client Secret: {'*' * 8}...")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # setting up the threshold value

# CELL ********************

# setting the threshold values
try:
    threshold = int(spark.conf.get("threshold", "5"))
except Exception:
    threshold = 5

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # getting auth token

# CELL ********************

# AUTH TOKEN
def get_access_token(tenant_id, client_id, client_secret):
    authority_url = f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token"
    resource = "https://analysis.windows.net/powerbi/api/.default"
    payload = {
        "client_id": client_id,
        "scope": resource,
        "client_secret": client_secret,
        "grant_type": "client_credentials"
    }
    response = requests.post(authority_url, data=payload)
    response.raise_for_status()
    return response.json()["access_token"]

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # fetching datasets

# CELL ********************

# DATASET FETCH
def fetch_datasets(token):
    url = "https://api.powerbi.com/v1.0/myorg/admin/datasets?$top=5000"
    headers = {"Authorization": f"Bearer {token}"}
    response = requests.get(url, headers=headers)
    response.raise_for_status()
    return response.json().get("value", [])

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # fetching refresh history

# CELL ********************

# REFRESH HISTORY FETCH
def fetch_refresh_history(token, workspace_id, dataset_id):
    url = f"https://api.powerbi.com/v1.0/myorg/groups/{workspace_id}/datasets/{dataset_id}/refreshes?$top=10"
    headers = {"Authorization": f"Bearer {token}"}
    response = requests.get(url, headers=headers)
    response.raise_for_status()
    return response.json().get("value", [])

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # analyis and classification

# CELL ********************

# ANALYSIS LOGIC
def analyze_refreshes(refreshes):
    durations = []
    failure_count = 0
    for r in refreshes:
        start, end, status = r.get("startTime"), r.get("endTime"), r.get("status")
        if start and end:
            start_t = datetime.fromisoformat(start.replace("Z", "+00:00"))
            end_t = datetime.fromisoformat(end.replace("Z", "+00:00"))
            durations.append((end_t - start_t).total_seconds() / 60)
        if status == "Failed":
            failure_count += 1

    if not durations:
        return 0.0, 0, failure_count, "No Trend Data"

    # Average duration and threshold analysis
    avg_duration = round(sum(durations) / len(durations), 2)
    slow_count = len([d for d in durations if d > threshold])  # Threshold: 5 min

    # Trend analysis
    half = len(durations) // 2
    early_avg = sum(durations[:half]) / half if half else avg_duration
    recent_avg = sum(durations[-half:]) / half if half else avg_duration

    if recent_avg > early_avg * 1.2:
        trend = "Getting Slower"
    elif recent_avg < early_avg * 0.8:
        trend = "Getting Faster"
    else:
        trend = "Stable"

    return avg_duration, slow_count, failure_count, trend

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAIN EXECUTION
print("\n" + "=" * 80)
print("Starting Power BI Dataset Refresh Analysis")
print("=" * 80)

token = get_access_token(TENANT_ID, CLIENT_ID, CLIENT_SECRET)
print("Access token generated successfully")

datasets = fetch_datasets(token)
print(f"Retrieved {len(datasets)} datasets")

results = []

for idx, dataset in enumerate(datasets, 1):
    dataset_name = dataset.get("name")
    workspace_id = dataset.get("workspaceId")
    dataset_id = dataset.get("id")

    try:
        refreshes = fetch_refresh_history(token, workspace_id, dataset_id)
    except Exception:
        continue

    if not refreshes:
        avg_duration, slow_count, fail_count, trend = 0.0, 0, 0, "No Data"
        status = "Need to be Refreshed"
        is_last_15 = is_last_30 = is_last_60 = "0"
    else:
        avg_duration, slow_count, fail_count, trend = analyze_refreshes(refreshes)
        status = "Slow" if avg_duration > 1 or slow_count > 0 else "Healthy"

        # Calculate last refresh date difference
        end_times = [
            datetime.fromisoformat(r["endTime"].replace("Z", "+00:00"))
            for r in refreshes if "endTime" in r and r["endTime"]
        ]
        if end_times:
            latest_refresh = max(end_times)
            now = datetime.now(timezone.utc)
            days_diff = (now - latest_refresh).days
            is_last_15 = "1" if days_diff <= 15 else "0"
            is_last_30 = "1" if days_diff <= 30 else "0"
            is_last_60 = "1" if days_diff <= 60 else "0"
        else:
            is_last_15 = is_last_30 = is_last_60 = "0"

    results.append({
        "Dataset_Name": dataset_name,
        "Dataset_Id": dataset_id,
        "Workspace_Id": workspace_id,
        "Avg_Refresh_Duration_min": float(avg_duration),
        "Slow_Refresh_Count": int(slow_count),
        "Failure_Count": int(fail_count),
        "Trend": trend,
        "Status": status,
        "IsLast15Days": is_last_15,
        "IsLast30Days": is_last_30,
        "IsLast60Days": is_last_60
    })

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # saving the results to lakehouse table

# CELL ********************

# Define schema for the DataFrame 
schema = StructType([
    StructField("Dataset_Name", StringType(), True),
    StructField("Dataset_Id", StringType(), True),
    StructField("Workspace_Id", StringType(), True),
    StructField("Avg_Refresh_Duration_min", DoubleType(), True),
    StructField("Slow_Refresh_Count", IntegerType(), True),
    StructField("Failure_Count", IntegerType(), True),
    StructField("Trend", StringType(), True),
    StructField("Status", StringType(), True),
    StructField("IsLast15Days", StringType(), True),
    StructField("IsLast30Days", StringType(), True),
    StructField("IsLast60Days", StringType(), True)
])

# Create Spark DataFrame directly from the results list
df_spark = spark.createDataFrame(results, schema=schema)

# Read FUAM Lakehouse table and prepare normalized join keys
try:
    df_ws = spark.read.format("delta").load(TABLE_PATHS['workspaces']).select(
        col("WorkspaceId").cast(StringType()).alias("WorkspaceId"),
        col("WorkspaceName").alias("WorkspaceName")
    )
    # normalize join keys (trim + lower) to avoid formatting mismatches
    df_left = df_spark.withColumn("_wk_left", lower(trim(col("Workspace_Id"))))
    df_right = df_ws.withColumn("_wk_right", lower(trim(col("WorkspaceId"))))

    df_final = df_left.join(df_right, df_left._wk_left == df_right._wk_right, how="left") \
                      .drop(df_right.WorkspaceId) \
                      .drop("_wk_left", "_wk_right")

    # Ensure final column name is WorkspaceName and not duplicated
    if "Workspace_Name" in df_final.columns:
        df_final = df_final.drop("Workspace_Name")

    print("Joined with FUAM_Lakehouse.workspaces")
except Exception as e:
    print(f"Could not read FUAM_Lakehouse.workspaces: {e}")
    df_final = df_spark.withColumn("WorkspaceName", lit(None).cast(StringType()))

# Drop the existing table if it exists to avoid schema conflicts
spark.sql("DROP TABLE IF EXISTS dbo.datasetrefreshanalysis")

# Write to table
df_final.write.mode("overwrite").saveAsTable("dbo.datasetrefreshanalysis")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # sample queries

# CELL ********************

df = spark.sql("SELECT * FROM FabricAdminAgent.dbo.datasetrefreshanalysis")
display(df)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

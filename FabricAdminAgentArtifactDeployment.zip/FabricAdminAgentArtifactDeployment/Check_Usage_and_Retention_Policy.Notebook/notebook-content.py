# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "b87c684f-6cc7-4782-9ed9-3030b3f58b71",
# META       "default_lakehouse_name": "FabricAdminAgent",
# META       "default_lakehouse_workspace_id": "1ea96d33-ced1-48f0-9098-ed7e13bdc625",
# META       "known_lakehouses": [
# META         {
# META           "id": "b87c684f-6cc7-4782-9ed9-3030b3f58b71"
# META         }
# META       ]
# META     }
# META   }
# META }

# MARKDOWN ********************

# # Imports

# CELL ********************

import json
import os
import time
import traceback
from datetime import datetime, timedelta
from typing import Dict, List, Optional
import requests
from azure.core.credentials import AccessToken
from azure.keyvault.secrets import SecretClient
from pyspark.sql import SparkSession, functions as F
from pyspark.sql.types import (
    BooleanType,
    IntegerType,
    LongType,
    StringType,
    StructField,
    StructType,
    TimestampType
)
from notebookutils import mssparkutils


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # Configuration

# CELL ********************

kustoUri = mssparkutils.notebook.run("ConfigNotebook", 60)
print("Received kustoUri:", kustoUri)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# =============================================
# EVENTHOUSE CONFIGURATION
# =============================================
# KUSTO_URI = "https://trd-zfmmx5us1trradc09u.z1.kusto.fabric.microsoft.com"
KUSTO_URI= kustoUri
KUSTO_DATABASE = "FabricAdminAgentLogs"
CONFIG_TABLE = "ConfigTable"
CONFIG_KEYS = {
    'KEY_VAULT_NAME': ('KeyVault', 'KeyVaultName'),
    'CLIENT_ID_SECRET': ('KeyVault', 'ClientId'),
    'CLIENT_SECRET_SECRET': ('KeyVault', 'ClientSecret'),
    'TENANT_ID_SECRET': ('KeyVault', 'TenantId'),
    'LAKEHOUSE_NAME': ('FUAMConfig', 'LakehouseName'),
    'WORKSPACE_ID': ('FUAMConfig', 'WorkspaceId'),       
    'LAKEHOUSE_ID': ('FUAMConfig', 'LakehouseId')         
}

LAKEHOUSE_NAME = None
BATCH_SIZE = 100 
MAX_RETRIES = 2
RETRY_WAIT_SECONDS = 5

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# =============================================
# ABFS PATH CONFIGURATION
# =============================================
def construct_abfs_paths(config: Dict[str, str]) -> Dict[str, str]:
    """Construct ABFS paths for all FUAM tables using config"""
    
    workspace_id = config.get('WORKSPACE_ID')
    lakehouse_id = config.get('LAKEHOUSE_ID')
    
    if not workspace_id or not lakehouse_id:
        raise ValueError("WORKSPACE_ID and LAKEHOUSE_ID must be present in config")
    
    base_path = f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}/Tables"
    
    abfs_paths = {
        'activities': f"{base_path}/activities",
        'capacities': f"{base_path}/capacities",
        'workspaces': f"{base_path}/workspaces",
    }
    
    print("\n" + "=" * 80)
    print("ABFS Paths Constructed")
    print("=" * 80)
    for table_name, path in abfs_paths.items():
        print(f"  {table_name}: {path}")
    print("=" * 80)
    
    return abfs_paths

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # Schema for tables

# CELL ********************

DATASETS_SCHEMA = StructType([
    StructField("WorkspaceId", StringType(), True),
    StructField("WorkspaceName", StringType(), True),
    StructField("DatasetId", StringType(), True),
    StructField("DatasetName", StringType(), True),
    StructField("CapacityId", StringType(), True),
    StructField("CapacityName", StringType(), True),
    StructField("ContentProviderType", StringType(), True),
    StructField("RefreshEnabled", BooleanType(), True),
    StructField("UsageLast30Days", LongType(), True),  
    StructField("UsageLast60Days", LongType(), True),   
    StructField("UsageLast90Days", LongType(), True),   
    StructField("IsOrphan", BooleanType(), True),
    StructField("IsUnused", BooleanType(), True)
])

REPORTS_SCHEMA = StructType([
    StructField("WorkspaceId", StringType(), True),
    StructField("WorkspaceName", StringType(), True),
    StructField("ReportId", StringType(), True),
    StructField("ReportName", StringType(), True),
    StructField("CapacityId", StringType(), True),
    StructField("CapacityName", StringType(), True),
    StructField("ModifiedDateTime", StringType(), True),
    StructField("users", StringType(), True),            
    StructField("ReportType", StringType(), True),
    StructField("UsageLast30Days", LongType(), True),   
    StructField("UsageLast60Days", LongType(), True),    
    StructField("UsageLast90Days", LongType(), True),    
    StructField("IsOrphan", BooleanType(), True),
    StructField("IsUnused", BooleanType(), True)
])

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # Eventhouse integraion

# CELL ********************

# =============================================
# EVENTHOUSE CONFIG INTEGRATION
# =============================================
def load_config_from_eventhouse(spark: SparkSession) -> Dict[str, str]:
    """Load configuration from Eventhouse Kusto database"""
    print("\n" + "=" * 80)
    print("Loading Configuration from Eventhouse")
    print("=" * 80)
    print(f"Kusto URI: {KUSTO_URI}")
    print(f"Database: {KUSTO_DATABASE}")
    print(f"Table: {CONFIG_TABLE}")
    
    try:
        # Get access token for Kusto
        access_token = mssparkutils.credentials.getToken(KUSTO_URI)
        
        # Query to fetch all required config values (KeyVault AND FUAMConfig)
        kusto_query = f"{CONFIG_TABLE} | where ConfigCategory in ('KeyVault', 'FUAMConfig') and IsActive == true"
        
        # Read from Kusto
        config_df = spark.read\
            .format("com.microsoft.kusto.spark.synapse.datasource")\
            .option("accessToken", access_token)\
            .option("kustoCluster", KUSTO_URI)\
            .option("kustoDatabase", KUSTO_DATABASE)\
            .option("kustoQuery", kusto_query)\
            .load()
        
        print(f"\nConnected to Eventhouse successfully!")
        
        # Convert to dictionary for easy lookup
        config_data = {}
        config_rows = config_df.collect()
        
        print(f"Retrieved {len(config_rows)} configuration entries")
        print("\nConfiguration Entries:")
        
        for row in config_rows:
            category = row['ConfigCategory']
            key = row['ConfigKey']
            value = row['ConfigValue']
            config_data[(category, key)] = value
            print(f"  → {category} | {key}: {value}")
        
        # Extract specific configuration values
        configuration = {}
        
        # Get Key Vault name (required)
        kv_key = CONFIG_KEYS['KEY_VAULT_NAME']
        if kv_key in config_data:
            configuration['KEY_VAULT_NAME'] = config_data[kv_key]
            print(f"\n✓ Key Vault Name: {configuration['KEY_VAULT_NAME']}")
        else:
            raise ValueError(f"Key Vault name not found in config (Category: {kv_key[0]}, Key: {kv_key[1]})")
        
        # Get secret names for each credential (required)
        for config_key in ['CLIENT_ID_SECRET', 'CLIENT_SECRET_SECRET', 'TENANT_ID_SECRET']:
            category, key = CONFIG_KEYS[config_key]
            
            if (category, key) in config_data:
                configuration[config_key] = config_data[(category, key)]
                print(f"✓ Secret Name for {config_key}: {configuration[config_key]}")
            else:
                raise ValueError(f"Configuration not found: Category={category}, Key={key}")
        
        # Get Lakehouse name (required)
        lakehouse_key = CONFIG_KEYS['LAKEHOUSE_NAME']
        if lakehouse_key in config_data:
            configuration['LAKEHOUSE_NAME'] = config_data[lakehouse_key]
            print(f"\n✓ Lakehouse Name: {configuration['LAKEHOUSE_NAME']}")
            
            # Update global variable
            global LAKEHOUSE_NAME
            LAKEHOUSE_NAME = configuration['LAKEHOUSE_NAME']
        else:
            print(f"⚠ Warning: Lakehouse name not found, using default: FabricAdminAgent")
            configuration['LAKEHOUSE_NAME'] = "FabricAdminAgent"
            LAKEHOUSE_NAME = "FabricAdminAgent"
            
        # Get Workspace ID (required for ABFS paths)
        workspace_id_key = CONFIG_KEYS['WORKSPACE_ID']
        if workspace_id_key in config_data:
            configuration['WORKSPACE_ID'] = config_data[workspace_id_key]
            print(f"✓ Workspace ID: {configuration['WORKSPACE_ID']}")
        else:
            raise ValueError(f"Workspace ID not found in config (Category: {workspace_id_key[0]}, Key: {workspace_id_key[1]})")
        
        # Get Lakehouse ID (required for ABFS paths)
        lakehouse_id_key = CONFIG_KEYS['LAKEHOUSE_ID']
        if lakehouse_id_key in config_data:
            configuration['LAKEHOUSE_ID'] = config_data[lakehouse_id_key]
            print(f"✓ Lakehouse ID: {configuration['LAKEHOUSE_ID']}")
        else:
            raise ValueError(f"Lakehouse ID not found in config (Category: {lakehouse_id_key[0]}, Key: {lakehouse_id_key[1]})")

        # Get optional FUAMConfig values
        optional_keys = ['WORKSPACE_ID', 'WORKSPACE_NAME', 'DATASET_NAME', 'SQL_DATABASE_NAME']
        for config_key in optional_keys:
            if config_key in CONFIG_KEYS:
                category, key = CONFIG_KEYS[config_key]
                if (category, key) in config_data:
                    configuration[config_key] = config_data[(category, key)]
                    print(f"✓ {config_key}: {configuration[config_key]}")
        
        print("=" * 80)
        print(f"All configuration loaded successfully ({len(configuration)} entries)")
        print("=" * 80)
        
        return configuration
        
    except Exception as e:
        print(f"Error loading configuration from Eventhouse: {e}")
        import traceback
        traceback.print_exc()
        raise

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # Key Vault Integration

# CELL ********************

class FabricTokenCredential:
    """Custom credential that uses Fabric's mssparkutils token"""
    def __init__(self):
        self.mssparkutils = mssparkutils
    
    def get_token(self, *scopes, **kwargs):
        """Get token from Fabric for Key Vault"""
        token_str = self.mssparkutils.credentials.getToken("https://vault.azure.net")
        expiry = int(time.time()) + 3600
        return AccessToken(token_str, expiry)


def get_keyvault_client(vault_uri: str) -> SecretClient:
    """Initialize Key Vault client with Fabric token"""
    try:
        print(f"Connecting to Key Vault: {vault_uri}")
        credential = FabricTokenCredential()
        client = SecretClient(
        vault_url=vault_uri, 
        credential=credential,
        verify_challenge_resource=False
        )
        
        # Test connection
        secrets_list = list(client.list_properties_of_secrets())
        print(f"Key Vault connected successfully! Found {len(secrets_list)} secrets")
        return client
        
    except Exception as e:
        print(f"Error connecting to Key Vault: {e}")
        raise


def load_credentials_from_keyvault(kv_client: SecretClient, secret_names: Dict[str, str]) -> Dict[str, str]:
    """Load all credentials from Key Vault using secret names from config"""
    print("\n" + "=" * 80)
    print("Loading Credentials from Key Vault")
    print("=" * 80)
    
    credentials = {}
    
    # Map config keys to credential keys
    credential_mapping = {
        'CLIENT_ID_SECRET': 'CLIENT_ID',
        'CLIENT_SECRET_SECRET': 'CLIENT_SECRET',
        'TENANT_ID_SECRET': 'TENANT_ID'
    }
    
    for config_key, credential_key in credential_mapping.items():
        secret_name = secret_names.get(config_key)
        if not secret_name:
            raise ValueError(f"Secret name not found for {config_key}")
        
        try:
            print(f"  Retrieving: {secret_name} (for {credential_key})")
            secret = kv_client.get_secret(secret_name)
            credentials[credential_key] = secret.value
            print(f"  {credential_key} loaded successfully")
        except Exception as e:
            print(f"  Error retrieving {secret_name}: {e}")
            raise
    
    print("=" * 80)
    print(f"All credentials loaded successfully ({len(credentials)}/{len(credential_mapping)})")
    print("=" * 80)
    
    return credentials

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # generating access token

# CELL ********************

def generate_access_token(tenant_id: str, client_id: str, client_secret: str) -> Optional[str]:
    """Generate OAuth 2.0 access token for Power BI API"""
    token_url = f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token"
    
    token_data = {
        'grant_type': 'client_credentials',
        'client_id': client_id,
        'client_secret': client_secret,
        'scope': 'https://analysis.windows.net/powerbi/api/.default'
    }
    
    try:
        print("\n" + "=" * 80)
        print("Generating Access Token...")
        response = requests.post(token_url, data=token_data, timeout=30)
        response.raise_for_status()
        
        token = response.json()['access_token']
        print("Access Token Generated Successfully!")
        print("=" * 80)
        return token
    
    except requests.exceptions.RequestException as e:
        print(f"Error generating token: {e}")
        if hasattr(e.response, 'text'):
            print(f"Response: {e.response.text}")
        return None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# #  get list of all workspaces API


# CELL ********************

def get_all_workspaces(access_token: str) -> Optional[List[Dict]]:
    """Fetch all workspaces using Fabric API"""
    workspaces_url = "https://api.fabric.microsoft.com/v1/workspaces"
    
    headers = {
        'Authorization': f'Bearer {access_token}',
        'Content-Type': 'application/json'
    }
    
    try:
        print(f"\n{'=' * 80}")
        print("Fetching All Workspaces from Fabric API...")
        print("=" * 80)
        
        response = requests.get(workspaces_url, headers=headers, timeout=30)
        response.raise_for_status()
        
        workspaces_data = response.json()
        workspaces = workspaces_data.get('value', [])
        
        print(f"Retrieved {len(workspaces)} workspaces")
        
        # Display workspace summary
        workspace_types = {}
        capacities = set()
        
        for ws in workspaces:
            ws_type = ws.get('type', 'Unknown')
            workspace_types[ws_type] = workspace_types.get(ws_type, 0) + 1
            
            if 'capacityId' in ws:
                capacities.add(ws['capacityId'])
        
        print(f"\nWorkspace Summary:")
        for ws_type, count in workspace_types.items():
            print(f"  - {ws_type}: {count}")
        print(f"  - Unique Capacities: {len(capacities)}")
        
        # Show first few workspaces
        print(f"\nSample Workspaces:")
        for ws in workspaces[:5]:
            print(f"  - {ws.get('displayName', 'N/A')} (ID: {ws.get('id', 'N/A')})")
        
        if len(workspaces) > 5:
            print(f"  ... and {len(workspaces) - 5} more")
        
        print("=" * 80)
        
        return workspaces
    
    except requests.exceptions.RequestException as e:
        print(f"Error fetching workspaces: {e}")
        if hasattr(e, 'response') and e.response is not None:
            print(f"Response: {e.response.text}")
        return None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # getting scan Id

# CELL ********************

def initiate_workspace_scan_batch(access_token: str, workspace_ids: List[str]) -> Optional[str]:
    """Initiate a workspace scan for multiple workspaces using Power BI Admin API"""
    scan_url = "https://api.powerbi.com/v1.0/myorg/admin/workspaces/getInfo"
    
    headers = {
        'Authorization': f'Bearer {access_token}',
        'Content-Type': 'application/json'
    }
    
    scan_body = {
        "workspaces": workspace_ids,
        "datasetExpressions": True,
        "datasetSchema": True,
        "datasourceDetails": True,
        "getArtifactUsers": True,
        "lineage": True
    }
    
    try:
        print(f"\nInitiating Workspace Scan for {len(workspace_ids)} workspaces...")
        response = requests.post(scan_url, headers=headers, json=scan_body, timeout=30)
        response.raise_for_status()
        
        scan_id = response.json()['id']
        print(f"Scan Initiated! Scan ID: {scan_id}")
        return scan_id
    
    except requests.exceptions.RequestException as e:
        print(f"Error initiating scan: {e}")
        if hasattr(e, 'response') and e.response is not None:
            print(f"Response: {e.response.text}")
        return None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # getting scan results

# CELL ********************

def get_scan_results(access_token: str, scan_id: str, max_retries: int = MAX_RETRIES, 
                     wait_seconds: int = RETRY_WAIT_SECONDS) -> Optional[Dict]:
    """Retrieve scan results with retry logic"""
    if not scan_id or str(scan_id).strip().lower() in ("none", "", "null"):
        print("Skipping scan result retrieval — scan_id is None (possibly due to a failed scan initiation).")
        return None

    result_url = f"https://api.powerbi.com/v1.0/myorg/admin/workspaces/scanResult/{scan_id}"

    headers = {
        'Authorization': f'Bearer {access_token}'
    }
    
    print(f"\nFetching Scan Results (Scan ID: {scan_id})...")
    
    for attempt in range(1, max_retries + 1):
        try:
            response = requests.get(result_url, headers=headers, timeout=30)
            
            if response.status_code == 200:
                print(f"Scan Results Retrieved Successfully!")
                return response.json()
            
            elif response.status_code == 202:
                print(f"Scan in progress... (Attempt {attempt}/{max_retries})")
                time.sleep(wait_seconds)
            
            else:
                response.raise_for_status()
        
        except requests.exceptions.RequestException as e:
            print(f"Error retrieving results (Attempt {attempt}): {e}")
            if attempt < max_retries:
                time.sleep(wait_seconds)
    
    print("✗ Failed to retrieve scan results after all retries")
    return None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # capacity mapping 

# CELL ********************

def get_capacity_mapping(spark: SparkSession, abfs_paths: Dict[str, str]) -> Dict[str, str]:
    """Get CapacityId to DisplayName mapping from capacities table using ABFS path"""
    print("\n" + "=" * 80)
    print("Loading Capacity Name Mapping")
    print("=" * 80)
    print(f"ABFS Path: {abfs_paths['capacities']}")
    
    try:
        # Read from ABFS path
        capacity_df = spark.read.format("delta").load(abfs_paths['capacities'])
        
        # Create temporary view for querying
        capacity_df.createOrReplaceTempView("temp_capacities")
        
        capacity_query = """
        SELECT DISTINCT
            CapacityId,
            displayName AS CapacityName
        FROM temp_capacities
        WHERE CapacityId IS NOT NULL
        """
        
        capacity_result_df = spark.sql(capacity_query)
        capacity_rows = capacity_result_df.collect()
        
        # Create mapping dictionary
        capacity_mapping = {}
        for row in capacity_rows:
            capacity_id = row['CapacityId']
            capacity_name = row['CapacityName']
            if capacity_id and capacity_name:
                capacity_mapping[capacity_id] = capacity_name
        
        print(f"Retrieved {len(capacity_mapping)} capacity mappings")
        
        # Show sample mappings
        print(f"\nSample Capacity Mappings:")
        for idx, (cap_id, cap_name) in enumerate(list(capacity_mapping.items())[:5]):
            print(f"  - {cap_id}: {cap_name}")
        
        if len(capacity_mapping) > 5:
            print(f"  ... and {len(capacity_mapping) - 5} more")
        
        print("=" * 80)
        
        return capacity_mapping
        
    except Exception as e:
        print(f"Warning: Could not retrieve capacity mapping: {e}")
        print("Continuing with empty capacity mapping...")
        import traceback
        traceback.print_exc()
        return {}

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # getting usage data 

# CELL ********************

def get_activity_based_usage(spark: SparkSession, abfs_paths: Dict[str, str]) -> Dict[str, any]:
    """Get comprehensive usage data from activities table using ABFS path"""
    print("\n" + "=" * 80)
    print("Retrieving Activity-Based Usage Data")
    print("=" * 80)
    print(f"ABFS Path: {abfs_paths['activities']}")
    
    try:
        # Read activities from ABFS path
        activities_df = spark.read.format("delta").load(abfs_paths['activities'])
        activities_df.createOrReplaceTempView("temp_activities")
        
        # Get report usage
        report_usage_query = """
        WITH LatestActivity AS (
            SELECT
                A.WorkspaceName,
                A.ReportName,
                MAX(A.CreationDate) AS LatestCreationDate
            FROM temp_activities A
            WHERE
                A.CreationDate >= DATE_SUB(current_date(), 90)
                AND A.ArtifactKind = 'Report'
                AND A.WorkspaceName IS NOT NULL
                AND A.ReportName IS NOT NULL
            GROUP BY A.WorkspaceName, A.ReportName
        )
        SELECT
            WorkspaceName,
            ReportName,
            LatestCreationDate,
            CASE WHEN DATEDIFF(current_date(), LatestCreationDate) <= 30 THEN 1 ELSE 0 END AS UsageLast30Days,
            CASE WHEN DATEDIFF(current_date(), LatestCreationDate) <= 60 THEN 1 ELSE 0 END AS UsageLast60Days,
            CASE WHEN DATEDIFF(current_date(), LatestCreationDate) <= 90 THEN 1 ELSE 0 END AS UsageLast90Days
        FROM LatestActivity
        """
        
        report_usage_df = spark.sql(report_usage_query)
        report_usage_data = report_usage_df.collect()
        
        # Convert to dictionary
        report_usage = {}
        for row in report_usage_data:
            workspace_name = row['WorkspaceName']
            report_name = row['ReportName']
            key = (workspace_name, report_name)
            
            report_usage[key] = {
                'UsageLast30Days': row['UsageLast30Days'],
                'UsageLast60Days': row['UsageLast60Days'],
                'UsageLast90Days': row['UsageLast90Days'],
                'LatestCreationDate': row['LatestCreationDate']
            }
        
        print(f"✓ Retrieved usage for {len(report_usage)} reports from activities")
        
        # Get dataset usage
        dataset_usage_query = """
        WITH LatestActivity AS (
            SELECT
                A.WorkspaceName,
                A.DatasetName,
                MAX(A.CreationDate) AS LatestCreationDate
            FROM temp_activities A
            WHERE
                A.CreationDate >= DATE_SUB(current_date(), 90)
                AND A.ArtifactKind = 'Dataset'
                AND A.WorkspaceName IS NOT NULL
                AND A.DatasetName IS NOT NULL
            GROUP BY A.WorkspaceName, A.DatasetName
        )
        SELECT
            WorkspaceName,
            DatasetName,
            LatestCreationDate,
            CASE WHEN DATEDIFF(current_date(), LatestCreationDate) <= 30 THEN 1 ELSE 0 END AS UsageLast30Days,
            CASE WHEN DATEDIFF(current_date(), LatestCreationDate) <= 60 THEN 1 ELSE 0 END AS UsageLast60Days,
            CASE WHEN DATEDIFF(current_date(), LatestCreationDate) <= 90 THEN 1 ELSE 0 END AS UsageLast90Days
        FROM LatestActivity
        """
        
        dataset_usage_df = spark.sql(dataset_usage_query)
        dataset_usage_data = dataset_usage_df.collect()
        
        # Convert to dictionary
        dataset_usage = {}
        for row in dataset_usage_data:
            workspace_name = row['WorkspaceName']
            dataset_name = row['DatasetName']
            key = (workspace_name, dataset_name)
            
            dataset_usage[key] = {
                'UsageLast30Days': row['UsageLast30Days'],
                'UsageLast60Days': row['UsageLast60Days'],
                'UsageLast90Days': row['UsageLast90Days'],
                'LatestCreationDate': row['LatestCreationDate']
            }
        
        print(f"✓ Retrieved usage for {len(dataset_usage)} datasets from activities")
        print("=" * 80)
        
        return {
            'reports': report_usage,
            'datasets': dataset_usage
        }
        
    except Exception as e:
        print(f"Warning: Could not retrieve usage data: {e}")
        print("Continuing with empty usage data...")
        import traceback
        traceback.print_exc()
        return {
            'reports': {},
            'datasets': {}
        }

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # processing reports

# CELL ********************

def process_reports(workspace_data: Dict, usage_data: Dict, capacity_mapping: Dict) -> List[Dict]:
    """
    Processes report metadata from workspace scan results and identifies orphan reports.
    A report is considered orphan if it lacks valid ownership information (i.e., missing 'modifiedBy' or 'modifiedById').
    The function enriches each report entry with workspace and capacity details, ensuring consistent schema for Lakehouse output.
    """
    
    reports_data = []
    workspace_id = workspace_data.get('id', '')
    workspace_name = workspace_data.get('name', 'N/A')
    capacity_id = workspace_data.get('capacityId', 'N/A')
    
    # Get capacity name from mapping
    capacity_name = capacity_mapping.get(capacity_id, 'N/A') if capacity_id != 'N/A' else 'N/A'
    
    # Process reports from scan
    for report in workspace_data.get('reports', []):
        report_id = report.get('id', 'N/A')
        report_name = report.get('name', 'N/A') or 'N/A'
        
        # Check if orphan (no dataset association or missing metadata)
        is_orphan = not report.get('datasetId') or 'modifiedBy' not in report
        
        # Get usage data from activities using (WorkspaceName, ReportName) as key
        lookup_key = (workspace_name, report_name)
        usage = usage_data.get(lookup_key, {
            'UsageLast30Days': 0,
            'UsageLast60Days': 0,
            'UsageLast90Days': 0
        })
        
        usage_30 = usage.get('UsageLast30Days', 0)
        usage_60 = usage.get('UsageLast60Days', 0)
        usage_90 = usage.get('UsageLast90Days', 0)
        
        # Unused if no usage in last 90 days
        is_unused = (usage_90 == 0)
        
        # CRITICAL FIX: Keep ModifiedDateTime as string, don't convert to datetime object
        # The API returns format like: "2025-09-04T10:31:00.650Z"
        # We just need to clean it up to a readable format
        modified_datetime_str = None
        if 'modifiedDateTime' in report and report['modifiedDateTime']:
            try:
                raw_datetime = report['modifiedDateTime']
                # Simple string manipulation - don't create datetime object
                # Convert "2025-09-04T10:31:00.650Z" to "2025-09-04 10:31:00"
                if 'T' in raw_datetime:
                    # Split on 'T' to separate date and time
                    date_part = raw_datetime.split('T')[0]
                    time_part = raw_datetime.split('T')[1]
                    # Remove 'Z' and milliseconds
                    time_part = time_part.replace('Z', '').split('.')[0]
                    # Combine with space
                    modified_datetime_str = f"{date_part} {time_part}"
                else:
                    # If format is different, just use as-is
                    modified_datetime_str = raw_datetime.replace('Z', '')
            except Exception as e:
                print(f"Warning: Could not format modifiedDateTime '{report.get('modifiedDateTime')}' for report {report_name}: {e}")
                # If all else fails, just use the raw value without the 'Z'
                modified_datetime_str = report.get('modifiedDateTime', '').replace('Z', '')
        
        users = json.dumps(report.get('users', []))
        
        report_record = {
            "WorkspaceId": workspace_id,
            "WorkspaceName": workspace_name,
            "ReportId": report_id,
            "ReportName": report_name,
            "CapacityId": capacity_id,
            "CapacityName": capacity_name,
            "ModifiedDateTime": modified_datetime_str,  # Pure string, no datetime object
            "Users": users,
            "ReportType": report.get('reportType', 'N/A'),
            "UsageLast30Days": usage_30,
            "UsageLast60Days": usage_60,
            "UsageLast90Days": usage_90,
            "IsOrphan": is_orphan,
            "IsUnused": is_unused
        }
        
        reports_data.append(report_record)
    
    return reports_data

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # processing datasets

# CELL ********************

def process_datasets(workspace_data: Dict, usage_data: Dict, capacity_mapping: Dict) -> List[Dict]:
    """Process datasets with usage data and identify orphans"""
    
    datasets_data = []
    workspace_id = workspace_data.get('id', '')
    workspace_name = workspace_data.get('name', 'N/A')
    capacity_id = workspace_data.get('capacityId', 'N/A')
    
    # Get capacity name from mapping
    capacity_name = capacity_mapping.get(capacity_id, 'N/A') if capacity_id != 'N/A' else 'N/A'
    
    # Process datasets from scan
    for dataset in workspace_data.get('datasets', []):
        dataset_id = dataset.get('id', 'N/A')
        dataset_name = dataset.get('name', 'N/A') or 'N/A'
        
        # Check if orphan (missing owner/configured by info)
        is_orphan = 'configuredBy' not in dataset or 'configuredById' not in dataset
        
        # Get usage data from activities using (WorkspaceName, DatasetName) as key
        lookup_key = (workspace_name, dataset_name)
        usage = usage_data.get(lookup_key, {
            'UsageLast30Days': 0,
            'UsageLast60Days': 0,
            'UsageLast90Days': 0
        })
        
        usage_30 = usage.get('UsageLast30Days', 0)
        usage_60 = usage.get('UsageLast60Days', 0)
        usage_90 = usage.get('UsageLast90Days', 0)
        
        # Unused if no usage in last 30 days
        # is_unused = (usage_30 == 0)
        is_unused = (usage_90 == 0)
        
        # Get refresh info
        refresh_enabled = False
        if 'refreshSchedule' in dataset:
            refresh_enabled = dataset['refreshSchedule'].get('enabled', False)
        
        dataset_record = {
            "WorkspaceId": workspace_id,
            "WorkspaceName": workspace_name,
            "DatasetId": dataset_id,
            "DatasetName": dataset_name,
            "CapacityId": capacity_id,
            "CapacityName": capacity_name,
            "ContentProviderType": dataset.get('contentProviderType', 'N/A'),
            "RefreshEnabled": refresh_enabled,
            "UsageLast30Days": usage_30,
            "UsageLast60Days": usage_60,
            "UsageLast90Days": usage_90,
            "IsOrphan": is_orphan,
            "IsUnused": is_unused
        }
        
        datasets_data.append(dataset_record)
    
    return datasets_data

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # appending activity log for non spn enabled workspaces

# CELL ********************

def append_activity_only_artifacts(existing_reports: List[Dict], existing_datasets: List[Dict], 
                                   usage_data: Dict, capacity_mapping: Dict) -> tuple:
    """
    Append artifacts that exist in activities table but were not found in workspace scans.
    This captures reports/datasets from non-SPM workspaces that have usage but no scan data.
    """
    print(f"\n{'=' * 80}")
    print("Checking for Activity-Only Artifacts (Non-SPM Workspaces)")
    print("=" * 80)
    
    # Build sets of already processed artifacts from scan results
    scanned_reports = set()
    scanned_datasets = set()
    
    for report in existing_reports:
        key = (report['WorkspaceName'], report['ReportName'])
        scanned_reports.add(key)
    
    for dataset in existing_datasets:
        key = (dataset['WorkspaceName'], dataset['DatasetName'])
        scanned_datasets.add(key)
    
    print(f"Already scanned reports: {len(scanned_reports)}")
    print(f"Already scanned datasets: {len(scanned_datasets)}")
    
    # Find reports in activities that weren't in scan
    activity_only_reports = []
    for (workspace_name, report_name), usage in usage_data['reports'].items():
        key = (workspace_name, report_name)
        if key not in scanned_reports:
            # This report has activity but wasn't in scan (likely non-SPM workspace)
            activity_only_reports.append({
                "WorkspaceId": "N/A",  # No workspace ID available from activities
                "WorkspaceName": workspace_name,
                "ReportId": "N/A",  # No report ID available from activities
                "ReportName": report_name,
                "CapacityId": "N/A",  # Not available from activities
                "CapacityName": "N/A",
                "ModifiedDateTime": None,
                "Users": "[]",  # No user data from activities
                "ReportType": "ActivityOnly",  # Mark as activity-only
                "UsageLast30Days": usage.get('UsageLast30Days', 0),
                "UsageLast60Days": usage.get('UsageLast60Days', 0),
                "UsageLast90Days": usage.get('UsageLast90Days', 0),
                "IsOrphan": False,  # Cannot determine orphan status without scan
                "IsUnused": (usage.get('UsageLast90Days', 0) == 0)
            })
    
    # Find datasets in activities that weren't in scan
    activity_only_datasets = []
    for (workspace_name, dataset_name), usage in usage_data['datasets'].items():
        key = (workspace_name, dataset_name)
        if key not in scanned_datasets:
            # This dataset has activity but wasn't in scan (likely non-SPM workspace)
            activity_only_datasets.append({
                "WorkspaceId": "N/A",
                "WorkspaceName": workspace_name,
                "DatasetId": "N/A",
                "DatasetName": dataset_name,
                "CapacityId": "N/A",
                "CapacityName": "N/A",
                "ContentProviderType": "ActivityOnly",
                "RefreshEnabled": None,
                "UsageLast30Days": usage.get('UsageLast30Days', 0),
                "UsageLast60Days": usage.get('UsageLast60Days', 0),
                "UsageLast90Days": usage.get('UsageLast90Days', 0),
                "IsOrphan": False,  # Cannot determine orphan status without scan
                "IsUnused": (usage.get('UsageLast90Days', 0) == 0)
            })
    
    print(f"\nFound {len(activity_only_reports)} activity-only reports (non-SPM workspaces)")
    print(f"Found {len(activity_only_datasets)} activity-only datasets (non-SPM workspaces)")
    
    # Show sample activity-only artifacts
    if activity_only_reports:
        print(f"\nSample Activity-Only Reports:")
        for report in activity_only_reports[:5]:
            print(f"  - {report['WorkspaceName']} / {report['ReportName']}")
            print(f"    Usage: 30d={report['UsageLast30Days']}, 60d={report['UsageLast60Days']}, 90d={report['UsageLast90Days']}")
    
    if activity_only_datasets:
        print(f"\nSample Activity-Only Datasets:")
        for dataset in activity_only_datasets[:5]:
            print(f"  - {dataset['WorkspaceName']} / {dataset['DatasetName']}")
            print(f"    Usage: 30d={dataset['UsageLast30Days']}, 60d={dataset['UsageLast60Days']}, 90d={dataset['UsageLast90Days']}")
    
    # Append to existing data
    combined_reports = existing_reports + activity_only_reports
    combined_datasets = existing_datasets + activity_only_datasets
    
    print(f"\nTotal Reports (after adding activity-only): {len(combined_reports)}")
    print(f"Total Datasets (after adding activity-only): {len(combined_datasets)}")
    print("=" * 80)
    
    return combined_reports, combined_datasets

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # saving to lakehouse

# CELL ********************

def save_to_lakehouse_tables(reports_data: List[Dict], datasets_data: List[Dict], spark: SparkSession):
    """Save processed data to Lakehouse Tables"""
    
    print(f"\n{'=' * 80}")
    print(f"Saving to {LAKEHOUSE_NAME} Lakehouse...")
    print("=" * 80)
    
    try:
        if reports_data:
            reports_df = spark.createDataFrame(reports_data, schema=REPORTS_SCHEMA)
            reports_table_name = "orphan_unused_reports"
            reports_df.write.mode("overwrite").format("delta").saveAsTable(reports_table_name)
            
            print(f"\nSaved {len(reports_data)} reports to table: {reports_table_name}")
            print(f"  - Orphan Reports: {sum(1 for r in reports_data if r['IsOrphan'])}")
            print(f"  - Unused Reports: {sum(1 for r in reports_data if r['IsUnused'])}")
        
        if datasets_data:
            datasets_df = spark.createDataFrame(datasets_data, schema=DATASETS_SCHEMA)
            datasets_table_name = "orphan_unused_datasets"
            datasets_df.write.mode("overwrite").format("delta").saveAsTable(datasets_table_name)
            
            print(f"\nSaved {len(datasets_data)} datasets to table: {datasets_table_name}")
            print(f"  - Orphan Datasets: {sum(1 for d in datasets_data if d['IsOrphan'])}")
            print(f"  - Unused Datasets: {sum(1 for d in datasets_data if d['IsUnused'])}")
        
        print("=" * 80)
        
    except Exception as e:
        print(f"Error saving to Lakehouse: {e}")
        traceback.print_exc()
# =============================================
# PROCESS WORKSPACES IN BATCHES
# =============================================
def process_workspaces_in_batches(access_token: str, workspaces: List[Dict], 
                                   usage_data: Dict, capacity_mapping: Dict, spark: SparkSession) -> tuple:
    """Process all workspaces in batches"""
    
    print(f"\n{'=' * 80}")
    print(f"Processing {len(workspaces)} Workspaces in Batches")
    print(f"Batch Size: {BATCH_SIZE}")
    print("=" * 80)
    
    all_reports = []
    all_datasets = []
    
    # Extract workspace IDs
    workspace_ids = [ws['id'] for ws in workspaces]
    
    # Build workspace name lookup
    workspace_lookup = {ws['id']: ws['displayName'] for ws in workspaces}
    
    # Process in batches
    total_batches = (len(workspace_ids) + BATCH_SIZE - 1) // BATCH_SIZE
    
    for batch_num in range(total_batches):
        start_idx = batch_num * BATCH_SIZE
        end_idx = min(start_idx + BATCH_SIZE, len(workspace_ids))
        batch_ids = workspace_ids[start_idx:end_idx]
        
        print(f"\n{'=' * 80}")
        print(f"Processing Batch {batch_num + 1}/{total_batches}")
        print(f"Workspaces: {start_idx + 1} to {end_idx} (Count: {len(batch_ids)})")
        print("=" * 80)

        # Initiate scan for this batch
        scan_id = initiate_workspace_scan_batch(access_token, batch_ids)
        
        if not scan_id or str(scan_id).strip().lower() in ("none", "", "null"):
            print(f"Warning: Failed to initiate scan for batch {batch_num + 1}, skipping...")
            continue
        
        # Get scan results
        scan_results = get_scan_results(access_token, scan_id)
        
        if not scan_results:
            print(f"Warning: Failed to retrieve results for batch {batch_num + 1}, skipping...")
            continue
        
        # Process each workspace in the batch
        workspaces_in_scan = scan_results.get('workspaces', [])
        print(f"\nRetrieved {len(workspaces_in_scan)} workspaces from scan")
        
        for workspace in workspaces_in_scan:
            workspace_id = workspace.get('id', '')
            workspace_name = workspace.get('name', workspace_lookup.get(workspace_id, 'N/A'))
            
            print(f"\n  Processing: {workspace_name} (ID: {workspace_id})")
            
            # Process reports and datasets with capacity mapping
            reports = process_reports(workspace, usage_data['reports'], capacity_mapping)
            datasets = process_datasets(workspace, usage_data['datasets'], capacity_mapping)
            
            all_reports.extend(reports)
            all_datasets.extend(datasets)
            
            print(f"    Reports: {len(reports)} (Orphans: {sum(1 for r in reports if r['IsOrphan'])}, "
                  f"Unused: {sum(1 for r in reports if r['IsUnused'])})")
            print(f"    Datasets: {len(datasets)} (Orphans: {sum(1 for d in datasets if d['IsOrphan'])}, "
                  f"Unused: {sum(1 for d in datasets if d['IsUnused'])})")
        
        # Progress summary
        print(f"\n{'=' * 80}")
        print(f"Batch {batch_num + 1}/{total_batches} Complete")
        print(f"Total Reports So Far: {len(all_reports)}")
        print(f"Total Datasets So Far: {len(all_datasets)}")
        print("=" * 80)
        
        # Small delay between batches to avoid rate limiting
        if batch_num < total_batches - 1:
            print(f"\nWaiting 2 seconds before next batch...")
            time.sleep(2)
    
    return all_reports, all_datasets

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # main function

# CELL ********************

def main():
    """Execute complete workflow with integrated unused detection for multiple workspaces"""
    
    # Initialize Spark
    # spark = SparkSession.builder.appName("PowerBI_Unused_Artifacts_MultiWorkspace").getOrCreate()
    
    # Step 1: Load configuration from Eventhouse
    try:
        config = load_config_from_eventhouse(spark)
    except Exception as e:
        print(f"\nCRITICAL ERROR: Cannot load configuration from Eventhouse: {e}")
        return None
    
    try:
        abfs_paths = construct_abfs_paths(config)
    except Exception as e:
        print(f"\nCRITICAL ERROR: Cannot construct ABFS paths: {e}")
        return None

    # Extract Key Vault name from config
    key_vault_name = config['KEY_VAULT_NAME']
    key_vault_uri = f"https://{key_vault_name}.vault.azure.net/"
    
    # Step 2: Connect to Key Vault
    try:
        kv_client = get_keyvault_client(key_vault_uri)
    except Exception as e:
        print(f"\nCRITICAL ERROR: Cannot connect to Key Vault: {e}")
        return None
    
    # Step 3: Load credentials from Key Vault using secret names from config
    try:
        credentials = load_credentials_from_keyvault(kv_client, config)
    except Exception as e:
        print(f"\nERROR: Failed to load credentials: {e}")
        return None
    
    # Extract credentials
    tenant_id = credentials['TENANT_ID']
    client_id = credentials['CLIENT_ID']
    client_secret = credentials['CLIENT_SECRET']
    
    # Generate Token
    access_token = generate_access_token(tenant_id, client_id, client_secret)
    if not access_token:
        print("\nFailed to generate access token")
        return None
    
    # Get all workspaces
    workspaces = get_all_workspaces(access_token)
    if not workspaces:
        print("\nFailed to retrieve workspaces")
        return None
    
    # Get capacity name mapping from capacities table
    # capacity_mapping = get_capacity_mapping(spark)
    capacity_mapping = get_capacity_mapping(spark, abfs_paths)
    
    # Get comprehensive usage data from activities table
    # usage_data = get_activity_based_usage(spark)
    usage_data = get_activity_based_usage(spark, abfs_paths)
    
    # Process all workspaces in batches with capacity mapping
    all_reports, all_datasets = process_workspaces_in_batches(
        access_token, workspaces, usage_data, capacity_mapping, spark
    )
    
    # Append artifacts that exist in activities but not in scan results (non-SPM workspaces)
    all_reports, all_datasets = append_activity_only_artifacts(
        all_reports, all_datasets, usage_data, capacity_mapping
    )
    
    # Save to Lakehouse
    save_to_lakehouse_tables(all_reports, all_datasets, spark)
    
    # Final Summary
    print(f"\n{'=' * 80}")
    print("FINAL SUMMARY")
    print("=" * 80)
    print(f"\nTotal Workspaces Processed: {len(workspaces)}")
    print(f"Total Reports: {len(all_reports)}")
    print(f"  - From Scanned Workspaces (SPM enabled): {sum(1 for r in all_reports if r['ReportType'] != 'ActivityOnly')}")
    print(f"  - From Activity-Only (Non-SPM workspaces): {sum(1 for r in all_reports if r['ReportType'] == 'ActivityOnly')}")
    print(f"  - Orphan Reports: {sum(1 for r in all_reports if r['IsOrphan'])}")
    print(f"  - Unused Reports (0 usage in last 90 days): {sum(1 for r in all_reports if r['IsUnused'])}")
    
    print(f"\nTotal Datasets: {len(all_datasets)}")
    print(f"  - From Scanned Workspaces (SPM enabled): {sum(1 for d in all_datasets if d['ContentProviderType'] != 'ActivityOnly')}")
    print(f"  - From Activity-Only (Non-SPM workspaces): {sum(1 for d in all_datasets if d['ContentProviderType'] == 'ActivityOnly')}")
    print(f"  - Orphan Datasets: {sum(1 for d in all_datasets if d['IsOrphan'])}")
    print(f"  - Unused Datasets (0 usage in last 90 days): {sum(1 for d in all_datasets if d['IsUnused'])}")
    
    # Additional breakdown
    unused_30 = sum(1 for r in all_reports if r['UsageLast30Days'] == 0)
    unused_60 = sum(1 for r in all_reports if r['UsageLast60Days'] == 0 and r['UsageLast30Days'] == 0)
    unused_90 = sum(1 for r in all_reports if r['UsageLast90Days'] == 0 and r['UsageLast60Days'] == 0 and r['UsageLast30Days'] == 0)
    
    print(f"\nReports Usage Breakdown:")
    print(f"  - No usage in last 30 days: {unused_30}")
    print(f"  - No usage in last 60 days: {unused_60}")
    print(f"  - No usage in last 90 days: {unused_90}")
    
    dataset_unused_30 = sum(1 for d in all_datasets if d['UsageLast30Days'] == 0)
    dataset_unused_60 = sum(1 for d in all_datasets if d['UsageLast60Days'] == 0 and d['UsageLast30Days'] == 0)
    dataset_unused_90 = sum(1 for d in all_datasets if d['UsageLast90Days'] == 0 and d['UsageLast60Days'] == 0 and d['UsageLast30Days'] == 0)
    
    print(f"\nDatasets Usage Breakdown:")
    print(f"  - No usage in last 30 days: {dataset_unused_30}")
    print(f"  - No usage in last 60 days: {dataset_unused_60}")
    print(f"  - No usage in last 90 days: {dataset_unused_90}")
    
    # Workspace breakdown
    workspace_report_counts = {}
    workspace_dataset_counts = {}
    
    for report in all_reports:
        ws_name = report['WorkspaceName']
        workspace_report_counts[ws_name] = workspace_report_counts.get(ws_name, 0) + 1
    
    for dataset in all_datasets:
        ws_name = dataset['WorkspaceName']
        workspace_dataset_counts[ws_name] = workspace_dataset_counts.get(ws_name, 0) + 1
    
    print(f"\n  Top 10 Workspaces by Report Count:")
    top_workspaces = sorted(workspace_report_counts.items(), key=lambda x: x[1], reverse=True)[:10]
    for ws_name, count in top_workspaces:
        print(f"    - {ws_name}: {count} reports")
    
    # Capacity statistics
    capacity_with_names = sum(1 for r in all_reports if r['CapacityName'] != 'N/A')
    capacity_without_names = sum(1 for r in all_reports if r['CapacityId'] != 'N/A' and r['CapacityName'] == 'N/A')
    
    print(f"\n  Capacity Name Mapping Statistics:")
    print(f"    - Reports with CapacityName: {capacity_with_names}")
    print(f"    - Reports with CapacityId but no CapacityName: {capacity_without_names}")
    
    dataset_capacity_with_names = sum(1 for d in all_datasets if d['CapacityName'] != 'N/A')
    dataset_capacity_without_names = sum(1 for d in all_datasets if d['CapacityId'] != 'N/A' and d['CapacityName'] == 'N/A')
    
    print(f"    - Datasets with CapacityName: {dataset_capacity_with_names}")
    print(f"    - Datasets with CapacityId but no CapacityName: {dataset_capacity_without_names}")
    
    # Activity-only statistics
    activity_only_reports = sum(1 for r in all_reports if r['ReportType'] == 'ActivityOnly')
    activity_only_datasets = sum(1 for d in all_datasets if d['ContentProviderType'] == 'ActivityOnly')
    
    print(f"\n  Activity-Only Artifacts (Non-SPM Workspaces):")
    print(f"    - Reports: {activity_only_reports}")
    print(f"    - Datasets: {activity_only_datasets}")
    print(f"    - Note: These artifacts have usage data but couldn't be scanned (workspace lacks SPM)")
    
    print(f"\nData Location:")
    print(f"  - Lakehouse: {LAKEHOUSE_NAME}")
    print(f"  - Reports Table: orphan_unused_reports")
    print(f"  - Datasets Table: orphan_unused_datasets")
    print("=" * 80)
    
    return all_reports, all_datasets

# =============================================
# RUN THE WORKFLOW
# =============================================
if __name__ == "__main__":
    reports, datasets = main()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # Orphan Unused workspaces

# CELL ********************

KUSTO_URI = "https://trd-zfmmx5us1trradc09u.z1.kusto.fabric.microsoft.com"
KUSTO_DATABASE = "FabricAdminAgentLogs"
CONFIG_TABLE = "ConfigTable"

CONFIG_KEYS = {
    'WORKSPACE_ID': ('FUAMConfig', 'WorkspaceId'),
    'LAKEHOUSE_ID': ('FUAMConfig', 'LakehouseId'),
    'LAKEHOUSE_NAME': ('FUAMConfig', 'LakehouseName')
}

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# =============================================
# SCHEMA DEFINITION
# =============================================
WORKSPACES_SCHEMA = StructType([
    StructField("WorkspaceId", StringType(), True),
    StructField("WorkspaceName", StringType(), True),
    StructField("State", StringType(), True),
    StructField("CapacityId", StringType(), True),
    StructField("CapacityName", StringType(), True),
    StructField("UsageLast30Days", IntegerType(), True),
    StructField("UsageLast60Days", IntegerType(), True),
    StructField("UsageLast90Days", IntegerType(), True),
    StructField("IsOrphan", BooleanType(), True),
    StructField("IsUnused", BooleanType(), True)
])

# =============================================
# PATH CONFIGURATION
# =============================================
def construct_abfs_paths(config: Dict[str, str]) -> Dict[str, str]:
    """
    Construct paths:
    - ABFS paths for reading from source lakehouse (has ID)
    - Relative path for writing to target lakehouse (has name)
    """
    workspace_id = config.get('WORKSPACE_ID')
    lakehouse_id = config.get('LAKEHOUSE_ID')
    lakehouse_name = config.get('LAKEHOUSE_NAME')
    
    if not workspace_id or not lakehouse_id:
        raise ValueError("WORKSPACE_ID and LAKEHOUSE_ID must be present in config")
    
    if not lakehouse_name:
        raise ValueError("LAKEHOUSE_NAME must be present in config")
    
    # Source lakehouse ABFS base path (for reading capacities, workspaces, activities)
    source_base = f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}/Tables"
    
    # Target lakehouse relative path (for writing orphan_unused_workspaces)
    target_base = f"Tables"
    
    abfs_paths = {
        # Read from source lakehouse via ABFS
        'activities': f"{source_base}/activities",
        'capacities': f"{source_base}/capacities",
        'workspaces': f"{source_base}/workspaces",
        # Write to target lakehouse via relative path
        'orphan_unused_workspaces': f"{target_base}/dbo/orphan_unused_workspaces"
    }

    return abfs_paths

# =============================================
# EVENTHOUSE CONFIG INTEGRATION
# =============================================
def load_config_from_eventhouse(spark: SparkSession) -> Dict[str, str]:
    try:
        access_token = mssparkutils.credentials.getToken(KUSTO_URI)
        kusto_query = f"{CONFIG_TABLE} | where ConfigCategory == 'FUAMConfig' and IsActive == true"
        config_df = spark.read\
            .format("com.microsoft.kusto.spark.synapse.datasource")\
            .option("accessToken", access_token)\
            .option("kustoCluster", KUSTO_URI)\
            .option("kustoDatabase", KUSTO_DATABASE)\
            .option("kustoQuery", kusto_query)\
            .load()
        
        config_data = {}
        config_rows = config_df.collect()
        for row in config_rows:
            config_data[(row['ConfigCategory'], row['ConfigKey'])] = row['ConfigValue']
        
        configuration = {}
        for config_key in CONFIG_KEYS:
            category, key = CONFIG_KEYS[config_key]
            if (category, key) in config_data:
                configuration[config_key] = config_data[(category, key)]
            else:
                # Provide defaults only for LAKEHOUSE_NAME
                if config_key == 'LAKEHOUSE_NAME':
                    configuration[config_key] = "FabricAdminAgent"
                else:
                    raise ValueError(f"Configuration not found: Category={category}, Key={key}")
        return configuration
    except Exception as e:
        traceback.print_exc()
        raise

# =============================================
# ORPHAN & UNUSED WORKSPACES PROCESSING
# =============================================
def process_orphan_unused_workspaces(spark: SparkSession, abfs_paths: Dict[str, str]):
    try:
        workspaces_df = spark.read.format("delta").load(abfs_paths['workspaces'])
        capacities_df = spark.read.format("delta").load(abfs_paths['capacities'])
        activities_df = spark.read.format("delta").load(abfs_paths['activities'])
        
        workspaces_df.createOrReplaceTempView("workspaces")
        capacities_df.createOrReplaceTempView("capacities")
        activities_df.createOrReplaceTempView("activities")
        
        orphan_query = """
        SELECT 
            W.WorkspaceId, 
            W.WorkspaceName, 
            W.State, 
            W.CapacityId, 
            COALESCE(MAX(C.displayName), 'N/A') AS CapacityName 
        FROM 
            workspaces W 
            LEFT JOIN capacities C ON W.CapacityId = C.CapacityId 
        WHERE 
            W.State = 'Orphaned'
            AND W.WorkspaceName IS NOT NULL
            AND W.WorkspaceName != 'My Workspace'
            AND W.WorkspaceName NOT LIKE '%PersonalWorkspace%'
        GROUP BY 
            W.WorkspaceId, 
            W.WorkspaceName, 
            W.State, 
            W.CapacityId
        """
        orphan_df = spark.sql(orphan_query) \
            .withColumn("UsageLast30Days", F.lit(0).cast(IntegerType())) \
            .withColumn("UsageLast60Days", F.lit(0).cast(IntegerType())) \
            .withColumn("UsageLast90Days", F.lit(0).cast(IntegerType())) \
            .withColumn("IsOrphan", F.lit(True)) \
            .withColumn("IsUnused", F.lit(False))
        
        unused_query = """
        WITH ActivitySummary AS (
            SELECT 
                A.WorkSpaceId,
                MAX(CASE WHEN DATEDIFF(current_date(), A.CreationDate) <= 30 THEN 1 ELSE 0 END) AS HasActivity30,
                MAX(CASE WHEN DATEDIFF(current_date(), A.CreationDate) <= 60 THEN 1 ELSE 0 END) AS HasActivity60,
                MAX(CASE WHEN DATEDIFF(current_date(), A.CreationDate) <= 90 THEN 1 ELSE 0 END) AS HasActivity90
            FROM 
                activities A
            WHERE 
                A.CreationDate >= DATE_SUB(current_date(), 90)
                AND A.WorkSpaceId IS NOT NULL
            GROUP BY 
                A.WorkSpaceId
        )
        SELECT 
            W.WorkspaceId,
            W.WorkspaceName,
            W.State,
            W.CapacityId,
            COALESCE(C.displayName, 'N/A') AS CapacityName,
            CASE WHEN COALESCE(A.HasActivity30, 0) > 0 THEN 1 ELSE 0 END AS UsageLast30Days,
            CASE WHEN COALESCE(A.HasActivity60, 0) > 0 THEN 1 ELSE 0 END AS UsageLast60Days,
            CASE WHEN COALESCE(A.HasActivity90, 0) > 0 THEN 1 ELSE 0 END AS UsageLast90Days
        FROM 
            workspaces W
            LEFT JOIN ActivitySummary A ON W.WorkspaceId = A.WorkSpaceId
            LEFT JOIN capacities C ON W.CapacityId = C.CapacityId
        WHERE 
            W.WorkspaceName IS NOT NULL
            AND W.WorkspaceName != 'My Workspace'
            AND W.WorkspaceName NOT LIKE '%PersonalWorkspace%'
        """
        unused_df = spark.sql(unused_query) \
            .withColumn("UsageLast30Days", F.col("UsageLast30Days").cast(IntegerType())) \
            .withColumn("UsageLast60Days", F.col("UsageLast60Days").cast(IntegerType())) \
            .withColumn("UsageLast90Days", F.col("UsageLast90Days").cast(IntegerType())) \
            .withColumn("IsOrphan", F.lit(False)) \
            .withColumn("IsUnused", F.when(F.col("UsageLast90Days") == 0, True).otherwise(False))
        
        column_order = [
            "WorkspaceId", "WorkspaceName", "State", "CapacityId", "CapacityName",
            "UsageLast30Days", "UsageLast60Days", "UsageLast90Days",
            "IsOrphan", "IsUnused"
        ]
        orphan_df = orphan_df.select(*column_order)
        unused_df = unused_df.select(*column_order)
        merged_df = orphan_df.unionByName(unused_df)
        
        final_df = merged_df.groupBy(
            "WorkspaceId", "WorkspaceName", "State", "CapacityId", "CapacityName"
        ).agg(
            F.max("UsageLast30Days").cast(IntegerType()).alias("UsageLast30Days"),
            F.max("UsageLast60Days").cast(IntegerType()).alias("UsageLast60Days"),
            F.max("UsageLast90Days").cast(IntegerType()).alias("UsageLast90Days"),
            F.max("IsOrphan").alias("IsOrphan"),
            F.max("IsUnused").alias("IsUnused")
        ).select(*column_order)
        
        output_path = abfs_paths['orphan_unused_workspaces']
        
        # Check if table exists and show current state
        try:
            existing_df = spark.read.format("delta").load(output_path)
            print(f"DEBUG: Existing table count BEFORE overwrite: {existing_df.count()}")
            existing_schema = existing_df.schema
            usage_cols = ['UsageLast30Days', 'UsageLast60Days', 'UsageLast90Days']
            needs_conversion = any(
                [f for f in existing_schema.fields if f.name in usage_cols and str(f.dataType) != 'IntegerType()']
            )
            if needs_conversion:
                print("DEBUG: Schema conversion needed - converting Integer to Long")
                final_df = final_df \
                    .withColumn("UsageLast30Days", F.col("UsageLast30Days").cast(LongType())) \
                    .withColumn("UsageLast60Days", F.col("UsageLast60Days").cast(LongType())) \
                    .withColumn("UsageLast90Days", F.col("UsageLast90Days").cast(LongType()))
        except Exception as e:
            print(f"DEBUG: Table does not exist yet or error reading: {e}")
        
        # Debug: Print counts before writing
        print(f"DEBUG: final_df count BEFORE write: {final_df.count()}")
        print(f"DEBUG: Writing to path: {output_path}")
        
        display(final_df)
        
        # Write with explicit overwrite mode
        final_df.write \
            .mode("overwrite") \
            .format("delta") \
            .option("overwriteSchema", "true") \
            .option("mergeSchema", "true") \
            .save(output_path)



        # Verify write by reading back
        written_df = spark.read.format("delta").load(output_path)
        print(f"DEBUG: Table count AFTER write: {written_df.count()}")
        
        if written_df.count() != final_df.count():
            print(f"WARNING: Count mismatch! Expected {final_df.count()}, but table has {written_df.count()}")
        
        return final_df
    except Exception:
        traceback.print_exc()
        raise

# =============================================
# MAIN EXECUTION
# =============================================
def main():
    spark = SparkSession.builder.appName("Orphan_Unused_Workspaces").getOrCreate()
    try:
        config = load_config_from_eventhouse(spark)
        abfs_paths = construct_abfs_paths(config)
        result_df = process_orphan_unused_workspaces(spark, abfs_paths)
        return result_df
    except Exception:
        traceback.print_exc()
        return None

if __name__ == "__main__":
    result = main()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # sample queries

# CELL ********************

df = spark.sql("SELECT * FROM FabricAdminAgent.dbo.orphan_unused_workspaces")
display(df)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df = spark.sql("SELECT * FROM FabricAdminAgent.dbo.orphan_unused_reports")
display(df)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df = spark.sql("SELECT * FROM FabricAdminAgent.dbo.orphan_unused_datasets")
display(df)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

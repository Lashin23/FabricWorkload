/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/index.js":
/*!*********************************************************************************************!*\
  !*** ./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/index.js ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   NIL: () => (/* reexport safe */ _nil_js__WEBPACK_IMPORTED_MODULE_4__["default"]),
/* harmony export */   parse: () => (/* reexport safe */ _parse_js__WEBPACK_IMPORTED_MODULE_8__["default"]),
/* harmony export */   stringify: () => (/* reexport safe */ _stringify_js__WEBPACK_IMPORTED_MODULE_7__["default"]),
/* harmony export */   v1: () => (/* reexport safe */ _v1_js__WEBPACK_IMPORTED_MODULE_0__["default"]),
/* harmony export */   v3: () => (/* reexport safe */ _v3_js__WEBPACK_IMPORTED_MODULE_1__["default"]),
/* harmony export */   v4: () => (/* reexport safe */ _v4_js__WEBPACK_IMPORTED_MODULE_2__["default"]),
/* harmony export */   v5: () => (/* reexport safe */ _v5_js__WEBPACK_IMPORTED_MODULE_3__["default"]),
/* harmony export */   validate: () => (/* reexport safe */ _validate_js__WEBPACK_IMPORTED_MODULE_6__["default"]),
/* harmony export */   version: () => (/* reexport safe */ _version_js__WEBPACK_IMPORTED_MODULE_5__["default"])
/* harmony export */ });
/* harmony import */ var _v1_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./v1.js */ "./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/v1.js");
/* harmony import */ var _v3_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./v3.js */ "./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/v3.js");
/* harmony import */ var _v4_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./v4.js */ "./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/v4.js");
/* harmony import */ var _v5_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./v5.js */ "./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/v5.js");
/* harmony import */ var _nil_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./nil.js */ "./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/nil.js");
/* harmony import */ var _version_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./version.js */ "./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/version.js");
/* harmony import */ var _validate_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./validate.js */ "./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/validate.js");
/* harmony import */ var _stringify_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./stringify.js */ "./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/stringify.js");
/* harmony import */ var _parse_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./parse.js */ "./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/parse.js");










/***/ }),

/***/ "./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/md5.js":
/*!*******************************************************************************************!*\
  !*** ./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/md5.js ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/*
 * Browser-compatible JavaScript MD5
 *
 * Modification of JavaScript MD5
 * https://github.com/blueimp/JavaScript-MD5
 *
 * Copyright 2011, Sebastian Tschan
 * https://blueimp.net
 *
 * Licensed under the MIT license:
 * https://opensource.org/licenses/MIT
 *
 * Based on
 * A JavaScript implementation of the RSA Data Security, Inc. MD5 Message
 * Digest Algorithm, as defined in RFC 1321.
 * Version 2.2 Copyright (C) Paul Johnston 1999 - 2009
 * Other contributors: Greg Holt, Andrew Kepert, Ydnar, Lostinet
 * Distributed under the BSD License
 * See http://pajhome.org.uk/crypt/md5 for more info.
 */
function md5(bytes) {
  if (typeof bytes === 'string') {
    var msg = unescape(encodeURIComponent(bytes)); // UTF8 escape

    bytes = new Uint8Array(msg.length);

    for (var i = 0; i < msg.length; ++i) {
      bytes[i] = msg.charCodeAt(i);
    }
  }

  return md5ToHexEncodedArray(wordsToMd5(bytesToWords(bytes), bytes.length * 8));
}
/*
 * Convert an array of little-endian words to an array of bytes
 */


function md5ToHexEncodedArray(input) {
  var output = [];
  var length32 = input.length * 32;
  var hexTab = '0123456789abcdef';

  for (var i = 0; i < length32; i += 8) {
    var x = input[i >> 5] >>> i % 32 & 0xff;
    var hex = parseInt(hexTab.charAt(x >>> 4 & 0x0f) + hexTab.charAt(x & 0x0f), 16);
    output.push(hex);
  }

  return output;
}
/**
 * Calculate output length with padding and bit length
 */


function getOutputLength(inputLength8) {
  return (inputLength8 + 64 >>> 9 << 4) + 14 + 1;
}
/*
 * Calculate the MD5 of an array of little-endian words, and a bit length.
 */


function wordsToMd5(x, len) {
  /* append padding */
  x[len >> 5] |= 0x80 << len % 32;
  x[getOutputLength(len) - 1] = len;
  var a = 1732584193;
  var b = -271733879;
  var c = -1732584194;
  var d = 271733878;

  for (var i = 0; i < x.length; i += 16) {
    var olda = a;
    var oldb = b;
    var oldc = c;
    var oldd = d;
    a = md5ff(a, b, c, d, x[i], 7, -680876936);
    d = md5ff(d, a, b, c, x[i + 1], 12, -389564586);
    c = md5ff(c, d, a, b, x[i + 2], 17, 606105819);
    b = md5ff(b, c, d, a, x[i + 3], 22, -1044525330);
    a = md5ff(a, b, c, d, x[i + 4], 7, -176418897);
    d = md5ff(d, a, b, c, x[i + 5], 12, 1200080426);
    c = md5ff(c, d, a, b, x[i + 6], 17, -1473231341);
    b = md5ff(b, c, d, a, x[i + 7], 22, -45705983);
    a = md5ff(a, b, c, d, x[i + 8], 7, 1770035416);
    d = md5ff(d, a, b, c, x[i + 9], 12, -1958414417);
    c = md5ff(c, d, a, b, x[i + 10], 17, -42063);
    b = md5ff(b, c, d, a, x[i + 11], 22, -1990404162);
    a = md5ff(a, b, c, d, x[i + 12], 7, 1804603682);
    d = md5ff(d, a, b, c, x[i + 13], 12, -40341101);
    c = md5ff(c, d, a, b, x[i + 14], 17, -1502002290);
    b = md5ff(b, c, d, a, x[i + 15], 22, 1236535329);
    a = md5gg(a, b, c, d, x[i + 1], 5, -165796510);
    d = md5gg(d, a, b, c, x[i + 6], 9, -1069501632);
    c = md5gg(c, d, a, b, x[i + 11], 14, 643717713);
    b = md5gg(b, c, d, a, x[i], 20, -373897302);
    a = md5gg(a, b, c, d, x[i + 5], 5, -701558691);
    d = md5gg(d, a, b, c, x[i + 10], 9, 38016083);
    c = md5gg(c, d, a, b, x[i + 15], 14, -660478335);
    b = md5gg(b, c, d, a, x[i + 4], 20, -405537848);
    a = md5gg(a, b, c, d, x[i + 9], 5, 568446438);
    d = md5gg(d, a, b, c, x[i + 14], 9, -1019803690);
    c = md5gg(c, d, a, b, x[i + 3], 14, -187363961);
    b = md5gg(b, c, d, a, x[i + 8], 20, 1163531501);
    a = md5gg(a, b, c, d, x[i + 13], 5, -1444681467);
    d = md5gg(d, a, b, c, x[i + 2], 9, -51403784);
    c = md5gg(c, d, a, b, x[i + 7], 14, 1735328473);
    b = md5gg(b, c, d, a, x[i + 12], 20, -1926607734);
    a = md5hh(a, b, c, d, x[i + 5], 4, -378558);
    d = md5hh(d, a, b, c, x[i + 8], 11, -2022574463);
    c = md5hh(c, d, a, b, x[i + 11], 16, 1839030562);
    b = md5hh(b, c, d, a, x[i + 14], 23, -35309556);
    a = md5hh(a, b, c, d, x[i + 1], 4, -1530992060);
    d = md5hh(d, a, b, c, x[i + 4], 11, 1272893353);
    c = md5hh(c, d, a, b, x[i + 7], 16, -155497632);
    b = md5hh(b, c, d, a, x[i + 10], 23, -1094730640);
    a = md5hh(a, b, c, d, x[i + 13], 4, 681279174);
    d = md5hh(d, a, b, c, x[i], 11, -358537222);
    c = md5hh(c, d, a, b, x[i + 3], 16, -722521979);
    b = md5hh(b, c, d, a, x[i + 6], 23, 76029189);
    a = md5hh(a, b, c, d, x[i + 9], 4, -640364487);
    d = md5hh(d, a, b, c, x[i + 12], 11, -421815835);
    c = md5hh(c, d, a, b, x[i + 15], 16, 530742520);
    b = md5hh(b, c, d, a, x[i + 2], 23, -995338651);
    a = md5ii(a, b, c, d, x[i], 6, -198630844);
    d = md5ii(d, a, b, c, x[i + 7], 10, 1126891415);
    c = md5ii(c, d, a, b, x[i + 14], 15, -1416354905);
    b = md5ii(b, c, d, a, x[i + 5], 21, -57434055);
    a = md5ii(a, b, c, d, x[i + 12], 6, 1700485571);
    d = md5ii(d, a, b, c, x[i + 3], 10, -1894986606);
    c = md5ii(c, d, a, b, x[i + 10], 15, -1051523);
    b = md5ii(b, c, d, a, x[i + 1], 21, -2054922799);
    a = md5ii(a, b, c, d, x[i + 8], 6, 1873313359);
    d = md5ii(d, a, b, c, x[i + 15], 10, -30611744);
    c = md5ii(c, d, a, b, x[i + 6], 15, -1560198380);
    b = md5ii(b, c, d, a, x[i + 13], 21, 1309151649);
    a = md5ii(a, b, c, d, x[i + 4], 6, -145523070);
    d = md5ii(d, a, b, c, x[i + 11], 10, -1120210379);
    c = md5ii(c, d, a, b, x[i + 2], 15, 718787259);
    b = md5ii(b, c, d, a, x[i + 9], 21, -343485551);
    a = safeAdd(a, olda);
    b = safeAdd(b, oldb);
    c = safeAdd(c, oldc);
    d = safeAdd(d, oldd);
  }

  return [a, b, c, d];
}
/*
 * Convert an array bytes to an array of little-endian words
 * Characters >255 have their high-byte silently ignored.
 */


function bytesToWords(input) {
  if (input.length === 0) {
    return [];
  }

  var length8 = input.length * 8;
  var output = new Uint32Array(getOutputLength(length8));

  for (var i = 0; i < length8; i += 8) {
    output[i >> 5] |= (input[i / 8] & 0xff) << i % 32;
  }

  return output;
}
/*
 * Add integers, wrapping at 2^32. This uses 16-bit operations internally
 * to work around bugs in some JS interpreters.
 */


function safeAdd(x, y) {
  var lsw = (x & 0xffff) + (y & 0xffff);
  var msw = (x >> 16) + (y >> 16) + (lsw >> 16);
  return msw << 16 | lsw & 0xffff;
}
/*
 * Bitwise rotate a 32-bit number to the left.
 */


function bitRotateLeft(num, cnt) {
  return num << cnt | num >>> 32 - cnt;
}
/*
 * These functions implement the four basic operations the algorithm uses.
 */


function md5cmn(q, a, b, x, s, t) {
  return safeAdd(bitRotateLeft(safeAdd(safeAdd(a, q), safeAdd(x, t)), s), b);
}

function md5ff(a, b, c, d, x, s, t) {
  return md5cmn(b & c | ~b & d, a, b, x, s, t);
}

function md5gg(a, b, c, d, x, s, t) {
  return md5cmn(b & d | c & ~d, a, b, x, s, t);
}

function md5hh(a, b, c, d, x, s, t) {
  return md5cmn(b ^ c ^ d, a, b, x, s, t);
}

function md5ii(a, b, c, d, x, s, t) {
  return md5cmn(c ^ (b | ~d), a, b, x, s, t);
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (md5);

/***/ }),

/***/ "./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/nil.js":
/*!*******************************************************************************************!*\
  !*** ./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/nil.js ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ('00000000-0000-0000-0000-000000000000');

/***/ }),

/***/ "./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/parse.js":
/*!*********************************************************************************************!*\
  !*** ./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/parse.js ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _validate_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./validate.js */ "./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/validate.js");


function parse(uuid) {
  if (!(0,_validate_js__WEBPACK_IMPORTED_MODULE_0__["default"])(uuid)) {
    throw TypeError('Invalid UUID');
  }

  var v;
  var arr = new Uint8Array(16); // Parse ########-....-....-....-............

  arr[0] = (v = parseInt(uuid.slice(0, 8), 16)) >>> 24;
  arr[1] = v >>> 16 & 0xff;
  arr[2] = v >>> 8 & 0xff;
  arr[3] = v & 0xff; // Parse ........-####-....-....-............

  arr[4] = (v = parseInt(uuid.slice(9, 13), 16)) >>> 8;
  arr[5] = v & 0xff; // Parse ........-....-####-....-............

  arr[6] = (v = parseInt(uuid.slice(14, 18), 16)) >>> 8;
  arr[7] = v & 0xff; // Parse ........-....-....-####-............

  arr[8] = (v = parseInt(uuid.slice(19, 23), 16)) >>> 8;
  arr[9] = v & 0xff; // Parse ........-....-....-....-############
  // (Use "/" to avoid 32-bit truncation when bit-shifting high-order bytes)

  arr[10] = (v = parseInt(uuid.slice(24, 36), 16)) / 0x10000000000 & 0xff;
  arr[11] = v / 0x100000000 & 0xff;
  arr[12] = v >>> 24 & 0xff;
  arr[13] = v >>> 16 & 0xff;
  arr[14] = v >>> 8 & 0xff;
  arr[15] = v & 0xff;
  return arr;
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (parse);

/***/ }),

/***/ "./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/regex.js":
/*!*********************************************************************************************!*\
  !*** ./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/regex.js ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/^(?:[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000)$/i);

/***/ }),

/***/ "./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/rng.js":
/*!*******************************************************************************************!*\
  !*** ./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/rng.js ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ rng)
/* harmony export */ });
// Unique ID creation requires a high quality random # generator. In the browser we therefore
// require the crypto API and do not support built-in fallback to lower quality random number
// generators (like Math.random()).
var getRandomValues;
var rnds8 = new Uint8Array(16);
function rng() {
  // lazy load so that environments that need to polyfill have a chance to do so
  if (!getRandomValues) {
    // getRandomValues needs to be invoked in a context where "this" is a Crypto implementation. Also,
    // find the complete implementation of crypto (msCrypto) on IE11.
    getRandomValues = typeof crypto !== 'undefined' && crypto.getRandomValues && crypto.getRandomValues.bind(crypto) || typeof msCrypto !== 'undefined' && typeof msCrypto.getRandomValues === 'function' && msCrypto.getRandomValues.bind(msCrypto);

    if (!getRandomValues) {
      throw new Error('crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported');
    }
  }

  return getRandomValues(rnds8);
}

/***/ }),

/***/ "./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/sha1.js":
/*!********************************************************************************************!*\
  !*** ./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/sha1.js ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// Adapted from Chris Veness' SHA1 code at
// http://www.movable-type.co.uk/scripts/sha1.html
function f(s, x, y, z) {
  switch (s) {
    case 0:
      return x & y ^ ~x & z;

    case 1:
      return x ^ y ^ z;

    case 2:
      return x & y ^ x & z ^ y & z;

    case 3:
      return x ^ y ^ z;
  }
}

function ROTL(x, n) {
  return x << n | x >>> 32 - n;
}

function sha1(bytes) {
  var K = [0x5a827999, 0x6ed9eba1, 0x8f1bbcdc, 0xca62c1d6];
  var H = [0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476, 0xc3d2e1f0];

  if (typeof bytes === 'string') {
    var msg = unescape(encodeURIComponent(bytes)); // UTF8 escape

    bytes = [];

    for (var i = 0; i < msg.length; ++i) {
      bytes.push(msg.charCodeAt(i));
    }
  } else if (!Array.isArray(bytes)) {
    // Convert Array-like to Array
    bytes = Array.prototype.slice.call(bytes);
  }

  bytes.push(0x80);
  var l = bytes.length / 4 + 2;
  var N = Math.ceil(l / 16);
  var M = new Array(N);

  for (var _i = 0; _i < N; ++_i) {
    var arr = new Uint32Array(16);

    for (var j = 0; j < 16; ++j) {
      arr[j] = bytes[_i * 64 + j * 4] << 24 | bytes[_i * 64 + j * 4 + 1] << 16 | bytes[_i * 64 + j * 4 + 2] << 8 | bytes[_i * 64 + j * 4 + 3];
    }

    M[_i] = arr;
  }

  M[N - 1][14] = (bytes.length - 1) * 8 / Math.pow(2, 32);
  M[N - 1][14] = Math.floor(M[N - 1][14]);
  M[N - 1][15] = (bytes.length - 1) * 8 & 0xffffffff;

  for (var _i2 = 0; _i2 < N; ++_i2) {
    var W = new Uint32Array(80);

    for (var t = 0; t < 16; ++t) {
      W[t] = M[_i2][t];
    }

    for (var _t = 16; _t < 80; ++_t) {
      W[_t] = ROTL(W[_t - 3] ^ W[_t - 8] ^ W[_t - 14] ^ W[_t - 16], 1);
    }

    var a = H[0];
    var b = H[1];
    var c = H[2];
    var d = H[3];
    var e = H[4];

    for (var _t2 = 0; _t2 < 80; ++_t2) {
      var s = Math.floor(_t2 / 20);
      var T = ROTL(a, 5) + f(s, b, c, d) + e + K[s] + W[_t2] >>> 0;
      e = d;
      d = c;
      c = ROTL(b, 30) >>> 0;
      b = a;
      a = T;
    }

    H[0] = H[0] + a >>> 0;
    H[1] = H[1] + b >>> 0;
    H[2] = H[2] + c >>> 0;
    H[3] = H[3] + d >>> 0;
    H[4] = H[4] + e >>> 0;
  }

  return [H[0] >> 24 & 0xff, H[0] >> 16 & 0xff, H[0] >> 8 & 0xff, H[0] & 0xff, H[1] >> 24 & 0xff, H[1] >> 16 & 0xff, H[1] >> 8 & 0xff, H[1] & 0xff, H[2] >> 24 & 0xff, H[2] >> 16 & 0xff, H[2] >> 8 & 0xff, H[2] & 0xff, H[3] >> 24 & 0xff, H[3] >> 16 & 0xff, H[3] >> 8 & 0xff, H[3] & 0xff, H[4] >> 24 & 0xff, H[4] >> 16 & 0xff, H[4] >> 8 & 0xff, H[4] & 0xff];
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (sha1);

/***/ }),

/***/ "./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/stringify.js":
/*!*************************************************************************************************!*\
  !*** ./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/stringify.js ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _validate_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./validate.js */ "./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/validate.js");

/**
 * Convert array of 16 byte values to UUID string format of the form:
 * XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX
 */

var byteToHex = [];

for (var i = 0; i < 256; ++i) {
  byteToHex.push((i + 0x100).toString(16).substr(1));
}

function stringify(arr) {
  var offset = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
  // Note: Be careful editing this code!  It's been tuned for performance
  // and works in ways you may not expect. See https://github.com/uuidjs/uuid/pull/434
  var uuid = (byteToHex[arr[offset + 0]] + byteToHex[arr[offset + 1]] + byteToHex[arr[offset + 2]] + byteToHex[arr[offset + 3]] + '-' + byteToHex[arr[offset + 4]] + byteToHex[arr[offset + 5]] + '-' + byteToHex[arr[offset + 6]] + byteToHex[arr[offset + 7]] + '-' + byteToHex[arr[offset + 8]] + byteToHex[arr[offset + 9]] + '-' + byteToHex[arr[offset + 10]] + byteToHex[arr[offset + 11]] + byteToHex[arr[offset + 12]] + byteToHex[arr[offset + 13]] + byteToHex[arr[offset + 14]] + byteToHex[arr[offset + 15]]).toLowerCase(); // Consistency check for valid UUID.  If this throws, it's likely due to one
  // of the following:
  // - One or more input array values don't map to a hex octet (leading to
  // "undefined" in the uuid)
  // - Invalid input values for the RFC `version` or `variant` fields

  if (!(0,_validate_js__WEBPACK_IMPORTED_MODULE_0__["default"])(uuid)) {
    throw TypeError('Stringified UUID is invalid');
  }

  return uuid;
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (stringify);

/***/ }),

/***/ "./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/v1.js":
/*!******************************************************************************************!*\
  !*** ./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/v1.js ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _rng_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./rng.js */ "./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/rng.js");
/* harmony import */ var _stringify_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./stringify.js */ "./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/stringify.js");

 // **`v1()` - Generate time-based UUID**
//
// Inspired by https://github.com/LiosK/UUID.js
// and http://docs.python.org/library/uuid.html

var _nodeId;

var _clockseq; // Previous uuid creation time


var _lastMSecs = 0;
var _lastNSecs = 0; // See https://github.com/uuidjs/uuid for API details

function v1(options, buf, offset) {
  var i = buf && offset || 0;
  var b = buf || new Array(16);
  options = options || {};
  var node = options.node || _nodeId;
  var clockseq = options.clockseq !== undefined ? options.clockseq : _clockseq; // node and clockseq need to be initialized to random values if they're not
  // specified.  We do this lazily to minimize issues related to insufficient
  // system entropy.  See #189

  if (node == null || clockseq == null) {
    var seedBytes = options.random || (options.rng || _rng_js__WEBPACK_IMPORTED_MODULE_0__["default"])();

    if (node == null) {
      // Per 4.5, create and 48-bit node id, (47 random bits + multicast bit = 1)
      node = _nodeId = [seedBytes[0] | 0x01, seedBytes[1], seedBytes[2], seedBytes[3], seedBytes[4], seedBytes[5]];
    }

    if (clockseq == null) {
      // Per 4.2.2, randomize (14 bit) clockseq
      clockseq = _clockseq = (seedBytes[6] << 8 | seedBytes[7]) & 0x3fff;
    }
  } // UUID timestamps are 100 nano-second units since the Gregorian epoch,
  // (1582-10-15 00:00).  JSNumbers aren't precise enough for this, so
  // time is handled internally as 'msecs' (integer milliseconds) and 'nsecs'
  // (100-nanoseconds offset from msecs) since unix epoch, 1970-01-01 00:00.


  var msecs = options.msecs !== undefined ? options.msecs : Date.now(); // Per 4.2.1.2, use count of uuid's generated during the current clock
  // cycle to simulate higher resolution clock

  var nsecs = options.nsecs !== undefined ? options.nsecs : _lastNSecs + 1; // Time since last uuid creation (in msecs)

  var dt = msecs - _lastMSecs + (nsecs - _lastNSecs) / 10000; // Per 4.2.1.2, Bump clockseq on clock regression

  if (dt < 0 && options.clockseq === undefined) {
    clockseq = clockseq + 1 & 0x3fff;
  } // Reset nsecs if clock regresses (new clockseq) or we've moved onto a new
  // time interval


  if ((dt < 0 || msecs > _lastMSecs) && options.nsecs === undefined) {
    nsecs = 0;
  } // Per 4.2.1.2 Throw error if too many uuids are requested


  if (nsecs >= 10000) {
    throw new Error("uuid.v1(): Can't create more than 10M uuids/sec");
  }

  _lastMSecs = msecs;
  _lastNSecs = nsecs;
  _clockseq = clockseq; // Per 4.1.4 - Convert from unix epoch to Gregorian epoch

  msecs += 12219292800000; // `time_low`

  var tl = ((msecs & 0xfffffff) * 10000 + nsecs) % 0x100000000;
  b[i++] = tl >>> 24 & 0xff;
  b[i++] = tl >>> 16 & 0xff;
  b[i++] = tl >>> 8 & 0xff;
  b[i++] = tl & 0xff; // `time_mid`

  var tmh = msecs / 0x100000000 * 10000 & 0xfffffff;
  b[i++] = tmh >>> 8 & 0xff;
  b[i++] = tmh & 0xff; // `time_high_and_version`

  b[i++] = tmh >>> 24 & 0xf | 0x10; // include version

  b[i++] = tmh >>> 16 & 0xff; // `clock_seq_hi_and_reserved` (Per 4.2.2 - include variant)

  b[i++] = clockseq >>> 8 | 0x80; // `clock_seq_low`

  b[i++] = clockseq & 0xff; // `node`

  for (var n = 0; n < 6; ++n) {
    b[i + n] = node[n];
  }

  return buf || (0,_stringify_js__WEBPACK_IMPORTED_MODULE_1__["default"])(b);
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (v1);

/***/ }),

/***/ "./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/v3.js":
/*!******************************************************************************************!*\
  !*** ./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/v3.js ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _v35_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./v35.js */ "./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/v35.js");
/* harmony import */ var _md5_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./md5.js */ "./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/md5.js");


var v3 = (0,_v35_js__WEBPACK_IMPORTED_MODULE_0__["default"])('v3', 0x30, _md5_js__WEBPACK_IMPORTED_MODULE_1__["default"]);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (v3);

/***/ }),

/***/ "./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/v35.js":
/*!*******************************************************************************************!*\
  !*** ./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/v35.js ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DNS: () => (/* binding */ DNS),
/* harmony export */   URL: () => (/* binding */ URL),
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _stringify_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./stringify.js */ "./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/stringify.js");
/* harmony import */ var _parse_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./parse.js */ "./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/parse.js");



function stringToBytes(str) {
  str = unescape(encodeURIComponent(str)); // UTF8 escape

  var bytes = [];

  for (var i = 0; i < str.length; ++i) {
    bytes.push(str.charCodeAt(i));
  }

  return bytes;
}

var DNS = '6ba7b810-9dad-11d1-80b4-00c04fd430c8';
var URL = '6ba7b811-9dad-11d1-80b4-00c04fd430c8';
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__(name, version, hashfunc) {
  function generateUUID(value, namespace, buf, offset) {
    if (typeof value === 'string') {
      value = stringToBytes(value);
    }

    if (typeof namespace === 'string') {
      namespace = (0,_parse_js__WEBPACK_IMPORTED_MODULE_1__["default"])(namespace);
    }

    if (namespace.length !== 16) {
      throw TypeError('Namespace must be array-like (16 iterable integer values, 0-255)');
    } // Compute hash of namespace and value, Per 4.3
    // Future: Use spread syntax when supported on all platforms, e.g. `bytes =
    // hashfunc([...namespace, ... value])`


    var bytes = new Uint8Array(16 + value.length);
    bytes.set(namespace);
    bytes.set(value, namespace.length);
    bytes = hashfunc(bytes);
    bytes[6] = bytes[6] & 0x0f | version;
    bytes[8] = bytes[8] & 0x3f | 0x80;

    if (buf) {
      offset = offset || 0;

      for (var i = 0; i < 16; ++i) {
        buf[offset + i] = bytes[i];
      }

      return buf;
    }

    return (0,_stringify_js__WEBPACK_IMPORTED_MODULE_0__["default"])(bytes);
  } // Function#name is not settable on some platforms (#270)


  try {
    generateUUID.name = name; // eslint-disable-next-line no-empty
  } catch (err) {} // For CommonJS default export support


  generateUUID.DNS = DNS;
  generateUUID.URL = URL;
  return generateUUID;
}

/***/ }),

/***/ "./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/v4.js":
/*!******************************************************************************************!*\
  !*** ./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/v4.js ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _rng_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./rng.js */ "./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/rng.js");
/* harmony import */ var _stringify_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./stringify.js */ "./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/stringify.js");



function v4(options, buf, offset) {
  options = options || {};
  var rnds = options.random || (options.rng || _rng_js__WEBPACK_IMPORTED_MODULE_0__["default"])(); // Per 4.4, set bits for version and `clock_seq_hi_and_reserved`

  rnds[6] = rnds[6] & 0x0f | 0x40;
  rnds[8] = rnds[8] & 0x3f | 0x80; // Copy bytes to buffer, if provided

  if (buf) {
    offset = offset || 0;

    for (var i = 0; i < 16; ++i) {
      buf[offset + i] = rnds[i];
    }

    return buf;
  }

  return (0,_stringify_js__WEBPACK_IMPORTED_MODULE_1__["default"])(rnds);
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (v4);

/***/ }),

/***/ "./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/v5.js":
/*!******************************************************************************************!*\
  !*** ./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/v5.js ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _v35_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./v35.js */ "./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/v35.js");
/* harmony import */ var _sha1_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./sha1.js */ "./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/sha1.js");


var v5 = (0,_v35_js__WEBPACK_IMPORTED_MODULE_0__["default"])('v5', 0x50, _sha1_js__WEBPACK_IMPORTED_MODULE_1__["default"]);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (v5);

/***/ }),

/***/ "./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/validate.js":
/*!************************************************************************************************!*\
  !*** ./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/validate.js ***!
  \************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _regex_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./regex.js */ "./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/regex.js");


function validate(uuid) {
  return typeof uuid === 'string' && _regex_js__WEBPACK_IMPORTED_MODULE_0__["default"].test(uuid);
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (validate);

/***/ }),

/***/ "./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/version.js":
/*!***********************************************************************************************!*\
  !*** ./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/version.js ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _validate_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./validate.js */ "./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/validate.js");


function version(uuid) {
  if (!(0,_validate_js__WEBPACK_IMPORTED_MODULE_0__["default"])(uuid)) {
    throw TypeError('Invalid UUID');
  }

  return parseInt(uuid.substr(14, 1), 16);
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (version);

/***/ }),

/***/ "./node_modules/@ms-fabric/workload-client/src/workload-client.js":
/*!************************************************************************!*\
  !*** ./node_modules/@ms-fabric/workload-client/src/workload-client.js ***!
  \************************************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

(function (global, factory) {
     true ? factory(exports, __webpack_require__(/*! uuid */ "./node_modules/@ms-fabric/workload-client/node_modules/uuid/dist/esm-browser/index.js"), __webpack_require__(/*! bowser */ "./node_modules/bowser/es5.js")) :
    0;
})(this, (function (exports, uuid, bowser) { 'use strict';

    function _interopNamespaceDefault(e) {
        var n = Object.create(null);
        if (e) {
            Object.keys(e).forEach(function (k) {
                if (k !== 'default') {
                    var d = Object.getOwnPropertyDescriptor(e, k);
                    Object.defineProperty(n, k, d.get ? d : {
                        enumerable: true,
                        get: function () { return e[k]; }
                    });
                }
            });
        }
        n.default = e;
        return Object.freeze(n);
    }

    var uuid__namespace = /*#__PURE__*/_interopNamespaceDefault(uuid);
    var bowser__namespace = /*#__PURE__*/_interopNamespaceDefault(bowser);

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    /**
     * @description An enum representing core permissions
     */
    exports.Permissions = void 0;
    (function (Permissions) {
        Permissions[Permissions["None"] = 0] = "None";
        Permissions[Permissions["Read"] = 1] = "Read";
        Permissions[Permissions["Write"] = 2] = "Write";
        Permissions[Permissions["ReShare"] = 4] = "ReShare";
        Permissions[Permissions["Explore"] = 8] = "Explore";
        Permissions[Permissions["CopyOnWrite"] = 16] = "CopyOnWrite";
        Permissions[Permissions["WriteCheckRelaxForReadOnlyGroup"] = 32] = "WriteCheckRelaxForReadOnlyGroup";
        Permissions[Permissions["Execute"] = 64] = "Execute";
        Permissions[Permissions["Subscribe"] = 128] = "Subscribe";
        Permissions[Permissions["ReadExplore"] = 9] = "ReadExplore";
        Permissions[Permissions["ReadWrite"] = 3] = "ReadWrite";
        Permissions[Permissions["ReadWriteCheckRelaxForReadOnlyGroup"] = 35] = "ReadWriteCheckRelaxForReadOnlyGroup";
        Permissions[Permissions["ReadReshare"] = 5] = "ReadReshare";
        Permissions[Permissions["All"] = 7] = "All";
    })(exports.Permissions || (exports.Permissions = {}));
    /**
     * @description An enum representing the scope of link sharing
     */
    exports.SharingLinkType = void 0;
    (function (SharingLinkType) {
        SharingLinkType["TenantOnly"] = "TenantOnly";
        SharingLinkType["SpecificPeople"] = "SpecificPeople";
        SharingLinkType["ExistingAccess"] = "ExistingAccess";
    })(exports.SharingLinkType || (exports.SharingLinkType = {}));

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    const DefaultWorkloadClientConfig = {
        workloadHostWindow: window.parent,
    };

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    /**
     * @description An enum of all valid display clolumn
     */
    exports.DisplayColumn = void 0;
    (function (DisplayColumn) {
        DisplayColumn["Expand"] = "expand";
        DisplayColumn["Icon"] = "icon";
        DisplayColumn["Name"] = "name";
        DisplayColumn["Type"] = "type";
        DisplayColumn["Endorsement"] = "endorsement";
        DisplayColumn["Owner"] = "owner";
        DisplayColumn["Workspace"] = "workspaceName";
        DisplayColumn["LastRefreshed"] = "lastRefreshed";
        DisplayColumn["Sensitivity"] = "sensitivity";
        DisplayColumn["LastAccessed"] = "lastAccessed";
        DisplayColumn["NextRefresh"] = "nextRefresh";
        DisplayColumn["Organization"] = "organization";
        DisplayColumn["Region"] = "region";
        DisplayColumn["Recent"] = "recent";
    })(exports.DisplayColumn || (exports.DisplayColumn = {}));

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    exports.GatewayType = void 0;
    (function (GatewayType) {
        GatewayType["Resource"] = "Resource";
        GatewayType["Personal"] = "Personal";
        GatewayType["VirtualNetwork"] = "VirtualNetwork";
        GatewayType["TenantCloud"] = "TenantCloud";
    })(exports.GatewayType || (exports.GatewayType = {}));
    var BooleanFilter;
    (function (BooleanFilter) {
        BooleanFilter[BooleanFilter["Both"] = 0] = "Both";
        BooleanFilter[BooleanFilter["True"] = 1] = "True";
        BooleanFilter[BooleanFilter["False"] = 2] = "False";
    })(BooleanFilter || (BooleanFilter = {}));

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    /**
     * @description An enum of all valid datahub filter type
     */
    exports.DatahubFilterType = void 0;
    (function (DatahubFilterType) {
        DatahubFilterType["domain"] = "domain";
        DatahubFilterType["workspace"] = "workspace";
        DatahubFilterType["fabricCreateShortcut"] = "fabricCreateShortcut";
        DatahubFilterType["fabricRegion"] = "FabricRegion";
    })(exports.DatahubFilterType || (exports.DatahubFilterType = {}));

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    /**
     * @description An enum of all valid datahub list pivot
     */
    exports.DatahubListPivot = void 0;
    (function (DatahubListPivot) {
        DatahubListPivot[DatahubListPivot["All"] = 0] = "All";
        DatahubListPivot[DatahubListPivot["MyData"] = 1] = "MyData";
        DatahubListPivot[DatahubListPivot["TrustedInYourOrg"] = 2] = "TrustedInYourOrg";
        /**
         * @deprecated this tab is not in use - ThisWorkspace
         */
        DatahubListPivot[DatahubListPivot["ThisWorkspace"] = 3] = "ThisWorkspace";
        DatahubListPivot[DatahubListPivot["ExternalDatasets"] = 4] = "ExternalDatasets";
        DatahubListPivot[DatahubListPivot["Recommended"] = 5] = "Recommended";
        DatahubListPivot[DatahubListPivot["Recent"] = 6] = "Recent";
        DatahubListPivot[DatahubListPivot["Favorites"] = 7] = "Favorites";
    })(exports.DatahubListPivot || (exports.DatahubListPivot = {}));

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    /**
     * @description An enum of datahub relevant control tokens - a minimal version of the definitions of PowerBI theming tokens
     * @references fabric\libs\theme-manager\src\lib\themes\json\fluent-no-header-teal.json
     */
    exports.ControlTokens = void 0;
    (function (ControlTokens) {
        ControlTokens[ControlTokens["colorNeutralBackground1"] = 0] = "colorNeutralBackground1";
        ControlTokens[ControlTokens["colorNeutralBackground1Hover"] = 1] = "colorNeutralBackground1Hover";
        /**
         * @description filter menu item pressed background color
         */
        ControlTokens[ControlTokens["colorNeutralBackground1Pressed"] = 2] = "colorNeutralBackground1Pressed";
        ControlTokens[ControlTokens["colorNeutralBackground1Selected"] = 3] = "colorNeutralBackground1Selected";
        ControlTokens[ControlTokens["colorNeutralForeground1"] = 4] = "colorNeutralForeground1";
        ControlTokens[ControlTokens["colorNeutralStroke1Pressed"] = 5] = "colorNeutralStroke1Pressed";
        ControlTokens[ControlTokens["colorNeutralStrokeFocus1"] = 6] = "colorNeutralStrokeFocus1";
        ControlTokens[ControlTokens["colorNeutralStroke1Selected"] = 7] = "colorNeutralStroke1Selected";
        ControlTokens[ControlTokens["colorNeutralStroke1"] = 8] = "colorNeutralStroke1";
        ControlTokens[ControlTokens["colorNeutralStroke1Hover"] = 9] = "colorNeutralStroke1Hover";
        /**
         * @description focus border color
         */
        ControlTokens[ControlTokens["colorNeutralStrokeFocus2"] = 10] = "colorNeutralStrokeFocus2";
        /**
         * @description filter menu text + icons(expend + clear + X in search box) color (except clear all text)
         */
        ControlTokens[ControlTokens["colorNeutralForeground2"] = 11] = "colorNeutralForeground2";
        /**
         * @description filter menu item text color - hover
         */
        ControlTokens[ControlTokens["colorNeutralForeground2Hover"] = 12] = "colorNeutralForeground2Hover";
        /**
         * @description filter menu text + icons(expend + clear + unchecked checkbox) pressed color
         */
        ControlTokens[ControlTokens["colorNeutralForeground2Pressed"] = 13] = "colorNeutralForeground2Pressed";
        /**
         * @description checkbox + search icon color
         */
        ControlTokens[ControlTokens["colorNeutralForeground3"] = 14] = "colorNeutralForeground3";
        /**
         * @description search input placeholder
         */
        ControlTokens[ControlTokens["colorNeutralForeground4"] = 15] = "colorNeutralForeground4";
        /**
         * @description search box focus border
         */
        ControlTokens[ControlTokens["colorNeutralStrokeAccessibleSelected"] = 16] = "colorNeutralStrokeAccessibleSelected";
        /**
         * @description filter + search background rest
         */
        ControlTokens[ControlTokens["colorNeutralForegroundInverted"] = 17] = "colorNeutralForegroundInverted";
        ControlTokens[ControlTokens["colorNeutralForegroundDisabled"] = 18] = "colorNeutralForegroundDisabled";
        ControlTokens[ControlTokens["colorNeutralBackgroundDisabled"] = 19] = "colorNeutralBackgroundDisabled";
        ControlTokens[ControlTokens["colorNeutralStrokeDisabled"] = 20] = "colorNeutralStrokeDisabled";
        ControlTokens[ControlTokens["colorNeutralForeground2BrandHover"] = 21] = "colorNeutralForeground2BrandHover";
        ControlTokens[ControlTokens["colorNeutralForeground2BrandSelected"] = 22] = "colorNeutralForeground2BrandSelected";
        ControlTokens[ControlTokens["colorBrandForeground2"] = 23] = "colorBrandForeground2";
        ControlTokens[ControlTokens["colorSubtleBackgroundHover"] = 24] = "colorSubtleBackgroundHover";
        ControlTokens[ControlTokens["colorSubtleBackgroundPressed"] = 25] = "colorSubtleBackgroundPressed";
        /**
         * @description hover on filter trigger button - text color
         */
        ControlTokens[ControlTokens["buttonDefaultHoverContentColor"] = 26] = "buttonDefaultHoverContentColor";
        /**
         * @description focus on filter trigger button and menu items - background color
         */
        ControlTokens[ControlTokens["focusBoxShadowWhiteColor"] = 27] = "focusBoxShadowWhiteColor";
        /**
         * @description hover on collapsable field in the filter (type) - background color
         */
        ControlTokens[ControlTokens["neutralLighterColor"] = 28] = "neutralLighterColor";
        /**
         * @description ws group icon background color
         */
        ControlTokens[ControlTokens["colorNeutralBackground6"] = 29] = "colorNeutralBackground6";
        /**
         * @description empty state button colors
         */
        ControlTokens[ControlTokens["colorBrandBackground"] = 30] = "colorBrandBackground";
        ControlTokens[ControlTokens["colorNeutralForegroundOnBrand"] = 31] = "colorNeutralForegroundOnBrand";
        ControlTokens[ControlTokens["colorBrandBackgroundHover"] = 32] = "colorBrandBackgroundHover";
        ControlTokens[ControlTokens["colorBrandBackgroundSelected"] = 33] = "colorBrandBackgroundSelected";
        /**
         * @description shimmer background color
         */
        ControlTokens[ControlTokens["colorNeutralStencil1"] = 34] = "colorNeutralStencil1";
        /**
         * @description focus on row - background color
         */
        ControlTokens[ControlTokens["colorNeutralBackground4Hover"] = 35] = "colorNeutralBackground4Hover";
        /**
         * @description filter menu box shadow colors
         */
        ControlTokens[ControlTokens["colorNeutralShadowAmbient"] = 36] = "colorNeutralShadowAmbient";
        ControlTokens[ControlTokens["colorNeutralShadowKey"] = 37] = "colorNeutralShadowKey";
        ControlTokens[ControlTokens["fluentThemeLinkcolor"] = 38] = "fluentThemeLinkcolor";
    })(exports.ControlTokens || (exports.ControlTokens = {}));
    /**
     * @description An enum of all valid supported datahub style proprties
     */
    exports.SupportedDatahubStyleProperties = void 0;
    (function (SupportedDatahubStyleProperties) {
        SupportedDatahubStyleProperties["searchHighlightColor"] = "searchHighlightColor";
        SupportedDatahubStyleProperties["lighterDialogBackgroundColor"] = "lighterDialogBackgroundColor";
        SupportedDatahubStyleProperties["shimmerBackgroundColor"] = "shimmerBackgroundColor";
        SupportedDatahubStyleProperties["shimmerColor"] = "shimmerColor";
        /* row */
        SupportedDatahubStyleProperties["selectedRowColor"] = "selectedRowColor";
        SupportedDatahubStyleProperties["hoverRowColor"] = "hoverRowColor";
        SupportedDatahubStyleProperties["rowBorderColor"] = "rowBorderColor";
        SupportedDatahubStyleProperties["rowForegroundColor"] = "rowForegroundColor";
        /* pill */
        SupportedDatahubStyleProperties["pillColor"] = "pillColor";
        SupportedDatahubStyleProperties["pillBorderColor"] = "pillBorderColor";
        SupportedDatahubStyleProperties["pillBackgroundColor"] = "pillBackgroundColor";
        SupportedDatahubStyleProperties["activePillColor"] = "activePillColor";
        SupportedDatahubStyleProperties["activePillBorderColor"] = "activePillBorderColor";
        SupportedDatahubStyleProperties["activePillBackgroundColor"] = "activePillBackgroundColor";
        SupportedDatahubStyleProperties["pillHoverBackgroundColor"] = "pillHoverBackgroundColor";
        SupportedDatahubStyleProperties["activePillHoverBackgroundColor"] = "activePillHoverBackgroundColor";
        /* endorsement */
        SupportedDatahubStyleProperties["endorsementForegroundColor"] = "endorsementForegroundColor";
        /* explorer - datahub workspace navigation*/
        SupportedDatahubStyleProperties["hoverDWBColor"] = "hoverDWBColor";
        SupportedDatahubStyleProperties["pressedDWBColor"] = "pressedDWBColor";
        SupportedDatahubStyleProperties["selectedDWBColor"] = "selectedDWBColor";
        SupportedDatahubStyleProperties["foregroundWSExpandIconColor"] = "foregroundWSExpandIconColor";
        SupportedDatahubStyleProperties["foregroundWSTitleColor"] = "foregroundWSTitleColor";
        SupportedDatahubStyleProperties["foregroundWSSubTitleColor"] = "foregroundWSSubTitleColor";
        SupportedDatahubStyleProperties["foregroundDWBColor"] = "foregroundDWBColor";
        SupportedDatahubStyleProperties["foregroundDWBIconColor"] = "foregroundDWBIconColor";
    })(exports.SupportedDatahubStyleProperties || (exports.SupportedDatahubStyleProperties = {}));

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    /**
     * @description An enum of all valid dialog types
     */
    exports.DialogType = void 0;
    (function (DialogType) {
        DialogType[DialogType["IFrame"] = 0] = "IFrame";
        DialogType[DialogType["MessageBox"] = 1] = "MessageBox";
    })(exports.DialogType || (exports.DialogType = {}));
    /**
     * @description An enum of all valid button types
     */
    exports.ButtonType = void 0;
    (function (ButtonType) {
        ButtonType[ButtonType["Default"] = 0] = "Default";
        ButtonType[ButtonType["Primary"] = 1] = "Primary";
    })(exports.ButtonType || (exports.ButtonType = {}));

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    /**
     * @description An enum of all valid error dialog widths
     */
    exports.ErrorDialogWidth = void 0;
    (function (ErrorDialogWidth) {
        ErrorDialogWidth["Small"] = "288px";
        ErrorDialogWidth["Medium"] = "576px";
        ErrorDialogWidth["Large"] = "864px";
        ErrorDialogWidth["XLarge"] = "1440px";
    })(exports.ErrorDialogWidth || (exports.ErrorDialogWidth = {}));
    /**
     * @description CapacitySkuTier refers to the pricing and resource allocation level for a specific service in Azure.
     * It is used to define the level of resources and capabilities available for a particular service.
     */
    exports.CapacitySkuTier = void 0;
    (function (CapacitySkuTier) {
        CapacitySkuTier[CapacitySkuTier["Premium"] = 1] = "Premium";
        CapacitySkuTier[CapacitySkuTier["Embedded"] = 2] = "Embedded";
        CapacitySkuTier[CapacitySkuTier["PBIE_Azure"] = 3] = "PBIE_Azure";
        CapacitySkuTier[CapacitySkuTier["PremiumPerUser"] = 4] = "PremiumPerUser";
        CapacitySkuTier[CapacitySkuTier["SharedOnPremium"] = 6] = "SharedOnPremium";
        CapacitySkuTier[CapacitySkuTier["DataCapacityTrial"] = 7] = "DataCapacityTrial";
        CapacitySkuTier[CapacitySkuTier["DataCapacity"] = 8] = "DataCapacity";
        CapacitySkuTier[CapacitySkuTier["DataCapacityLimited"] = 9] = "DataCapacityLimited";
    })(exports.CapacitySkuTier || (exports.CapacitySkuTier = {}));
    /**
     * @description An enum of all valid error sources
     */
    exports.ErrorSource = void 0;
    (function (ErrorSource) {
        ErrorSource["FabricWorkload"] = "FabricWorkload";
        ErrorSource["WorkloadHost"] = "WorkloadHost";
        ErrorSource["WorkloadSDK"] = "WorkloadSDK";
    })(exports.ErrorSource || (exports.ErrorSource = {}));
    /**
     * @description An enum of all valid error kinds
     */
    exports.ErrorKind = void 0;
    (function (ErrorKind) {
        ErrorKind[ErrorKind["Error"] = 1] = "Error";
        ErrorKind[ErrorKind["Fatal"] = 2] = "Fatal";
        ErrorKind[ErrorKind["Warning"] = 3] = "Warning";
        ErrorKind[ErrorKind["Custom"] = 4] = "Custom";
    })(exports.ErrorKind || (exports.ErrorKind = {}));

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    /**
     *  @description A list of predefined events that will be exposed to all consumers when they are emitted.
     */
    const PreDefinedEventName = ['loaded', 'rendered', 'error'];

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    /** @internal */
    exports.PreDefinedWorkloadAction = void 0;
    (function (PreDefinedWorkloadAction) {
        PreDefinedWorkloadAction["getItemActionDynamicAttrs"] = "getItemActionDynamicAttrs";
        PreDefinedWorkloadAction["getHelpPaneData"] = "getHelpPaneData";
    })(exports.PreDefinedWorkloadAction || (exports.PreDefinedWorkloadAction = {}));

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    /**
     * @description An enum of all valid types of the message bar
     */
    exports.MessageBarType = void 0;
    (function (MessageBarType) {
        MessageBarType[MessageBarType["Information"] = 0] = "Information";
        MessageBarType[MessageBarType["Error"] = 1] = "Error";
        MessageBarType[MessageBarType["Warning"] = 2] = "Warning";
        MessageBarType[MessageBarType["Success"] = 3] = "Success";
        // SevereWarning = 4 has been deprecated
        MessageBarType[MessageBarType["Blocked"] = 5] = "Blocked";
        MessageBarType[MessageBarType["Copilot"] = 6] = "Copilot";
        MessageBarType[MessageBarType["Promotion"] = 7] = "Promotion";
    })(exports.MessageBarType || (exports.MessageBarType = {}));

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    /**
     * @description An enum of all valid notification types
     */
    exports.NotificationType = void 0;
    (function (NotificationType) {
        /** @deprecated */
        NotificationType[NotificationType["Default"] = 0] = "Default";
        /** @deprecated */
        NotificationType[NotificationType["Alert"] = 1] = "Alert";
        NotificationType[NotificationType["Error"] = 2] = "Error";
        NotificationType[NotificationType["Loading"] = 3] = "Loading";
        NotificationType[NotificationType["Success"] = 4] = "Success";
        NotificationType[NotificationType["Warning"] = 5] = "Warning";
        NotificationType[NotificationType["Share"] = 6] = "Share";
        NotificationType[NotificationType["Info"] = 7] = "Info";
        /** @deprecated */
        NotificationType[NotificationType["NoIcon"] = 8] = "NoIcon";
        /** @deprecated */
        NotificationType[NotificationType["Delete"] = 10] = "Delete";
        /** @deprecated */
        NotificationType[NotificationType["Add"] = 11] = "Add";
        /** @deprecated */
        NotificationType[NotificationType["Feedback"] = 12] = "Feedback";
    })(exports.NotificationType || (exports.NotificationType = {}));
    /**
     * @description An enum of all valid notification toast durations
     */
    exports.NotificationToastDuration = void 0;
    (function (NotificationToastDuration) {
        NotificationToastDuration["Short"] = "Short";
        NotificationToastDuration["Medium"] = "Medium";
        NotificationToastDuration["Long"] = "Long";
    })(exports.NotificationToastDuration || (exports.NotificationToastDuration = {}));
    /**
     * @description An enum of all valid notification button types
     */
    exports.OpenNotificationButtonType = void 0;
    (function (OpenNotificationButtonType) {
        OpenNotificationButtonType[OpenNotificationButtonType["Primary"] = 1] = "Primary";
        OpenNotificationButtonType[OpenNotificationButtonType["Secondary"] = 2] = "Secondary";
        OpenNotificationButtonType[OpenNotificationButtonType["Link"] = 3] = "Link";
    })(exports.OpenNotificationButtonType || (exports.OpenNotificationButtonType = {}));

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    exports.OnelakeExplorerType = void 0;
    (function (OnelakeExplorerType) {
        OnelakeExplorerType["Tables"] = "Tables";
        OnelakeExplorerType["Files"] = "Files";
    })(exports.OnelakeExplorerType || (exports.OnelakeExplorerType = {}));
    exports.OnelakeExplorerCheckMode = void 0;
    (function (OnelakeExplorerCheckMode) {
        OnelakeExplorerCheckMode[OnelakeExplorerCheckMode["None"] = 0] = "None";
        OnelakeExplorerCheckMode[OnelakeExplorerCheckMode["Single"] = 1] = "Single";
        OnelakeExplorerCheckMode[OnelakeExplorerCheckMode["Multi"] = 2] = "Multi";
    })(exports.OnelakeExplorerCheckMode || (exports.OnelakeExplorerCheckMode = {}));

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    /**
     * @description An enum of all valid host application types
     */
    exports.WorkloadHostApp = void 0;
    (function (WorkloadHostApp) {
        WorkloadHostApp[WorkloadHostApp["FabricWebApp"] = 0] = "FabricWebApp";
        WorkloadHostApp[WorkloadHostApp["EmbedApp"] = 1] = "EmbedApp";
    })(exports.WorkloadHostApp || (exports.WorkloadHostApp = {}));

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    /** @internal */
    exports.LifecycleEventType = void 0;
    (function (LifecycleEventType) {
        LifecycleEventType[LifecycleEventType["InitSucceeded"] = 1] = "InitSucceeded";
        LifecycleEventType[LifecycleEventType["InitFailed"] = 2] = "InitFailed";
    })(exports.LifecycleEventType || (exports.LifecycleEventType = {}));
    /** @internal */
    exports.WorkloadLoadEventType = void 0;
    (function (WorkloadLoadEventType) {
        WorkloadLoadEventType["WorkloadBootstrap"] = "WorkloadBootstrap";
        WorkloadLoadEventType["WorkloadBootstrapStart"] = "WorkloadBootstrapStart";
    })(exports.WorkloadLoadEventType || (exports.WorkloadLoadEventType = {}));

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    /**
     * @description An enum of all valid modes for opening an workload UI
     */
    exports.OpenMode = void 0;
    (function (OpenMode) {
        OpenMode[OpenMode["Append"] = 1] = "Append";
        OpenMode[OpenMode["ReplaceAll"] = 2] = "ReplaceAll";
    })(exports.OpenMode || (exports.OpenMode = {}));
    /**
     * @description An enum of all valid modes for closing an workload UI
     */
    exports.CloseMode = void 0;
    (function (CloseMode) {
        CloseMode[CloseMode["PopOne"] = 1] = "PopOne";
        CloseMode[CloseMode["ClearAll"] = 2] = "ClearAll";
    })(exports.CloseMode || (exports.CloseMode = {}));

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    const EXT_META_KEY = Symbol.for('WORKLOAD_META');
    const iframeIdKey = '__iframeId';
    const iframeTypeKey = '__iframeType';
    const environmentNameKey = '__environmentName';
    const workloadNameKey = '__extensionName';
    const workloadHostOriginKey = '__extensionHostOrigin';
    const bootstrapPathKey = '__bootstrapPath';
    const unminKey = '__unmin';
    const useCDNKey = '__useCDN';
    const cdnFallbackKey = '__cdnFallbackTime';
    const parallelLoadKey = '__parallelLoadingEnabled';
    const errorHandlingKey = '__eh';
    const eagerLoadTimeoutFallbackKey = '__el';

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    /**
     * @description
     * This class is responsible for loading and providing metadata for workloads, including information such as iframe ID and type.
     */
    class WorkloadMetaLoader {
        constructor(target = window) {
            this.target = target;
        }
        /**
         * @description
         * A static method to load the workload metadata for a given workload window
         * @param target The target workload window
         * @returns Loaded workload metadata
         */
        static Load(target) {
            return new this(target).load();
        }
        /**
         * @description
         * A method to load the workload metadata
         * @returns Loaded workload metadata
         */
        load() {
            return this.meta || (this.meta = this.tryLoad());
        }
        get meta() {
            return this.target[EXT_META_KEY];
        }
        set meta(meta) {
            Object.defineProperty(this.target, EXT_META_KEY, {
                get: () => meta,
                enumerable: false,
                configurable: false,
            });
        }
        tryLoad() {
            const params = new URLSearchParams(this.target.location.search);
            const raw = {
                iframeId: params.get(iframeIdKey),
                iframeType: params.get(iframeTypeKey),
                environmentName: params.get(environmentNameKey),
                workloadName: params.get(workloadNameKey),
                workloadHostOrigin: params.get(workloadHostOriginKey),
                bootstrapPath: params.get(bootstrapPathKey),
                unmin: params.get(unminKey) === 'true',
                useCDN: params.get(useCDNKey) === 'true',
                cdnFallbackTime: params.get(cdnFallbackKey),
                parallelLoadingEnabled: params.get(parallelLoadKey) === 'true',
                errorHandlingEnabled: params.get(errorHandlingKey) === 'true',
                eagerLoadTimeoutFallbackEnabled: params.get(eagerLoadTimeoutFallbackKey) === '1',
            };
            this.assert(raw);
            return Object.freeze(raw);
        }
        // Note: update this method if meta definition changed
        assert(isMeta) {
            const meta = isMeta;
            if (meta.iframeId == null) {
                throw new Error("Empty iframeId");
            }
            if (!/^(worker|dialog|panel|page)$/.test(meta.iframeType || '')) {
                throw new Error(`Invalid uiType: "${meta.iframeType}", must be 'worker', 'page', 'panel' or 'dialog'`);
            }
            if (meta.environmentName == null) {
                throw new Error("Empty environmentName");
            }
            if (meta.workloadName == null) {
                throw new Error("Empty workloadName");
            }
            if (meta.workloadHostOrigin == null) {
                throw new Error("Empty workloadHostOrigin");
            }
            if (meta.unmin == null) {
                throw new Error("Empty unmin");
            }
            if (meta.useCDN == null) {
                throw new Error("Empty useCDN");
            }
            if (meta.parallelLoadingEnabled == null) {
                throw new Error("Empty parallelLoadingEnabled");
            }
            if (meta.errorHandlingEnabled == null) {
                throw new Error("Empty errorHandlingEnabled");
            }
            if (meta.eagerLoadTimeoutFallbackEnabled == null) {
                throw new Error("Empty eagerLoadTimeoutFallback");
            }
        }
    }

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    /**
     * @description A function that creates a message creator with a specified type and optional properties
     */
    const createMessage = (type, creator) => Object.assign(creator !== undefined
        ? (...args) => ({
            type,
            ...creator(...args),
        })
        : (props) => props !== undefined
            ? ({ type, ...props })
            : ({ type }), { type });
    /**
     * @description A function that merge tracing information into a message
     */
    const mergeTracingInfoIntoMessage = (props, tracingInfo) => {
        Object.defineProperties(props, {
            tracingInfo: {
                value: tracingInfo,
                enumerable: false, // Only allow direct access. Avoid being iterated.
            },
        });
        return props;
    };
    /**
     * @description A function that creates a message creator for workload messages with a specified type and optional properties
     */
    const createWorkloadMessage = (type) => Object.assign((props) => createMessage(type, (iframeId) => mergeTracingInfoIntoMessage({
        iframeId,
        ...props,
    }, {
        ...props?.tracingInfo,
        startTime: Date.now(),
    })), { type });
    const startPrefix = '[Start]';
    const resolvePrefix = '[Resolve]';
    const rejectPrefix = '[Reject]';
    /**
     * @description A function that creates a set of message creators for asynchronous workload messages with a specified type and optional properties
     */
    const createAsyncWorkloadMessage = (type) => ({
        start: Object.assign((props) => createMessage(`${startPrefix} ${type}`, (iframeId) => mergeTracingInfoIntoMessage({
            ...props,
            asyncId: uuid.v4(),
            iframeId,
        }, {
            ...props?.tracingInfo,
            startTime: Date.now(),
        })), { type: `${startPrefix} ${type}` }),
        resolve: Object.assign((props) => createMessage(`${resolvePrefix} ${type}`, (iframeId, asyncId, tracingInfo) => mergeTracingInfoIntoMessage({
            ...props,
            asyncId,
            iframeId,
        }, tracingInfo)), { type: `${resolvePrefix} ${type}` }),
        reject: Object.assign((props) => createMessage(`${rejectPrefix} ${type}`, (iframeId, asyncId, tracingInfo) => mergeTracingInfoIntoMessage({
            ...props,
            asyncId,
            iframeId,
        }, tracingInfo)), { type: `${rejectPrefix} ${type}` }),
    });

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    /**
     * @description A function that checks if a given message is an workload message
     * @param message The input message
     * @returns True if the message is an workload message. Otherwise, False.
     */
    function isWorkloadMessage(message) {
        const workloadMessage = message;
        return workloadMessage != null
            && typeof workloadMessage === 'object'
            && workloadMessage.type !== undefined
            && workloadMessage.iframeId !== undefined;
    }
    /**
     * @description A function that checks if a given message is an asynchronous workload message
     * @param message The input message
     * @returns True if the message is an asynchronous workload message. Otherwise, False.
     */
    function isAsyncWorkloadMessage(message) {
        return message.asyncId !== undefined;
    }
    /**
     * @description
     * A broker that facilitates duplex communication between the host and workload using postMessage
     */
    function recursiveRenameKeys(obj, reverse = false) {
    const mapping = {
        artifact: 'item',
        Artifact: 'Item',
        ARTIFACT: 'ITEM',
        trident: 'fabric',
        Trident: 'Fabric',
        TRIDENT: 'FABRIC',
        extension: 'workload',
        Extension: 'Workload',
        EXTENSION: 'WORKLOAD'
    };
    const keyMapping = reverse ? invertMapping(mapping) : mapping;

    // Set of keys that should not be transformed
    const immutableKeys = new Set(['workloadPayload']);
    const immutableObjects = new Set(['searchTokenMatchesBySection']);

    // Helper function to reverse the mapping
    function invertMapping(map) {
        const inverted = {};
        for (const key in map) {
            inverted[map[key]] = key;
        }
        return inverted;
    }

    // Helper function to transform keys based on keyMapping
    function transformName(name) {
        if (name == null || typeof name !== 'string' || immutableKeys.has(name)) {
            return name;
        }
        let transformedName = name;
        for (const mapKey in keyMapping) {
            transformedName = transformedName.replace(mapKey, keyMapping[mapKey]);
        }
        return transformedName;
    }

    // Helper function to recursively transform object keys
    function transformObject(obj) {
        if (Array.isArray(obj)) {
            return obj.map(transformObject);
        } else if (obj && typeof obj === 'object') {
            return Object.keys(obj).reduce((acc, key) => {
                if (immutableObjects.has(key)) {
                    acc[key] = obj[key];
                } else {
                    const newKey = immutableKeys.has(key) ? key : transformName(key);
                    acc[newKey] = key === 'type' ? transformName(obj[key]) : transformObject(obj[key]);
                }
                return acc;
            }, {});
        }

        return obj;
    }

    return transformObject(obj);
}

function transformMessageEvent(eventMessage, mapping) {
    const newEvent = {};
    for (const key in eventMessage) {
        newEvent[key] = eventMessage[key];
    }
    if (newEvent.data) {
        newEvent.data = recursiveRenameKeys(newEvent.data, mapping);
    }

    return newEvent;
}

class MessageBroker {
        constructor(config) {
            this.genericListeners = new Set();
            this.syncListeners = new Map();
            this.asyncListeners = new Map();
            this.asyncResponders = new Map();
            this.listener = (message) => this.onMessage(message);
            this.getTargetWindow = config.getTargetWindow;
            this.getTargetOrigin = config.getTargetOrigin;
            this.onWorkloadMessage = config.onWorkloadMessage;
            this.shouldProcessMessage = config.shouldProcessMessage;
            window.addEventListener('message', this.listener);
        }
        /**
         * @description Registers a message listener that is invoked whenever a message of any type is received by the message broker
         * @param handler The message listener
         */
        listen(handler) {
            this.genericListeners.add(handler);
        }
        /**
         * @description Registers a message listener that is invoked when a synchronous message of a specific type is received by the message broker
         * @param creator The synchronous message type to listen for
         * @param handler The message listener
         */
        listenFor(creator, handler) {
            const type = creator.type;
            const syncListeners = this.syncListeners.get(type);
            if (syncListeners) {
                syncListeners.add(handler);
            }
            else {
                this.syncListeners.set(type, new Set([handler]));
            }
        }
        /**
         * @description Registers a message listener that is invoked when an asynchronous message of a specific type is received by the message broker
         * @param creator The asynchronous message type to listen for
         * @param handler The message listener
         */
        listenForAsync(creator, handler) {
            const type = creator.start.type;
            const asyncListeners = this.asyncListeners.get(type);
            if (asyncListeners) {
                asyncListeners.add(handler);
            }
            else {
                this.asyncListeners.set(type, new Set([handler]));
            }
        }
        /**
         * @description Sends a synchronous message and returns immediately
         * @param message The synchronous messsage to send
         */
        send(message) {
            this.sendMessage(message);
        }
        /**
         * @description Sends an asynchronous message and waits until the receiver of the message responds
         * @param message The asynchronous messsage to send
         * @returns The response of the asynchronous messsage
         */
        async sendAsync(message) {
            return new Promise((resolve, reject) => {
                const { asyncId } = message;
                this.asyncResponders.set(asyncId, [
                    resolve,
                    reject,
                ]);
                this.sendMessage(message);
            });
        }
        onMessage(event) {
            event = transformMessageEvent(event);
            if (!this.shouldProcessMessage(event)) {
                return;
            }
            const message = event.data;
            if (isWorkloadMessage(message)) {
                if (this.onWorkloadMessage) {
                    this.onWorkloadMessage(event);
                }
                const isAsyncMessage = isAsyncWorkloadMessage(message);
                if (isAsyncMessage) {
                    const resolvers = this.asyncResponders.get(message.asyncId);
                    if (resolvers) {
                        const [resolve, reject] = resolvers;
                        const { type, asyncId, iframeId, tracingInfo, ...props } = message;
                        if (type.startsWith(resolvePrefix)) {
                            resolve(props);
                            this.asyncResponders.delete(message.asyncId);
                        }
                        else if (message.type.startsWith(rejectPrefix)) {
                            reject(props);
                            this.asyncResponders.delete(message.asyncId);
                        }
                    }
                }
                for (const listener of Array.from(this.genericListeners)) {
                    listener(message);
                }
                const syncListeners = this.syncListeners.get(message.type);
                if (syncListeners) {
                    for (const listener of Array.from(syncListeners)) {
                        listener(message);
                    }
                }
                if (isAsyncWorkloadMessage(message) && message.type.startsWith(startPrefix)) {
                    const asyncListeners = this.asyncListeners.get(message.type);
                    if (asyncListeners) {
                        for (const listener of Array.from(asyncListeners)) {
                            Promise.resolve(listener(message)).then((responseCreator) => this.sendMessage(responseCreator(message.iframeId, message.asyncId, message.tracingInfo)));
                        }
                    }
                }
            }
        }
            sendMessage(message) {
    const extMessage = recursiveRenameKeys(message, true);
    this.getTargetWindow(extMessage).postMessage(extMessage, this.getTargetOrigin(extMessage));
    
        }
    }

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    /**
     * @description A function that creates WorkloadClientMessageBroker instance
     * @param config Configuration settings for creating an instance of WorkloadClientMessageBroker
     * @returns The created WorkloadClientMessageBroker instance
     */
    function createWorkloadClientMessageBroker(config) {
        return new WorkloadClientMessageBrokerImpl(config.getIframeId, config.workloadHostWindow);
    }
    class WorkloadClientMessageBrokerImpl {
        constructor(getIframeId, workloadHostWindow) {
            this.getIframeId = getIframeId;
            this.broker = new MessageBroker({
                getTargetWindow: () => {
                    if (!workloadHostWindow) {
                        throw new Error('Cannot find the workload host window');
                    }
                    return workloadHostWindow;
                },
                getTargetOrigin: () => {
                    return WorkloadMetaLoader.Load().workloadHostOrigin;
                },
                shouldProcessMessage: (event) => {
                    return event.origin === WorkloadMetaLoader.Load().workloadHostOrigin;
                },
            });
        }
        listenFor(creator, handler) {
            this.broker.listenFor(creator, handler);
        }
        listenForAsync(creator, handler) {
            this.broker.listenForAsync(creator, handler);
        }
        send(message) {
            this.broker.send(message(this.getIframeId()));
        }
        async sendAsync(message) {
            return this.broker.sendAsync(message(this.getIframeId()));
        }
    }

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    /** @internal */
    exports.WorkloadMessageType = void 0;
    (function (WorkloadMessageType) {
        WorkloadMessageType["executeAction"] = "ExecuteAction";
        WorkloadMessageType["listenAction"] = "ListenAction";
        WorkloadMessageType["onAction"] = "OnAction";
        WorkloadMessageType["navigateAsync"] = "NavigateAsync";
        WorkloadMessageType["navigateWorkloadAsync"] = "NavigateWorkloadAsync";
        WorkloadMessageType["onNavigate"] = "OnNavigate";
        WorkloadMessageType["listenLeave"] = "ListenLeave";
        WorkloadMessageType["onLeave"] = "OnLeave";
        WorkloadMessageType["listenLeaveEnd"] = "ListenLeaveEnd";
        WorkloadMessageType["onLeaveEnd"] = "OnLeaveEnd";
        WorkloadMessageType["getAccessToken"] = "GetAccessToken";
        WorkloadMessageType["getSettings"] = "GetSettings";
        WorkloadMessageType["onSettingsChange"] = "OnSettingsChange";
        WorkloadMessageType["openNotification"] = "OpenNotification";
        WorkloadMessageType["hideNotification"] = "hideNotification";
        WorkloadMessageType["openPage"] = "OpenPage";
        WorkloadMessageType["openDatahubDialog"] = "OpenDatahubDialog";
        WorkloadMessageType["openDatahubWizardDialog"] = "OpenDatahubWizardDialog";
        WorkloadMessageType["openDialog"] = "OpenDialog";
        WorkloadMessageType["closeDialog"] = "CloseDialog";
        WorkloadMessageType["openPanel"] = "OpenPanel";
        WorkloadMessageType["closePanel"] = "ClosePanel";
        WorkloadMessageType["logEvent"] = "LogEvent";
        WorkloadMessageType["postLifecycleEvent"] = "PostLifecycleEvent";
        WorkloadMessageType["postDOMEvent"] = "PostDOMEvent";
        WorkloadMessageType["getDOMRect"] = "GetDOMRect";
        WorkloadMessageType["resetFocus"] = "ResetFocus";
        WorkloadMessageType["getTheme"] = "GetTheme";
        WorkloadMessageType["onThemeChange"] = "OnThemeChange";
        WorkloadMessageType["openItemRecentRuns"] = "OpenItemRecentRuns";
        WorkloadMessageType["handleRequestFailure"] = "HandleRequestFailure";
        WorkloadMessageType["handleInvalidRoute"] = "HandleInvalidRoute";
        WorkloadMessageType["openError"] = "openError";
        WorkloadMessageType["emitEvent"] = "EmitEvent";
        WorkloadMessageType["checkPermissionsOfItem"] = "CheckPermissionsOfItem";
        WorkloadMessageType["checkPermissionsOfItems"] = "checkPermissionsOfItems";
        WorkloadMessageType["checkPermissionsOfWorkspace"] = "CheckPermissionsOfWorkspace";
        WorkloadMessageType["getPermissionsOfItem"] = "GetPermissionsOfItem";
        WorkloadMessageType["getPermissionsOfItemByUser"] = "GetPermissionsOfItemByUser";
        WorkloadMessageType["getPermissionsOfWorkspace"] = "GetPermissionsOfWorkspace";
        WorkloadMessageType["getUsersWithAccessToItem"] = "GetUsersWithAccessToItem";
        WorkloadMessageType["checkItemSharingEnabled"] = "CheckItemSharingEnabled";
        WorkloadMessageType["getItemTypeShareablePermissions"] = "GetItemTypeShareablePermissions";
        WorkloadMessageType["openItemSharingDialog"] = "OpenItemSharingDialog";
        WorkloadMessageType["openItemSharingDialogWithResult"] = "OpenItemSharingDialogWithResult";
        WorkloadMessageType["openItemSettings"] = "OpenItemSettings";
        WorkloadMessageType["onCloseItemSettings"] = "onCloseItemSettings";
        WorkloadMessageType["resizeIframeHeight"] = "resizeIframeHeight";
        WorkloadMessageType["postCdnFallbackEvent"] = "PostCdnFallbackEvent";
        WorkloadMessageType["postCdnLazyLoadFailureEvent"] = "PostCdnLazyLoadFailureEvent";
        WorkloadMessageType["openSubfolderPickerDialog"] = "OpenSubfolderPickerDialog";
        WorkloadMessageType["favoriteItem"] = "FavoriteItem";
        WorkloadMessageType["unFavoriteItem"] = "UnFavoriteItem";
        WorkloadMessageType["getItemFavoriteState"] = "GetItemFavoriteState";
        WorkloadMessageType["onItemFavoriteStateChange"] = "OnItemFavoriteUpdate";
        WorkloadMessageType["subscribeItemFavoriteStateChange"] = "SubscribeItemFavoriteUpdate";
        WorkloadMessageType["unSubscribeItemFavoriteStateChange"] = "UnSubscribeItemFavoriteUpdate";
        WorkloadMessageType["performanceItemsRequest"] = "PerformanceItemsRequest";
        WorkloadMessageType["reportPackageMetadata"] = "ReportPackageMetadata";
        WorkloadMessageType["logError"] = "LogError";
        WorkloadMessageType["getItemDefinitions"] = "GetItemDefinitions";
    })(exports.WorkloadMessageType || (exports.WorkloadMessageType = {}));
    const executeAction = createAsyncWorkloadMessage(exports.WorkloadMessageType.executeAction);
    const listenAction = createAsyncWorkloadMessage(exports.WorkloadMessageType.listenAction);
    const onAction = createAsyncWorkloadMessage(exports.WorkloadMessageType.onAction);
    const navigateAsync = createAsyncWorkloadMessage(exports.WorkloadMessageType.navigateAsync);
    const navigateWorkloadAsync = createAsyncWorkloadMessage(exports.WorkloadMessageType.navigateWorkloadAsync);
    const onNavigate = createWorkloadMessage(exports.WorkloadMessageType.onNavigate);
    const listenLeave = createAsyncWorkloadMessage(exports.WorkloadMessageType.listenLeave);
    const onLeave = createAsyncWorkloadMessage(exports.WorkloadMessageType.onLeave);
    const listenLeaveEnd = createAsyncWorkloadMessage(exports.WorkloadMessageType.listenLeaveEnd);
    const onLeaveEnd = createAsyncWorkloadMessage(exports.WorkloadMessageType.onLeaveEnd);
    const getAccessToken = createAsyncWorkloadMessage(exports.WorkloadMessageType.getAccessToken);
    const getSettings = createAsyncWorkloadMessage(exports.WorkloadMessageType.getSettings);
    const onSettingsChange = createWorkloadMessage(exports.WorkloadMessageType.onSettingsChange);
    const openNotification = createAsyncWorkloadMessage(exports.WorkloadMessageType.openNotification);
    const hideNotification = createWorkloadMessage(exports.WorkloadMessageType.hideNotification);
    const openPage = createAsyncWorkloadMessage(exports.WorkloadMessageType.openPage);
    const openDatahubDialog = createAsyncWorkloadMessage(exports.WorkloadMessageType.openDatahubDialog);
    const openDatahubWizardDialog = createAsyncWorkloadMessage(exports.WorkloadMessageType.openDatahubWizardDialog);
    const openDialog = createAsyncWorkloadMessage(exports.WorkloadMessageType.openDialog);
    const closeDialog = createAsyncWorkloadMessage(exports.WorkloadMessageType.closeDialog);
    const openPanel = createAsyncWorkloadMessage(exports.WorkloadMessageType.openPanel);
    const closePanel = createAsyncWorkloadMessage(exports.WorkloadMessageType.closePanel);
    const logEvent = createWorkloadMessage(exports.WorkloadMessageType.logEvent);
    const postLifecycleEvent = createWorkloadMessage(exports.WorkloadMessageType.postLifecycleEvent);
    const postDOMEvent = createWorkloadMessage(exports.WorkloadMessageType.postDOMEvent);
    const getDOMRect = createAsyncWorkloadMessage(exports.WorkloadMessageType.getDOMRect);
    const resetFocus = createWorkloadMessage(exports.WorkloadMessageType.resetFocus);
    const getTheme = createAsyncWorkloadMessage(exports.WorkloadMessageType.getTheme);
    const onThemeChange = createWorkloadMessage(exports.WorkloadMessageType.onThemeChange);
    const openItemRecentRuns = createAsyncWorkloadMessage(exports.WorkloadMessageType.openItemRecentRuns);
    const handleRequestFailure = createAsyncWorkloadMessage(exports.WorkloadMessageType.handleRequestFailure);
    const handleInvalidRoute = createWorkloadMessage(exports.WorkloadMessageType.handleInvalidRoute);
    const openError = createAsyncWorkloadMessage(exports.WorkloadMessageType.openError);
    const emitEvent = createWorkloadMessage(exports.WorkloadMessageType.emitEvent);
    const checkPermissionsOfItem = createAsyncWorkloadMessage(exports.WorkloadMessageType.checkPermissionsOfItem);
    const checkPermissionsOfItems = createAsyncWorkloadMessage(exports.WorkloadMessageType.checkPermissionsOfItems);
    const checkPermissionsOfWorkspace = createAsyncWorkloadMessage(exports.WorkloadMessageType.checkPermissionsOfWorkspace);
    const getPermissionsOfItem = createAsyncWorkloadMessage(exports.WorkloadMessageType.getPermissionsOfItem);
    const getPermissionsOfItemByUser = createAsyncWorkloadMessage(exports.WorkloadMessageType.getPermissionsOfItemByUser);
    const getPermissionsOfWorkspace = createAsyncWorkloadMessage(exports.WorkloadMessageType.getPermissionsOfWorkspace);
    const getUsersWithAccessToItem = createAsyncWorkloadMessage(exports.WorkloadMessageType.getUsersWithAccessToItem);
    const checkItemSharingEnabled = createAsyncWorkloadMessage(exports.WorkloadMessageType.checkItemSharingEnabled);
    const getItemTypeShareablePermissions = createAsyncWorkloadMessage(exports.WorkloadMessageType.getItemTypeShareablePermissions);
    const openItemSharingDialog = createWorkloadMessage(exports.WorkloadMessageType.openItemSharingDialog);
    const openItemSharingDialogWithResult = createAsyncWorkloadMessage(exports.WorkloadMessageType.openItemSharingDialogWithResult);
    const openItemSettings = createAsyncWorkloadMessage(exports.WorkloadMessageType.openItemSettings);
    const onCloseItemSettings = createWorkloadMessage(exports.WorkloadMessageType.onCloseItemSettings);
    const resizeIframeHeight = createAsyncWorkloadMessage(exports.WorkloadMessageType.resizeIframeHeight);
    const postCdnFallbackEvent = createWorkloadMessage(exports.WorkloadMessageType.postCdnFallbackEvent);
    const postCdnLazyLoadFailureEvent = createWorkloadMessage(exports.WorkloadMessageType.postCdnLazyLoadFailureEvent);
    const openSubfolderPickerDialog = createAsyncWorkloadMessage(exports.WorkloadMessageType.openSubfolderPickerDialog);
    const favoriteItem = createAsyncWorkloadMessage(exports.WorkloadMessageType.favoriteItem);
    const unFavoriteItem = createAsyncWorkloadMessage(exports.WorkloadMessageType.unFavoriteItem);
    const getItemFavoriteState = createAsyncWorkloadMessage(exports.WorkloadMessageType.getItemFavoriteState);
    const onItemFavoriteStateChange = createWorkloadMessage(exports.WorkloadMessageType.onItemFavoriteStateChange);
    const subscribeItemFavoriteStateChange = createAsyncWorkloadMessage(exports.WorkloadMessageType.subscribeItemFavoriteStateChange);
    const unSubscribeItemFavoriteStateChange = createWorkloadMessage(exports.WorkloadMessageType.unSubscribeItemFavoriteStateChange);
    const getPerformanceItems = createAsyncWorkloadMessage(exports.WorkloadMessageType.performanceItemsRequest);
    const reportPackageMetadata = createWorkloadMessage(exports.WorkloadMessageType.reportPackageMetadata);
    const logError = createWorkloadMessage(exports.WorkloadMessageType.logError);
    const getItemDefinitions = createAsyncWorkloadMessage(exports.WorkloadMessageType.getItemDefinitions);
    /** @internal */
    const Messages$1 = {
        executeAction,
        listenAction,
        onAction,
        navigateAsync,
        navigateWorkloadAsync,
        onNavigate,
        listenLeave,
        onLeave,
        listenLeaveEnd,
        onLeaveEnd,
        getAccessToken,
        getSettings,
        onSettingsChange,
        openNotification,
        hideNotification,
        openPage,
        openDatahubDialog,
        openDatahubWizardDialog,
        openDialog,
        closeDialog,
        openPanel,
        closePanel,
        logEvent,
        postLifecycleEvent,
        postDOMEvent,
        getDOMRect,
        resetFocus,
        getTheme,
        onThemeChange,
        openItemRecentRuns,
        openError,
        emitEvent,
        handleRequestFailure,
        handleInvalidRoute,
        checkPermissionsOfItem,
        checkPermissionsOfItems,
        checkPermissionsOfWorkspace,
        getPermissionsOfItem,
        getPermissionsOfItemByUser,
        getPermissionsOfWorkspace,
        getUsersWithAccessToItem,
        checkItemSharingEnabled,
        getItemTypeShareablePermissions,
        openItemSharingDialog,
        openItemSharingDialogWithResult,
        openItemSettings,
        onCloseItemSettings,
        resizeIframeHeight,
        postCdnFallbackEvent,
        postCdnLazyLoadFailureEvent,
        openSubfolderPickerDialog,
        favoriteItem,
        unFavoriteItem,
        getItemFavoriteState,
        onItemFavoriteStateChange,
        subscribeItemFavoriteStateChange,
        unSubscribeItemFavoriteStateChange,
        getPerformanceItems,
        reportPackageMetadata,
        logError,
        getItemDefinitions,
    };

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    class _ErrorHandlingClient {
        constructor(broker) {
            this.broker = broker;
        }
        registerUnhandledExceptionHandler(config) {
            window.addEventListener('unhandledrejection', (event) => {
                event.preventDefault();
                let unhandledErrorMessage = 'Unknown Error';
                if (event.reason instanceof Error) {
                    unhandledErrorMessage = event.reason.message;
                }
                else {
                    unhandledErrorMessage = `Got unhandled rejection of non Error type. Type: ${typeof event?.reason}, className: ${event?.reason?.constructor?.name || ''}.`;
                }
                this.broker.send(Messages$1.logEvent({
                    name: 'Unhandled Exception',
                    properties: {
                        ErrorCategory: 'UnhandledRejection',
                        ErrorMessage: unhandledErrorMessage,
                        IFrame: config.iframe,
                    },
                }));
            });
            window.addEventListener('error', (event) => {
                this.broker.send(Messages$1.logEvent({
                    name: 'Unhandled Exception',
                    properties: {
                        ErrorCategory: 'GlobalError',
                        ErrorMessage: event?.message || '',
                        ErrorSource: event?.filename || '',
                        IFrame: config.iframe,
                    },
                }));
            });
        }
    }

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    class _InteractionClient {
        constructor(broker) {
            this.broker = broker;
        }
        postDOMEvent(config) {
            const defaultConfig = {
                eventInitDict: {
                    bubbles: true,
                    cancelable: true,
                    composed: true,
                },
            };
            return this.broker.send(Messages$1.postDOMEvent({ ...defaultConfig, ...config }));
        }
        onResetFocus(callback) {
            return this.broker.listenFor(Messages$1.resetFocus, callback);
        }
        onQueryDomRect(callback) {
            this.broker.listenForAsync(Messages$1.getDOMRect, (config) => {
                return callback(config)
                    .then((result) => Messages$1.getDOMRect.resolve({ ...result }))
                    .catch((error) => Messages$1.getDOMRect.reject({ error }));
            });
        }
    }

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    const MAX_CACHE_SIZE = 1000;
    /** @internal */
    class _PerformanceItemsClient {
        constructor(broker) {
            this.broker = broker;
            this.cursor = 0; // cursor to keep track of the current position in the virtual performanceItems array.
            this.performanceItems = [];
            this.performanceObserver = window.PerformanceObserver
                ? new PerformanceObserver((list) => {
                    this.pushPerformanceItems(list.getEntries());
                })
                : null;
        }
        init() {
            this.pushPerformanceItems(performance.getEntries()); // push the initial performance items.
            this.performanceObserver?.observe({
                entryTypes: [
                    // mark and measure are usually customized by workloads, which are not meanful to shell, instead, they can be noisy.
                    ...PerformanceObserver.supportedEntryTypes.filter((t) => t !== 'mark' && t !== 'measure')
                ],
                buffered: false, // Ignore the buffered entries.
            });
            // start listening for getPerformanceItems requests.
            this.broker.listenForAsync(Messages$1.getPerformanceItems, (config) => {
                return Messages$1.getPerformanceItems.resolve(this.pickPerformanceItems(config));
            });
        }
        pushPerformanceItems(items) {
            this.performanceItems = this.performanceItems.concat(items);
            this.checkSize();
        }
        checkSize() {
            if (this.performanceItems.length > MAX_CACHE_SIZE) {
                const excess = this.performanceItems.length - MAX_CACHE_SIZE;
                this.performanceItems.splice(0, excess);
                this.cursor += excess;
            }
        }
        pickPerformanceItems(config) {
            const { start, length } = config;
            const startIndex = Math.max(start - this.cursor, 0);
            const endIndex = Math.min(startIndex + Math.max(length, 0), this.performanceItems.length);
            const items = this.performanceItems.slice(startIndex, endIndex);
            this.performanceItems.splice(0, endIndex); // remove the items that are being sent, also remove the items before these.
            const originalCursor = this.cursor;
            this.cursor += endIndex;
            if (length === 0) { // Special input to stop the observer.
                this.performanceObserver?.disconnect();
            }
            return {
                performanceItems: items.map(this.convertPerformanceItem),
                range: [startIndex + originalCursor, endIndex + originalCursor],
                pendingItemsLength: this.performanceItems.length,
            };
        }
        convertPerformanceItem(entry) {
            return JSON.parse(JSON.stringify(entry));
        }
    }

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    class _TelemetryClient {
        constructor(broker) {
            this.broker = broker;
        }
        logEvent(event, eventOptions) {
            return this.broker.send(Messages$1.logEvent({ ...event, eventOptions }));
        }
        postLifecycleEvent(event) {
            this.broker.send(Messages$1.postLifecycleEvent(event));
        }
        postCdnFallbackEvent(event) {
            this.broker.send(Messages$1.postCdnFallbackEvent(event));
        }
        postCdnLazyLoadFailureEvent(event) {
            this.broker.send(Messages$1.postCdnLazyLoadFailureEvent(event));
        }
        reportPackageMetadata(event) {
            this.broker.send(Messages$1.reportPackageMetadata(event));
        }
    }

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    function getWorker(meta, frames) {
        return meta.iframeType === 'worker'
            ? window
            : Array.prototype.find.call(frames, (frame) => {
                try {
                    return isTargetedIFrame(frame, meta.workloadName, 'worker');
                }
                catch {
                    return undefined;
                }
            });
    }
    function isTargetedIFrame(target, workloadName, iframeType) {
        const meta = WorkloadMetaLoader.Load(target);
        return meta.iframeType === iframeType && meta.workloadName === workloadName;
    }

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    const WORKER_IFRAME_STATE = 'WORKER_IFRAME_STATE';
    /** @internal */
    class _WorkerClient {
        constructor(metaFactory, config) {
            this.metaFactory = metaFactory;
            this.config = config;
        }
        get workIFrameState() {
            if (this._workerIFrameState) {
                return Promise.resolve(this._workerIFrameState);
            }
            const meta = this.metaFactory();
            return this.getState(meta, this.config.workloadHostWindow.frames, WORKER_IFRAME_STATE).then(workerState => {
                this._workerIFrameState = workerState;
                return workerState;
            });
        }
        sleep(delayInMS) {
            return new Promise(resolve => setTimeout(resolve, delayInMS));
        }
        async getState(meta, frames, symbolKey) {
            const symbol = Symbol.for(symbolKey);
            // In scenarios where the UI iframe cannot find the worker iframe, but the worker iframe ultimately loads successfully, the 95th percentile load duration for the worker iframe is 14,853 ms in the failed cases. Therefore, in this version, I will set the maxRetryDuration to 15,000 ms.
            const maxRetryCount = 150;
            const delayInMS = 100;
            let worker = undefined;
            let currentRetryCount = 0;
            while (currentRetryCount < maxRetryCount && !worker) {
                worker = getWorker(meta, frames);
                if (!worker) {
                    await this.sleep(delayInMS);
                    currentRetryCount++;
                }
            }
            if (!worker) {
                throw new Error(`Cannot find the worker frame of ${meta.workloadName}`);
            }
            if (!worker[symbol]) {
                Object.defineProperty(worker, symbol, {
                    value: {},
                    writable: false,
                    enumerable: false,
                    configurable: false,
                });
            }
            return worker;
        }
    }

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    /** @internal */
    class ActionClient {
        constructor(broker) {
            this.broker = broker;
        }
        execute(action) {
            return this.broker.sendAsync(Messages$1.executeAction.start(action));
        }
        onAction(handler) {
            // For now, we are using a fire-and-forget approach as the shell does not return any useful information.
            // In the future, we can have the shell return action execution-related settings via  this asynchronous
            // communication. These settings can then be used to control the onAction callback behavior.
            this.broker.sendAsync(Messages$1.listenAction.start({}));
            return this.broker.listenForAsync(Messages$1.onAction, (action) => {
                return handler(action)
                    .then((result) => Messages$1.onAction.resolve({ result }))
                    .catch((error) => Messages$1.onAction.reject({ error }));
            });
        }
    }

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    /** @internal */
    class ItemRecentRunsClient {
        constructor(broker) {
            this.broker = broker;
        }
        open(config) {
            return this.broker.sendAsync(Messages$1.openItemRecentRuns.start(config));
        }
    }

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    /** @internal */
    class ItemSettingsClient {
        constructor(broker) {
            this.broker = broker;
        }
        open(config) {
            return this.broker.sendAsync(Messages$1.openItemSettings.start(config));
        }
        onClose(callback) {
            return this.broker.listenFor(Messages$1.onCloseItemSettings, callback);
        }
        setIframeDimensions(config) {
            this.broker.sendAsync(Messages$1.resizeIframeHeight.start({ iframeHeight: config.iframeHeight, itemId: config.itemId }));
        }
    }

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    /** @internal */
    let AuthClient$1 = class AuthClient {
        constructor(broker) {
            this.broker = broker;
        }
        getAccessToken(scopes, forceRefresh) {
            return this.broker.sendAsync(Messages$1.getAccessToken.start({ scopes, forceRefresh }));
        }
    };

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    /** @internal */
    class DatahubClient {
        constructor(broker) {
            this.broker = broker;
        }
        openDialog(config) {
            return this.broker.sendAsync(Messages$1.openDatahubDialog.start(config));
        }
        openDatahubWizardDialog(config) {
            return this.broker.sendAsync(Messages$1.openDatahubWizardDialog.start(config));
        }
    }

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    async function runWithFocusRestoration(callback, preventFocusRestoration) {
        if (preventFocusRestoration) {
            return await callback();
        }
        const activeElement = getFocusedElementPierceShadowDom();
        try {
            return await callback();
        }
        finally {
            if (activeElement instanceof HTMLElement && activeElement.isConnected) {
                activeElement.focus();
            }
        }
    }
    /** copied from @angular/cdk/platform */
    function getFocusedElementPierceShadowDom() {
        let activeElement = typeof document !== 'undefined' && document
            ? document.activeElement
            : null;
        while (activeElement && activeElement.shadowRoot) {
            const newActiveElement = activeElement.shadowRoot.activeElement;
            if (newActiveElement === activeElement) {
                break;
            }
            else {
                activeElement = newActiveElement;
            }
        }
        return activeElement;
    }

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    /** @internal */
    class DialogClient {
        constructor(broker) {
            this.broker = broker;
        }
        open(config) {
            return runWithFocusRestoration(() => this.broker.sendAsync(Messages$1.openDialog.start(config)), config.preventFocusRestoration);
        }
        close(config) {
            return this.broker.sendAsync(Messages$1.closeDialog.start(config || {}));
        }
    }

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    /** @internal */
    class ErrorHandlingClient {
        constructor(broker) {
            this.broker = broker;
        }
        handleRequestFailure(response) {
            // Normalize headers because Headers object cannot be serialized by postMessage.
            let headers = response.headers;
            if (Headers && response.headers instanceof Headers) {
                headers = {};
                response.headers.forEach((value, key) => {
                    headers[key] = value;
                });
            }
            return this.broker.sendAsync(Messages$1.handleRequestFailure.start({ ...response, headers }));
        }
        handleInvalidRoute(config) {
            this.broker.send(Messages$1.handleInvalidRoute(config || {}));
        }
        openErrorDialog(config) {
            function probeErrorMessage(reason) {
                if (reason == null) {
                    return 'Unknown error';
                }
                if (reason instanceof Error) {
                    return `${reason.name}: ${reason.message}`;
                }
                if (typeof reason === 'object') {
                    try {
                        return JSON.stringify(reason);
                    }
                    catch (e) {
                        return `Unstructured Error: ${e instanceof Error ? e.message : e}`;
                    }
                }
                return `${reason}`;
            }
            const { errorMsg, errorOptions, kind, featureName, width, autoFocus, ...rest } = config;
            return this.broker.sendAsync(Messages$1.openError.start({
                ...rest,
                errorMsg: probeErrorMessage(errorMsg),
                errorOptions,
                kind,
                featureName,
                width,
                autoFocus,
            }));
        }
    }

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    /** @internal */
    class EventClient {
        constructor(broker) {
            this.broker = broker;
        }
        emitEvent(details) {
            return this.broker.send(Messages$1.emitEvent(details));
        }
    }

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    /** @internal */
    let NavigationClient$1 = class NavigationClient {
        constructor(broker) {
            this.broker = broker;
        }
        navigate(target, route) {
            return target === 'host'
                ? this.broker.sendAsync(Messages$1.navigateAsync.start(route))
                : this.broker.sendAsync(Messages$1.navigateWorkloadAsync.start(route));
        }
        onNavigate(callback) {
            return this.broker.listenFor(Messages$1.onNavigate, callback);
        }
        onBeforeNavigateAway(callback) {
            this.broker.listenForAsync(Messages$1.onLeave, (leaveData) => {
                return callback(leaveData)
                    .then((result) => Messages$1.onLeave.resolve({ ...result }))
                    .catch((error) => Messages$1.onLeave.reject({ error }));
            });
            this.broker.sendAsync(Messages$1.listenLeave.start());
        }
        onAfterNavigateAway(callback) {
            this.broker.listenForAsync(Messages$1.onLeaveEnd, (leaveEndData) => {
                return callback(leaveEndData)
                    .then((result) => Messages$1.onLeaveEnd.resolve({ result }))
                    .catch((error) => Messages$1.onLeaveEnd.reject({ error }));
            });
            this.broker.sendAsync(Messages$1.listenLeaveEnd.start());
        }
    };

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    /** @internal */
    class NotificationClient {
        constructor(broker) {
            this.broker = broker;
        }
        open(config) {
            return this.broker.sendAsync(Messages$1.openNotification.start(config));
        }
        hide(config) {
            return this.broker.send(Messages$1.hideNotification(config));
        }
    }

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    /** @internal */
    class PageClient {
        constructor(broker) {
            this.broker = broker;
        }
        open(config) {
            return this.broker.sendAsync(Messages$1.openPage.start(config));
        }
    }

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    /** @internal */
    class PanelClient {
        constructor(broker) {
            this.broker = broker;
        }
        open(config) {
            return runWithFocusRestoration(() => this.broker.sendAsync(Messages$1.openPanel.start(config)), config.preventFocusRestoration);
        }
        close(config) {
            return this.broker.sendAsync(Messages$1.closePanel.start(config || {}));
        }
    }

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    /** @internal */
    class PermissionClient {
        constructor(broker) {
            this.broker = broker;
        }
        checkPermissionsOfItem(input) {
            return this.broker.sendAsync(Messages$1.checkPermissionsOfItem.start(input));
        }
        checkPermissionsOfItems(input) {
            return this.broker.sendAsync(Messages$1.checkPermissionsOfItems.start(input));
        }
        checkPermissionsOfWorkspace(input) {
            return this.broker.sendAsync(Messages$1.checkPermissionsOfWorkspace.start(input));
        }
        getPermissionsOfItem(input) {
            return this.broker.sendAsync(Messages$1.getPermissionsOfItem.start(input));
        }
        getPermissionsOfItemByUser(input) {
            return this.broker.sendAsync(Messages$1.getPermissionsOfItemByUser.start(input));
        }
        getPermissionsOfWorkspace(input) {
            return this.broker.sendAsync(Messages$1.getPermissionsOfWorkspace.start(input));
        }
        getUsersWithAccessToItem(input) {
            return this.broker.sendAsync(Messages$1.getUsersWithAccessToItem.start(input));
        }
        openItemSharingDialog(config) {
            return this.broker.send(Messages$1.openItemSharingDialog(config));
        }
        openItemSharingDialogWithResult(config) {
            return this.broker.sendAsync(Messages$1.openItemSharingDialogWithResult.start(config));
        }
        checkItemSharingEnabled(input) {
            return this.broker.sendAsync(Messages$1.checkItemSharingEnabled.start(input));
        }
        getItemTypeShareablePermissions(input) {
            return this.broker.sendAsync(Messages$1.getItemTypeShareablePermissions.start(input));
        }
    }

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    /** @internal */
    class SettingsClient {
        constructor(broker) {
            this.broker = broker;
        }
        get() {
            return this.broker.sendAsync(Messages$1.getSettings.start());
        }
        onChange(callback) {
            return this.broker.listenFor(Messages$1.onSettingsChange, callback);
        }
    }

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    const SHARED_STATE_KEY = Symbol.for('SHARED_STATE');
    /** @internal */
    class StateClient {
        constructor(metaFactory, config) {
            this.metaFactory = metaFactory;
            this.config = config;
        }
        get sharedState() {
            if (this._sharedState) {
                return this._sharedState;
            }
            const meta = this.metaFactory();
            const worker = getWorker(meta, this.config.workloadHostWindow.frames);
            if (!worker) {
                throw new Error(`Cannot find the worker frame of ${meta.workloadName}`);
            }
            if (!worker[SHARED_STATE_KEY]) {
                Object.defineProperty(worker, SHARED_STATE_KEY, {
                    value: {},
                    writable: false,
                    enumerable: false,
                    configurable: false,
                });
            }
            return (this._sharedState = worker[SHARED_STATE_KEY]);
        }
    }

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    /** @internal */
    class SubfolderClient {
        constructor(broker) {
            this.broker = broker;
        }
        openSubfolderPickerDialog(config) {
            return this.broker.sendAsync(Messages$1.openSubfolderPickerDialog.start(config));
        }
    }

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    /** @internal */
    class ThemeClient {
        constructor(broker) {
            this.broker = broker;
        }
        get() {
            return this.broker.sendAsync(Messages$1.getTheme.start());
        }
        onChange(callback) {
            return this.broker.listenFor(Messages$1.onThemeChange, callback);
        }
    }

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    /** @internal */
    class FavoriteClient {
        constructor(broker) {
            this.broker = broker;
        }
        favoriteItem(input) {
            return this.broker.sendAsync(Messages$1.favoriteItem.start(input));
        }
        unFavoriteItem(input) {
            return this.broker.sendAsync(Messages$1.unFavoriteItem.start(input));
        }
        getItemFavoriteState(input) {
            return this.broker.sendAsync(Messages$1.getItemFavoriteState.start(input));
        }
        onItemFavoriteStateChange(input, callback) {
            let subId;
            this.broker.listenFor(Messages$1.onItemFavoriteStateChange, ({ subscriptionId, changes }) => {
                if (subscriptionId === subId) {
                    const item = changes.find(change => change.itemObjectId === input.itemObjectId);
                    if (item) {
                        callback({ favorited: item.favorited });
                    }
                }
            });
            return this.broker.sendAsync(Messages$1.subscribeItemFavoriteStateChange.start(input)).then(({ subscriptionId }) => {
                subId = subscriptionId;
                return {
                    unsubscribe: () => {
                        subId = undefined;
                        this.broker.send(Messages$1.unSubscribeItemFavoriteStateChange({ subscriptionId }));
                    },
                };
            });
        }
    }

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    /** @internal */
    class ItemDefinitionsClient {
        constructor(broker) {
            this.broker = broker;
        }
        getItemDefinitions(input) {
            return this.broker.sendAsync(Messages$1.getItemDefinitions.start(input));
        }
    }

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    /** @internal */
    let WorkloadClient$1 = class WorkloadClient {
        constructor(config = DefaultWorkloadClientConfig) {
            this.config = config;
            this.broker = createWorkloadClientMessageBroker({ getIframeId: () => this.meta.iframeId, workloadHostWindow: this.config.workloadHostWindow });
            /** @internal */
            this._errorHandling = new _ErrorHandlingClient(this.broker);
            /** @internal */
            this._interaction = new _InteractionClient(this.broker);
            /** @internal */
            this._performanceItems = new _PerformanceItemsClient(this.broker);
            /** @internal */
            this._telemetry = new _TelemetryClient(this.broker);
            /** @internal */
            this._worker = new _WorkerClient(() => this.meta, this.config);
            /** @internal */
            this.auth = new AuthClient$1(this.broker);
            /** @internal */
            this.event = new EventClient(this.broker);
            this.action = new ActionClient(this.broker);
            this.itemDefinitions = new ItemDefinitionsClient(this.broker);
            this.itemRecentRuns = new ItemRecentRunsClient(this.broker);
            this.itemSettings = new ItemSettingsClient(this.broker);
            this.dialog = new DialogClient(this.broker);
            this.datahub = new DatahubClient(this.broker);
            this.errorHandling = new ErrorHandlingClient(this.broker);
            this.favorite = new FavoriteClient(this.broker);
            this.navigation = new NavigationClient$1(this.broker);
            this.notification = new NotificationClient(this.broker);
            this.page = new PageClient(this.broker);
            this.panel = new PanelClient(this.broker);
            this.permission = new PermissionClient(this.broker);
            this.settings = new SettingsClient(this.broker);
            this.state = new StateClient(() => this.meta, this.config);
            this.subfolder = new SubfolderClient(this.broker);
            this.theme = new ThemeClient(this.broker);
            if (!config.workloadHostWindow) {
                throw new Error('Create workload client failed: empty workload host window');
            }
        }
        get meta() {
            return WorkloadMetaLoader.Load();
        }
    };

    // This version file is auto generated from /fabric/.pipelines/scripts/publishPackages.ts via npm package publish pipeline.
    const PACKAGE_NAME$2 = '@fabric/workload-client-common';
    const CLIENT_VERSION$2 = '1.20.83';
    const PUBLISH_DATE$2 = '2025-06-22T07:10:40.056Z';
    if (window.reportPackageMetadata) {
        window.reportPackageMetadata({
            packageName: PACKAGE_NAME$2,
            version: CLIENT_VERSION$2,
            publishDate: PUBLISH_DATE$2
        });
    }
    else {
        if (!window.packageMetadata)
            window.packageMetadata = {};
        window.packageMetadata[PACKAGE_NAME$2] = {
            packageName: PACKAGE_NAME$2,
            version: CLIENT_VERSION$2,
            publishDate: PUBLISH_DATE$2
        };
    }

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //    Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    var ConsumptionMethod;
    (function (ConsumptionMethod) {
        ConsumptionMethod["EmbedCustomers"] = "Embed for Customers";
        ConsumptionMethod["EmbedOrganization"] = "Embed for Organization";
        ConsumptionMethod["Mobile"] = "Power BI Mobile App";
        ConsumptionMethod["PublishToWeb"] = "Custom App (Publish to Web)";
        ConsumptionMethod["SecureEmbed"] = "Custom App (Secure Embed)";
        ConsumptionMethod["TeamsPersonalApp"] = "Power BI Teams Personal App";
        ConsumptionMethod["TeamsTabApp"] = "Power BI Teams Tab App";
        ConsumptionMethod["WebApp"] = "Power BI Web App";
        ConsumptionMethod["FabricWebApp"] = "Fabric Web App";
        ConsumptionMethod["DesktopReportView"] = "Power BI Desktop Report View";
        ConsumptionMethod["Unknown"] = "Unknown";
        ConsumptionMethod["OneDrive"] = "Power BI OneDrive";
    })(ConsumptionMethod || (ConsumptionMethod = {}));
    var SessionSource;
    (function (SessionSource) {
        SessionSource["Fabric"] = "Fabric";
        SessionSource["PowerBI"] = "PowerBI";
        SessionSource["FabricEmbed"] = "FabricEmbed";
    })(SessionSource || (SessionSource = {}));
    var EmbedType;
    (function (EmbedType) {
        EmbedType["AnonymousLiveEmbed"] = "AnonymousLiveEmbed";
        EmbedType["EmbedToken"] = "EmbedToken";
        EmbedType["SaaSEmbed"] = "SaaSEmbed";
        EmbedType["SecurePublishToWebEmbed"] = "SecurePublishToWebEmbed";
        EmbedType["UnknownEmbed"] = "UnknownEmbed";
    })(EmbedType || (EmbedType = {}));
    var Level;
    (function (Level) {
        Level["Informational"] = "Informational";
        Level["Warning"] = "Warning";
        Level["Error"] = "Error";
        Level["Critical"] = "Critical";
    })(Level || (Level = {}));
    var LogAnalyticsCategory;
    (function (LogAnalyticsCategory) {
        LogAnalyticsCategory["ReportUserAction"] = "Report User Action";
    })(LogAnalyticsCategory || (LogAnalyticsCategory = {}));
    var Status;
    (function (Status) {
        /** @deprecated use 'Pending'. */
        Status["Started"] = "Started";
        Status["Succeeded"] = "Succeeded";
        Status["Failed"] = "Failed";
        Status["Cancelled"] = "Cancelled";
        Status["Pending"] = "Pending";
        Status["SucceededWithErrors"] = "SucceededWithErrors";
        Status["FailedWithRemote"] = "FailedWithRemote";
        Status["Interrupted"] = "Interrupted";
    })(Status || (Status = {}));
    var Scenario;
    (function (Scenario) {
        Scenario["MetricAssignmentStatusUpdateNotification"] = "MetricAssignmentStatusUpdateNotification";
        Scenario["MissedActivityNotification"] = "MissedActivityNotification";
        Scenario["RequestAccessNotification"] = "RequestAccessNotification";
    })(Scenario || (Scenario = {}));

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //    Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    var ItemKind;
    (function (ItemKind) {
        ItemKind["InteractiveReport"] = "InteractiveReport";
    })(ItemKind || (ItemKind = {}));
    var DatasetLocation;
    (function (DatasetLocation) {
        DatasetLocation["OnPrem"] = "OnPrem";
        DatasetLocation["AzureAnalysisServices"] = "AzureAnalysisServices";
        DatasetLocation["Shared"] = "Shared";
        DatasetLocation["Premium"] = "Premium";
        DatasetLocation["Unknown"] = "Unknown";
    })(DatasetLocation || (DatasetLocation = {}));
    var DatasetMode;
    (function (DatasetMode) {
        DatasetMode["Import"] = "Import";
        DatasetMode["DirectQuery"] = "DirectQuery";
        DatasetMode["Composite"] = "Composite";
    })(DatasetMode || (DatasetMode = {}));
    var DistributionMethod;
    (function (DistributionMethod) {
        DistributionMethod["App"] = "App";
        DistributionMethod["Workspace"] = "Workspace";
        DistributionMethod["Shared"] = "Shared";
        DistributionMethod["Desktop"] = "Desktop";
    })(DistributionMethod || (DistributionMethod = {}));
    var OpenReportInitializationFlags;
    (function (OpenReportInitializationFlags) {
        OpenReportInitializationFlags[OpenReportInitializationFlags["PersistentState"] = 1] = "PersistentState";
        OpenReportInitializationFlags[OpenReportInitializationFlags["Bookmark"] = 2] = "Bookmark";
        OpenReportInitializationFlags[OpenReportInitializationFlags["DrillthroughFilters"] = 4] = "DrillthroughFilters";
        OpenReportInitializationFlags[OpenReportInitializationFlags["CustomVisuals"] = 8] = "CustomVisuals";
    })(OpenReportInitializationFlags || (OpenReportInitializationFlags = {}));
    /**
     * This is a copy of `enum PackageType` from `src/Clients/PowerBIContracts/contracts.ts`
     * This is a copy of `enum PackageType` $/Power BI/Main/Sql/CloudBI/AS/src/PowerBI/DatabaseContracts/Package.cs
     * It was required to add a separate enum here to avoid a circular dependency between jscommon and PowerBIContracts for certified telemetry
     * NOTE: Please keep these enums in sync.
     */
    var PackageTypeName;
    (function (PackageTypeName) {
        PackageTypeName["Undefined"] = "Undefined";
        PackageTypeName["AppTemplate"] = "AppTemplate";
        PackageTypeName["AppInstance"] = "AppInstance";
        PackageTypeName["AppCopy"] = "AppCopy";
        PackageTypeName["UsageMetricsV2"] = "UsageMetricsV2";
        PackageTypeName["ProtectionMetrics"] = "ProtectionMetrics";
        PackageTypeName["AdminUsageMetrics"] = "AdminUsageMetrics";
        PackageTypeName["AdminPerformanceMetrics"] = "AdminPerformanceMetrics";
        PackageTypeName["Sample"] = "Sample";
        PackageTypeName["Scorecard"] = "Scorecard";
        PackageTypeName["TeamsAnalytics"] = "TeamsAnalytics";
        PackageTypeName["Datamart"] = "Datamart";
        PackageTypeName["AdminMonitoring"] = "AdminMonitoring";
        PackageTypeName["AuditLogSearchDataflow"] = "AuditLogSearchDataflow";
        PackageTypeName["AdminInsightsUsageMetrics"] = "AdminInsightsUsageMetrics";
        PackageTypeName["AdminInsights"] = "AdminInsights";
        PackageTypeName["SeeThruModel"] = "SeeThruModel";
    })(PackageTypeName || (PackageTypeName = {}));
    var ReportMode;
    (function (ReportMode) {
        ReportMode["View"] = "View";
        ReportMode["Edit"] = "Edit";
        ReportMode["Create"] = "Create";
        ReportMode["QuickCreate"] = "Quick Create";
    })(ReportMode || (ReportMode = {}));
    var VisualContainerLifecycleFlags;
    (function (VisualContainerLifecycleFlags) {
        VisualContainerLifecycleFlags[VisualContainerLifecycleFlags["hasPreviewData"] = 1] = "hasPreviewData";
        VisualContainerLifecycleFlags[VisualContainerLifecycleFlags["hasQueryResult"] = 2] = "hasQueryResult";
        VisualContainerLifecycleFlags[VisualContainerLifecycleFlags["hasEmptyQueryResult"] = 4] = "hasEmptyQueryResult";
        VisualContainerLifecycleFlags[VisualContainerLifecycleFlags["hasQueryError"] = 8] = "hasQueryError";
        VisualContainerLifecycleFlags[VisualContainerLifecycleFlags["updatedNonQueryVisual"] = 16] = "updatedNonQueryVisual";
        VisualContainerLifecycleFlags[VisualContainerLifecycleFlags["gotNextDataSegment"] = 32] = "gotNextDataSegment";
        VisualContainerLifecycleFlags[VisualContainerLifecycleFlags["loadedMoreData"] = 64] = "loadedMoreData";
        VisualContainerLifecycleFlags[VisualContainerLifecycleFlags["loadedWindow"] = 128] = "loadedWindow";
        VisualContainerLifecycleFlags[VisualContainerLifecycleFlags["reloadedDataSegment"] = 256] = "reloadedDataSegment";
        VisualContainerLifecycleFlags[VisualContainerLifecycleFlags["appliedUpdate"] = 512] = "appliedUpdate";
        VisualContainerLifecycleFlags[VisualContainerLifecycleFlags["tookQueryHandlerFromPrimer"] = 1024] = "tookQueryHandlerFromPrimer";
        VisualContainerLifecycleFlags[VisualContainerLifecycleFlags["visualizedDataViewSource"] = 2048] = "visualizedDataViewSource";
    })(VisualContainerLifecycleFlags || (VisualContainerLifecycleFlags = {}));

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //    Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    var EventName;
    (function (EventName) {
        EventName["WorkloadLoad"] = "WorkloadLoad";
        EventName["ApplicationLoad"] = "ApplicationLoad";
        EventName["ScriptLoad"] = "ScriptLoad";
        EventName["DevTrace"] = "DevTrace";
        EventName["DiagnosticTrace"] = "DiagnosticTrace";
    })(EventName || (EventName = {}));

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //    Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    var FabricFeatures;
    (function (FabricFeatures) {
        FabricFeatures["WorkloadApiUsage"] = "Fabric.WorkloadApiUsage";
        FabricFeatures["HomePage"] = "Home";
        FabricFeatures["LandingPage"] = "Landing";
        FabricFeatures["CreateHub"] = "Create hub";
        FabricFeatures["CreateWorkspace"] = "Create workspace";
        FabricFeatures["WorkspaceSettings"] = "Fabric Workspace Settings";
        FabricFeatures["WorkspaceSettingsAuditEvents"] = "Workspace Settings Audit Events";
        FabricFeatures["CapacitySettings"] = "Capacity settings";
        FabricFeatures["ItemSettings"] = "Item settings";
        FabricFeatures["ProductSwitcher"] = "Product switcher";
        FabricFeatures["Browse"] = "Browse";
        FabricFeatures["Embed"] = "Embed";
        FabricFeatures["Workspace"] = "Workspace";
        FabricFeatures["GlobalSearch"] = "Global search";
        FabricFeatures["ManageAccessOfWorkspace"] = "Manage access of workspace";
        FabricFeatures["Header"] = "Header";
        FabricFeatures["HeaderFlyout"] = "Header flyout";
        FabricFeatures["Feedback"] = "Feedback";
        FabricFeatures["DataflowsGen2"] = "Dataflows Gen2";
        FabricFeatures["DelegatedSettings"] = "Delegated Settings";
        FabricFeatures["Domains"] = "Domains";
        FabricFeatures["DomainsConsumption"] = "Domains Consumption";
        FabricFeatures["DomainsDirectMAU"] = "Domains Direct MAU";
        FabricFeatures["DomainsManagedMAU"] = "Domains Managed MAU";
        FabricFeatures["DomainsSettings"] = "Domains Settings";
        FabricFeatures["DomainsWSManagement"] = "Domains WS Management";
        FabricFeatures["ItemWithDomainViewed"] = "Item with Domain Viewed";
        FabricFeatures["InformationProtection"] = "Information protection";
        FabricFeatures["InformationProtectionSetLabel"] = "Information Protection - Set Label";
        FabricFeatures["InformationProtectionDeleteLabel"] = "Information Protection - Delete Label";
        FabricFeatures["Shortcuts"] = "Shortcuts";
        FabricFeatures["OneSecurity"] = "One security";
        FabricFeatures["MonitoringHub"] = "Monitoring hub";
        FabricFeatures["WorkloadHub"] = "Workload hub";
        FabricFeatures["HelpPane"] = "Help pane";
        FabricFeatures["TutorialPane"] = "Tutorial pane";
        FabricFeatures["PurviewHub"] = "Purview Hub";
        FabricFeatures["NotificationUX"] = "Notification UX";
        FabricFeatures["NotificationCenter"] = "Notification center";
        FabricFeatures["Workload"] = "Workload";
        FabricFeatures["ItemSharing"] = "Item sharing";
        FabricFeatures["ItemPermissionManagement"] = "Item permission management";
        FabricFeatures["Trial"] = "Trial";
        FabricFeatures["DeploymentPipelines"] = "DeploymentPipelines";
        FabricFeatures["QuickCreate"] = "Quick create";
        FabricFeatures["UserSettings"] = "User settings";
        FabricFeatures["LeftNav"] = "Left nav";
        FabricFeatures["ItemDefinition"] = "Item definition";
        FabricFeatures["Subfolder"] = "Subfolder";
        FabricFeatures["Taskflow"] = "Taskflow";
        FabricFeatures["TaskFlowOnboarding"] = "Task flow onboarding";
        FabricFeatures["TaskFlowService"] = "Task flow service";
        FabricFeatures["DataSharing"] = "Data Sharing";
        FabricFeatures["GitIntegration"] = "Git Integration";
        FabricFeatures["CreateItemPanel"] = "Create Item Panel";
        FabricFeatures["FabricItemCRUD"] = "Fabric Item CRUD";
        FabricFeatures["Import"] = "Import";
        FabricFeatures["ItemSchedule"] = "Item schedule";
        FabricFeatures["BusinessTags"] = "Business Tags";
        FabricFeatures["BusinessTagsDirectUsage"] = "Business Tags Direct Usage";
        FabricFeatures["BusinessTagsManagedUsage"] = "Business Tags Managed Usage";
        FabricFeatures["BusinessTagsConsumption"] = "Business Tags Consumption";
        FabricFeatures["BusinessTagsWorkspaceLoad"] = "Business Tags Workspace Load";
        FabricFeatures["BusinessTagsItemLoad"] = "Business Tags Item Load";
        FabricFeatures["DefaultSensitivityLabel"] = "Default Sensitivity Label";
        FabricFeatures["UnsupportedBrowserNotification"] = "Unsupported Browser Notification";
        FabricFeatures["StandardItemCreation"] = "Standard Item Creation";
        FabricFeatures["SemanticModelRefreshDetailsPage"] = "semantic_model_refresh_details_page";
        FabricFeatures["CreateShortcutEnableCacheEvent"] = "CreateShortcutEnableCacheEvent";
        //Governance Hub
        FabricFeatures["GovernanceHub"] = "Governance Hub";
        FabricFeatures["GovernanceHubGetStatus"] = "Governance Hub Get Status";
        FabricFeatures["GovernanceHubGetInsightsAndActions"] = "Governance Hub Get Insights And Actions";
        FabricFeatures["GovernanceHubRefreshData"] = "Governance Hub Refresh Data";
        FabricFeatures["GovernBaseUsage"] = "Govern Base Usage";
        FabricFeatures["GovernanceHubViewMoreInsightsClicked"] = "Governance Hub View More Insights Clicked";
        FabricFeatures["GovernanceHubViewMoreNavigationBack"] = "Governance Hub View More Navigation Back";
        FabricFeatures["GovernanceHubRefreshClicked"] = "Governance Hub Refresh Clicked";
        FabricFeatures["GovernanceHubActionClicked"] = "Governance Hub Action Clicked";
        FabricFeatures["GovernanceHubActionInteraction"] = "Governance Hub Action Interaction";
        FabricFeatures["GovernanceHubSolutionInteraction"] = "Governance Hub Solution Interaction";
        FabricFeatures["GovernanceHubEducationInteraction"] = "Governance Hub Education Interaction";
        FabricFeatures["GovernanceHubPageLoad"] = "Governance Hub Page Load";
        FabricFeatures["GovernanceHubLandingPageLoad"] = "Governance Hub Landing Page Load";
        FabricFeatures["GovernanceHubTourDialogInteraction"] = "Governance Hub Tour Dialog Interaction";
        FabricFeatures["GovernanceHubTourPopupCancel"] = "Governance Hub Tour Popup Cancel";
        FabricFeatures["RealmSwitcher"] = "Realm Switcher";
        FabricFeatures["OlcExploreTour"] = "OneLake catalog Explore Tour";
    })(FabricFeatures || (FabricFeatures = {}));
    var OriginatingService;
    (function (OriginatingService) {
        OriginatingService["DataIntegration"] = "DataIntegration";
        OriginatingService["FabricWorkloadClientSdk"] = "FabricWorkloadClientSDK";
        OriginatingService["FabricUX"] = "DataCloudUX";
        OriginatingService["OneLakeUX"] = "One-lake";
    })(OriginatingService || (OriginatingService = {}));

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    /*
     * Background:
     * 1.Datapipeline team use es6 while other teams use es5 online
     * 2.Bowser lib use export default and the compile is not compatible with es6
     * Solution:
     * 1. Use import * as bowser from 'bowser' and bowser? to compatible while the bowser is undifined after compile
     * Notice:
     * 1. Why don't use import bowser from 'bowser' lib? Because it need add compileOption esModuleInterop and allowSyntheticDefaultImports,
     * and need to modify the compile, not make sence.
     * 2. Don't use import { getParser } from 'bowser' which will lead to a regression -- let Datapipeline compile error
     */
    /** @internal */
    function populateWorkloadLoadPerformanceTelemetry(workloadIframePerformance) {
        const { clientVersion, workloadName, iframeId, workloadBootstrapStartTimestamp, workloadBootstrapEndTimestamp } = workloadIframePerformance;
        const navigator = window.navigator;
        const navigatorConnection = window.navigator?.connection;
        const performanceNavigationTiming = (window.performance.getEntriesByType("navigation"))[0];
        const { connectEnd, connectStart, decodedBodySize, domContentLoadedEventEnd, domContentLoadedEventStart, domInteractive, domainLookupEnd, domainLookupStart, duration, encodedBodySize, entryType, fetchStart, loadEventEnd, nextHopProtocol, redirectCount, redirectEnd, redirectStart, requestStart, responseStart, responseEnd, secureConnectionStart, transferSize, unloadEventEnd, unloadEventStart, } = performanceNavigationTiming;
        // Use bowser? to compatible with es6
        const browser = bowser__namespace?.getParser ? bowser__namespace.getParser(navigator.userAgent) : undefined;
        const windowPerformanceTimeOrigin = window.performance.timeOrigin;
        return {
            ...buildBaseEvent(clientVersion),
            workloadName,
            eventName: "WorkloadLoad",
            iframeId,
            // cdnEnabled: !!(window as any).useCDN, // Update this with global setting if this doesn't depend on workload specific setting
            compressionSavings: (transferSize && decodedBodySize) ? Math.round((1 - (transferSize / decodedBodySize)) * 100) : -1,
            decodedBodySize: decodedBodySize ?? -1,
            deviceMemory: navigator.deviceMemory || 0,
            dnsLookupDuration: Math.ceil(domainLookupEnd - domainLookupStart),
            dnsPersistentConnectionOrCached: fetchStart === domainLookupStart && fetchStart === domainLookupEnd,
            documentLoadDuration: Math.ceil(windowPerformanceTimeOrigin + loadEventEnd - windowPerformanceTimeOrigin + fetchStart),
            documentLoadEndTimestamp: new Date(Math.ceil(windowPerformanceTimeOrigin + loadEventEnd)).toISOString(),
            documentLoadStartTimestamp: new Date(Math.ceil(windowPerformanceTimeOrigin + fetchStart)).toISOString(),
            domContentLoadedDuration: Math.ceil(windowPerformanceTimeOrigin + domContentLoadedEventEnd - windowPerformanceTimeOrigin + domContentLoadedEventStart),
            effectiveBandwidth: navigatorConnection?.downlink,
            effectiveConnectionType: navigatorConnection?.effectiveType,
            effectiveRoundTripTime: navigatorConnection?.rtt,
            encodedBodySize: encodedBodySize ?? -1,
            hardwareConcurrency: navigator.hardwareConcurrency,
            isHttp2: nextHopProtocol === "http/2",
            workloadBootstrapLoadDuration: Math.ceil(workloadBootstrapEndTimestamp - workloadBootstrapStartTimestamp),
            workloadBootstrapLoadEndTimestamp: new Date(Math.ceil(windowPerformanceTimeOrigin + workloadBootstrapEndTimestamp)).toISOString(),
            workloadBootstrapLoadStartTimestamp: new Date(Math.ceil(windowPerformanceTimeOrigin + workloadBootstrapStartTimestamp)).toISOString(),
            navigationType: entryType,
            redirectCount,
            redirectDocumentDuration: Math.ceil(((windowPerformanceTimeOrigin + redirectEnd) - (windowPerformanceTimeOrigin + redirectStart))),
            requestDuration: Math.ceil(((windowPerformanceTimeOrigin + responseStart) - (windowPerformanceTimeOrigin + requestStart))),
            responseDuration: Math.ceil(((windowPerformanceTimeOrigin + responseEnd) - (windowPerformanceTimeOrigin + responseStart))),
            screenHeight: window.screen.height,
            screenWidth: window.screen.width,
            sslNegotiationDuration: Math.ceil(((windowPerformanceTimeOrigin + requestStart) - (windowPerformanceTimeOrigin + secureConnectionStart))),
            tcpConnectionSetupDuration: Math.ceil(((windowPerformanceTimeOrigin + connectEnd) - (windowPerformanceTimeOrigin + connectStart))),
            timeToFirstByte: Math.ceil(((windowPerformanceTimeOrigin + responseStart) - (windowPerformanceTimeOrigin + fetchStart))),
            timeToLastByte: Math.ceil(((windowPerformanceTimeOrigin + responseEnd) - (windowPerformanceTimeOrigin + fetchStart))),
            timeToInteractiveDom: domInteractive,
            transferSize: transferSize ?? -1,
            unloadDocumentDuration: Math.ceil((unloadEventEnd - unloadEventStart)),
            visualViewportHeight: window.outerHeight,
            visualViewportWidth: window.outerWidth,
        };
        function buildBaseEvent(clientVersion) {
            return {
                browserName: browser?.getBrowserName() ?? '',
                browserVersion: browser?.getBrowserVersion() ?? '',
                operatingSystemName: browser?.getOSName() ?? '',
                operatingSystemVersion: browser?.getOSVersion() ?? '',
                userAgent: window.navigator.userAgent,
                durationMs: Math.ceil(duration),
                eventId: uuid__namespace.v4(),
                level: Level.Informational,
                logAnalyticsCategory: LogAnalyticsCategory.ReportUserAction,
                pageHidden: !!window.document.hidden,
                sessionSource: SessionSource.Fabric,
                status: Status.Succeeded,
                timeGenerated: new Date(Math.ceil(windowPerformanceTimeOrigin + fetchStart)).toISOString(),
                clientVersion,
                consumptionMethod: ConsumptionMethod.FabricWebApp,
                online: true,
                operationEndTime: new Date(Math.floor(windowPerformanceTimeOrigin + loadEventEnd)).toISOString(),
                operationStartTime: new Date(Math.floor(windowPerformanceTimeOrigin + fetchStart)).toISOString(),
                operationName: "WorkloadLoad",
                operationVersion: "1.0.0",
            };
        }
    }

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    const maxResoureceTimingsNum = 20;
    /** @internal */
    function getWorkloadPerformance(workloadIframePerformance) {
        const { workloadBootstrapStart, workloadBootstrapEnd } = workloadIframePerformance;
        const navigator = window.navigator;
        const navigatorConnection = navigator?.connection;
        const performanceNavigationTiming = (window.performance.getEntriesByType("navigation"))[0];
        const { connectEnd, connectStart, decodedBodySize, domContentLoadedEventEnd, domContentLoadedEventStart, domInteractive, domainLookupEnd, domainLookupStart, encodedBodySize, entryType, fetchStart, loadEventStart, loadEventEnd, nextHopProtocol, redirectCount, redirectEnd, redirectStart, requestStart, responseStart, responseEnd, secureConnectionStart, transferSize, unloadEventEnd, unloadEventStart, } = performanceNavigationTiming;
        const performanceResourceTimings = (window.performance.getEntriesByType("resource"));
        const workloadResourceTimings = performanceResourceTimings.map(performanceResourceTiming => {
            return {
                fetchStart: String(Math.round(performanceResourceTiming.fetchStart)),
                initiatorType: performanceResourceTiming.initiatorType,
                name: performanceResourceTiming.name,
                requestStart: String(Math.round(performanceResourceTiming.requestStart)),
                responseStart: String(Math.round(performanceResourceTiming.responseStart)),
                responseEnd: String(Math.round(performanceResourceTiming.responseEnd)),
                transferSize: String(Math.round(performanceResourceTiming.transferSize ?? -1)),
            };
        });
        const workloadResourceTimingsNum = workloadResourceTimings.length;
        // keep the workloadResourceTimings less than maxResoureceTimingsNum and return the max perf cost Timings; else will be trunked by telemetry service
        if (workloadResourceTimings.length > maxResoureceTimingsNum) {
            workloadResourceTimings.sort((resourceTiming1, resourceTiming2) => {
                return (Number(resourceTiming2.responseEnd) - Number(resourceTiming2.requestStart)) - (Number(resourceTiming1.responseEnd) - Number(resourceTiming1.requestStart));
            });
            workloadResourceTimings.splice(maxResoureceTimingsNum);
        }
        const windowPerformanceTimeOrigin = window.performance.timeOrigin;
        // Use bowser? to compatible with es6
        const browser = bowser__namespace?.getParser ? bowser__namespace.getParser(navigator.userAgent) : undefined;
        return {
            connectEnd: String(Math.round(connectEnd)),
            connectStart: String(Math.round(connectStart)),
            decodedBodySize: String(decodedBodySize ?? -1),
            domContentLoadedEventEnd: String(Math.round(domContentLoadedEventEnd)),
            domContentLoadedEventStart: String(Math.round(domContentLoadedEventStart)),
            domInteractive: String(Math.round(domInteractive)),
            domainLookupEnd: String(Math.round(domainLookupEnd)),
            domainLookupStart: String(Math.round(domainLookupStart)),
            encodedBodySize: String(encodedBodySize ?? -1),
            entryType: entryType,
            fetchStart: String(Math.round(fetchStart)),
            loadEventStart: String(Math.round(loadEventStart)),
            loadEventEnd: String(Math.round(loadEventEnd)),
            nextHopProtocol,
            redirectCount: String(redirectCount),
            redirectEnd: String(Math.round(redirectEnd)),
            redirectStart: String(Math.round(redirectStart)),
            requestStart: String(Math.round(requestStart)),
            responseStart: String(Math.round(responseStart)),
            responseEnd: String(Math.round(responseEnd)),
            secureConnectionStart: String(Math.round(secureConnectionStart)),
            transferSize: String(transferSize ?? -1),
            unloadEventEnd: String(Math.round(unloadEventEnd)),
            unloadEventStart: String(Math.round(unloadEventStart)),
            timeOrigin: String(Math.round(windowPerformanceTimeOrigin)),
            deviceMemory: String(navigator.deviceMemory || 0),
            downlink: String(navigatorConnection?.downlink),
            effectiveType: String(navigatorConnection?.effectiveType),
            hardwareConcurrency: String(navigator.hardwareConcurrency),
            rtt: String(navigatorConnection?.rtt),
            userAgent: navigator.userAgent,
            browserName: browser?.getBrowserName() ?? '',
            browserVersion: browser?.getBrowserVersion() ?? '',
            operatingSystemName: browser?.getOSName() ?? '',
            operatingSystemVersion: browser?.getOSVersion() ?? '',
            workloadBootstrapEnd: String(Math.round(workloadBootstrapEnd)),
            workloadBootstrapStart: String(Math.round(workloadBootstrapStart)),
            performanceResourceTimings: JSON.stringify(workloadResourceTimings),
            performanceResourceTimingsNum: String(workloadResourceTimingsNum),
        };
    }

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    /**
     * @description
     * Every workload app needs to support being loaded in two modes:
     * - **UI mode**: App in UI mode is loaded in visible IFrames and listens for its own route changes
     * to render corresponding UI components, including pages, panels, dialogs, and so on.
     * - **Worker mode**: App in worker mode runs in an invisible IFrame, which is mainly used to receive
     * commands sent from the outside world and respond to them.
     *
     * The bootstrap() method is to simplify the initialization steps. The bootstrap() method internally
     * detects whether the current App is loaded in UI mode or worker mode, and then call the appropriate
     * initialization method (initializeUI vs. initializeWorker). After the initialization is complete,
     * it notifies Fabric micro-frontend framework of the initialization success or failure.
     *
     * @returns promise which resolves when the initialization is complete.
     */
    async function bootstrap(config) {
        const { iframeType, environmentName, iframeId, workloadName, bootstrapPath, cdnFallbackTime, parallelLoadingEnabled, errorHandlingEnabled } = WorkloadMetaLoader.Load();
        const client = new WorkloadClient$1({
            workloadHostWindow: config.workloadHostWindow ?? DefaultWorkloadClientConfig.workloadHostWindow
        });
        try {
            flushEventAndInit(client);
            window.postCdnLazyLoadFailureEvent = client._telemetry.postCdnLazyLoadFailureEvent.bind(client._telemetry);
            if (errorHandlingEnabled) {
                if (window.detectWorkloadLoadTimeoutID) {
                    clearTimeout(window.detectWorkloadLoadTimeoutID);
                    window.detectWorkloadLoadTimeoutID = null;
                }
                if (window.onWorkloadLoadError) {
                    window.removeEventListener('error', window.onWorkloadLoadError, true);
                }
            }
            const params = {
                environmentName,
                bootstrapPath: bootstrapPath ? (bootstrapPath.startsWith('/') ? bootstrapPath : `/${bootstrapPath}`) : null,
            };
            window.performance.mark("FabricWorkloadBootstrapLoadStartTimestamp");
            client._telemetry.logEvent({
                name: exports.WorkloadLoadEventType.WorkloadBootstrapStart,
                properties: {
                    workloadName,
                    iframeType,
                    iframeId,
                }
            });
            window.reportPackageMetadata = (meta) => {
                if (!window.packageMetadata)
                    window.packageMetadata = {};
                window.packageMetadata[meta.packageName] = meta;
                client._telemetry.reportPackageMetadata({
                    originIframeId: iframeId,
                    iframeType,
                    workloadName,
                    packageMetadata: window.packageMetadata,
                });
            };
            window.reportPackageMetadata({
                packageName: PACKAGE_NAME$2,
                version: CLIENT_VERSION$2,
                publishDate: PUBLISH_DATE$2
            });
            const workIFrameState = await client._worker.workIFrameState;
            if (iframeType === 'worker') {
                await config.initializeWorker(params);
                if (parallelLoadingEnabled) {
                    workIFrameState['initState'] = 'succeeded';
                    if (workIFrameState['callbacks']) {
                        Object.values(workIFrameState['callbacks']).map(iframeCallback => {
                            if (typeof iframeCallback === 'function') {
                                iframeCallback();
                            }
                        });
                    }
                }
            }
            else {
                if (!parallelLoadingEnabled || workIFrameState['initState'] === 'succeeded') {
                    await config.initializeUI(params);
                }
                else {
                    await new Promise((resolve) => {
                        if (!workIFrameState['callbacks']) {
                            workIFrameState['callbacks'] = {};
                        }
                        workIFrameState['callbacks'][iframeType] = (async () => {
                            await config.initializeUI(params);
                            resolve();
                        });
                    });
                }
                client._interaction.onResetFocus((config) => {
                    const allTabbable = document.body.querySelectorAll('input, select, textarea, button, [href], [tabindex]:not([tabindex="-1"])');
                    if (allTabbable.length > 0) {
                        if (config.index === 'first') {
                            allTabbable[0].focus();
                        }
                        else {
                            allTabbable[allTabbable.length - 1].focus();
                        }
                    }
                });
                if (iframeType === 'page' || iframeType === 'panel') {
                    window.performance.mark("FabricWorkloadBootstrapLoadEndTimestamp");
                    const workloadBootstrapStartTimeMarker = window.performance.getEntriesByName("FabricWorkloadBootstrapLoadStartTimestamp", "mark");
                    const workloadBootstrapEndTimeMarker = window.performance.getEntriesByName("FabricWorkloadBootstrapLoadEndTimestamp", "mark");
                    const workloadBootstrapStartTimestamp = workloadBootstrapStartTimeMarker?.length > 0 ? workloadBootstrapStartTimeMarker[0].startTime : 0;
                    const workloadBootstrapEndTimestamp = workloadBootstrapEndTimeMarker?.length > 0 ? workloadBootstrapEndTimeMarker[0].startTime : 0;
                    client._telemetry.logEvent({
                        name: exports.WorkloadLoadEventType.WorkloadBootstrap,
                        properties: populateWorkloadLoadPerformanceTelemetry({
                            workloadBootstrapStartTimestamp,
                            workloadBootstrapEndTimestamp,
                            clientVersion: CLIENT_VERSION$2,
                            workloadName,
                            iframeId,
                        })
                    });
                    client._interaction.onQueryDomRect((config) => {
                        const { selector, setFocus } = config;
                        let target;
                        if (selector) {
                            target = document.querySelector(selector);
                        }
                        if (!target || !selector) {
                            return Promise.resolve({ isSucceed: false });
                        }
                        else {
                            const rect = target.getBoundingClientRect();
                            if (setFocus) {
                                target.focus();
                            }
                            return Promise.resolve({
                                isSucceed: true,
                                rect
                            });
                        }
                    });
                }
                registerDocumentEventListeners(client);
            }
            client._errorHandling.registerUnhandledExceptionHandler({ iframe: iframeType });
            try {
                client._performanceItems.init();
            }
            catch (e) {
                client._telemetry.logEvent({
                    name: 'PerformanceItemsClientInitFailed',
                    properties: { errorName: e?.name, errorMessage: e?.message },
                });
            }
            const workloadBootstrapStartTimeMarker = window.performance.getEntriesByName("FabricWorkloadBootstrapLoadStartTimestamp", "mark");
            const workloadBootstrapStart = workloadBootstrapStartTimeMarker?.length > 0 ? workloadBootstrapStartTimeMarker[0].startTime : 0;
            const workloadBootstrapEnd = Date.now() - window.performance.timeOrigin;
            client._telemetry.postLifecycleEvent({
                name: exports.LifecycleEventType.InitSucceeded,
                properties: {
                    clientVersion: CLIENT_VERSION$2,
                    iframeType,
                    iframeId,
                    workloadName,
                    isCDNFallback: cdnFallbackTime != null,
                    ...getWorkloadPerformance({ workloadBootstrapStart, workloadBootstrapEnd }),
                }
            });
        }
        catch (error) {
            let errMessage = '';
            let errStack = '';
            if (error instanceof Error) {
                errMessage = error.message || '';
                errStack = error.stack ? error.stack.slice(0, 256) : '';
            }
            else {
                errMessage = String(error);
            }
            client._telemetry.postLifecycleEvent({
                name: exports.LifecycleEventType.InitFailed,
                properties: {
                    errMessage,
                    errStack,
                    clientVersion: CLIENT_VERSION$2,
                    isCDNFallback: cdnFallbackTime != null,
                },
            });
        }
        finally {
            postCDNFallbackMessage(client, workloadName, cdnFallbackTime);
        }
    }
    function registerDocumentEventListeners(client) {
        document.addEventListener('click', (event) => {
            client._interaction.postDOMEvent({ eventType: event.type });
        });
        document.addEventListener('keydown', (event) => {
            client._interaction.postDOMEvent({
                eventType: event.type,
                eventProps: {
                    key: event.key
                }
            });
        });
        document.addEventListener('keyup', (event) => {
            client._interaction.postDOMEvent({
                eventType: event.type,
                eventProps: {
                    key: event.key
                }
            });
        });
    }
    function flushEventAndInit(client) {
        try {
            let cachedEvents = [];
            try {
                const cachedEventsJSON = sessionStorage.getItem('cachedEvents');
                if (cachedEventsJSON) {
                    cachedEvents = JSON.parse(cachedEventsJSON);
                }
            }
            catch (exception) {
                client._telemetry.logEvent({
                    name: 'ParseCachedEventsFailed',
                    properties: { error: String(exception) }
                });
            }
            for (const event of cachedEvents) {
                client._telemetry.logEvent(event);
            }
            try {
                sessionStorage.removeItem('cachedEvents');
            }
            catch (exception) {
                console.error(exception);
            }
            window.logEvent = client._telemetry.logEvent.bind(client._telemetry);
        }
        catch { }
    }
    function postCDNFallbackMessage(client, workloadName, cdnFallbackTime) {
        if (cdnFallbackTime) {
            client._telemetry.postCdnFallbackEvent({
                workloadName: workloadName,
                timestamp: cdnFallbackTime ?? Date.now().toString(),
            });
        }
    }

    const THEME_ATTRIBUTE = 'data-theme';
    const STYLE_ELEMENT_ID = "theme-styles";
    const defaultOptions = {
        enableThemeGlobally: true
    };
    /**
     * CssVariableThemeProvider loads themes from json. Writes json themes into the dom as css variables. It can return the theme object to consumers
     */
    class CssVariableThemeProvider {
        constructor() {
            this.styleElement = document.createElement('style');
            this.styleElement.id = STYLE_ELEMENT_ID;
            document.head.appendChild(this.styleElement);
        }
        provideTheme(theme, options = defaultOptions) {
            let styles = this.buildCSSVarList(theme.tokens);
            styles += this.buildCSSColorScheme(theme);
            const stylesheetContents = this.createStyleSheet(styles, theme.name);
            this.styleElement.textContent = stylesheetContents;
            if (options.enableThemeGlobally)
                this.enableThemeGlobally(theme.name);
        }
        enableThemeGlobally(themeName) {
            window.document.documentElement.setAttribute(THEME_ATTRIBUTE, themeName);
        }
        createStyleSheet(styles, themeName) {
            return `
[data-theme="${themeName}"] {
    ${styles}
}
`;
        }
        buildCSSVarList(tokens) {
            let styles = '';
            for (const [key, value] of Object.entries(tokens)) {
                styles += `--${key}: ${value};\n`;
            }
            return styles;
        }
        buildCSSColorScheme(theme) {
            return `color-scheme: ${theme.colorScheme};\n`;
        }
    }

    // This version file is auto generated from /fabric/.pipelines/scripts/publishPackages.ts via npm package publish pipeline.
    const PACKAGE_NAME$1 = '@fabric/workload-client-3p';
    const CLIENT_VERSION$1 = '0.28.40';
    const PUBLISH_DATE$1 = '2025-05-20T14:54:12.635Z';
    if (window.reportPackageMetadata) {
        window.reportPackageMetadata({
            packageName: PACKAGE_NAME$1,
            version: CLIENT_VERSION$1,
            publishDate: PUBLISH_DATE$1
        });
    }
    else {
        if (!window.packageMetadata)
            window.packageMetadata = {};
        window.packageMetadata[PACKAGE_NAME$1] = {
            packageName: PACKAGE_NAME$1,
            version: CLIENT_VERSION$1,
            publishDate: PUBLISH_DATE$1
        };
    }

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    var WorkloadMessageType;
    (function (WorkloadMessageType) {
        WorkloadMessageType["acquireAADToken"] = "acquireAADToken";
        WorkloadMessageType["acquireFrontendAADToken"] = "acquireFrontendAADToken";
        WorkloadMessageType["cancelItemJob"] = "cancelItemJob";
        WorkloadMessageType["createItem"] = "createItem";
        WorkloadMessageType["createItemScheduledJobs"] = "createItemScheduledJobs";
        WorkloadMessageType["deleteItem"] = "deleteItem";
        WorkloadMessageType["deleteItemScheduledJobs"] = "deleteItemScheduledJobs";
        WorkloadMessageType["getItem"] = "getItem";
        WorkloadMessageType["getItemDefinition"] = "getItemDefinition";
        WorkloadMessageType["getItemJobHistory"] = "getItemJobHistory";
        WorkloadMessageType["getItemScheduledJobs"] = "getItemScheduledJobs";
        WorkloadMessageType["listItemSchedules"] = "listItemSchedules";
        WorkloadMessageType["openBrowserTabAsync"] = "OpenBrowserTabAsync";
        WorkloadMessageType["resolveEndpoint"] = "resolveEndpoint";
        WorkloadMessageType["runItemJob"] = "runItemJob";
        WorkloadMessageType["updateItem"] = "updateItem";
        WorkloadMessageType["updateItemDefinition"] = "updateItemDefinition";
        WorkloadMessageType["updateItemScheduledJobs"] = "updateItemScheduledJobs";
    })(WorkloadMessageType || (WorkloadMessageType = {}));
    const acquireAADToken = createAsyncWorkloadMessage(WorkloadMessageType.acquireAADToken);
    const acquireFrontendAADToken = createAsyncWorkloadMessage(WorkloadMessageType.acquireFrontendAADToken);
    const cancelItemJob = createAsyncWorkloadMessage(WorkloadMessageType.cancelItemJob);
    const createItem = createAsyncWorkloadMessage(WorkloadMessageType.createItem);
    const createItemScheduledJobs = createAsyncWorkloadMessage(WorkloadMessageType.createItemScheduledJobs);
    const deleteItem = createAsyncWorkloadMessage(WorkloadMessageType.deleteItem);
    const deleteItemScheduledJobs = createAsyncWorkloadMessage(WorkloadMessageType.deleteItemScheduledJobs);
    const getItem = createAsyncWorkloadMessage(WorkloadMessageType.getItem);
    const getItemDefinition = createAsyncWorkloadMessage(WorkloadMessageType.getItemDefinition);
    const getItemJobHistory = createAsyncWorkloadMessage(WorkloadMessageType.getItemJobHistory);
    const getItemScheduledJobs = createAsyncWorkloadMessage(WorkloadMessageType.getItemScheduledJobs);
    const listItemSchedules = createAsyncWorkloadMessage(WorkloadMessageType.listItemSchedules);
    const openBrowserTabAsync = createAsyncWorkloadMessage(WorkloadMessageType.openBrowserTabAsync);
    const resolveEndpoint = createAsyncWorkloadMessage(WorkloadMessageType.resolveEndpoint);
    const runItemJob = createAsyncWorkloadMessage(WorkloadMessageType.runItemJob);
    const updateItem = createAsyncWorkloadMessage(WorkloadMessageType.updateItem);
    const updateItemDefinition = createAsyncWorkloadMessage(WorkloadMessageType.updateItemDefinition);
    const updateItemScheduledJobs = createAsyncWorkloadMessage(WorkloadMessageType.updateItemScheduledJobs);
    const Messages = {
        ...Messages$1,
        acquireAADToken,
        acquireFrontendAADToken,
        cancelItemJob,
        createItem,
        createItemScheduledJobs,
        deleteItem,
        deleteItemScheduledJobs,
        getItem,
        getItemDefinition,
        getItemJobHistory,
        getItemScheduledJobs,
        listItemSchedules,
        openBrowserTabAsync,
        resolveEndpoint,
        runItemJob,
        updateItem,
        updateItemDefinition,
        updateItemScheduledJobs,
    };

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    class ItemCrudClient {
        constructor(broker) {
            this.broker = broker;
        }
        createItem(params) {
            return this.broker.sendAsync(Messages.createItem.start(params));
        }
        getItem(params) {
            return this.broker.sendAsync(Messages.getItem.start(params));
        }
        updateItem(params) {
            return this.broker.sendAsync(Messages.updateItem.start(params));
        }
        deleteItem(params) {
            return this.broker.sendAsync(Messages.deleteItem.start(params));
        }
    }

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    /** @hidden */
    class ItemCrudPublicClient {
        constructor(broker) {
            this.broker = broker;
        }
        getItemDefinition(params) {
            return this.broker.sendAsync(Messages.getItemDefinition.start(params));
        }
        updateItemDefinition(params) {
            return this.broker.sendAsync(Messages.updateItemDefinition.start(params));
        }
    }

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    class ItemScheduleClient {
        constructor(broker) {
            this.broker = broker;
        }
        getItemScheduledJobs(objectId) {
            return this.broker.sendAsync(Messages.getItemScheduledJobs.start({ objectId }));
        }
        listItemSchedules(listItemSchedulesParams) {
            return this.broker.sendAsync(Messages.listItemSchedules.start(listItemSchedulesParams));
        }
        createItemScheduledJobs(createItemScheduledJobs) {
            return this.broker.sendAsync(Messages.createItemScheduledJobs.start(createItemScheduledJobs));
        }
        updateItemScheduledJobs(updateItemScheduleParams) {
            return this.broker.sendAsync(Messages.updateItemScheduledJobs.start(updateItemScheduleParams));
        }
        deleteItemScheduledJobs(deleteItemScheduledJobs) {
            return this.broker.sendAsync(Messages.deleteItemScheduledJobs.start(deleteItemScheduledJobs));
        }
        runItemJob(jobParams) {
            return this.broker.sendAsync(Messages.runItemJob.start(jobParams));
        }
        cancelItemJob(jobParams) {
            return this.broker.sendAsync(Messages.cancelItemJob.start(jobParams));
        }
        getItemJobHistory(getHistoryParams) {
            return this.broker.sendAsync(Messages.getItemJobHistory.start(getHistoryParams));
        }
    }

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    class AuthClient {
        constructor(broker) {
            this.broker = broker;
        }
        acquireAccessToken(params) {
            return this.broker.sendAsync(Messages.acquireAADToken.start(params));
        }
        /** @hidden */
        acquireFrontendAccessToken(params) {
            return this.broker.sendAsync(Messages.acquireFrontendAADToken.start(params));
        }
    }

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    class EndpointClient {
        constructor(broker) {
            this.broker = broker;
        }
        resolveEndpoint(params) {
            return this.broker.sendAsync(Messages.resolveEndpoint.start(params));
        }
    }

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    class NavigationClient {
        constructor(workloadClientCommon) {
            this.workloadClientCommon = workloadClientCommon;
        }
        navigate(target, route) {
            return this.workloadClientCommon.navigation.navigate(target, route);
        }
        onNavigate(callback) {
            return this.workloadClientCommon.navigation.onNavigate(callback);
        }
        onBeforeNavigateAway(callback) {
            return this.workloadClientCommon.navigation.onBeforeNavigateAway(callback);
        }
        onAfterNavigateAway(callback) {
            return this.workloadClientCommon.navigation.onAfterNavigateAway(callback);
        }
        openBrowserTab(params) {
            return this.workloadClientCommon.broker.sendAsync(Messages.openBrowserTabAsync.start(params));
        }
    }

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    class WorkloadClient {
        constructor(config = DefaultWorkloadClientConfig) {
            this.config = config;
            this.client = new WorkloadClient$1(this.config);
            this.action = this.client.action;
            this.itemCrud = new ItemCrudClient(this.broker);
            this.itemCrudPublic = new ItemCrudPublicClient(this.broker);
            this.itemDefinitions = this.client.itemDefinitions;
            this.itemRecentRuns = this.client.itemRecentRuns;
            this.itemSchedule = new ItemScheduleClient(this.broker);
            this.itemSettings = this.client.itemSettings;
            this.auth = new AuthClient(this.broker);
            this.datahub = this.client.datahub;
            this.dialog = this.client.dialog;
            this.endpoint = new EndpointClient(this.broker);
            this.errorHandling = this.client.errorHandling;
            this.event = this.client.event;
            this.favorite = this.client.favorite;
            this.navigation = new NavigationClient(this.client);
            this.notification = this.client.notification;
            this.page = this.client.page;
            this.panel = this.client.panel;
            this.permission = this.client.permission;
            this.settings = this.client.settings;
            this.state = this.client.state;
            this.subfolder = this.client.subfolder;
            this.theme = this.client.theme;
        }
        get broker() {
            return this.client.broker;
        }
    }
    /**
     * @description create an workload client instance.
     *
     * @returns the workload client instance
     *
     * @param config configuration of the workload client, optional with default config:
     * - `workloadHostWindow` – A window object - Reference to the workload host window, usefully when workloads have nested frames and use the workload client library in the inner frame - optional with default value to window.parent!.
     */
    function createWorkloadClient(config = DefaultWorkloadClientConfig) {
        return new WorkloadClient(config);
    }

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    /**
     * @description An array of all valid Power BI item types.
     */
    /**
     * @description An enum of all valid provision states
     */
    exports.ProvisionStateEnum = void 0;
    (function (ProvisionStateEnum) {
        ProvisionStateEnum[ProvisionStateEnum["InProgress"] = 0] = "InProgress";
        ProvisionStateEnum[ProvisionStateEnum["Active"] = 1] = "Active";
        ProvisionStateEnum[ProvisionStateEnum["Migrating"] = 2] = "Migrating";
        ProvisionStateEnum[ProvisionStateEnum["SoftDeleted"] = 19] = "SoftDeleted";
        ProvisionStateEnum[ProvisionStateEnum["Failed"] = 20] = "Failed";
        ProvisionStateEnum[ProvisionStateEnum["Deleting"] = 21] = "Deleting";
        ProvisionStateEnum[ProvisionStateEnum["DisabledByDeprovisioning"] = 30] = "DisabledByDeprovisioning";
        ProvisionStateEnum[ProvisionStateEnum["DeprovisioningFailed"] = 31] = "DeprovisioningFailed";
        ProvisionStateEnum[ProvisionStateEnum["DeletedByDeprovision"] = 32] = "DeletedByDeprovision";
        ProvisionStateEnum[ProvisionStateEnum["DeletedByWorkload"] = 34] = "DeletedByWorkload";
    })(exports.ProvisionStateEnum || (exports.ProvisionStateEnum = {}));
    /**
     * @description An enum of all valid payload content types
     */
    exports.PayloadContentTypeEnum = void 0;
    (function (PayloadContentTypeEnum) {
        PayloadContentTypeEnum[PayloadContentTypeEnum["InlineJson"] = 0] = "InlineJson";
        PayloadContentTypeEnum[PayloadContentTypeEnum["InlinePlainText"] = 1] = "InlinePlainText";
        PayloadContentTypeEnum[PayloadContentTypeEnum["InlineXml"] = 2] = "InlineXml";
        PayloadContentTypeEnum[PayloadContentTypeEnum["InlineBase64"] = 3] = "InlineBase64";
    })(exports.PayloadContentTypeEnum || (exports.PayloadContentTypeEnum = {}));
    var RestrictionSources;
    (function (RestrictionSources) {
        RestrictionSources[RestrictionSources["None"] = 0] = "None";
        RestrictionSources[RestrictionSources["DLP"] = 1] = "DLP";
        RestrictionSources[RestrictionSources["MIP"] = 2] = "MIP"; // MIP protection policies
    })(RestrictionSources || (RestrictionSources = {}));
    /**
     * @description An enum of all valid item relation settings
     */
    exports.ItemRelationSettings = void 0;
    (function (ItemRelationSettings) {
        ItemRelationSettings[ItemRelationSettings["Association"] = 0] = "Association";
        ItemRelationSettings[ItemRelationSettings["CascadeDelete"] = 1] = "CascadeDelete";
        ItemRelationSettings[ItemRelationSettings["WeakAssociation"] = 2] = "WeakAssociation";
        ItemRelationSettings[ItemRelationSettings["Datasource"] = 3] = "Datasource";
        ItemRelationSettings[ItemRelationSettings["PushData"] = 4] = "PushData";
        ItemRelationSettings[ItemRelationSettings["Orchestration"] = 5] = "Orchestration";
        ItemRelationSettings[ItemRelationSettings["Shortcut"] = 6] = "Shortcut";
        ItemRelationSettings[ItemRelationSettings["HiddenInWorkspace"] = 7] = "HiddenInWorkspace";
    })(exports.ItemRelationSettings || (exports.ItemRelationSettings = {}));
    /**
     * @description An enum of all methods to apply a label
     */
    exports.TriggerType = void 0;
    (function (TriggerType) {
        TriggerType[TriggerType["Manual"] = 1] = "Manual";
        TriggerType[TriggerType["InheritanceUponCreation"] = 2] = "InheritanceUponCreation";
        TriggerType[TriggerType["Publish"] = 3] = "Publish";
        TriggerType[TriggerType["DownstreamInheritanceBySystem"] = 4] = "DownstreamInheritanceBySystem";
        TriggerType[TriggerType["DownstreamInheritanceByUser"] = 5] = "DownstreamInheritanceByUser";
        TriggerType[TriggerType["InheritanceFromDataSource"] = 6] = "InheritanceFromDataSource";
        TriggerType[TriggerType["Alm"] = 7] = "Alm";
        TriggerType[TriggerType["PublicApiPrivileged"] = 8] = "PublicApiPrivileged";
        TriggerType[TriggerType["PublicApiStandard"] = 9] = "PublicApiStandard";
        TriggerType[TriggerType["DefaultLabelPolicy"] = 10] = "DefaultLabelPolicy";
    })(exports.TriggerType || (exports.TriggerType = {}));

    // -----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    // -----------------------------------------------------------------------
    /**
     * @description An enum of all valid item types that support the Most Recently Used (MRU) feature
     */
    var MRUItemType;
    (function (MRUItemType) {
        MRUItemType[MRUItemType["Dashboards"] = 0] = "Dashboards";
        MRUItemType[MRUItemType["Reports"] = 1] = "Reports";
        MRUItemType[MRUItemType["Workbooks"] = 2] = "Workbooks";
        MRUItemType[MRUItemType["AppInstance"] = 3] = "AppInstance";
        MRUItemType[MRUItemType["RdlReports"] = 4] = "RdlReports";
        MRUItemType[MRUItemType["Workspaces"] = 5] = "Workspaces";
        MRUItemType[MRUItemType["Datasets"] = 6] = "Datasets";
        MRUItemType[MRUItemType["FabricItem"] = 7] = "FabricItem";
        MRUItemType[MRUItemType["Datamarts"] = 8] = "Datamarts";
    })(MRUItemType || (MRUItemType = {}));

    // -----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    // -----------------------------------------------------------------------
    /**
     * @description An enum type of all valid schedule types after serialization
     */
    var ScheduleTypeWire;
    (function (ScheduleTypeWire) {
        ScheduleTypeWire[ScheduleTypeWire["None"] = 0] = "None";
        ScheduleTypeWire[ScheduleTypeWire["Daily"] = 1] = "Daily";
        ScheduleTypeWire[ScheduleTypeWire["Cron"] = 2] = "Cron";
        ScheduleTypeWire[ScheduleTypeWire["Weekly"] = 3] = "Weekly";
        ScheduleTypeWire[ScheduleTypeWire["CronHours"] = 4] = "CronHours";
        ScheduleTypeWire[ScheduleTypeWire["Monthly"] = 5] = "Monthly";
        ScheduleTypeWire[ScheduleTypeWire["RelativeMonthly"] = 6] = "RelativeMonthly";
    })(ScheduleTypeWire || (ScheduleTypeWire = {}));
    /**
     * @description An enum of all valid item job status types
     */
    exports.ItemJobStatus = void 0;
    (function (ItemJobStatus) {
        /**
         * @description Job is scheduled or triggered, but not yet started
         */
        ItemJobStatus[ItemJobStatus["NotStarted"] = 0] = "NotStarted";
        /**
         * @description Job is running
         */
        ItemJobStatus[ItemJobStatus["InProgress"] = 1] = "InProgress";
        /**
         * @description Job is completed successfully
         */
        ItemJobStatus[ItemJobStatus["Completed"] = 2] = "Completed";
        /**
         * @description Job is failed because of error
         */
        ItemJobStatus[ItemJobStatus["Failed"] = 3] = "Failed";
        /**
         * @description Job is cancelled by user
         */
        ItemJobStatus[ItemJobStatus["Cancelled"] = 4] = "Cancelled";
        /**
         * @description Job could not be found
         */
        ItemJobStatus[ItemJobStatus["NotFound"] = 5] = "NotFound";
        /**
         * @description Job is duplicated
         */
        ItemJobStatus[ItemJobStatus["Duplicate"] = 6] = "Duplicate";
        ItemJobStatus[ItemJobStatus["OwnerUserMissing"] = 7] = "OwnerUserMissing";
        /**
         * @description Job is marked as Deadletter if not started after trigger for N hours
         */
        ItemJobStatus[ItemJobStatus["DeadLettered"] = 8] = "DeadLettered";
        /**
         * @description This status is used for backwards compatibility and never set
         */
        ItemJobStatus[ItemJobStatus["Unknown"] = 9] = "Unknown";
    })(exports.ItemJobStatus || (exports.ItemJobStatus = {}));

    // This version file is auto generated from /fabric/.pipelines/scripts/publishPackages.ts via npm package publish pipeline.
    const PACKAGE_NAME = '@fabric/data-access-item-common';
    const CLIENT_VERSION = '1.2.38';
    const PUBLISH_DATE = '2025-06-18T08:47:12.875Z';
    if (window.reportPackageMetadata) {
        window.reportPackageMetadata({
            packageName: PACKAGE_NAME,
            version: CLIENT_VERSION,
            publishDate: PUBLISH_DATE
        });
    }
    else {
        if (!window.packageMetadata)
            window.packageMetadata = {};
        window.packageMetadata[PACKAGE_NAME] = {
            packageName: PACKAGE_NAME,
            version: CLIENT_VERSION,
            publishDate: PUBLISH_DATE
        };
    }

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    /**
     * @description The type of the definition part payload. Additional payload types may be added over time.
     *
     * @hidden
     */
    exports.PayloadType = void 0;
    (function (PayloadType) {
        /**
         * @description Inline Base 64.
         */
        PayloadType["InlineBase64"] = "InlineBase64";
    })(exports.PayloadType || (exports.PayloadType = {}));

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    exports.WorkloadAuthError = void 0;
    (function (WorkloadAuthError) {
        /**
        * @description Indicates that authentication feature is not available.
        */
        WorkloadAuthError[WorkloadAuthError["UnsupportedError"] = 0] = "UnsupportedError";
        /**
         * @description Indicates that there was a problem with user interaction.
         */
        WorkloadAuthError[WorkloadAuthError["UserInteractionFailedError"] = 1] = "UserInteractionFailedError";
        /**
         * @description Indicates that there's a problem with the configuration in the workload for authentication (The redirectUri/Audience does not meet the requirements).
         */
        WorkloadAuthError[WorkloadAuthError["WorkloadConfigError"] = 2] = "WorkloadConfigError";
        /**
         * @description Indicates that there was an unknown error when trying to fetch the token.
         */
        WorkloadAuthError[WorkloadAuthError["UnknownError"] = 3] = "UnknownError";
        /**
         * @description Indicates that there is a problem with the provided authentication scopes.
         */
        WorkloadAuthError[WorkloadAuthError["ScopesError"] = 4] = "ScopesError";
    })(exports.WorkloadAuthError || (exports.WorkloadAuthError = {}));

    //-----------------------------------------------------------------------
    // <copyright company="Microsoft Corporation">
    //        Copyright (c) Microsoft Corporation.  All rights reserved.
    // </copyright>
    //-----------------------------------------------------------------------
    /**
     * @description The source of the error.
     */
    exports.WorkloadErrorSource = void 0;
    (function (WorkloadErrorSource) {
        /**
        * @description Indicates that the error was a system error.
        */
        WorkloadErrorSource[WorkloadErrorSource["System"] = 0] = "System";
        /**
        * @description Indicates that the error was a user error.
        */
        WorkloadErrorSource[WorkloadErrorSource["User"] = 1] = "User";
        /**
        * @description Indicates that the error was an external error.
        */
        WorkloadErrorSource[WorkloadErrorSource["External"] = 2] = "External";
    })(exports.WorkloadErrorSource || (exports.WorkloadErrorSource = {}));

    exports.CLIENT_VERSION = CLIENT_VERSION$1;
    exports.CssVariableThemeProvider = CssVariableThemeProvider;
    exports.DefaultWorkloadClientConfig = DefaultWorkloadClientConfig;
    exports.WorkloadClient = WorkloadClient$1;
    exports.Messages = Messages$1;
    exports.PreDefinedEventName = PreDefinedEventName;
    exports.STYLE_ELEMENT_ID = STYLE_ELEMENT_ID;
    exports.THEME_ATTRIBUTE = THEME_ATTRIBUTE;
    exports.bootstrap = bootstrap;
    exports.createWorkloadClient = createWorkloadClient;

}));



/***/ }),

/***/ "./node_modules/bowser/es5.js":
/*!************************************!*\
  !*** ./node_modules/bowser/es5.js ***!
  \************************************/
/***/ (function(module) {

!function(e,t){ true?module.exports=t():0}(this,(function(){return function(e){var t={};function r(i){if(t[i])return t[i].exports;var n=t[i]={i:i,l:!1,exports:{}};return e[i].call(n.exports,n,n.exports,r),n.l=!0,n.exports}return r.m=e,r.c=t,r.d=function(e,t,i){r.o(e,t)||Object.defineProperty(e,t,{enumerable:!0,get:i})},r.r=function(e){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},r.t=function(e,t){if(1&t&&(e=r(e)),8&t)return e;if(4&t&&"object"==typeof e&&e&&e.__esModule)return e;var i=Object.create(null);if(r.r(i),Object.defineProperty(i,"default",{enumerable:!0,value:e}),2&t&&"string"!=typeof e)for(var n in e)r.d(i,n,function(t){return e[t]}.bind(null,n));return i},r.n=function(e){var t=e&&e.__esModule?function(){return e.default}:function(){return e};return r.d(t,"a",t),t},r.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},r.p="",r(r.s=90)}({17:function(e,t,r){"use strict";t.__esModule=!0,t.default=void 0;var i=r(18),n=function(){function e(){}return e.getFirstMatch=function(e,t){var r=t.match(e);return r&&r.length>0&&r[1]||""},e.getSecondMatch=function(e,t){var r=t.match(e);return r&&r.length>1&&r[2]||""},e.matchAndReturnConst=function(e,t,r){if(e.test(t))return r},e.getWindowsVersionName=function(e){switch(e){case"NT":return"NT";case"XP":return"XP";case"NT 5.0":return"2000";case"NT 5.1":return"XP";case"NT 5.2":return"2003";case"NT 6.0":return"Vista";case"NT 6.1":return"7";case"NT 6.2":return"8";case"NT 6.3":return"8.1";case"NT 10.0":return"10";default:return}},e.getMacOSVersionName=function(e){var t=e.split(".").splice(0,2).map((function(e){return parseInt(e,10)||0}));if(t.push(0),10===t[0])switch(t[1]){case 5:return"Leopard";case 6:return"Snow Leopard";case 7:return"Lion";case 8:return"Mountain Lion";case 9:return"Mavericks";case 10:return"Yosemite";case 11:return"El Capitan";case 12:return"Sierra";case 13:return"High Sierra";case 14:return"Mojave";case 15:return"Catalina";default:return}},e.getAndroidVersionName=function(e){var t=e.split(".").splice(0,2).map((function(e){return parseInt(e,10)||0}));if(t.push(0),!(1===t[0]&&t[1]<5))return 1===t[0]&&t[1]<6?"Cupcake":1===t[0]&&t[1]>=6?"Donut":2===t[0]&&t[1]<2?"Eclair":2===t[0]&&2===t[1]?"Froyo":2===t[0]&&t[1]>2?"Gingerbread":3===t[0]?"Honeycomb":4===t[0]&&t[1]<1?"Ice Cream Sandwich":4===t[0]&&t[1]<4?"Jelly Bean":4===t[0]&&t[1]>=4?"KitKat":5===t[0]?"Lollipop":6===t[0]?"Marshmallow":7===t[0]?"Nougat":8===t[0]?"Oreo":9===t[0]?"Pie":void 0},e.getVersionPrecision=function(e){return e.split(".").length},e.compareVersions=function(t,r,i){void 0===i&&(i=!1);var n=e.getVersionPrecision(t),s=e.getVersionPrecision(r),a=Math.max(n,s),o=0,u=e.map([t,r],(function(t){var r=a-e.getVersionPrecision(t),i=t+new Array(r+1).join(".0");return e.map(i.split("."),(function(e){return new Array(20-e.length).join("0")+e})).reverse()}));for(i&&(o=a-Math.min(n,s)),a-=1;a>=o;){if(u[0][a]>u[1][a])return 1;if(u[0][a]===u[1][a]){if(a===o)return 0;a-=1}else if(u[0][a]<u[1][a])return-1}},e.map=function(e,t){var r,i=[];if(Array.prototype.map)return Array.prototype.map.call(e,t);for(r=0;r<e.length;r+=1)i.push(t(e[r]));return i},e.find=function(e,t){var r,i;if(Array.prototype.find)return Array.prototype.find.call(e,t);for(r=0,i=e.length;r<i;r+=1){var n=e[r];if(t(n,r))return n}},e.assign=function(e){for(var t,r,i=e,n=arguments.length,s=new Array(n>1?n-1:0),a=1;a<n;a++)s[a-1]=arguments[a];if(Object.assign)return Object.assign.apply(Object,[e].concat(s));var o=function(){var e=s[t];"object"==typeof e&&null!==e&&Object.keys(e).forEach((function(t){i[t]=e[t]}))};for(t=0,r=s.length;t<r;t+=1)o();return e},e.getBrowserAlias=function(e){return i.BROWSER_ALIASES_MAP[e]},e.getBrowserTypeByAlias=function(e){return i.BROWSER_MAP[e]||""},e}();t.default=n,e.exports=t.default},18:function(e,t,r){"use strict";t.__esModule=!0,t.ENGINE_MAP=t.OS_MAP=t.PLATFORMS_MAP=t.BROWSER_MAP=t.BROWSER_ALIASES_MAP=void 0;t.BROWSER_ALIASES_MAP={"Amazon Silk":"amazon_silk","Android Browser":"android",Bada:"bada",BlackBerry:"blackberry",Chrome:"chrome",Chromium:"chromium",Electron:"electron",Epiphany:"epiphany",Firefox:"firefox",Focus:"focus",Generic:"generic","Google Search":"google_search",Googlebot:"googlebot","Internet Explorer":"ie","K-Meleon":"k_meleon",Maxthon:"maxthon","Microsoft Edge":"edge","MZ Browser":"mz","NAVER Whale Browser":"naver",Opera:"opera","Opera Coast":"opera_coast","Pale Moon":"pale_moon",PhantomJS:"phantomjs",Puffin:"puffin",QupZilla:"qupzilla",QQ:"qq",QQLite:"qqlite",Safari:"safari",Sailfish:"sailfish","Samsung Internet for Android":"samsung_internet",SeaMonkey:"seamonkey",Sleipnir:"sleipnir",Swing:"swing",Tizen:"tizen","UC Browser":"uc",Vivaldi:"vivaldi","WebOS Browser":"webos",WeChat:"wechat","Yandex Browser":"yandex",Roku:"roku"};t.BROWSER_MAP={amazon_silk:"Amazon Silk",android:"Android Browser",bada:"Bada",blackberry:"BlackBerry",chrome:"Chrome",chromium:"Chromium",electron:"Electron",epiphany:"Epiphany",firefox:"Firefox",focus:"Focus",generic:"Generic",googlebot:"Googlebot",google_search:"Google Search",ie:"Internet Explorer",k_meleon:"K-Meleon",maxthon:"Maxthon",edge:"Microsoft Edge",mz:"MZ Browser",naver:"NAVER Whale Browser",opera:"Opera",opera_coast:"Opera Coast",pale_moon:"Pale Moon",phantomjs:"PhantomJS",puffin:"Puffin",qupzilla:"QupZilla",qq:"QQ Browser",qqlite:"QQ Browser Lite",safari:"Safari",sailfish:"Sailfish",samsung_internet:"Samsung Internet for Android",seamonkey:"SeaMonkey",sleipnir:"Sleipnir",swing:"Swing",tizen:"Tizen",uc:"UC Browser",vivaldi:"Vivaldi",webos:"WebOS Browser",wechat:"WeChat",yandex:"Yandex Browser"};t.PLATFORMS_MAP={tablet:"tablet",mobile:"mobile",desktop:"desktop",tv:"tv",bot:"bot"};t.OS_MAP={WindowsPhone:"Windows Phone",Windows:"Windows",MacOS:"macOS",iOS:"iOS",Android:"Android",WebOS:"WebOS",BlackBerry:"BlackBerry",Bada:"Bada",Tizen:"Tizen",Linux:"Linux",ChromeOS:"Chrome OS",PlayStation4:"PlayStation 4",Roku:"Roku"};t.ENGINE_MAP={EdgeHTML:"EdgeHTML",Blink:"Blink",Trident:"Trident",Presto:"Presto",Gecko:"Gecko",WebKit:"WebKit"}},90:function(e,t,r){"use strict";t.__esModule=!0,t.default=void 0;var i,n=(i=r(91))&&i.__esModule?i:{default:i},s=r(18);function a(e,t){for(var r=0;r<t.length;r++){var i=t[r];i.enumerable=i.enumerable||!1,i.configurable=!0,"value"in i&&(i.writable=!0),Object.defineProperty(e,i.key,i)}}var o=function(){function e(){}var t,r,i;return e.getParser=function(e,t){if(void 0===t&&(t=!1),"string"!=typeof e)throw new Error("UserAgent should be a string");return new n.default(e,t)},e.parse=function(e){return new n.default(e).getResult()},t=e,i=[{key:"BROWSER_MAP",get:function(){return s.BROWSER_MAP}},{key:"ENGINE_MAP",get:function(){return s.ENGINE_MAP}},{key:"OS_MAP",get:function(){return s.OS_MAP}},{key:"PLATFORMS_MAP",get:function(){return s.PLATFORMS_MAP}}],(r=null)&&a(t.prototype,r),i&&a(t,i),e}();t.default=o,e.exports=t.default},91:function(e,t,r){"use strict";t.__esModule=!0,t.default=void 0;var i=u(r(92)),n=u(r(93)),s=u(r(94)),a=u(r(95)),o=u(r(17));function u(e){return e&&e.__esModule?e:{default:e}}var d=function(){function e(e,t){if(void 0===t&&(t=!1),null==e||""===e)throw new Error("UserAgent parameter can't be empty");this._ua=e,this.parsedResult={},!0!==t&&this.parse()}var t=e.prototype;return t.getUA=function(){return this._ua},t.test=function(e){return e.test(this._ua)},t.parseBrowser=function(){var e=this;this.parsedResult.browser={};var t=o.default.find(i.default,(function(t){if("function"==typeof t.test)return t.test(e);if(Array.isArray(t.test))return t.test.some((function(t){return e.test(t)}));throw new Error("Browser's test function is not valid")}));return t&&(this.parsedResult.browser=t.describe(this.getUA())),this.parsedResult.browser},t.getBrowser=function(){return this.parsedResult.browser?this.parsedResult.browser:this.parseBrowser()},t.getBrowserName=function(e){return e?String(this.getBrowser().name).toLowerCase()||"":this.getBrowser().name||""},t.getBrowserVersion=function(){return this.getBrowser().version},t.getOS=function(){return this.parsedResult.os?this.parsedResult.os:this.parseOS()},t.parseOS=function(){var e=this;this.parsedResult.os={};var t=o.default.find(n.default,(function(t){if("function"==typeof t.test)return t.test(e);if(Array.isArray(t.test))return t.test.some((function(t){return e.test(t)}));throw new Error("Browser's test function is not valid")}));return t&&(this.parsedResult.os=t.describe(this.getUA())),this.parsedResult.os},t.getOSName=function(e){var t=this.getOS().name;return e?String(t).toLowerCase()||"":t||""},t.getOSVersion=function(){return this.getOS().version},t.getPlatform=function(){return this.parsedResult.platform?this.parsedResult.platform:this.parsePlatform()},t.getPlatformType=function(e){void 0===e&&(e=!1);var t=this.getPlatform().type;return e?String(t).toLowerCase()||"":t||""},t.parsePlatform=function(){var e=this;this.parsedResult.platform={};var t=o.default.find(s.default,(function(t){if("function"==typeof t.test)return t.test(e);if(Array.isArray(t.test))return t.test.some((function(t){return e.test(t)}));throw new Error("Browser's test function is not valid")}));return t&&(this.parsedResult.platform=t.describe(this.getUA())),this.parsedResult.platform},t.getEngine=function(){return this.parsedResult.engine?this.parsedResult.engine:this.parseEngine()},t.getEngineName=function(e){return e?String(this.getEngine().name).toLowerCase()||"":this.getEngine().name||""},t.parseEngine=function(){var e=this;this.parsedResult.engine={};var t=o.default.find(a.default,(function(t){if("function"==typeof t.test)return t.test(e);if(Array.isArray(t.test))return t.test.some((function(t){return e.test(t)}));throw new Error("Browser's test function is not valid")}));return t&&(this.parsedResult.engine=t.describe(this.getUA())),this.parsedResult.engine},t.parse=function(){return this.parseBrowser(),this.parseOS(),this.parsePlatform(),this.parseEngine(),this},t.getResult=function(){return o.default.assign({},this.parsedResult)},t.satisfies=function(e){var t=this,r={},i=0,n={},s=0;if(Object.keys(e).forEach((function(t){var a=e[t];"string"==typeof a?(n[t]=a,s+=1):"object"==typeof a&&(r[t]=a,i+=1)})),i>0){var a=Object.keys(r),u=o.default.find(a,(function(e){return t.isOS(e)}));if(u){var d=this.satisfies(r[u]);if(void 0!==d)return d}var c=o.default.find(a,(function(e){return t.isPlatform(e)}));if(c){var f=this.satisfies(r[c]);if(void 0!==f)return f}}if(s>0){var l=Object.keys(n),h=o.default.find(l,(function(e){return t.isBrowser(e,!0)}));if(void 0!==h)return this.compareVersion(n[h])}},t.isBrowser=function(e,t){void 0===t&&(t=!1);var r=this.getBrowserName().toLowerCase(),i=e.toLowerCase(),n=o.default.getBrowserTypeByAlias(i);return t&&n&&(i=n.toLowerCase()),i===r},t.compareVersion=function(e){var t=[0],r=e,i=!1,n=this.getBrowserVersion();if("string"==typeof n)return">"===e[0]||"<"===e[0]?(r=e.substr(1),"="===e[1]?(i=!0,r=e.substr(2)):t=[],">"===e[0]?t.push(1):t.push(-1)):"="===e[0]?r=e.substr(1):"~"===e[0]&&(i=!0,r=e.substr(1)),t.indexOf(o.default.compareVersions(n,r,i))>-1},t.isOS=function(e){return this.getOSName(!0)===String(e).toLowerCase()},t.isPlatform=function(e){return this.getPlatformType(!0)===String(e).toLowerCase()},t.isEngine=function(e){return this.getEngineName(!0)===String(e).toLowerCase()},t.is=function(e,t){return void 0===t&&(t=!1),this.isBrowser(e,t)||this.isOS(e)||this.isPlatform(e)},t.some=function(e){var t=this;return void 0===e&&(e=[]),e.some((function(e){return t.is(e)}))},e}();t.default=d,e.exports=t.default},92:function(e,t,r){"use strict";t.__esModule=!0,t.default=void 0;var i,n=(i=r(17))&&i.__esModule?i:{default:i};var s=/version\/(\d+(\.?_?\d+)+)/i,a=[{test:[/googlebot/i],describe:function(e){var t={name:"Googlebot"},r=n.default.getFirstMatch(/googlebot\/(\d+(\.\d+))/i,e)||n.default.getFirstMatch(s,e);return r&&(t.version=r),t}},{test:[/opera/i],describe:function(e){var t={name:"Opera"},r=n.default.getFirstMatch(s,e)||n.default.getFirstMatch(/(?:opera)[\s/](\d+(\.?_?\d+)+)/i,e);return r&&(t.version=r),t}},{test:[/opr\/|opios/i],describe:function(e){var t={name:"Opera"},r=n.default.getFirstMatch(/(?:opr|opios)[\s/](\S+)/i,e)||n.default.getFirstMatch(s,e);return r&&(t.version=r),t}},{test:[/SamsungBrowser/i],describe:function(e){var t={name:"Samsung Internet for Android"},r=n.default.getFirstMatch(s,e)||n.default.getFirstMatch(/(?:SamsungBrowser)[\s/](\d+(\.?_?\d+)+)/i,e);return r&&(t.version=r),t}},{test:[/Whale/i],describe:function(e){var t={name:"NAVER Whale Browser"},r=n.default.getFirstMatch(s,e)||n.default.getFirstMatch(/(?:whale)[\s/](\d+(?:\.\d+)+)/i,e);return r&&(t.version=r),t}},{test:[/PaleMoon/i],describe:function(e){var t={name:"Pale Moon"},r=n.default.getFirstMatch(s,e)||n.default.getFirstMatch(/(?:PaleMoon)[\s/](\d+(?:\.\d+)+)/i,e);return r&&(t.version=r),t}},{test:[/MZBrowser/i],describe:function(e){var t={name:"MZ Browser"},r=n.default.getFirstMatch(/(?:MZBrowser)[\s/](\d+(?:\.\d+)+)/i,e)||n.default.getFirstMatch(s,e);return r&&(t.version=r),t}},{test:[/focus/i],describe:function(e){var t={name:"Focus"},r=n.default.getFirstMatch(/(?:focus)[\s/](\d+(?:\.\d+)+)/i,e)||n.default.getFirstMatch(s,e);return r&&(t.version=r),t}},{test:[/swing/i],describe:function(e){var t={name:"Swing"},r=n.default.getFirstMatch(/(?:swing)[\s/](\d+(?:\.\d+)+)/i,e)||n.default.getFirstMatch(s,e);return r&&(t.version=r),t}},{test:[/coast/i],describe:function(e){var t={name:"Opera Coast"},r=n.default.getFirstMatch(s,e)||n.default.getFirstMatch(/(?:coast)[\s/](\d+(\.?_?\d+)+)/i,e);return r&&(t.version=r),t}},{test:[/opt\/\d+(?:.?_?\d+)+/i],describe:function(e){var t={name:"Opera Touch"},r=n.default.getFirstMatch(/(?:opt)[\s/](\d+(\.?_?\d+)+)/i,e)||n.default.getFirstMatch(s,e);return r&&(t.version=r),t}},{test:[/yabrowser/i],describe:function(e){var t={name:"Yandex Browser"},r=n.default.getFirstMatch(/(?:yabrowser)[\s/](\d+(\.?_?\d+)+)/i,e)||n.default.getFirstMatch(s,e);return r&&(t.version=r),t}},{test:[/ucbrowser/i],describe:function(e){var t={name:"UC Browser"},r=n.default.getFirstMatch(s,e)||n.default.getFirstMatch(/(?:ucbrowser)[\s/](\d+(\.?_?\d+)+)/i,e);return r&&(t.version=r),t}},{test:[/Maxthon|mxios/i],describe:function(e){var t={name:"Maxthon"},r=n.default.getFirstMatch(s,e)||n.default.getFirstMatch(/(?:Maxthon|mxios)[\s/](\d+(\.?_?\d+)+)/i,e);return r&&(t.version=r),t}},{test:[/epiphany/i],describe:function(e){var t={name:"Epiphany"},r=n.default.getFirstMatch(s,e)||n.default.getFirstMatch(/(?:epiphany)[\s/](\d+(\.?_?\d+)+)/i,e);return r&&(t.version=r),t}},{test:[/puffin/i],describe:function(e){var t={name:"Puffin"},r=n.default.getFirstMatch(s,e)||n.default.getFirstMatch(/(?:puffin)[\s/](\d+(\.?_?\d+)+)/i,e);return r&&(t.version=r),t}},{test:[/sleipnir/i],describe:function(e){var t={name:"Sleipnir"},r=n.default.getFirstMatch(s,e)||n.default.getFirstMatch(/(?:sleipnir)[\s/](\d+(\.?_?\d+)+)/i,e);return r&&(t.version=r),t}},{test:[/k-meleon/i],describe:function(e){var t={name:"K-Meleon"},r=n.default.getFirstMatch(s,e)||n.default.getFirstMatch(/(?:k-meleon)[\s/](\d+(\.?_?\d+)+)/i,e);return r&&(t.version=r),t}},{test:[/micromessenger/i],describe:function(e){var t={name:"WeChat"},r=n.default.getFirstMatch(/(?:micromessenger)[\s/](\d+(\.?_?\d+)+)/i,e)||n.default.getFirstMatch(s,e);return r&&(t.version=r),t}},{test:[/qqbrowser/i],describe:function(e){var t={name:/qqbrowserlite/i.test(e)?"QQ Browser Lite":"QQ Browser"},r=n.default.getFirstMatch(/(?:qqbrowserlite|qqbrowser)[/](\d+(\.?_?\d+)+)/i,e)||n.default.getFirstMatch(s,e);return r&&(t.version=r),t}},{test:[/msie|trident/i],describe:function(e){var t={name:"Internet Explorer"},r=n.default.getFirstMatch(/(?:msie |rv:)(\d+(\.?_?\d+)+)/i,e);return r&&(t.version=r),t}},{test:[/\sedg\//i],describe:function(e){var t={name:"Microsoft Edge"},r=n.default.getFirstMatch(/\sedg\/(\d+(\.?_?\d+)+)/i,e);return r&&(t.version=r),t}},{test:[/edg([ea]|ios)/i],describe:function(e){var t={name:"Microsoft Edge"},r=n.default.getSecondMatch(/edg([ea]|ios)\/(\d+(\.?_?\d+)+)/i,e);return r&&(t.version=r),t}},{test:[/vivaldi/i],describe:function(e){var t={name:"Vivaldi"},r=n.default.getFirstMatch(/vivaldi\/(\d+(\.?_?\d+)+)/i,e);return r&&(t.version=r),t}},{test:[/seamonkey/i],describe:function(e){var t={name:"SeaMonkey"},r=n.default.getFirstMatch(/seamonkey\/(\d+(\.?_?\d+)+)/i,e);return r&&(t.version=r),t}},{test:[/sailfish/i],describe:function(e){var t={name:"Sailfish"},r=n.default.getFirstMatch(/sailfish\s?browser\/(\d+(\.\d+)?)/i,e);return r&&(t.version=r),t}},{test:[/silk/i],describe:function(e){var t={name:"Amazon Silk"},r=n.default.getFirstMatch(/silk\/(\d+(\.?_?\d+)+)/i,e);return r&&(t.version=r),t}},{test:[/phantom/i],describe:function(e){var t={name:"PhantomJS"},r=n.default.getFirstMatch(/phantomjs\/(\d+(\.?_?\d+)+)/i,e);return r&&(t.version=r),t}},{test:[/slimerjs/i],describe:function(e){var t={name:"SlimerJS"},r=n.default.getFirstMatch(/slimerjs\/(\d+(\.?_?\d+)+)/i,e);return r&&(t.version=r),t}},{test:[/blackberry|\bbb\d+/i,/rim\stablet/i],describe:function(e){var t={name:"BlackBerry"},r=n.default.getFirstMatch(s,e)||n.default.getFirstMatch(/blackberry[\d]+\/(\d+(\.?_?\d+)+)/i,e);return r&&(t.version=r),t}},{test:[/(web|hpw)[o0]s/i],describe:function(e){var t={name:"WebOS Browser"},r=n.default.getFirstMatch(s,e)||n.default.getFirstMatch(/w(?:eb)?[o0]sbrowser\/(\d+(\.?_?\d+)+)/i,e);return r&&(t.version=r),t}},{test:[/bada/i],describe:function(e){var t={name:"Bada"},r=n.default.getFirstMatch(/dolfin\/(\d+(\.?_?\d+)+)/i,e);return r&&(t.version=r),t}},{test:[/tizen/i],describe:function(e){var t={name:"Tizen"},r=n.default.getFirstMatch(/(?:tizen\s?)?browser\/(\d+(\.?_?\d+)+)/i,e)||n.default.getFirstMatch(s,e);return r&&(t.version=r),t}},{test:[/qupzilla/i],describe:function(e){var t={name:"QupZilla"},r=n.default.getFirstMatch(/(?:qupzilla)[\s/](\d+(\.?_?\d+)+)/i,e)||n.default.getFirstMatch(s,e);return r&&(t.version=r),t}},{test:[/firefox|iceweasel|fxios/i],describe:function(e){var t={name:"Firefox"},r=n.default.getFirstMatch(/(?:firefox|iceweasel|fxios)[\s/](\d+(\.?_?\d+)+)/i,e);return r&&(t.version=r),t}},{test:[/electron/i],describe:function(e){var t={name:"Electron"},r=n.default.getFirstMatch(/(?:electron)\/(\d+(\.?_?\d+)+)/i,e);return r&&(t.version=r),t}},{test:[/MiuiBrowser/i],describe:function(e){var t={name:"Miui"},r=n.default.getFirstMatch(/(?:MiuiBrowser)[\s/](\d+(\.?_?\d+)+)/i,e);return r&&(t.version=r),t}},{test:[/chromium/i],describe:function(e){var t={name:"Chromium"},r=n.default.getFirstMatch(/(?:chromium)[\s/](\d+(\.?_?\d+)+)/i,e)||n.default.getFirstMatch(s,e);return r&&(t.version=r),t}},{test:[/chrome|crios|crmo/i],describe:function(e){var t={name:"Chrome"},r=n.default.getFirstMatch(/(?:chrome|crios|crmo)\/(\d+(\.?_?\d+)+)/i,e);return r&&(t.version=r),t}},{test:[/GSA/i],describe:function(e){var t={name:"Google Search"},r=n.default.getFirstMatch(/(?:GSA)\/(\d+(\.?_?\d+)+)/i,e);return r&&(t.version=r),t}},{test:function(e){var t=!e.test(/like android/i),r=e.test(/android/i);return t&&r},describe:function(e){var t={name:"Android Browser"},r=n.default.getFirstMatch(s,e);return r&&(t.version=r),t}},{test:[/playstation 4/i],describe:function(e){var t={name:"PlayStation 4"},r=n.default.getFirstMatch(s,e);return r&&(t.version=r),t}},{test:[/safari|applewebkit/i],describe:function(e){var t={name:"Safari"},r=n.default.getFirstMatch(s,e);return r&&(t.version=r),t}},{test:[/.*/i],describe:function(e){var t=-1!==e.search("\\(")?/^(.*)\/(.*)[ \t]\((.*)/:/^(.*)\/(.*) /;return{name:n.default.getFirstMatch(t,e),version:n.default.getSecondMatch(t,e)}}}];t.default=a,e.exports=t.default},93:function(e,t,r){"use strict";t.__esModule=!0,t.default=void 0;var i,n=(i=r(17))&&i.__esModule?i:{default:i},s=r(18);var a=[{test:[/Roku\/DVP/],describe:function(e){var t=n.default.getFirstMatch(/Roku\/DVP-(\d+\.\d+)/i,e);return{name:s.OS_MAP.Roku,version:t}}},{test:[/windows phone/i],describe:function(e){var t=n.default.getFirstMatch(/windows phone (?:os)?\s?(\d+(\.\d+)*)/i,e);return{name:s.OS_MAP.WindowsPhone,version:t}}},{test:[/windows /i],describe:function(e){var t=n.default.getFirstMatch(/Windows ((NT|XP)( \d\d?.\d)?)/i,e),r=n.default.getWindowsVersionName(t);return{name:s.OS_MAP.Windows,version:t,versionName:r}}},{test:[/Macintosh(.*?) FxiOS(.*?)\//],describe:function(e){var t={name:s.OS_MAP.iOS},r=n.default.getSecondMatch(/(Version\/)(\d[\d.]+)/,e);return r&&(t.version=r),t}},{test:[/macintosh/i],describe:function(e){var t=n.default.getFirstMatch(/mac os x (\d+(\.?_?\d+)+)/i,e).replace(/[_\s]/g,"."),r=n.default.getMacOSVersionName(t),i={name:s.OS_MAP.MacOS,version:t};return r&&(i.versionName=r),i}},{test:[/(ipod|iphone|ipad)/i],describe:function(e){var t=n.default.getFirstMatch(/os (\d+([_\s]\d+)*) like mac os x/i,e).replace(/[_\s]/g,".");return{name:s.OS_MAP.iOS,version:t}}},{test:function(e){var t=!e.test(/like android/i),r=e.test(/android/i);return t&&r},describe:function(e){var t=n.default.getFirstMatch(/android[\s/-](\d+(\.\d+)*)/i,e),r=n.default.getAndroidVersionName(t),i={name:s.OS_MAP.Android,version:t};return r&&(i.versionName=r),i}},{test:[/(web|hpw)[o0]s/i],describe:function(e){var t=n.default.getFirstMatch(/(?:web|hpw)[o0]s\/(\d+(\.\d+)*)/i,e),r={name:s.OS_MAP.WebOS};return t&&t.length&&(r.version=t),r}},{test:[/blackberry|\bbb\d+/i,/rim\stablet/i],describe:function(e){var t=n.default.getFirstMatch(/rim\stablet\sos\s(\d+(\.\d+)*)/i,e)||n.default.getFirstMatch(/blackberry\d+\/(\d+([_\s]\d+)*)/i,e)||n.default.getFirstMatch(/\bbb(\d+)/i,e);return{name:s.OS_MAP.BlackBerry,version:t}}},{test:[/bada/i],describe:function(e){var t=n.default.getFirstMatch(/bada\/(\d+(\.\d+)*)/i,e);return{name:s.OS_MAP.Bada,version:t}}},{test:[/tizen/i],describe:function(e){var t=n.default.getFirstMatch(/tizen[/\s](\d+(\.\d+)*)/i,e);return{name:s.OS_MAP.Tizen,version:t}}},{test:[/linux/i],describe:function(){return{name:s.OS_MAP.Linux}}},{test:[/CrOS/],describe:function(){return{name:s.OS_MAP.ChromeOS}}},{test:[/PlayStation 4/],describe:function(e){var t=n.default.getFirstMatch(/PlayStation 4[/\s](\d+(\.\d+)*)/i,e);return{name:s.OS_MAP.PlayStation4,version:t}}}];t.default=a,e.exports=t.default},94:function(e,t,r){"use strict";t.__esModule=!0,t.default=void 0;var i,n=(i=r(17))&&i.__esModule?i:{default:i},s=r(18);var a=[{test:[/googlebot/i],describe:function(){return{type:s.PLATFORMS_MAP.bot,vendor:"Google"}}},{test:[/huawei/i],describe:function(e){var t=n.default.getFirstMatch(/(can-l01)/i,e)&&"Nova",r={type:s.PLATFORMS_MAP.mobile,vendor:"Huawei"};return t&&(r.model=t),r}},{test:[/nexus\s*(?:7|8|9|10).*/i],describe:function(){return{type:s.PLATFORMS_MAP.tablet,vendor:"Nexus"}}},{test:[/ipad/i],describe:function(){return{type:s.PLATFORMS_MAP.tablet,vendor:"Apple",model:"iPad"}}},{test:[/Macintosh(.*?) FxiOS(.*?)\//],describe:function(){return{type:s.PLATFORMS_MAP.tablet,vendor:"Apple",model:"iPad"}}},{test:[/kftt build/i],describe:function(){return{type:s.PLATFORMS_MAP.tablet,vendor:"Amazon",model:"Kindle Fire HD 7"}}},{test:[/silk/i],describe:function(){return{type:s.PLATFORMS_MAP.tablet,vendor:"Amazon"}}},{test:[/tablet(?! pc)/i],describe:function(){return{type:s.PLATFORMS_MAP.tablet}}},{test:function(e){var t=e.test(/ipod|iphone/i),r=e.test(/like (ipod|iphone)/i);return t&&!r},describe:function(e){var t=n.default.getFirstMatch(/(ipod|iphone)/i,e);return{type:s.PLATFORMS_MAP.mobile,vendor:"Apple",model:t}}},{test:[/nexus\s*[0-6].*/i,/galaxy nexus/i],describe:function(){return{type:s.PLATFORMS_MAP.mobile,vendor:"Nexus"}}},{test:[/Nokia/i],describe:function(e){var t=n.default.getFirstMatch(/Nokia\s+([0-9]+(\.[0-9]+)?)/i,e),r={type:s.PLATFORMS_MAP.mobile,vendor:"Nokia"};return t&&(r.model=t),r}},{test:[/[^-]mobi/i],describe:function(){return{type:s.PLATFORMS_MAP.mobile}}},{test:function(e){return"blackberry"===e.getBrowserName(!0)},describe:function(){return{type:s.PLATFORMS_MAP.mobile,vendor:"BlackBerry"}}},{test:function(e){return"bada"===e.getBrowserName(!0)},describe:function(){return{type:s.PLATFORMS_MAP.mobile}}},{test:function(e){return"windows phone"===e.getBrowserName()},describe:function(){return{type:s.PLATFORMS_MAP.mobile,vendor:"Microsoft"}}},{test:function(e){var t=Number(String(e.getOSVersion()).split(".")[0]);return"android"===e.getOSName(!0)&&t>=3},describe:function(){return{type:s.PLATFORMS_MAP.tablet}}},{test:function(e){return"android"===e.getOSName(!0)},describe:function(){return{type:s.PLATFORMS_MAP.mobile}}},{test:function(e){return"macos"===e.getOSName(!0)},describe:function(){return{type:s.PLATFORMS_MAP.desktop,vendor:"Apple"}}},{test:function(e){return"windows"===e.getOSName(!0)},describe:function(){return{type:s.PLATFORMS_MAP.desktop}}},{test:function(e){return"linux"===e.getOSName(!0)},describe:function(){return{type:s.PLATFORMS_MAP.desktop}}},{test:function(e){return"playstation 4"===e.getOSName(!0)},describe:function(){return{type:s.PLATFORMS_MAP.tv}}},{test:function(e){return"roku"===e.getOSName(!0)},describe:function(){return{type:s.PLATFORMS_MAP.tv}}}];t.default=a,e.exports=t.default},95:function(e,t,r){"use strict";t.__esModule=!0,t.default=void 0;var i,n=(i=r(17))&&i.__esModule?i:{default:i},s=r(18);var a=[{test:function(e){return"microsoft edge"===e.getBrowserName(!0)},describe:function(e){if(/\sedg\//i.test(e))return{name:s.ENGINE_MAP.Blink};var t=n.default.getFirstMatch(/edge\/(\d+(\.?_?\d+)+)/i,e);return{name:s.ENGINE_MAP.EdgeHTML,version:t}}},{test:[/trident/i],describe:function(e){var t={name:s.ENGINE_MAP.Trident},r=n.default.getFirstMatch(/trident\/(\d+(\.?_?\d+)+)/i,e);return r&&(t.version=r),t}},{test:function(e){return e.test(/presto/i)},describe:function(e){var t={name:s.ENGINE_MAP.Presto},r=n.default.getFirstMatch(/presto\/(\d+(\.?_?\d+)+)/i,e);return r&&(t.version=r),t}},{test:function(e){var t=e.test(/gecko/i),r=e.test(/like gecko/i);return t&&!r},describe:function(e){var t={name:s.ENGINE_MAP.Gecko},r=n.default.getFirstMatch(/gecko\/(\d+(\.?_?\d+)+)/i,e);return r&&(t.version=r),t}},{test:[/(apple)?webkit\/537\.36/i],describe:function(){return{name:s.ENGINE_MAP.Blink}}},{test:[/(apple)?webkit/i],describe:function(e){var t={name:s.ENGINE_MAP.WebKit},r=n.default.getFirstMatch(/webkit\/(\d+(\.?_?\d+)+)/i,e);return r&&(t.version=r),t}}];t.default=a,e.exports=t.default}})}));

/***/ }),

/***/ "./node_modules/cross-fetch/dist/browser-ponyfill.js":
/*!***********************************************************!*\
  !*** ./node_modules/cross-fetch/dist/browser-ponyfill.js ***!
  \***********************************************************/
/***/ ((module, exports, __webpack_require__) => {

// Save global object in a variable
var __global__ =
(typeof globalThis !== 'undefined' && globalThis) ||
(typeof self !== 'undefined' && self) ||
(typeof __webpack_require__.g !== 'undefined' && __webpack_require__.g);
// Create an object that extends from __global__ without the fetch function
var __globalThis__ = (function () {
function F() {
this.fetch = false;
this.DOMException = __global__.DOMException
}
F.prototype = __global__; // Needed for feature detection on whatwg-fetch's code
return new F();
})();
// Wraps whatwg-fetch with a function scope to hijack the global object
// "globalThis" that's going to be patched
(function(globalThis) {

var irrelevant = (function (exports) {

  var global =
    (typeof globalThis !== 'undefined' && globalThis) ||
    (typeof self !== 'undefined' && self) ||
    (typeof global !== 'undefined' && global);

  var support = {
    searchParams: 'URLSearchParams' in global,
    iterable: 'Symbol' in global && 'iterator' in Symbol,
    blob:
      'FileReader' in global &&
      'Blob' in global &&
      (function() {
        try {
          new Blob();
          return true
        } catch (e) {
          return false
        }
      })(),
    formData: 'FormData' in global,
    arrayBuffer: 'ArrayBuffer' in global
  };

  function isDataView(obj) {
    return obj && DataView.prototype.isPrototypeOf(obj)
  }

  if (support.arrayBuffer) {
    var viewClasses = [
      '[object Int8Array]',
      '[object Uint8Array]',
      '[object Uint8ClampedArray]',
      '[object Int16Array]',
      '[object Uint16Array]',
      '[object Int32Array]',
      '[object Uint32Array]',
      '[object Float32Array]',
      '[object Float64Array]'
    ];

    var isArrayBufferView =
      ArrayBuffer.isView ||
      function(obj) {
        return obj && viewClasses.indexOf(Object.prototype.toString.call(obj)) > -1
      };
  }

  function normalizeName(name) {
    if (typeof name !== 'string') {
      name = String(name);
    }
    if (/[^a-z0-9\-#$%&'*+.^_`|~!]/i.test(name) || name === '') {
      throw new TypeError('Invalid character in header field name: "' + name + '"')
    }
    return name.toLowerCase()
  }

  function normalizeValue(value) {
    if (typeof value !== 'string') {
      value = String(value);
    }
    return value
  }

  // Build a destructive iterator for the value list
  function iteratorFor(items) {
    var iterator = {
      next: function() {
        var value = items.shift();
        return {done: value === undefined, value: value}
      }
    };

    if (support.iterable) {
      iterator[Symbol.iterator] = function() {
        return iterator
      };
    }

    return iterator
  }

  function Headers(headers) {
    this.map = {};

    if (headers instanceof Headers) {
      headers.forEach(function(value, name) {
        this.append(name, value);
      }, this);
    } else if (Array.isArray(headers)) {
      headers.forEach(function(header) {
        this.append(header[0], header[1]);
      }, this);
    } else if (headers) {
      Object.getOwnPropertyNames(headers).forEach(function(name) {
        this.append(name, headers[name]);
      }, this);
    }
  }

  Headers.prototype.append = function(name, value) {
    name = normalizeName(name);
    value = normalizeValue(value);
    var oldValue = this.map[name];
    this.map[name] = oldValue ? oldValue + ', ' + value : value;
  };

  Headers.prototype['delete'] = function(name) {
    delete this.map[normalizeName(name)];
  };

  Headers.prototype.get = function(name) {
    name = normalizeName(name);
    return this.has(name) ? this.map[name] : null
  };

  Headers.prototype.has = function(name) {
    return this.map.hasOwnProperty(normalizeName(name))
  };

  Headers.prototype.set = function(name, value) {
    this.map[normalizeName(name)] = normalizeValue(value);
  };

  Headers.prototype.forEach = function(callback, thisArg) {
    for (var name in this.map) {
      if (this.map.hasOwnProperty(name)) {
        callback.call(thisArg, this.map[name], name, this);
      }
    }
  };

  Headers.prototype.keys = function() {
    var items = [];
    this.forEach(function(value, name) {
      items.push(name);
    });
    return iteratorFor(items)
  };

  Headers.prototype.values = function() {
    var items = [];
    this.forEach(function(value) {
      items.push(value);
    });
    return iteratorFor(items)
  };

  Headers.prototype.entries = function() {
    var items = [];
    this.forEach(function(value, name) {
      items.push([name, value]);
    });
    return iteratorFor(items)
  };

  if (support.iterable) {
    Headers.prototype[Symbol.iterator] = Headers.prototype.entries;
  }

  function consumed(body) {
    if (body.bodyUsed) {
      return Promise.reject(new TypeError('Already read'))
    }
    body.bodyUsed = true;
  }

  function fileReaderReady(reader) {
    return new Promise(function(resolve, reject) {
      reader.onload = function() {
        resolve(reader.result);
      };
      reader.onerror = function() {
        reject(reader.error);
      };
    })
  }

  function readBlobAsArrayBuffer(blob) {
    var reader = new FileReader();
    var promise = fileReaderReady(reader);
    reader.readAsArrayBuffer(blob);
    return promise
  }

  function readBlobAsText(blob) {
    var reader = new FileReader();
    var promise = fileReaderReady(reader);
    reader.readAsText(blob);
    return promise
  }

  function readArrayBufferAsText(buf) {
    var view = new Uint8Array(buf);
    var chars = new Array(view.length);

    for (var i = 0; i < view.length; i++) {
      chars[i] = String.fromCharCode(view[i]);
    }
    return chars.join('')
  }

  function bufferClone(buf) {
    if (buf.slice) {
      return buf.slice(0)
    } else {
      var view = new Uint8Array(buf.byteLength);
      view.set(new Uint8Array(buf));
      return view.buffer
    }
  }

  function Body() {
    this.bodyUsed = false;

    this._initBody = function(body) {
      /*
        fetch-mock wraps the Response object in an ES6 Proxy to
        provide useful test harness features such as flush. However, on
        ES5 browsers without fetch or Proxy support pollyfills must be used;
        the proxy-pollyfill is unable to proxy an attribute unless it exists
        on the object before the Proxy is created. This change ensures
        Response.bodyUsed exists on the instance, while maintaining the
        semantic of setting Request.bodyUsed in the constructor before
        _initBody is called.
      */
      this.bodyUsed = this.bodyUsed;
      this._bodyInit = body;
      if (!body) {
        this._bodyText = '';
      } else if (typeof body === 'string') {
        this._bodyText = body;
      } else if (support.blob && Blob.prototype.isPrototypeOf(body)) {
        this._bodyBlob = body;
      } else if (support.formData && FormData.prototype.isPrototypeOf(body)) {
        this._bodyFormData = body;
      } else if (support.searchParams && URLSearchParams.prototype.isPrototypeOf(body)) {
        this._bodyText = body.toString();
      } else if (support.arrayBuffer && support.blob && isDataView(body)) {
        this._bodyArrayBuffer = bufferClone(body.buffer);
        // IE 10-11 can't handle a DataView body.
        this._bodyInit = new Blob([this._bodyArrayBuffer]);
      } else if (support.arrayBuffer && (ArrayBuffer.prototype.isPrototypeOf(body) || isArrayBufferView(body))) {
        this._bodyArrayBuffer = bufferClone(body);
      } else {
        this._bodyText = body = Object.prototype.toString.call(body);
      }

      if (!this.headers.get('content-type')) {
        if (typeof body === 'string') {
          this.headers.set('content-type', 'text/plain;charset=UTF-8');
        } else if (this._bodyBlob && this._bodyBlob.type) {
          this.headers.set('content-type', this._bodyBlob.type);
        } else if (support.searchParams && URLSearchParams.prototype.isPrototypeOf(body)) {
          this.headers.set('content-type', 'application/x-www-form-urlencoded;charset=UTF-8');
        }
      }
    };

    if (support.blob) {
      this.blob = function() {
        var rejected = consumed(this);
        if (rejected) {
          return rejected
        }

        if (this._bodyBlob) {
          return Promise.resolve(this._bodyBlob)
        } else if (this._bodyArrayBuffer) {
          return Promise.resolve(new Blob([this._bodyArrayBuffer]))
        } else if (this._bodyFormData) {
          throw new Error('could not read FormData body as blob')
        } else {
          return Promise.resolve(new Blob([this._bodyText]))
        }
      };

      this.arrayBuffer = function() {
        if (this._bodyArrayBuffer) {
          var isConsumed = consumed(this);
          if (isConsumed) {
            return isConsumed
          }
          if (ArrayBuffer.isView(this._bodyArrayBuffer)) {
            return Promise.resolve(
              this._bodyArrayBuffer.buffer.slice(
                this._bodyArrayBuffer.byteOffset,
                this._bodyArrayBuffer.byteOffset + this._bodyArrayBuffer.byteLength
              )
            )
          } else {
            return Promise.resolve(this._bodyArrayBuffer)
          }
        } else {
          return this.blob().then(readBlobAsArrayBuffer)
        }
      };
    }

    this.text = function() {
      var rejected = consumed(this);
      if (rejected) {
        return rejected
      }

      if (this._bodyBlob) {
        return readBlobAsText(this._bodyBlob)
      } else if (this._bodyArrayBuffer) {
        return Promise.resolve(readArrayBufferAsText(this._bodyArrayBuffer))
      } else if (this._bodyFormData) {
        throw new Error('could not read FormData body as text')
      } else {
        return Promise.resolve(this._bodyText)
      }
    };

    if (support.formData) {
      this.formData = function() {
        return this.text().then(decode)
      };
    }

    this.json = function() {
      return this.text().then(JSON.parse)
    };

    return this
  }

  // HTTP methods whose capitalization should be normalized
  var methods = ['DELETE', 'GET', 'HEAD', 'OPTIONS', 'POST', 'PUT'];

  function normalizeMethod(method) {
    var upcased = method.toUpperCase();
    return methods.indexOf(upcased) > -1 ? upcased : method
  }

  function Request(input, options) {
    if (!(this instanceof Request)) {
      throw new TypeError('Please use the "new" operator, this DOM object constructor cannot be called as a function.')
    }

    options = options || {};
    var body = options.body;

    if (input instanceof Request) {
      if (input.bodyUsed) {
        throw new TypeError('Already read')
      }
      this.url = input.url;
      this.credentials = input.credentials;
      if (!options.headers) {
        this.headers = new Headers(input.headers);
      }
      this.method = input.method;
      this.mode = input.mode;
      this.signal = input.signal;
      if (!body && input._bodyInit != null) {
        body = input._bodyInit;
        input.bodyUsed = true;
      }
    } else {
      this.url = String(input);
    }

    this.credentials = options.credentials || this.credentials || 'same-origin';
    if (options.headers || !this.headers) {
      this.headers = new Headers(options.headers);
    }
    this.method = normalizeMethod(options.method || this.method || 'GET');
    this.mode = options.mode || this.mode || null;
    this.signal = options.signal || this.signal;
    this.referrer = null;

    if ((this.method === 'GET' || this.method === 'HEAD') && body) {
      throw new TypeError('Body not allowed for GET or HEAD requests')
    }
    this._initBody(body);

    if (this.method === 'GET' || this.method === 'HEAD') {
      if (options.cache === 'no-store' || options.cache === 'no-cache') {
        // Search for a '_' parameter in the query string
        var reParamSearch = /([?&])_=[^&]*/;
        if (reParamSearch.test(this.url)) {
          // If it already exists then set the value with the current time
          this.url = this.url.replace(reParamSearch, '$1_=' + new Date().getTime());
        } else {
          // Otherwise add a new '_' parameter to the end with the current time
          var reQueryString = /\?/;
          this.url += (reQueryString.test(this.url) ? '&' : '?') + '_=' + new Date().getTime();
        }
      }
    }
  }

  Request.prototype.clone = function() {
    return new Request(this, {body: this._bodyInit})
  };

  function decode(body) {
    var form = new FormData();
    body
      .trim()
      .split('&')
      .forEach(function(bytes) {
        if (bytes) {
          var split = bytes.split('=');
          var name = split.shift().replace(/\+/g, ' ');
          var value = split.join('=').replace(/\+/g, ' ');
          form.append(decodeURIComponent(name), decodeURIComponent(value));
        }
      });
    return form
  }

  function parseHeaders(rawHeaders) {
    var headers = new Headers();
    // Replace instances of \r\n and \n followed by at least one space or horizontal tab with a space
    // https://tools.ietf.org/html/rfc7230#section-3.2
    var preProcessedHeaders = rawHeaders.replace(/\r?\n[\t ]+/g, ' ');
    // Avoiding split via regex to work around a common IE11 bug with the core-js 3.6.0 regex polyfill
    // https://github.com/github/fetch/issues/748
    // https://github.com/zloirock/core-js/issues/751
    preProcessedHeaders
      .split('\r')
      .map(function(header) {
        return header.indexOf('\n') === 0 ? header.substr(1, header.length) : header
      })
      .forEach(function(line) {
        var parts = line.split(':');
        var key = parts.shift().trim();
        if (key) {
          var value = parts.join(':').trim();
          headers.append(key, value);
        }
      });
    return headers
  }

  Body.call(Request.prototype);

  function Response(bodyInit, options) {
    if (!(this instanceof Response)) {
      throw new TypeError('Please use the "new" operator, this DOM object constructor cannot be called as a function.')
    }
    if (!options) {
      options = {};
    }

    this.type = 'default';
    this.status = options.status === undefined ? 200 : options.status;
    this.ok = this.status >= 200 && this.status < 300;
    this.statusText = options.statusText === undefined ? '' : '' + options.statusText;
    this.headers = new Headers(options.headers);
    this.url = options.url || '';
    this._initBody(bodyInit);
  }

  Body.call(Response.prototype);

  Response.prototype.clone = function() {
    return new Response(this._bodyInit, {
      status: this.status,
      statusText: this.statusText,
      headers: new Headers(this.headers),
      url: this.url
    })
  };

  Response.error = function() {
    var response = new Response(null, {status: 0, statusText: ''});
    response.type = 'error';
    return response
  };

  var redirectStatuses = [301, 302, 303, 307, 308];

  Response.redirect = function(url, status) {
    if (redirectStatuses.indexOf(status) === -1) {
      throw new RangeError('Invalid status code')
    }

    return new Response(null, {status: status, headers: {location: url}})
  };

  exports.DOMException = global.DOMException;
  try {
    new exports.DOMException();
  } catch (err) {
    exports.DOMException = function(message, name) {
      this.message = message;
      this.name = name;
      var error = Error(message);
      this.stack = error.stack;
    };
    exports.DOMException.prototype = Object.create(Error.prototype);
    exports.DOMException.prototype.constructor = exports.DOMException;
  }

  function fetch(input, init) {
    return new Promise(function(resolve, reject) {
      var request = new Request(input, init);

      if (request.signal && request.signal.aborted) {
        return reject(new exports.DOMException('Aborted', 'AbortError'))
      }

      var xhr = new XMLHttpRequest();

      function abortXhr() {
        xhr.abort();
      }

      xhr.onload = function() {
        var options = {
          status: xhr.status,
          statusText: xhr.statusText,
          headers: parseHeaders(xhr.getAllResponseHeaders() || '')
        };
        options.url = 'responseURL' in xhr ? xhr.responseURL : options.headers.get('X-Request-URL');
        var body = 'response' in xhr ? xhr.response : xhr.responseText;
        setTimeout(function() {
          resolve(new Response(body, options));
        }, 0);
      };

      xhr.onerror = function() {
        setTimeout(function() {
          reject(new TypeError('Network request failed'));
        }, 0);
      };

      xhr.ontimeout = function() {
        setTimeout(function() {
          reject(new TypeError('Network request failed'));
        }, 0);
      };

      xhr.onabort = function() {
        setTimeout(function() {
          reject(new exports.DOMException('Aborted', 'AbortError'));
        }, 0);
      };

      function fixUrl(url) {
        try {
          return url === '' && global.location.href ? global.location.href : url
        } catch (e) {
          return url
        }
      }

      xhr.open(request.method, fixUrl(request.url), true);

      if (request.credentials === 'include') {
        xhr.withCredentials = true;
      } else if (request.credentials === 'omit') {
        xhr.withCredentials = false;
      }

      if ('responseType' in xhr) {
        if (support.blob) {
          xhr.responseType = 'blob';
        } else if (
          support.arrayBuffer &&
          request.headers.get('Content-Type') &&
          request.headers.get('Content-Type').indexOf('application/octet-stream') !== -1
        ) {
          xhr.responseType = 'arraybuffer';
        }
      }

      if (init && typeof init.headers === 'object' && !(init.headers instanceof Headers)) {
        Object.getOwnPropertyNames(init.headers).forEach(function(name) {
          xhr.setRequestHeader(name, normalizeValue(init.headers[name]));
        });
      } else {
        request.headers.forEach(function(value, name) {
          xhr.setRequestHeader(name, value);
        });
      }

      if (request.signal) {
        request.signal.addEventListener('abort', abortXhr);

        xhr.onreadystatechange = function() {
          // DONE (success or failure)
          if (xhr.readyState === 4) {
            request.signal.removeEventListener('abort', abortXhr);
          }
        };
      }

      xhr.send(typeof request._bodyInit === 'undefined' ? null : request._bodyInit);
    })
  }

  fetch.polyfill = true;

  if (!global.fetch) {
    global.fetch = fetch;
    global.Headers = Headers;
    global.Request = Request;
    global.Response = Response;
  }

  exports.Headers = Headers;
  exports.Request = Request;
  exports.Response = Response;
  exports.fetch = fetch;

  return exports;

})({});
})(__globalThis__);
// This is a ponyfill, so...
__globalThis__.fetch.ponyfill = true;
delete __globalThis__.fetch.polyfill;
// Choose between native implementation (__global__) or custom implementation (__globalThis__)
var ctx = __global__.fetch ? __global__ : __globalThis__;
exports = ctx.fetch // To enable: import fetch from 'cross-fetch'
exports["default"] = ctx.fetch // For TypeScript consumers without esModuleInterop.
exports.fetch = ctx.fetch // To enable: import {fetch} from 'cross-fetch'
exports.Headers = ctx.Headers
exports.Request = ctx.Request
exports.Response = ctx.Response
module.exports = exports


/***/ }),

/***/ "./node_modules/html-parse-stringify/dist/html-parse-stringify.module.js":
/*!*******************************************************************************!*\
  !*** ./node_modules/html-parse-stringify/dist/html-parse-stringify.module.js ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var void_elements__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! void-elements */ "./node_modules/void-elements/index.js");
/* harmony import */ var void_elements__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(void_elements__WEBPACK_IMPORTED_MODULE_0__);
var t=/\s([^'"/\s><]+?)[\s/>]|([^\s=]+)=\s?(".*?"|'.*?')/g;function n(n){var r={type:"tag",name:"",voidElement:!1,attrs:{},children:[]},i=n.match(/<\/?([^\s]+?)[/\s>]/);if(i&&(r.name=i[1],((void_elements__WEBPACK_IMPORTED_MODULE_0___default())[i[1]]||"/"===n.charAt(n.length-2))&&(r.voidElement=!0),r.name.startsWith("!--"))){var s=n.indexOf("--\x3e");return{type:"comment",comment:-1!==s?n.slice(4,s):""}}for(var a=new RegExp(t),c=null;null!==(c=a.exec(n));)if(c[0].trim())if(c[1]){var o=c[1].trim(),l=[o,""];o.indexOf("=")>-1&&(l=o.split("=")),r.attrs[l[0]]=l[1],a.lastIndex--}else c[2]&&(r.attrs[c[2]]=c[3].trim().substring(1,c[3].length-1));return r}var r=/<[a-zA-Z0-9\-\!\/](?:"[^"]*"|'[^']*'|[^'">])*>/g,i=/^\s*$/,s=Object.create(null);function a(e,t){switch(t.type){case"text":return e+t.content;case"tag":return e+="<"+t.name+(t.attrs?function(e){var t=[];for(var n in e)t.push(n+'="'+e[n]+'"');return t.length?" "+t.join(" "):""}(t.attrs):"")+(t.voidElement?"/>":">"),t.voidElement?e:e+t.children.reduce(a,"")+"</"+t.name+">";case"comment":return e+"\x3c!--"+t.comment+"--\x3e"}}var c={parse:function(e,t){t||(t={}),t.components||(t.components=s);var a,c=[],o=[],l=-1,m=!1;if(0!==e.indexOf("<")){var u=e.indexOf("<");c.push({type:"text",content:-1===u?e:e.substring(0,u)})}return e.replace(r,function(r,s){if(m){if(r!=="</"+a.name+">")return;m=!1}var u,f="/"!==r.charAt(1),h=r.startsWith("\x3c!--"),p=s+r.length,d=e.charAt(p);if(h){var v=n(r);return l<0?(c.push(v),c):((u=o[l]).children.push(v),c)}if(f&&(l++,"tag"===(a=n(r)).type&&t.components[a.name]&&(a.type="component",m=!0),a.voidElement||m||!d||"<"===d||a.children.push({type:"text",content:e.slice(p,e.indexOf("<",p))}),0===l&&c.push(a),(u=o[l-1])&&u.children.push(a),o[l]=a),(!f||a.voidElement)&&(l>-1&&(a.voidElement||a.name===r.slice(2,-1))&&(l--,a=-1===l?c:o[l]),!m&&"<"!==d&&d)){u=-1===l?c:o[l].children;var x=e.indexOf("<",p),g=e.slice(p,-1===x?void 0:x);i.test(g)&&(g=" "),(x>-1&&l+u.length>=0||" "!==g)&&u.push({type:"text",content:g})}}),c},stringify:function(e){return e.reduce(function(e,t){return e+a("",t)},"")}};/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (c);
//# sourceMappingURL=html-parse-stringify.module.js.map


/***/ }),

/***/ "./node_modules/i18next-http-backend/esm/getFetch.cjs":
/*!************************************************************!*\
  !*** ./node_modules/i18next-http-backend/esm/getFetch.cjs ***!
  \************************************************************/
/***/ ((module, exports, __webpack_require__) => {

var fetchApi = typeof fetch === 'function' ? fetch : undefined
if (typeof __webpack_require__.g !== 'undefined' && __webpack_require__.g.fetch) {
  fetchApi = __webpack_require__.g.fetch
} else if (typeof window !== 'undefined' && window.fetch) {
  fetchApi = window.fetch
}

if ( true && typeof window === 'undefined') {
  var f = fetchApi || __webpack_require__(/*! cross-fetch */ "./node_modules/cross-fetch/dist/browser-ponyfill.js")
  if (f.default) f = f.default
  exports["default"] = f
  module.exports = exports.default
}


/***/ }),

/***/ "./node_modules/i18next-http-backend/esm/index.js":
/*!********************************************************!*\
  !*** ./node_modules/i18next-http-backend/esm/index.js ***!
  \********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils.js */ "./node_modules/i18next-http-backend/esm/utils.js");
/* harmony import */ var _request_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./request.js */ "./node_modules/i18next-http-backend/esm/request.js");
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _classCallCheck(a, n) { if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function"); }
function _defineProperties(e, r) { for (var t = 0; t < r.length; t++) { var o = r[t]; o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, _toPropertyKey(o.key), o); } }
function _createClass(e, r, t) { return r && _defineProperties(e.prototype, r), t && _defineProperties(e, t), Object.defineProperty(e, "prototype", { writable: !1 }), e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == _typeof(i) ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != _typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != _typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }


var getDefaults = function getDefaults() {
  return {
    loadPath: '/locales/{{lng}}/{{ns}}.json',
    addPath: '/locales/add/{{lng}}/{{ns}}',
    parse: function parse(data) {
      return JSON.parse(data);
    },
    stringify: JSON.stringify,
    parsePayload: function parsePayload(namespace, key, fallbackValue) {
      return _defineProperty({}, key, fallbackValue || '');
    },
    parseLoadPayload: function parseLoadPayload(languages, namespaces) {
      return undefined;
    },
    request: _request_js__WEBPACK_IMPORTED_MODULE_1__["default"],
    reloadInterval: typeof window !== 'undefined' ? false : 60 * 60 * 1000,
    customHeaders: {},
    queryStringParams: {},
    crossDomain: false,
    withCredentials: false,
    overrideMimeType: false,
    requestOptions: {
      mode: 'cors',
      credentials: 'same-origin',
      cache: 'default'
    }
  };
};
var Backend = function () {
  function Backend(services) {
    var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    var allOptions = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    _classCallCheck(this, Backend);
    this.services = services;
    this.options = options;
    this.allOptions = allOptions;
    this.type = 'backend';
    this.init(services, options, allOptions);
  }
  return _createClass(Backend, [{
    key: "init",
    value: function init(services) {
      var _this = this;
      var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
      var allOptions = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
      this.services = services;
      this.options = _objectSpread(_objectSpread(_objectSpread({}, getDefaults()), this.options || {}), options);
      this.allOptions = allOptions;
      if (this.services && this.options.reloadInterval) {
        var timer = setInterval(function () {
          return _this.reload();
        }, this.options.reloadInterval);
        if (_typeof(timer) === 'object' && typeof timer.unref === 'function') timer.unref();
      }
    }
  }, {
    key: "readMulti",
    value: function readMulti(languages, namespaces, callback) {
      this._readAny(languages, languages, namespaces, namespaces, callback);
    }
  }, {
    key: "read",
    value: function read(language, namespace, callback) {
      this._readAny([language], language, [namespace], namespace, callback);
    }
  }, {
    key: "_readAny",
    value: function _readAny(languages, loadUrlLanguages, namespaces, loadUrlNamespaces, callback) {
      var _this2 = this;
      var loadPath = this.options.loadPath;
      if (typeof this.options.loadPath === 'function') {
        loadPath = this.options.loadPath(languages, namespaces);
      }
      loadPath = (0,_utils_js__WEBPACK_IMPORTED_MODULE_0__.makePromise)(loadPath);
      loadPath.then(function (resolvedLoadPath) {
        if (!resolvedLoadPath) return callback(null, {});
        var url = _this2.services.interpolator.interpolate(resolvedLoadPath, {
          lng: languages.join('+'),
          ns: namespaces.join('+')
        });
        _this2.loadUrl(url, callback, loadUrlLanguages, loadUrlNamespaces);
      });
    }
  }, {
    key: "loadUrl",
    value: function loadUrl(url, callback, languages, namespaces) {
      var _this3 = this;
      var lng = typeof languages === 'string' ? [languages] : languages;
      var ns = typeof namespaces === 'string' ? [namespaces] : namespaces;
      var payload = this.options.parseLoadPayload(lng, ns);
      this.options.request(this.options, url, payload, function (err, res) {
        if (res && (res.status >= 500 && res.status < 600 || !res.status)) return callback('failed loading ' + url + '; status code: ' + res.status, true);
        if (res && res.status >= 400 && res.status < 500) return callback('failed loading ' + url + '; status code: ' + res.status, false);
        if (!res && err && err.message) {
          var errorMessage = err.message.toLowerCase();
          var isNetworkError = ['failed', 'fetch', 'network', 'load'].find(function (term) {
            return errorMessage.indexOf(term) > -1;
          });
          if (isNetworkError) {
            return callback('failed loading ' + url + ': ' + err.message, true);
          }
        }
        if (err) return callback(err, false);
        var ret, parseErr;
        try {
          if (typeof res.data === 'string') {
            ret = _this3.options.parse(res.data, languages, namespaces);
          } else {
            ret = res.data;
          }
        } catch (e) {
          parseErr = 'failed parsing ' + url + ' to json';
        }
        if (parseErr) return callback(parseErr, false);
        callback(null, ret);
      });
    }
  }, {
    key: "create",
    value: function create(languages, namespace, key, fallbackValue, callback) {
      var _this4 = this;
      if (!this.options.addPath) return;
      if (typeof languages === 'string') languages = [languages];
      var payload = this.options.parsePayload(namespace, key, fallbackValue);
      var finished = 0;
      var dataArray = [];
      var resArray = [];
      languages.forEach(function (lng) {
        var addPath = _this4.options.addPath;
        if (typeof _this4.options.addPath === 'function') {
          addPath = _this4.options.addPath(lng, namespace);
        }
        var url = _this4.services.interpolator.interpolate(addPath, {
          lng: lng,
          ns: namespace
        });
        _this4.options.request(_this4.options, url, payload, function (data, res) {
          finished += 1;
          dataArray.push(data);
          resArray.push(res);
          if (finished === languages.length) {
            if (typeof callback === 'function') callback(dataArray, resArray);
          }
        });
      });
    }
  }, {
    key: "reload",
    value: function reload() {
      var _this5 = this;
      var _this$services = this.services,
        backendConnector = _this$services.backendConnector,
        languageUtils = _this$services.languageUtils,
        logger = _this$services.logger;
      var currentLanguage = backendConnector.language;
      if (currentLanguage && currentLanguage.toLowerCase() === 'cimode') return;
      var toLoad = [];
      var append = function append(lng) {
        var lngs = languageUtils.toResolveHierarchy(lng);
        lngs.forEach(function (l) {
          if (toLoad.indexOf(l) < 0) toLoad.push(l);
        });
      };
      append(currentLanguage);
      if (this.allOptions.preload) this.allOptions.preload.forEach(function (l) {
        return append(l);
      });
      toLoad.forEach(function (lng) {
        _this5.allOptions.ns.forEach(function (ns) {
          backendConnector.read(lng, ns, 'read', null, null, function (err, data) {
            if (err) logger.warn("loading namespace ".concat(ns, " for language ").concat(lng, " failed"), err);
            if (!err && data) logger.log("loaded namespace ".concat(ns, " for language ").concat(lng), data);
            backendConnector.loaded("".concat(lng, "|").concat(ns), err, data);
          });
        });
      });
    }
  }]);
}();
Backend.type = 'backend';
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Backend);

/***/ }),

/***/ "./node_modules/i18next-http-backend/esm/request.js":
/*!**********************************************************!*\
  !*** ./node_modules/i18next-http-backend/esm/request.js ***!
  \**********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
var _getFetch_cjs__WEBPACK_IMPORTED_MODULE_1___namespace_cache;
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils.js */ "./node_modules/i18next-http-backend/esm/utils.js");
/* harmony import */ var _getFetch_cjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./getFetch.cjs */ "./node_modules/i18next-http-backend/esm/getFetch.cjs");
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == _typeof(i) ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != _typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != _typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }


var fetchApi = typeof fetch === 'function' ? fetch : undefined;
if (typeof global !== 'undefined' && global.fetch) {
  fetchApi = global.fetch;
} else if (typeof window !== 'undefined' && window.fetch) {
  fetchApi = window.fetch;
}
var XmlHttpRequestApi;
if ((0,_utils_js__WEBPACK_IMPORTED_MODULE_0__.hasXMLHttpRequest)()) {
  if (typeof global !== 'undefined' && global.XMLHttpRequest) {
    XmlHttpRequestApi = global.XMLHttpRequest;
  } else if (typeof window !== 'undefined' && window.XMLHttpRequest) {
    XmlHttpRequestApi = window.XMLHttpRequest;
  }
}
var ActiveXObjectApi;
if (typeof ActiveXObject === 'function') {
  if (typeof global !== 'undefined' && global.ActiveXObject) {
    ActiveXObjectApi = global.ActiveXObject;
  } else if (typeof window !== 'undefined' && window.ActiveXObject) {
    ActiveXObjectApi = window.ActiveXObject;
  }
}
if (!fetchApi && /*#__PURE__*/ (_getFetch_cjs__WEBPACK_IMPORTED_MODULE_1___namespace_cache || (_getFetch_cjs__WEBPACK_IMPORTED_MODULE_1___namespace_cache = __webpack_require__.t(_getFetch_cjs__WEBPACK_IMPORTED_MODULE_1__, 2))) && !XmlHttpRequestApi && !ActiveXObjectApi) fetchApi = _getFetch_cjs__WEBPACK_IMPORTED_MODULE_1__ || /*#__PURE__*/ (_getFetch_cjs__WEBPACK_IMPORTED_MODULE_1___namespace_cache || (_getFetch_cjs__WEBPACK_IMPORTED_MODULE_1___namespace_cache = __webpack_require__.t(_getFetch_cjs__WEBPACK_IMPORTED_MODULE_1__, 2)));
if (typeof fetchApi !== 'function') fetchApi = undefined;
var addQueryString = function addQueryString(url, params) {
  if (params && _typeof(params) === 'object') {
    var queryString = '';
    for (var paramName in params) {
      queryString += '&' + encodeURIComponent(paramName) + '=' + encodeURIComponent(params[paramName]);
    }
    if (!queryString) return url;
    url = url + (url.indexOf('?') !== -1 ? '&' : '?') + queryString.slice(1);
  }
  return url;
};
var fetchIt = function fetchIt(url, fetchOptions, callback, altFetch) {
  var resolver = function resolver(response) {
    if (!response.ok) return callback(response.statusText || 'Error', {
      status: response.status
    });
    response.text().then(function (data) {
      callback(null, {
        status: response.status,
        data: data
      });
    }).catch(callback);
  };
  if (altFetch) {
    var altResponse = altFetch(url, fetchOptions);
    if (altResponse instanceof Promise) {
      altResponse.then(resolver).catch(callback);
      return;
    }
  }
  if (typeof fetch === 'function') {
    fetch(url, fetchOptions).then(resolver).catch(callback);
  } else {
    fetchApi(url, fetchOptions).then(resolver).catch(callback);
  }
};
var omitFetchOptions = false;
var requestWithFetch = function requestWithFetch(options, url, payload, callback) {
  if (options.queryStringParams) {
    url = addQueryString(url, options.queryStringParams);
  }
  var headers = _objectSpread({}, typeof options.customHeaders === 'function' ? options.customHeaders() : options.customHeaders);
  if (typeof window === 'undefined' && typeof global !== 'undefined' && typeof global.process !== 'undefined' && global.process.versions && global.process.versions.node) {
    headers['User-Agent'] = "i18next-http-backend (node/".concat(global.process.version, "; ").concat(global.process.platform, " ").concat(global.process.arch, ")");
  }
  if (payload) headers['Content-Type'] = 'application/json';
  var reqOptions = typeof options.requestOptions === 'function' ? options.requestOptions(payload) : options.requestOptions;
  var fetchOptions = _objectSpread({
    method: payload ? 'POST' : 'GET',
    body: payload ? options.stringify(payload) : undefined,
    headers: headers
  }, omitFetchOptions ? {} : reqOptions);
  var altFetch = typeof options.alternateFetch === 'function' && options.alternateFetch.length >= 1 ? options.alternateFetch : undefined;
  try {
    fetchIt(url, fetchOptions, callback, altFetch);
  } catch (e) {
    if (!reqOptions || Object.keys(reqOptions).length === 0 || !e.message || e.message.indexOf('not implemented') < 0) {
      return callback(e);
    }
    try {
      Object.keys(reqOptions).forEach(function (opt) {
        delete fetchOptions[opt];
      });
      fetchIt(url, fetchOptions, callback, altFetch);
      omitFetchOptions = true;
    } catch (err) {
      callback(err);
    }
  }
};
var requestWithXmlHttpRequest = function requestWithXmlHttpRequest(options, url, payload, callback) {
  if (payload && _typeof(payload) === 'object') {
    payload = addQueryString('', payload).slice(1);
  }
  if (options.queryStringParams) {
    url = addQueryString(url, options.queryStringParams);
  }
  try {
    var x;
    if (XmlHttpRequestApi) {
      x = new XmlHttpRequestApi();
    } else {
      x = new ActiveXObjectApi('MSXML2.XMLHTTP.3.0');
    }
    x.open(payload ? 'POST' : 'GET', url, 1);
    if (!options.crossDomain) {
      x.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
    }
    x.withCredentials = !!options.withCredentials;
    if (payload) {
      x.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    }
    if (x.overrideMimeType) {
      x.overrideMimeType('application/json');
    }
    var h = options.customHeaders;
    h = typeof h === 'function' ? h() : h;
    if (h) {
      for (var i in h) {
        x.setRequestHeader(i, h[i]);
      }
    }
    x.onreadystatechange = function () {
      x.readyState > 3 && callback(x.status >= 400 ? x.statusText : null, {
        status: x.status,
        data: x.responseText
      });
    };
    x.send(payload);
  } catch (e) {
    console && console.log(e);
  }
};
var request = function request(options, url, payload, callback) {
  if (typeof payload === 'function') {
    callback = payload;
    payload = undefined;
  }
  callback = callback || function () {};
  if (fetchApi && url.indexOf('file:') !== 0) {
    return requestWithFetch(options, url, payload, callback);
  }
  if ((0,_utils_js__WEBPACK_IMPORTED_MODULE_0__.hasXMLHttpRequest)() || typeof ActiveXObject === 'function') {
    return requestWithXmlHttpRequest(options, url, payload, callback);
  }
  callback(new Error('No fetch and no xhr implementation found!'));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (request);

/***/ }),

/***/ "./node_modules/i18next-http-backend/esm/utils.js":
/*!********************************************************!*\
  !*** ./node_modules/i18next-http-backend/esm/utils.js ***!
  \********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   defaults: () => (/* binding */ defaults),
/* harmony export */   hasXMLHttpRequest: () => (/* binding */ hasXMLHttpRequest),
/* harmony export */   makePromise: () => (/* binding */ makePromise)
/* harmony export */ });
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
var arr = [];
var each = arr.forEach;
var slice = arr.slice;
function defaults(obj) {
  each.call(slice.call(arguments, 1), function (source) {
    if (source) {
      for (var prop in source) {
        if (obj[prop] === undefined) obj[prop] = source[prop];
      }
    }
  });
  return obj;
}
function hasXMLHttpRequest() {
  return typeof XMLHttpRequest === 'function' || (typeof XMLHttpRequest === "undefined" ? "undefined" : _typeof(XMLHttpRequest)) === 'object';
}
function isPromise(maybePromise) {
  return !!maybePromise && typeof maybePromise.then === 'function';
}
function makePromise(maybePromise) {
  if (isPromise(maybePromise)) {
    return maybePromise;
  }
  return Promise.resolve(maybePromise);
}

/***/ }),

/***/ "./node_modules/i18next/dist/esm/i18next.js":
/*!**************************************************!*\
  !*** ./node_modules/i18next/dist/esm/i18next.js ***!
  \**************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   changeLanguage: () => (/* binding */ changeLanguage),
/* harmony export */   createInstance: () => (/* binding */ createInstance),
/* harmony export */   "default": () => (/* binding */ instance),
/* harmony export */   dir: () => (/* binding */ dir),
/* harmony export */   exists: () => (/* binding */ exists),
/* harmony export */   getFixedT: () => (/* binding */ getFixedT),
/* harmony export */   hasLoadedNamespace: () => (/* binding */ hasLoadedNamespace),
/* harmony export */   init: () => (/* binding */ init),
/* harmony export */   keyFromSelector: () => (/* binding */ keysFromSelector),
/* harmony export */   loadLanguages: () => (/* binding */ loadLanguages),
/* harmony export */   loadNamespaces: () => (/* binding */ loadNamespaces),
/* harmony export */   loadResources: () => (/* binding */ loadResources),
/* harmony export */   reloadResources: () => (/* binding */ reloadResources),
/* harmony export */   setDefaultNamespace: () => (/* binding */ setDefaultNamespace),
/* harmony export */   t: () => (/* binding */ t),
/* harmony export */   use: () => (/* binding */ use)
/* harmony export */ });
const isString = obj => typeof obj === 'string';
const defer = () => {
  let res;
  let rej;
  const promise = new Promise((resolve, reject) => {
    res = resolve;
    rej = reject;
  });
  promise.resolve = res;
  promise.reject = rej;
  return promise;
};
const makeString = object => {
  if (object == null) return '';
  return '' + object;
};
const copy = (a, s, t) => {
  a.forEach(m => {
    if (s[m]) t[m] = s[m];
  });
};
const lastOfPathSeparatorRegExp = /###/g;
const cleanKey = key => key && key.indexOf('###') > -1 ? key.replace(lastOfPathSeparatorRegExp, '.') : key;
const canNotTraverseDeeper = object => !object || isString(object);
const getLastOfPath = (object, path, Empty) => {
  const stack = !isString(path) ? path : path.split('.');
  let stackIndex = 0;
  while (stackIndex < stack.length - 1) {
    if (canNotTraverseDeeper(object)) return {};
    const key = cleanKey(stack[stackIndex]);
    if (!object[key] && Empty) object[key] = new Empty();
    if (Object.prototype.hasOwnProperty.call(object, key)) {
      object = object[key];
    } else {
      object = {};
    }
    ++stackIndex;
  }
  if (canNotTraverseDeeper(object)) return {};
  return {
    obj: object,
    k: cleanKey(stack[stackIndex])
  };
};
const setPath = (object, path, newValue) => {
  const {
    obj,
    k
  } = getLastOfPath(object, path, Object);
  if (obj !== undefined || path.length === 1) {
    obj[k] = newValue;
    return;
  }
  let e = path[path.length - 1];
  let p = path.slice(0, path.length - 1);
  let last = getLastOfPath(object, p, Object);
  while (last.obj === undefined && p.length) {
    e = `${p[p.length - 1]}.${e}`;
    p = p.slice(0, p.length - 1);
    last = getLastOfPath(object, p, Object);
    if (last?.obj && typeof last.obj[`${last.k}.${e}`] !== 'undefined') {
      last.obj = undefined;
    }
  }
  last.obj[`${last.k}.${e}`] = newValue;
};
const pushPath = (object, path, newValue, concat) => {
  const {
    obj,
    k
  } = getLastOfPath(object, path, Object);
  obj[k] = obj[k] || [];
  obj[k].push(newValue);
};
const getPath = (object, path) => {
  const {
    obj,
    k
  } = getLastOfPath(object, path);
  if (!obj) return undefined;
  if (!Object.prototype.hasOwnProperty.call(obj, k)) return undefined;
  return obj[k];
};
const getPathWithDefaults = (data, defaultData, key) => {
  const value = getPath(data, key);
  if (value !== undefined) {
    return value;
  }
  return getPath(defaultData, key);
};
const deepExtend = (target, source, overwrite) => {
  for (const prop in source) {
    if (prop !== '__proto__' && prop !== 'constructor') {
      if (prop in target) {
        if (isString(target[prop]) || target[prop] instanceof String || isString(source[prop]) || source[prop] instanceof String) {
          if (overwrite) target[prop] = source[prop];
        } else {
          deepExtend(target[prop], source[prop], overwrite);
        }
      } else {
        target[prop] = source[prop];
      }
    }
  }
  return target;
};
const regexEscape = str => str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, '\\$&');
var _entityMap = {
  '&': '&amp;',
  '<': '&lt;',
  '>': '&gt;',
  '"': '&quot;',
  "'": '&#39;',
  '/': '&#x2F;'
};
const escape = data => {
  if (isString(data)) {
    return data.replace(/[&<>"'\/]/g, s => _entityMap[s]);
  }
  return data;
};
class RegExpCache {
  constructor(capacity) {
    this.capacity = capacity;
    this.regExpMap = new Map();
    this.regExpQueue = [];
  }
  getRegExp(pattern) {
    const regExpFromCache = this.regExpMap.get(pattern);
    if (regExpFromCache !== undefined) {
      return regExpFromCache;
    }
    const regExpNew = new RegExp(pattern);
    if (this.regExpQueue.length === this.capacity) {
      this.regExpMap.delete(this.regExpQueue.shift());
    }
    this.regExpMap.set(pattern, regExpNew);
    this.regExpQueue.push(pattern);
    return regExpNew;
  }
}
const chars = [' ', ',', '?', '!', ';'];
const looksLikeObjectPathRegExpCache = new RegExpCache(20);
const looksLikeObjectPath = (key, nsSeparator, keySeparator) => {
  nsSeparator = nsSeparator || '';
  keySeparator = keySeparator || '';
  const possibleChars = chars.filter(c => nsSeparator.indexOf(c) < 0 && keySeparator.indexOf(c) < 0);
  if (possibleChars.length === 0) return true;
  const r = looksLikeObjectPathRegExpCache.getRegExp(`(${possibleChars.map(c => c === '?' ? '\\?' : c).join('|')})`);
  let matched = !r.test(key);
  if (!matched) {
    const ki = key.indexOf(keySeparator);
    if (ki > 0 && !r.test(key.substring(0, ki))) {
      matched = true;
    }
  }
  return matched;
};
const deepFind = (obj, path, keySeparator = '.') => {
  if (!obj) return undefined;
  if (obj[path]) {
    if (!Object.prototype.hasOwnProperty.call(obj, path)) return undefined;
    return obj[path];
  }
  const tokens = path.split(keySeparator);
  let current = obj;
  for (let i = 0; i < tokens.length;) {
    if (!current || typeof current !== 'object') {
      return undefined;
    }
    let next;
    let nextPath = '';
    for (let j = i; j < tokens.length; ++j) {
      if (j !== i) {
        nextPath += keySeparator;
      }
      nextPath += tokens[j];
      next = current[nextPath];
      if (next !== undefined) {
        if (['string', 'number', 'boolean'].indexOf(typeof next) > -1 && j < tokens.length - 1) {
          continue;
        }
        i += j - i + 1;
        break;
      }
    }
    current = next;
  }
  return current;
};
const getCleanedCode = code => code?.replace('_', '-');

const consoleLogger = {
  type: 'logger',
  log(args) {
    this.output('log', args);
  },
  warn(args) {
    this.output('warn', args);
  },
  error(args) {
    this.output('error', args);
  },
  output(type, args) {
    console?.[type]?.apply?.(console, args);
  }
};
class Logger {
  constructor(concreteLogger, options = {}) {
    this.init(concreteLogger, options);
  }
  init(concreteLogger, options = {}) {
    this.prefix = options.prefix || 'i18next:';
    this.logger = concreteLogger || consoleLogger;
    this.options = options;
    this.debug = options.debug;
  }
  log(...args) {
    return this.forward(args, 'log', '', true);
  }
  warn(...args) {
    return this.forward(args, 'warn', '', true);
  }
  error(...args) {
    return this.forward(args, 'error', '');
  }
  deprecate(...args) {
    return this.forward(args, 'warn', 'WARNING DEPRECATED: ', true);
  }
  forward(args, lvl, prefix, debugOnly) {
    if (debugOnly && !this.debug) return null;
    if (isString(args[0])) args[0] = `${prefix}${this.prefix} ${args[0]}`;
    return this.logger[lvl](args);
  }
  create(moduleName) {
    return new Logger(this.logger, {
      ...{
        prefix: `${this.prefix}:${moduleName}:`
      },
      ...this.options
    });
  }
  clone(options) {
    options = options || this.options;
    options.prefix = options.prefix || this.prefix;
    return new Logger(this.logger, options);
  }
}
var baseLogger = new Logger();

class EventEmitter {
  constructor() {
    this.observers = {};
  }
  on(events, listener) {
    events.split(' ').forEach(event => {
      if (!this.observers[event]) this.observers[event] = new Map();
      const numListeners = this.observers[event].get(listener) || 0;
      this.observers[event].set(listener, numListeners + 1);
    });
    return this;
  }
  off(event, listener) {
    if (!this.observers[event]) return;
    if (!listener) {
      delete this.observers[event];
      return;
    }
    this.observers[event].delete(listener);
  }
  emit(event, ...args) {
    if (this.observers[event]) {
      const cloned = Array.from(this.observers[event].entries());
      cloned.forEach(([observer, numTimesAdded]) => {
        for (let i = 0; i < numTimesAdded; i++) {
          observer(...args);
        }
      });
    }
    if (this.observers['*']) {
      const cloned = Array.from(this.observers['*'].entries());
      cloned.forEach(([observer, numTimesAdded]) => {
        for (let i = 0; i < numTimesAdded; i++) {
          observer.apply(observer, [event, ...args]);
        }
      });
    }
  }
}

class ResourceStore extends EventEmitter {
  constructor(data, options = {
    ns: ['translation'],
    defaultNS: 'translation'
  }) {
    super();
    this.data = data || {};
    this.options = options;
    if (this.options.keySeparator === undefined) {
      this.options.keySeparator = '.';
    }
    if (this.options.ignoreJSONStructure === undefined) {
      this.options.ignoreJSONStructure = true;
    }
  }
  addNamespaces(ns) {
    if (this.options.ns.indexOf(ns) < 0) {
      this.options.ns.push(ns);
    }
  }
  removeNamespaces(ns) {
    const index = this.options.ns.indexOf(ns);
    if (index > -1) {
      this.options.ns.splice(index, 1);
    }
  }
  getResource(lng, ns, key, options = {}) {
    const keySeparator = options.keySeparator !== undefined ? options.keySeparator : this.options.keySeparator;
    const ignoreJSONStructure = options.ignoreJSONStructure !== undefined ? options.ignoreJSONStructure : this.options.ignoreJSONStructure;
    let path;
    if (lng.indexOf('.') > -1) {
      path = lng.split('.');
    } else {
      path = [lng, ns];
      if (key) {
        if (Array.isArray(key)) {
          path.push(...key);
        } else if (isString(key) && keySeparator) {
          path.push(...key.split(keySeparator));
        } else {
          path.push(key);
        }
      }
    }
    const result = getPath(this.data, path);
    if (!result && !ns && !key && lng.indexOf('.') > -1) {
      lng = path[0];
      ns = path[1];
      key = path.slice(2).join('.');
    }
    if (result || !ignoreJSONStructure || !isString(key)) return result;
    return deepFind(this.data?.[lng]?.[ns], key, keySeparator);
  }
  addResource(lng, ns, key, value, options = {
    silent: false
  }) {
    const keySeparator = options.keySeparator !== undefined ? options.keySeparator : this.options.keySeparator;
    let path = [lng, ns];
    if (key) path = path.concat(keySeparator ? key.split(keySeparator) : key);
    if (lng.indexOf('.') > -1) {
      path = lng.split('.');
      value = ns;
      ns = path[1];
    }
    this.addNamespaces(ns);
    setPath(this.data, path, value);
    if (!options.silent) this.emit('added', lng, ns, key, value);
  }
  addResources(lng, ns, resources, options = {
    silent: false
  }) {
    for (const m in resources) {
      if (isString(resources[m]) || Array.isArray(resources[m])) this.addResource(lng, ns, m, resources[m], {
        silent: true
      });
    }
    if (!options.silent) this.emit('added', lng, ns, resources);
  }
  addResourceBundle(lng, ns, resources, deep, overwrite, options = {
    silent: false,
    skipCopy: false
  }) {
    let path = [lng, ns];
    if (lng.indexOf('.') > -1) {
      path = lng.split('.');
      deep = resources;
      resources = ns;
      ns = path[1];
    }
    this.addNamespaces(ns);
    let pack = getPath(this.data, path) || {};
    if (!options.skipCopy) resources = JSON.parse(JSON.stringify(resources));
    if (deep) {
      deepExtend(pack, resources, overwrite);
    } else {
      pack = {
        ...pack,
        ...resources
      };
    }
    setPath(this.data, path, pack);
    if (!options.silent) this.emit('added', lng, ns, resources);
  }
  removeResourceBundle(lng, ns) {
    if (this.hasResourceBundle(lng, ns)) {
      delete this.data[lng][ns];
    }
    this.removeNamespaces(ns);
    this.emit('removed', lng, ns);
  }
  hasResourceBundle(lng, ns) {
    return this.getResource(lng, ns) !== undefined;
  }
  getResourceBundle(lng, ns) {
    if (!ns) ns = this.options.defaultNS;
    return this.getResource(lng, ns);
  }
  getDataByLanguage(lng) {
    return this.data[lng];
  }
  hasLanguageSomeTranslations(lng) {
    const data = this.getDataByLanguage(lng);
    const n = data && Object.keys(data) || [];
    return !!n.find(v => data[v] && Object.keys(data[v]).length > 0);
  }
  toJSON() {
    return this.data;
  }
}

var postProcessor = {
  processors: {},
  addPostProcessor(module) {
    this.processors[module.name] = module;
  },
  handle(processors, value, key, options, translator) {
    processors.forEach(processor => {
      value = this.processors[processor]?.process(value, key, options, translator) ?? value;
    });
    return value;
  }
};

const PATH_KEY = Symbol('i18next/PATH_KEY');
function createProxy() {
  const state = [];
  const handler = Object.create(null);
  let proxy;
  handler.get = (target, key) => {
    proxy?.revoke?.();
    if (key === PATH_KEY) return state;
    state.push(key);
    proxy = Proxy.revocable(target, handler);
    return proxy.proxy;
  };
  return Proxy.revocable(Object.create(null), handler).proxy;
}
function keysFromSelector(selector, opts) {
  const {
    [PATH_KEY]: path
  } = selector(createProxy());
  return path.join(opts?.keySeparator ?? '.');
}

const checkedLoadedFor = {};
const shouldHandleAsObject = res => !isString(res) && typeof res !== 'boolean' && typeof res !== 'number';
class Translator extends EventEmitter {
  constructor(services, options = {}) {
    super();
    copy(['resourceStore', 'languageUtils', 'pluralResolver', 'interpolator', 'backendConnector', 'i18nFormat', 'utils'], services, this);
    this.options = options;
    if (this.options.keySeparator === undefined) {
      this.options.keySeparator = '.';
    }
    this.logger = baseLogger.create('translator');
  }
  changeLanguage(lng) {
    if (lng) this.language = lng;
  }
  exists(key, o = {
    interpolation: {}
  }) {
    const opt = {
      ...o
    };
    if (key == null) return false;
    const resolved = this.resolve(key, opt);
    if (resolved?.res === undefined) return false;
    const isObject = shouldHandleAsObject(resolved.res);
    if (opt.returnObjects === false && isObject) {
      return false;
    }
    return true;
  }
  extractFromKey(key, opt) {
    let nsSeparator = opt.nsSeparator !== undefined ? opt.nsSeparator : this.options.nsSeparator;
    if (nsSeparator === undefined) nsSeparator = ':';
    const keySeparator = opt.keySeparator !== undefined ? opt.keySeparator : this.options.keySeparator;
    let namespaces = opt.ns || this.options.defaultNS || [];
    const wouldCheckForNsInKey = nsSeparator && key.indexOf(nsSeparator) > -1;
    const seemsNaturalLanguage = !this.options.userDefinedKeySeparator && !opt.keySeparator && !this.options.userDefinedNsSeparator && !opt.nsSeparator && !looksLikeObjectPath(key, nsSeparator, keySeparator);
    if (wouldCheckForNsInKey && !seemsNaturalLanguage) {
      const m = key.match(this.interpolator.nestingRegexp);
      if (m && m.length > 0) {
        return {
          key,
          namespaces: isString(namespaces) ? [namespaces] : namespaces
        };
      }
      const parts = key.split(nsSeparator);
      if (nsSeparator !== keySeparator || nsSeparator === keySeparator && this.options.ns.indexOf(parts[0]) > -1) namespaces = parts.shift();
      key = parts.join(keySeparator);
    }
    return {
      key,
      namespaces: isString(namespaces) ? [namespaces] : namespaces
    };
  }
  translate(keys, o, lastKey) {
    let opt = typeof o === 'object' ? {
      ...o
    } : o;
    if (typeof opt !== 'object' && this.options.overloadTranslationOptionHandler) {
      opt = this.options.overloadTranslationOptionHandler(arguments);
    }
    if (typeof opt === 'object') opt = {
      ...opt
    };
    if (!opt) opt = {};
    if (keys == null) return '';
    if (typeof keys === 'function') keys = keysFromSelector(keys, {
      ...this.options,
      ...opt
    });
    if (!Array.isArray(keys)) keys = [String(keys)];
    const returnDetails = opt.returnDetails !== undefined ? opt.returnDetails : this.options.returnDetails;
    const keySeparator = opt.keySeparator !== undefined ? opt.keySeparator : this.options.keySeparator;
    const {
      key,
      namespaces
    } = this.extractFromKey(keys[keys.length - 1], opt);
    const namespace = namespaces[namespaces.length - 1];
    let nsSeparator = opt.nsSeparator !== undefined ? opt.nsSeparator : this.options.nsSeparator;
    if (nsSeparator === undefined) nsSeparator = ':';
    const lng = opt.lng || this.language;
    const appendNamespaceToCIMode = opt.appendNamespaceToCIMode || this.options.appendNamespaceToCIMode;
    if (lng?.toLowerCase() === 'cimode') {
      if (appendNamespaceToCIMode) {
        if (returnDetails) {
          return {
            res: `${namespace}${nsSeparator}${key}`,
            usedKey: key,
            exactUsedKey: key,
            usedLng: lng,
            usedNS: namespace,
            usedParams: this.getUsedParamsDetails(opt)
          };
        }
        return `${namespace}${nsSeparator}${key}`;
      }
      if (returnDetails) {
        return {
          res: key,
          usedKey: key,
          exactUsedKey: key,
          usedLng: lng,
          usedNS: namespace,
          usedParams: this.getUsedParamsDetails(opt)
        };
      }
      return key;
    }
    const resolved = this.resolve(keys, opt);
    let res = resolved?.res;
    const resUsedKey = resolved?.usedKey || key;
    const resExactUsedKey = resolved?.exactUsedKey || key;
    const noObject = ['[object Number]', '[object Function]', '[object RegExp]'];
    const joinArrays = opt.joinArrays !== undefined ? opt.joinArrays : this.options.joinArrays;
    const handleAsObjectInI18nFormat = !this.i18nFormat || this.i18nFormat.handleAsObject;
    const needsPluralHandling = opt.count !== undefined && !isString(opt.count);
    const hasDefaultValue = Translator.hasDefaultValue(opt);
    const defaultValueSuffix = needsPluralHandling ? this.pluralResolver.getSuffix(lng, opt.count, opt) : '';
    const defaultValueSuffixOrdinalFallback = opt.ordinal && needsPluralHandling ? this.pluralResolver.getSuffix(lng, opt.count, {
      ordinal: false
    }) : '';
    const needsZeroSuffixLookup = needsPluralHandling && !opt.ordinal && opt.count === 0;
    const defaultValue = needsZeroSuffixLookup && opt[`defaultValue${this.options.pluralSeparator}zero`] || opt[`defaultValue${defaultValueSuffix}`] || opt[`defaultValue${defaultValueSuffixOrdinalFallback}`] || opt.defaultValue;
    let resForObjHndl = res;
    if (handleAsObjectInI18nFormat && !res && hasDefaultValue) {
      resForObjHndl = defaultValue;
    }
    const handleAsObject = shouldHandleAsObject(resForObjHndl);
    const resType = Object.prototype.toString.apply(resForObjHndl);
    if (handleAsObjectInI18nFormat && resForObjHndl && handleAsObject && noObject.indexOf(resType) < 0 && !(isString(joinArrays) && Array.isArray(resForObjHndl))) {
      if (!opt.returnObjects && !this.options.returnObjects) {
        if (!this.options.returnedObjectHandler) {
          this.logger.warn('accessing an object - but returnObjects options is not enabled!');
        }
        const r = this.options.returnedObjectHandler ? this.options.returnedObjectHandler(resUsedKey, resForObjHndl, {
          ...opt,
          ns: namespaces
        }) : `key '${key} (${this.language})' returned an object instead of string.`;
        if (returnDetails) {
          resolved.res = r;
          resolved.usedParams = this.getUsedParamsDetails(opt);
          return resolved;
        }
        return r;
      }
      if (keySeparator) {
        const resTypeIsArray = Array.isArray(resForObjHndl);
        const copy = resTypeIsArray ? [] : {};
        const newKeyToUse = resTypeIsArray ? resExactUsedKey : resUsedKey;
        for (const m in resForObjHndl) {
          if (Object.prototype.hasOwnProperty.call(resForObjHndl, m)) {
            const deepKey = `${newKeyToUse}${keySeparator}${m}`;
            if (hasDefaultValue && !res) {
              copy[m] = this.translate(deepKey, {
                ...opt,
                defaultValue: shouldHandleAsObject(defaultValue) ? defaultValue[m] : undefined,
                ...{
                  joinArrays: false,
                  ns: namespaces
                }
              });
            } else {
              copy[m] = this.translate(deepKey, {
                ...opt,
                ...{
                  joinArrays: false,
                  ns: namespaces
                }
              });
            }
            if (copy[m] === deepKey) copy[m] = resForObjHndl[m];
          }
        }
        res = copy;
      }
    } else if (handleAsObjectInI18nFormat && isString(joinArrays) && Array.isArray(res)) {
      res = res.join(joinArrays);
      if (res) res = this.extendTranslation(res, keys, opt, lastKey);
    } else {
      let usedDefault = false;
      let usedKey = false;
      if (!this.isValidLookup(res) && hasDefaultValue) {
        usedDefault = true;
        res = defaultValue;
      }
      if (!this.isValidLookup(res)) {
        usedKey = true;
        res = key;
      }
      const missingKeyNoValueFallbackToKey = opt.missingKeyNoValueFallbackToKey || this.options.missingKeyNoValueFallbackToKey;
      const resForMissing = missingKeyNoValueFallbackToKey && usedKey ? undefined : res;
      const updateMissing = hasDefaultValue && defaultValue !== res && this.options.updateMissing;
      if (usedKey || usedDefault || updateMissing) {
        this.logger.log(updateMissing ? 'updateKey' : 'missingKey', lng, namespace, key, updateMissing ? defaultValue : res);
        if (keySeparator) {
          const fk = this.resolve(key, {
            ...opt,
            keySeparator: false
          });
          if (fk && fk.res) this.logger.warn('Seems the loaded translations were in flat JSON format instead of nested. Either set keySeparator: false on init or make sure your translations are published in nested format.');
        }
        let lngs = [];
        const fallbackLngs = this.languageUtils.getFallbackCodes(this.options.fallbackLng, opt.lng || this.language);
        if (this.options.saveMissingTo === 'fallback' && fallbackLngs && fallbackLngs[0]) {
          for (let i = 0; i < fallbackLngs.length; i++) {
            lngs.push(fallbackLngs[i]);
          }
        } else if (this.options.saveMissingTo === 'all') {
          lngs = this.languageUtils.toResolveHierarchy(opt.lng || this.language);
        } else {
          lngs.push(opt.lng || this.language);
        }
        const send = (l, k, specificDefaultValue) => {
          const defaultForMissing = hasDefaultValue && specificDefaultValue !== res ? specificDefaultValue : resForMissing;
          if (this.options.missingKeyHandler) {
            this.options.missingKeyHandler(l, namespace, k, defaultForMissing, updateMissing, opt);
          } else if (this.backendConnector?.saveMissing) {
            this.backendConnector.saveMissing(l, namespace, k, defaultForMissing, updateMissing, opt);
          }
          this.emit('missingKey', l, namespace, k, res);
        };
        if (this.options.saveMissing) {
          if (this.options.saveMissingPlurals && needsPluralHandling) {
            lngs.forEach(language => {
              const suffixes = this.pluralResolver.getSuffixes(language, opt);
              if (needsZeroSuffixLookup && opt[`defaultValue${this.options.pluralSeparator}zero`] && suffixes.indexOf(`${this.options.pluralSeparator}zero`) < 0) {
                suffixes.push(`${this.options.pluralSeparator}zero`);
              }
              suffixes.forEach(suffix => {
                send([language], key + suffix, opt[`defaultValue${suffix}`] || defaultValue);
              });
            });
          } else {
            send(lngs, key, defaultValue);
          }
        }
      }
      res = this.extendTranslation(res, keys, opt, resolved, lastKey);
      if (usedKey && res === key && this.options.appendNamespaceToMissingKey) {
        res = `${namespace}${nsSeparator}${key}`;
      }
      if ((usedKey || usedDefault) && this.options.parseMissingKeyHandler) {
        res = this.options.parseMissingKeyHandler(this.options.appendNamespaceToMissingKey ? `${namespace}${nsSeparator}${key}` : key, usedDefault ? res : undefined, opt);
      }
    }
    if (returnDetails) {
      resolved.res = res;
      resolved.usedParams = this.getUsedParamsDetails(opt);
      return resolved;
    }
    return res;
  }
  extendTranslation(res, key, opt, resolved, lastKey) {
    if (this.i18nFormat?.parse) {
      res = this.i18nFormat.parse(res, {
        ...this.options.interpolation.defaultVariables,
        ...opt
      }, opt.lng || this.language || resolved.usedLng, resolved.usedNS, resolved.usedKey, {
        resolved
      });
    } else if (!opt.skipInterpolation) {
      if (opt.interpolation) this.interpolator.init({
        ...opt,
        ...{
          interpolation: {
            ...this.options.interpolation,
            ...opt.interpolation
          }
        }
      });
      const skipOnVariables = isString(res) && (opt?.interpolation?.skipOnVariables !== undefined ? opt.interpolation.skipOnVariables : this.options.interpolation.skipOnVariables);
      let nestBef;
      if (skipOnVariables) {
        const nb = res.match(this.interpolator.nestingRegexp);
        nestBef = nb && nb.length;
      }
      let data = opt.replace && !isString(opt.replace) ? opt.replace : opt;
      if (this.options.interpolation.defaultVariables) data = {
        ...this.options.interpolation.defaultVariables,
        ...data
      };
      res = this.interpolator.interpolate(res, data, opt.lng || this.language || resolved.usedLng, opt);
      if (skipOnVariables) {
        const na = res.match(this.interpolator.nestingRegexp);
        const nestAft = na && na.length;
        if (nestBef < nestAft) opt.nest = false;
      }
      if (!opt.lng && resolved && resolved.res) opt.lng = this.language || resolved.usedLng;
      if (opt.nest !== false) res = this.interpolator.nest(res, (...args) => {
        if (lastKey?.[0] === args[0] && !opt.context) {
          this.logger.warn(`It seems you are nesting recursively key: ${args[0]} in key: ${key[0]}`);
          return null;
        }
        return this.translate(...args, key);
      }, opt);
      if (opt.interpolation) this.interpolator.reset();
    }
    const postProcess = opt.postProcess || this.options.postProcess;
    const postProcessorNames = isString(postProcess) ? [postProcess] : postProcess;
    if (res != null && postProcessorNames?.length && opt.applyPostProcessor !== false) {
      res = postProcessor.handle(postProcessorNames, res, key, this.options && this.options.postProcessPassResolved ? {
        i18nResolved: {
          ...resolved,
          usedParams: this.getUsedParamsDetails(opt)
        },
        ...opt
      } : opt, this);
    }
    return res;
  }
  resolve(keys, opt = {}) {
    let found;
    let usedKey;
    let exactUsedKey;
    let usedLng;
    let usedNS;
    if (isString(keys)) keys = [keys];
    keys.forEach(k => {
      if (this.isValidLookup(found)) return;
      const extracted = this.extractFromKey(k, opt);
      const key = extracted.key;
      usedKey = key;
      let namespaces = extracted.namespaces;
      if (this.options.fallbackNS) namespaces = namespaces.concat(this.options.fallbackNS);
      const needsPluralHandling = opt.count !== undefined && !isString(opt.count);
      const needsZeroSuffixLookup = needsPluralHandling && !opt.ordinal && opt.count === 0;
      const needsContextHandling = opt.context !== undefined && (isString(opt.context) || typeof opt.context === 'number') && opt.context !== '';
      const codes = opt.lngs ? opt.lngs : this.languageUtils.toResolveHierarchy(opt.lng || this.language, opt.fallbackLng);
      namespaces.forEach(ns => {
        if (this.isValidLookup(found)) return;
        usedNS = ns;
        if (!checkedLoadedFor[`${codes[0]}-${ns}`] && this.utils?.hasLoadedNamespace && !this.utils?.hasLoadedNamespace(usedNS)) {
          checkedLoadedFor[`${codes[0]}-${ns}`] = true;
          this.logger.warn(`key "${usedKey}" for languages "${codes.join(', ')}" won't get resolved as namespace "${usedNS}" was not yet loaded`, 'This means something IS WRONG in your setup. You access the t function before i18next.init / i18next.loadNamespace / i18next.changeLanguage was done. Wait for the callback or Promise to resolve before accessing it!!!');
        }
        codes.forEach(code => {
          if (this.isValidLookup(found)) return;
          usedLng = code;
          const finalKeys = [key];
          if (this.i18nFormat?.addLookupKeys) {
            this.i18nFormat.addLookupKeys(finalKeys, key, code, ns, opt);
          } else {
            let pluralSuffix;
            if (needsPluralHandling) pluralSuffix = this.pluralResolver.getSuffix(code, opt.count, opt);
            const zeroSuffix = `${this.options.pluralSeparator}zero`;
            const ordinalPrefix = `${this.options.pluralSeparator}ordinal${this.options.pluralSeparator}`;
            if (needsPluralHandling) {
              if (opt.ordinal && pluralSuffix.indexOf(ordinalPrefix) === 0) {
                finalKeys.push(key + pluralSuffix.replace(ordinalPrefix, this.options.pluralSeparator));
              }
              finalKeys.push(key + pluralSuffix);
              if (needsZeroSuffixLookup) {
                finalKeys.push(key + zeroSuffix);
              }
            }
            if (needsContextHandling) {
              const contextKey = `${key}${this.options.contextSeparator || '_'}${opt.context}`;
              finalKeys.push(contextKey);
              if (needsPluralHandling) {
                if (opt.ordinal && pluralSuffix.indexOf(ordinalPrefix) === 0) {
                  finalKeys.push(contextKey + pluralSuffix.replace(ordinalPrefix, this.options.pluralSeparator));
                }
                finalKeys.push(contextKey + pluralSuffix);
                if (needsZeroSuffixLookup) {
                  finalKeys.push(contextKey + zeroSuffix);
                }
              }
            }
          }
          let possibleKey;
          while (possibleKey = finalKeys.pop()) {
            if (!this.isValidLookup(found)) {
              exactUsedKey = possibleKey;
              found = this.getResource(code, ns, possibleKey, opt);
            }
          }
        });
      });
    });
    return {
      res: found,
      usedKey,
      exactUsedKey,
      usedLng,
      usedNS
    };
  }
  isValidLookup(res) {
    return res !== undefined && !(!this.options.returnNull && res === null) && !(!this.options.returnEmptyString && res === '');
  }
  getResource(code, ns, key, options = {}) {
    if (this.i18nFormat?.getResource) return this.i18nFormat.getResource(code, ns, key, options);
    return this.resourceStore.getResource(code, ns, key, options);
  }
  getUsedParamsDetails(options = {}) {
    const optionsKeys = ['defaultValue', 'ordinal', 'context', 'replace', 'lng', 'lngs', 'fallbackLng', 'ns', 'keySeparator', 'nsSeparator', 'returnObjects', 'returnDetails', 'joinArrays', 'postProcess', 'interpolation'];
    const useOptionsReplaceForData = options.replace && !isString(options.replace);
    let data = useOptionsReplaceForData ? options.replace : options;
    if (useOptionsReplaceForData && typeof options.count !== 'undefined') {
      data.count = options.count;
    }
    if (this.options.interpolation.defaultVariables) {
      data = {
        ...this.options.interpolation.defaultVariables,
        ...data
      };
    }
    if (!useOptionsReplaceForData) {
      data = {
        ...data
      };
      for (const key of optionsKeys) {
        delete data[key];
      }
    }
    return data;
  }
  static hasDefaultValue(options) {
    const prefix = 'defaultValue';
    for (const option in options) {
      if (Object.prototype.hasOwnProperty.call(options, option) && prefix === option.substring(0, prefix.length) && undefined !== options[option]) {
        return true;
      }
    }
    return false;
  }
}

class LanguageUtil {
  constructor(options) {
    this.options = options;
    this.supportedLngs = this.options.supportedLngs || false;
    this.logger = baseLogger.create('languageUtils');
  }
  getScriptPartFromCode(code) {
    code = getCleanedCode(code);
    if (!code || code.indexOf('-') < 0) return null;
    const p = code.split('-');
    if (p.length === 2) return null;
    p.pop();
    if (p[p.length - 1].toLowerCase() === 'x') return null;
    return this.formatLanguageCode(p.join('-'));
  }
  getLanguagePartFromCode(code) {
    code = getCleanedCode(code);
    if (!code || code.indexOf('-') < 0) return code;
    const p = code.split('-');
    return this.formatLanguageCode(p[0]);
  }
  formatLanguageCode(code) {
    if (isString(code) && code.indexOf('-') > -1) {
      let formattedCode;
      try {
        formattedCode = Intl.getCanonicalLocales(code)[0];
      } catch (e) {}
      if (formattedCode && this.options.lowerCaseLng) {
        formattedCode = formattedCode.toLowerCase();
      }
      if (formattedCode) return formattedCode;
      if (this.options.lowerCaseLng) {
        return code.toLowerCase();
      }
      return code;
    }
    return this.options.cleanCode || this.options.lowerCaseLng ? code.toLowerCase() : code;
  }
  isSupportedCode(code) {
    if (this.options.load === 'languageOnly' || this.options.nonExplicitSupportedLngs) {
      code = this.getLanguagePartFromCode(code);
    }
    return !this.supportedLngs || !this.supportedLngs.length || this.supportedLngs.indexOf(code) > -1;
  }
  getBestMatchFromCodes(codes) {
    if (!codes) return null;
    let found;
    codes.forEach(code => {
      if (found) return;
      const cleanedLng = this.formatLanguageCode(code);
      if (!this.options.supportedLngs || this.isSupportedCode(cleanedLng)) found = cleanedLng;
    });
    if (!found && this.options.supportedLngs) {
      codes.forEach(code => {
        if (found) return;
        const lngScOnly = this.getScriptPartFromCode(code);
        if (this.isSupportedCode(lngScOnly)) return found = lngScOnly;
        const lngOnly = this.getLanguagePartFromCode(code);
        if (this.isSupportedCode(lngOnly)) return found = lngOnly;
        found = this.options.supportedLngs.find(supportedLng => {
          if (supportedLng === lngOnly) return supportedLng;
          if (supportedLng.indexOf('-') < 0 && lngOnly.indexOf('-') < 0) return;
          if (supportedLng.indexOf('-') > 0 && lngOnly.indexOf('-') < 0 && supportedLng.substring(0, supportedLng.indexOf('-')) === lngOnly) return supportedLng;
          if (supportedLng.indexOf(lngOnly) === 0 && lngOnly.length > 1) return supportedLng;
        });
      });
    }
    if (!found) found = this.getFallbackCodes(this.options.fallbackLng)[0];
    return found;
  }
  getFallbackCodes(fallbacks, code) {
    if (!fallbacks) return [];
    if (typeof fallbacks === 'function') fallbacks = fallbacks(code);
    if (isString(fallbacks)) fallbacks = [fallbacks];
    if (Array.isArray(fallbacks)) return fallbacks;
    if (!code) return fallbacks.default || [];
    let found = fallbacks[code];
    if (!found) found = fallbacks[this.getScriptPartFromCode(code)];
    if (!found) found = fallbacks[this.formatLanguageCode(code)];
    if (!found) found = fallbacks[this.getLanguagePartFromCode(code)];
    if (!found) found = fallbacks.default;
    return found || [];
  }
  toResolveHierarchy(code, fallbackCode) {
    const fallbackCodes = this.getFallbackCodes((fallbackCode === false ? [] : fallbackCode) || this.options.fallbackLng || [], code);
    const codes = [];
    const addCode = c => {
      if (!c) return;
      if (this.isSupportedCode(c)) {
        codes.push(c);
      } else {
        this.logger.warn(`rejecting language code not found in supportedLngs: ${c}`);
      }
    };
    if (isString(code) && (code.indexOf('-') > -1 || code.indexOf('_') > -1)) {
      if (this.options.load !== 'languageOnly') addCode(this.formatLanguageCode(code));
      if (this.options.load !== 'languageOnly' && this.options.load !== 'currentOnly') addCode(this.getScriptPartFromCode(code));
      if (this.options.load !== 'currentOnly') addCode(this.getLanguagePartFromCode(code));
    } else if (isString(code)) {
      addCode(this.formatLanguageCode(code));
    }
    fallbackCodes.forEach(fc => {
      if (codes.indexOf(fc) < 0) addCode(this.formatLanguageCode(fc));
    });
    return codes;
  }
}

const suffixesOrder = {
  zero: 0,
  one: 1,
  two: 2,
  few: 3,
  many: 4,
  other: 5
};
const dummyRule = {
  select: count => count === 1 ? 'one' : 'other',
  resolvedOptions: () => ({
    pluralCategories: ['one', 'other']
  })
};
class PluralResolver {
  constructor(languageUtils, options = {}) {
    this.languageUtils = languageUtils;
    this.options = options;
    this.logger = baseLogger.create('pluralResolver');
    this.pluralRulesCache = {};
  }
  addRule(lng, obj) {
    this.rules[lng] = obj;
  }
  clearCache() {
    this.pluralRulesCache = {};
  }
  getRule(code, options = {}) {
    const cleanedCode = getCleanedCode(code === 'dev' ? 'en' : code);
    const type = options.ordinal ? 'ordinal' : 'cardinal';
    const cacheKey = JSON.stringify({
      cleanedCode,
      type
    });
    if (cacheKey in this.pluralRulesCache) {
      return this.pluralRulesCache[cacheKey];
    }
    let rule;
    try {
      rule = new Intl.PluralRules(cleanedCode, {
        type
      });
    } catch (err) {
      if (!Intl) {
        this.logger.error('No Intl support, please use an Intl polyfill!');
        return dummyRule;
      }
      if (!code.match(/-|_/)) return dummyRule;
      const lngPart = this.languageUtils.getLanguagePartFromCode(code);
      rule = this.getRule(lngPart, options);
    }
    this.pluralRulesCache[cacheKey] = rule;
    return rule;
  }
  needsPlural(code, options = {}) {
    let rule = this.getRule(code, options);
    if (!rule) rule = this.getRule('dev', options);
    return rule?.resolvedOptions().pluralCategories.length > 1;
  }
  getPluralFormsOfKey(code, key, options = {}) {
    return this.getSuffixes(code, options).map(suffix => `${key}${suffix}`);
  }
  getSuffixes(code, options = {}) {
    let rule = this.getRule(code, options);
    if (!rule) rule = this.getRule('dev', options);
    if (!rule) return [];
    return rule.resolvedOptions().pluralCategories.sort((pluralCategory1, pluralCategory2) => suffixesOrder[pluralCategory1] - suffixesOrder[pluralCategory2]).map(pluralCategory => `${this.options.prepend}${options.ordinal ? `ordinal${this.options.prepend}` : ''}${pluralCategory}`);
  }
  getSuffix(code, count, options = {}) {
    const rule = this.getRule(code, options);
    if (rule) {
      return `${this.options.prepend}${options.ordinal ? `ordinal${this.options.prepend}` : ''}${rule.select(count)}`;
    }
    this.logger.warn(`no plural rule found for: ${code}`);
    return this.getSuffix('dev', count, options);
  }
}

const deepFindWithDefaults = (data, defaultData, key, keySeparator = '.', ignoreJSONStructure = true) => {
  let path = getPathWithDefaults(data, defaultData, key);
  if (!path && ignoreJSONStructure && isString(key)) {
    path = deepFind(data, key, keySeparator);
    if (path === undefined) path = deepFind(defaultData, key, keySeparator);
  }
  return path;
};
const regexSafe = val => val.replace(/\$/g, '$$$$');
class Interpolator {
  constructor(options = {}) {
    this.logger = baseLogger.create('interpolator');
    this.options = options;
    this.format = options?.interpolation?.format || (value => value);
    this.init(options);
  }
  init(options = {}) {
    if (!options.interpolation) options.interpolation = {
      escapeValue: true
    };
    const {
      escape: escape$1,
      escapeValue,
      useRawValueToEscape,
      prefix,
      prefixEscaped,
      suffix,
      suffixEscaped,
      formatSeparator,
      unescapeSuffix,
      unescapePrefix,
      nestingPrefix,
      nestingPrefixEscaped,
      nestingSuffix,
      nestingSuffixEscaped,
      nestingOptionsSeparator,
      maxReplaces,
      alwaysFormat
    } = options.interpolation;
    this.escape = escape$1 !== undefined ? escape$1 : escape;
    this.escapeValue = escapeValue !== undefined ? escapeValue : true;
    this.useRawValueToEscape = useRawValueToEscape !== undefined ? useRawValueToEscape : false;
    this.prefix = prefix ? regexEscape(prefix) : prefixEscaped || '{{';
    this.suffix = suffix ? regexEscape(suffix) : suffixEscaped || '}}';
    this.formatSeparator = formatSeparator || ',';
    this.unescapePrefix = unescapeSuffix ? '' : unescapePrefix || '-';
    this.unescapeSuffix = this.unescapePrefix ? '' : unescapeSuffix || '';
    this.nestingPrefix = nestingPrefix ? regexEscape(nestingPrefix) : nestingPrefixEscaped || regexEscape('$t(');
    this.nestingSuffix = nestingSuffix ? regexEscape(nestingSuffix) : nestingSuffixEscaped || regexEscape(')');
    this.nestingOptionsSeparator = nestingOptionsSeparator || ',';
    this.maxReplaces = maxReplaces || 1000;
    this.alwaysFormat = alwaysFormat !== undefined ? alwaysFormat : false;
    this.resetRegExp();
  }
  reset() {
    if (this.options) this.init(this.options);
  }
  resetRegExp() {
    const getOrResetRegExp = (existingRegExp, pattern) => {
      if (existingRegExp?.source === pattern) {
        existingRegExp.lastIndex = 0;
        return existingRegExp;
      }
      return new RegExp(pattern, 'g');
    };
    this.regexp = getOrResetRegExp(this.regexp, `${this.prefix}(.+?)${this.suffix}`);
    this.regexpUnescape = getOrResetRegExp(this.regexpUnescape, `${this.prefix}${this.unescapePrefix}(.+?)${this.unescapeSuffix}${this.suffix}`);
    this.nestingRegexp = getOrResetRegExp(this.nestingRegexp, `${this.nestingPrefix}((?:[^()"']+|"[^"]*"|'[^']*'|\\((?:[^()]|"[^"]*"|'[^']*')*\\))*?)${this.nestingSuffix}`);
  }
  interpolate(str, data, lng, options) {
    let match;
    let value;
    let replaces;
    const defaultData = this.options && this.options.interpolation && this.options.interpolation.defaultVariables || {};
    const handleFormat = key => {
      if (key.indexOf(this.formatSeparator) < 0) {
        const path = deepFindWithDefaults(data, defaultData, key, this.options.keySeparator, this.options.ignoreJSONStructure);
        return this.alwaysFormat ? this.format(path, undefined, lng, {
          ...options,
          ...data,
          interpolationkey: key
        }) : path;
      }
      const p = key.split(this.formatSeparator);
      const k = p.shift().trim();
      const f = p.join(this.formatSeparator).trim();
      return this.format(deepFindWithDefaults(data, defaultData, k, this.options.keySeparator, this.options.ignoreJSONStructure), f, lng, {
        ...options,
        ...data,
        interpolationkey: k
      });
    };
    this.resetRegExp();
    const missingInterpolationHandler = options?.missingInterpolationHandler || this.options.missingInterpolationHandler;
    const skipOnVariables = options?.interpolation?.skipOnVariables !== undefined ? options.interpolation.skipOnVariables : this.options.interpolation.skipOnVariables;
    const todos = [{
      regex: this.regexpUnescape,
      safeValue: val => regexSafe(val)
    }, {
      regex: this.regexp,
      safeValue: val => this.escapeValue ? regexSafe(this.escape(val)) : regexSafe(val)
    }];
    todos.forEach(todo => {
      replaces = 0;
      while (match = todo.regex.exec(str)) {
        const matchedVar = match[1].trim();
        value = handleFormat(matchedVar);
        if (value === undefined) {
          if (typeof missingInterpolationHandler === 'function') {
            const temp = missingInterpolationHandler(str, match, options);
            value = isString(temp) ? temp : '';
          } else if (options && Object.prototype.hasOwnProperty.call(options, matchedVar)) {
            value = '';
          } else if (skipOnVariables) {
            value = match[0];
            continue;
          } else {
            this.logger.warn(`missed to pass in variable ${matchedVar} for interpolating ${str}`);
            value = '';
          }
        } else if (!isString(value) && !this.useRawValueToEscape) {
          value = makeString(value);
        }
        const safeValue = todo.safeValue(value);
        str = str.replace(match[0], safeValue);
        if (skipOnVariables) {
          todo.regex.lastIndex += value.length;
          todo.regex.lastIndex -= match[0].length;
        } else {
          todo.regex.lastIndex = 0;
        }
        replaces++;
        if (replaces >= this.maxReplaces) {
          break;
        }
      }
    });
    return str;
  }
  nest(str, fc, options = {}) {
    let match;
    let value;
    let clonedOptions;
    const handleHasOptions = (key, inheritedOptions) => {
      const sep = this.nestingOptionsSeparator;
      if (key.indexOf(sep) < 0) return key;
      const c = key.split(new RegExp(`${sep}[ ]*{`));
      let optionsString = `{${c[1]}`;
      key = c[0];
      optionsString = this.interpolate(optionsString, clonedOptions);
      const matchedSingleQuotes = optionsString.match(/'/g);
      const matchedDoubleQuotes = optionsString.match(/"/g);
      if ((matchedSingleQuotes?.length ?? 0) % 2 === 0 && !matchedDoubleQuotes || matchedDoubleQuotes.length % 2 !== 0) {
        optionsString = optionsString.replace(/'/g, '"');
      }
      try {
        clonedOptions = JSON.parse(optionsString);
        if (inheritedOptions) clonedOptions = {
          ...inheritedOptions,
          ...clonedOptions
        };
      } catch (e) {
        this.logger.warn(`failed parsing options string in nesting for key ${key}`, e);
        return `${key}${sep}${optionsString}`;
      }
      if (clonedOptions.defaultValue && clonedOptions.defaultValue.indexOf(this.prefix) > -1) delete clonedOptions.defaultValue;
      return key;
    };
    while (match = this.nestingRegexp.exec(str)) {
      let formatters = [];
      clonedOptions = {
        ...options
      };
      clonedOptions = clonedOptions.replace && !isString(clonedOptions.replace) ? clonedOptions.replace : clonedOptions;
      clonedOptions.applyPostProcessor = false;
      delete clonedOptions.defaultValue;
      const keyEndIndex = /{.*}/.test(match[1]) ? match[1].lastIndexOf('}') + 1 : match[1].indexOf(this.formatSeparator);
      if (keyEndIndex !== -1) {
        formatters = match[1].slice(keyEndIndex).split(this.formatSeparator).map(elem => elem.trim()).filter(Boolean);
        match[1] = match[1].slice(0, keyEndIndex);
      }
      value = fc(handleHasOptions.call(this, match[1].trim(), clonedOptions), clonedOptions);
      if (value && match[0] === str && !isString(value)) return value;
      if (!isString(value)) value = makeString(value);
      if (!value) {
        this.logger.warn(`missed to resolve ${match[1]} for nesting ${str}`);
        value = '';
      }
      if (formatters.length) {
        value = formatters.reduce((v, f) => this.format(v, f, options.lng, {
          ...options,
          interpolationkey: match[1].trim()
        }), value.trim());
      }
      str = str.replace(match[0], value);
      this.regexp.lastIndex = 0;
    }
    return str;
  }
}

const parseFormatStr = formatStr => {
  let formatName = formatStr.toLowerCase().trim();
  const formatOptions = {};
  if (formatStr.indexOf('(') > -1) {
    const p = formatStr.split('(');
    formatName = p[0].toLowerCase().trim();
    const optStr = p[1].substring(0, p[1].length - 1);
    if (formatName === 'currency' && optStr.indexOf(':') < 0) {
      if (!formatOptions.currency) formatOptions.currency = optStr.trim();
    } else if (formatName === 'relativetime' && optStr.indexOf(':') < 0) {
      if (!formatOptions.range) formatOptions.range = optStr.trim();
    } else {
      const opts = optStr.split(';');
      opts.forEach(opt => {
        if (opt) {
          const [key, ...rest] = opt.split(':');
          const val = rest.join(':').trim().replace(/^'+|'+$/g, '');
          const trimmedKey = key.trim();
          if (!formatOptions[trimmedKey]) formatOptions[trimmedKey] = val;
          if (val === 'false') formatOptions[trimmedKey] = false;
          if (val === 'true') formatOptions[trimmedKey] = true;
          if (!isNaN(val)) formatOptions[trimmedKey] = parseInt(val, 10);
        }
      });
    }
  }
  return {
    formatName,
    formatOptions
  };
};
const createCachedFormatter = fn => {
  const cache = {};
  return (v, l, o) => {
    let optForCache = o;
    if (o && o.interpolationkey && o.formatParams && o.formatParams[o.interpolationkey] && o[o.interpolationkey]) {
      optForCache = {
        ...optForCache,
        [o.interpolationkey]: undefined
      };
    }
    const key = l + JSON.stringify(optForCache);
    let frm = cache[key];
    if (!frm) {
      frm = fn(getCleanedCode(l), o);
      cache[key] = frm;
    }
    return frm(v);
  };
};
const createNonCachedFormatter = fn => (v, l, o) => fn(getCleanedCode(l), o)(v);
class Formatter {
  constructor(options = {}) {
    this.logger = baseLogger.create('formatter');
    this.options = options;
    this.init(options);
  }
  init(services, options = {
    interpolation: {}
  }) {
    this.formatSeparator = options.interpolation.formatSeparator || ',';
    const cf = options.cacheInBuiltFormats ? createCachedFormatter : createNonCachedFormatter;
    this.formats = {
      number: cf((lng, opt) => {
        const formatter = new Intl.NumberFormat(lng, {
          ...opt
        });
        return val => formatter.format(val);
      }),
      currency: cf((lng, opt) => {
        const formatter = new Intl.NumberFormat(lng, {
          ...opt,
          style: 'currency'
        });
        return val => formatter.format(val);
      }),
      datetime: cf((lng, opt) => {
        const formatter = new Intl.DateTimeFormat(lng, {
          ...opt
        });
        return val => formatter.format(val);
      }),
      relativetime: cf((lng, opt) => {
        const formatter = new Intl.RelativeTimeFormat(lng, {
          ...opt
        });
        return val => formatter.format(val, opt.range || 'day');
      }),
      list: cf((lng, opt) => {
        const formatter = new Intl.ListFormat(lng, {
          ...opt
        });
        return val => formatter.format(val);
      })
    };
  }
  add(name, fc) {
    this.formats[name.toLowerCase().trim()] = fc;
  }
  addCached(name, fc) {
    this.formats[name.toLowerCase().trim()] = createCachedFormatter(fc);
  }
  format(value, format, lng, options = {}) {
    const formats = format.split(this.formatSeparator);
    if (formats.length > 1 && formats[0].indexOf('(') > 1 && formats[0].indexOf(')') < 0 && formats.find(f => f.indexOf(')') > -1)) {
      const lastIndex = formats.findIndex(f => f.indexOf(')') > -1);
      formats[0] = [formats[0], ...formats.splice(1, lastIndex)].join(this.formatSeparator);
    }
    const result = formats.reduce((mem, f) => {
      const {
        formatName,
        formatOptions
      } = parseFormatStr(f);
      if (this.formats[formatName]) {
        let formatted = mem;
        try {
          const valOptions = options?.formatParams?.[options.interpolationkey] || {};
          const l = valOptions.locale || valOptions.lng || options.locale || options.lng || lng;
          formatted = this.formats[formatName](mem, l, {
            ...formatOptions,
            ...options,
            ...valOptions
          });
        } catch (error) {
          this.logger.warn(error);
        }
        return formatted;
      } else {
        this.logger.warn(`there was no format function for ${formatName}`);
      }
      return mem;
    }, value);
    return result;
  }
}

const removePending = (q, name) => {
  if (q.pending[name] !== undefined) {
    delete q.pending[name];
    q.pendingCount--;
  }
};
class Connector extends EventEmitter {
  constructor(backend, store, services, options = {}) {
    super();
    this.backend = backend;
    this.store = store;
    this.services = services;
    this.languageUtils = services.languageUtils;
    this.options = options;
    this.logger = baseLogger.create('backendConnector');
    this.waitingReads = [];
    this.maxParallelReads = options.maxParallelReads || 10;
    this.readingCalls = 0;
    this.maxRetries = options.maxRetries >= 0 ? options.maxRetries : 5;
    this.retryTimeout = options.retryTimeout >= 1 ? options.retryTimeout : 350;
    this.state = {};
    this.queue = [];
    this.backend?.init?.(services, options.backend, options);
  }
  queueLoad(languages, namespaces, options, callback) {
    const toLoad = {};
    const pending = {};
    const toLoadLanguages = {};
    const toLoadNamespaces = {};
    languages.forEach(lng => {
      let hasAllNamespaces = true;
      namespaces.forEach(ns => {
        const name = `${lng}|${ns}`;
        if (!options.reload && this.store.hasResourceBundle(lng, ns)) {
          this.state[name] = 2;
        } else if (this.state[name] < 0) ; else if (this.state[name] === 1) {
          if (pending[name] === undefined) pending[name] = true;
        } else {
          this.state[name] = 1;
          hasAllNamespaces = false;
          if (pending[name] === undefined) pending[name] = true;
          if (toLoad[name] === undefined) toLoad[name] = true;
          if (toLoadNamespaces[ns] === undefined) toLoadNamespaces[ns] = true;
        }
      });
      if (!hasAllNamespaces) toLoadLanguages[lng] = true;
    });
    if (Object.keys(toLoad).length || Object.keys(pending).length) {
      this.queue.push({
        pending,
        pendingCount: Object.keys(pending).length,
        loaded: {},
        errors: [],
        callback
      });
    }
    return {
      toLoad: Object.keys(toLoad),
      pending: Object.keys(pending),
      toLoadLanguages: Object.keys(toLoadLanguages),
      toLoadNamespaces: Object.keys(toLoadNamespaces)
    };
  }
  loaded(name, err, data) {
    const s = name.split('|');
    const lng = s[0];
    const ns = s[1];
    if (err) this.emit('failedLoading', lng, ns, err);
    if (!err && data) {
      this.store.addResourceBundle(lng, ns, data, undefined, undefined, {
        skipCopy: true
      });
    }
    this.state[name] = err ? -1 : 2;
    if (err && data) this.state[name] = 0;
    const loaded = {};
    this.queue.forEach(q => {
      pushPath(q.loaded, [lng], ns);
      removePending(q, name);
      if (err) q.errors.push(err);
      if (q.pendingCount === 0 && !q.done) {
        Object.keys(q.loaded).forEach(l => {
          if (!loaded[l]) loaded[l] = {};
          const loadedKeys = q.loaded[l];
          if (loadedKeys.length) {
            loadedKeys.forEach(n => {
              if (loaded[l][n] === undefined) loaded[l][n] = true;
            });
          }
        });
        q.done = true;
        if (q.errors.length) {
          q.callback(q.errors);
        } else {
          q.callback();
        }
      }
    });
    this.emit('loaded', loaded);
    this.queue = this.queue.filter(q => !q.done);
  }
  read(lng, ns, fcName, tried = 0, wait = this.retryTimeout, callback) {
    if (!lng.length) return callback(null, {});
    if (this.readingCalls >= this.maxParallelReads) {
      this.waitingReads.push({
        lng,
        ns,
        fcName,
        tried,
        wait,
        callback
      });
      return;
    }
    this.readingCalls++;
    const resolver = (err, data) => {
      this.readingCalls--;
      if (this.waitingReads.length > 0) {
        const next = this.waitingReads.shift();
        this.read(next.lng, next.ns, next.fcName, next.tried, next.wait, next.callback);
      }
      if (err && data && tried < this.maxRetries) {
        setTimeout(() => {
          this.read.call(this, lng, ns, fcName, tried + 1, wait * 2, callback);
        }, wait);
        return;
      }
      callback(err, data);
    };
    const fc = this.backend[fcName].bind(this.backend);
    if (fc.length === 2) {
      try {
        const r = fc(lng, ns);
        if (r && typeof r.then === 'function') {
          r.then(data => resolver(null, data)).catch(resolver);
        } else {
          resolver(null, r);
        }
      } catch (err) {
        resolver(err);
      }
      return;
    }
    return fc(lng, ns, resolver);
  }
  prepareLoading(languages, namespaces, options = {}, callback) {
    if (!this.backend) {
      this.logger.warn('No backend was added via i18next.use. Will not load resources.');
      return callback && callback();
    }
    if (isString(languages)) languages = this.languageUtils.toResolveHierarchy(languages);
    if (isString(namespaces)) namespaces = [namespaces];
    const toLoad = this.queueLoad(languages, namespaces, options, callback);
    if (!toLoad.toLoad.length) {
      if (!toLoad.pending.length) callback();
      return null;
    }
    toLoad.toLoad.forEach(name => {
      this.loadOne(name);
    });
  }
  load(languages, namespaces, callback) {
    this.prepareLoading(languages, namespaces, {}, callback);
  }
  reload(languages, namespaces, callback) {
    this.prepareLoading(languages, namespaces, {
      reload: true
    }, callback);
  }
  loadOne(name, prefix = '') {
    const s = name.split('|');
    const lng = s[0];
    const ns = s[1];
    this.read(lng, ns, 'read', undefined, undefined, (err, data) => {
      if (err) this.logger.warn(`${prefix}loading namespace ${ns} for language ${lng} failed`, err);
      if (!err && data) this.logger.log(`${prefix}loaded namespace ${ns} for language ${lng}`, data);
      this.loaded(name, err, data);
    });
  }
  saveMissing(languages, namespace, key, fallbackValue, isUpdate, options = {}, clb = () => {}) {
    if (this.services?.utils?.hasLoadedNamespace && !this.services?.utils?.hasLoadedNamespace(namespace)) {
      this.logger.warn(`did not save key "${key}" as the namespace "${namespace}" was not yet loaded`, 'This means something IS WRONG in your setup. You access the t function before i18next.init / i18next.loadNamespace / i18next.changeLanguage was done. Wait for the callback or Promise to resolve before accessing it!!!');
      return;
    }
    if (key === undefined || key === null || key === '') return;
    if (this.backend?.create) {
      const opts = {
        ...options,
        isUpdate
      };
      const fc = this.backend.create.bind(this.backend);
      if (fc.length < 6) {
        try {
          let r;
          if (fc.length === 5) {
            r = fc(languages, namespace, key, fallbackValue, opts);
          } else {
            r = fc(languages, namespace, key, fallbackValue);
          }
          if (r && typeof r.then === 'function') {
            r.then(data => clb(null, data)).catch(clb);
          } else {
            clb(null, r);
          }
        } catch (err) {
          clb(err);
        }
      } else {
        fc(languages, namespace, key, fallbackValue, clb, opts);
      }
    }
    if (!languages || !languages[0]) return;
    this.store.addResource(languages[0], namespace, key, fallbackValue);
  }
}

const get = () => ({
  debug: false,
  initAsync: true,
  ns: ['translation'],
  defaultNS: ['translation'],
  fallbackLng: ['dev'],
  fallbackNS: false,
  supportedLngs: false,
  nonExplicitSupportedLngs: false,
  load: 'all',
  preload: false,
  simplifyPluralSuffix: true,
  keySeparator: '.',
  nsSeparator: ':',
  pluralSeparator: '_',
  contextSeparator: '_',
  partialBundledLanguages: false,
  saveMissing: false,
  updateMissing: false,
  saveMissingTo: 'fallback',
  saveMissingPlurals: true,
  missingKeyHandler: false,
  missingInterpolationHandler: false,
  postProcess: false,
  postProcessPassResolved: false,
  returnNull: false,
  returnEmptyString: true,
  returnObjects: false,
  joinArrays: false,
  returnedObjectHandler: false,
  parseMissingKeyHandler: false,
  appendNamespaceToMissingKey: false,
  appendNamespaceToCIMode: false,
  overloadTranslationOptionHandler: args => {
    let ret = {};
    if (typeof args[1] === 'object') ret = args[1];
    if (isString(args[1])) ret.defaultValue = args[1];
    if (isString(args[2])) ret.tDescription = args[2];
    if (typeof args[2] === 'object' || typeof args[3] === 'object') {
      const options = args[3] || args[2];
      Object.keys(options).forEach(key => {
        ret[key] = options[key];
      });
    }
    return ret;
  },
  interpolation: {
    escapeValue: true,
    format: value => value,
    prefix: '{{',
    suffix: '}}',
    formatSeparator: ',',
    unescapePrefix: '-',
    nestingPrefix: '$t(',
    nestingSuffix: ')',
    nestingOptionsSeparator: ',',
    maxReplaces: 1000,
    skipOnVariables: true
  },
  cacheInBuiltFormats: true
});
const transformOptions = options => {
  if (isString(options.ns)) options.ns = [options.ns];
  if (isString(options.fallbackLng)) options.fallbackLng = [options.fallbackLng];
  if (isString(options.fallbackNS)) options.fallbackNS = [options.fallbackNS];
  if (options.supportedLngs?.indexOf?.('cimode') < 0) {
    options.supportedLngs = options.supportedLngs.concat(['cimode']);
  }
  if (typeof options.initImmediate === 'boolean') options.initAsync = options.initImmediate;
  return options;
};

const noop = () => {};
const bindMemberFunctions = inst => {
  const mems = Object.getOwnPropertyNames(Object.getPrototypeOf(inst));
  mems.forEach(mem => {
    if (typeof inst[mem] === 'function') {
      inst[mem] = inst[mem].bind(inst);
    }
  });
};
class I18n extends EventEmitter {
  constructor(options = {}, callback) {
    super();
    this.options = transformOptions(options);
    this.services = {};
    this.logger = baseLogger;
    this.modules = {
      external: []
    };
    bindMemberFunctions(this);
    if (callback && !this.isInitialized && !options.isClone) {
      if (!this.options.initAsync) {
        this.init(options, callback);
        return this;
      }
      setTimeout(() => {
        this.init(options, callback);
      }, 0);
    }
  }
  init(options = {}, callback) {
    this.isInitializing = true;
    if (typeof options === 'function') {
      callback = options;
      options = {};
    }
    if (options.defaultNS == null && options.ns) {
      if (isString(options.ns)) {
        options.defaultNS = options.ns;
      } else if (options.ns.indexOf('translation') < 0) {
        options.defaultNS = options.ns[0];
      }
    }
    const defOpts = get();
    this.options = {
      ...defOpts,
      ...this.options,
      ...transformOptions(options)
    };
    this.options.interpolation = {
      ...defOpts.interpolation,
      ...this.options.interpolation
    };
    if (options.keySeparator !== undefined) {
      this.options.userDefinedKeySeparator = options.keySeparator;
    }
    if (options.nsSeparator !== undefined) {
      this.options.userDefinedNsSeparator = options.nsSeparator;
    }
    const createClassOnDemand = ClassOrObject => {
      if (!ClassOrObject) return null;
      if (typeof ClassOrObject === 'function') return new ClassOrObject();
      return ClassOrObject;
    };
    if (!this.options.isClone) {
      if (this.modules.logger) {
        baseLogger.init(createClassOnDemand(this.modules.logger), this.options);
      } else {
        baseLogger.init(null, this.options);
      }
      let formatter;
      if (this.modules.formatter) {
        formatter = this.modules.formatter;
      } else {
        formatter = Formatter;
      }
      const lu = new LanguageUtil(this.options);
      this.store = new ResourceStore(this.options.resources, this.options);
      const s = this.services;
      s.logger = baseLogger;
      s.resourceStore = this.store;
      s.languageUtils = lu;
      s.pluralResolver = new PluralResolver(lu, {
        prepend: this.options.pluralSeparator,
        simplifyPluralSuffix: this.options.simplifyPluralSuffix
      });
      const usingLegacyFormatFunction = this.options.interpolation.format && this.options.interpolation.format !== defOpts.interpolation.format;
      if (usingLegacyFormatFunction) {
        this.logger.deprecate(`init: you are still using the legacy format function, please use the new approach: https://www.i18next.com/translation-function/formatting`);
      }
      if (formatter && (!this.options.interpolation.format || this.options.interpolation.format === defOpts.interpolation.format)) {
        s.formatter = createClassOnDemand(formatter);
        if (s.formatter.init) s.formatter.init(s, this.options);
        this.options.interpolation.format = s.formatter.format.bind(s.formatter);
      }
      s.interpolator = new Interpolator(this.options);
      s.utils = {
        hasLoadedNamespace: this.hasLoadedNamespace.bind(this)
      };
      s.backendConnector = new Connector(createClassOnDemand(this.modules.backend), s.resourceStore, s, this.options);
      s.backendConnector.on('*', (event, ...args) => {
        this.emit(event, ...args);
      });
      if (this.modules.languageDetector) {
        s.languageDetector = createClassOnDemand(this.modules.languageDetector);
        if (s.languageDetector.init) s.languageDetector.init(s, this.options.detection, this.options);
      }
      if (this.modules.i18nFormat) {
        s.i18nFormat = createClassOnDemand(this.modules.i18nFormat);
        if (s.i18nFormat.init) s.i18nFormat.init(this);
      }
      this.translator = new Translator(this.services, this.options);
      this.translator.on('*', (event, ...args) => {
        this.emit(event, ...args);
      });
      this.modules.external.forEach(m => {
        if (m.init) m.init(this);
      });
    }
    this.format = this.options.interpolation.format;
    if (!callback) callback = noop;
    if (this.options.fallbackLng && !this.services.languageDetector && !this.options.lng) {
      const codes = this.services.languageUtils.getFallbackCodes(this.options.fallbackLng);
      if (codes.length > 0 && codes[0] !== 'dev') this.options.lng = codes[0];
    }
    if (!this.services.languageDetector && !this.options.lng) {
      this.logger.warn('init: no languageDetector is used and no lng is defined');
    }
    const storeApi = ['getResource', 'hasResourceBundle', 'getResourceBundle', 'getDataByLanguage'];
    storeApi.forEach(fcName => {
      this[fcName] = (...args) => this.store[fcName](...args);
    });
    const storeApiChained = ['addResource', 'addResources', 'addResourceBundle', 'removeResourceBundle'];
    storeApiChained.forEach(fcName => {
      this[fcName] = (...args) => {
        this.store[fcName](...args);
        return this;
      };
    });
    const deferred = defer();
    const load = () => {
      const finish = (err, t) => {
        this.isInitializing = false;
        if (this.isInitialized && !this.initializedStoreOnce) this.logger.warn('init: i18next is already initialized. You should call init just once!');
        this.isInitialized = true;
        if (!this.options.isClone) this.logger.log('initialized', this.options);
        this.emit('initialized', this.options);
        deferred.resolve(t);
        callback(err, t);
      };
      if (this.languages && !this.isInitialized) return finish(null, this.t.bind(this));
      this.changeLanguage(this.options.lng, finish);
    };
    if (this.options.resources || !this.options.initAsync) {
      load();
    } else {
      setTimeout(load, 0);
    }
    return deferred;
  }
  loadResources(language, callback = noop) {
    let usedCallback = callback;
    const usedLng = isString(language) ? language : this.language;
    if (typeof language === 'function') usedCallback = language;
    if (!this.options.resources || this.options.partialBundledLanguages) {
      if (usedLng?.toLowerCase() === 'cimode' && (!this.options.preload || this.options.preload.length === 0)) return usedCallback();
      const toLoad = [];
      const append = lng => {
        if (!lng) return;
        if (lng === 'cimode') return;
        const lngs = this.services.languageUtils.toResolveHierarchy(lng);
        lngs.forEach(l => {
          if (l === 'cimode') return;
          if (toLoad.indexOf(l) < 0) toLoad.push(l);
        });
      };
      if (!usedLng) {
        const fallbacks = this.services.languageUtils.getFallbackCodes(this.options.fallbackLng);
        fallbacks.forEach(l => append(l));
      } else {
        append(usedLng);
      }
      this.options.preload?.forEach?.(l => append(l));
      this.services.backendConnector.load(toLoad, this.options.ns, e => {
        if (!e && !this.resolvedLanguage && this.language) this.setResolvedLanguage(this.language);
        usedCallback(e);
      });
    } else {
      usedCallback(null);
    }
  }
  reloadResources(lngs, ns, callback) {
    const deferred = defer();
    if (typeof lngs === 'function') {
      callback = lngs;
      lngs = undefined;
    }
    if (typeof ns === 'function') {
      callback = ns;
      ns = undefined;
    }
    if (!lngs) lngs = this.languages;
    if (!ns) ns = this.options.ns;
    if (!callback) callback = noop;
    this.services.backendConnector.reload(lngs, ns, err => {
      deferred.resolve();
      callback(err);
    });
    return deferred;
  }
  use(module) {
    if (!module) throw new Error('You are passing an undefined module! Please check the object you are passing to i18next.use()');
    if (!module.type) throw new Error('You are passing a wrong module! Please check the object you are passing to i18next.use()');
    if (module.type === 'backend') {
      this.modules.backend = module;
    }
    if (module.type === 'logger' || module.log && module.warn && module.error) {
      this.modules.logger = module;
    }
    if (module.type === 'languageDetector') {
      this.modules.languageDetector = module;
    }
    if (module.type === 'i18nFormat') {
      this.modules.i18nFormat = module;
    }
    if (module.type === 'postProcessor') {
      postProcessor.addPostProcessor(module);
    }
    if (module.type === 'formatter') {
      this.modules.formatter = module;
    }
    if (module.type === '3rdParty') {
      this.modules.external.push(module);
    }
    return this;
  }
  setResolvedLanguage(l) {
    if (!l || !this.languages) return;
    if (['cimode', 'dev'].indexOf(l) > -1) return;
    for (let li = 0; li < this.languages.length; li++) {
      const lngInLngs = this.languages[li];
      if (['cimode', 'dev'].indexOf(lngInLngs) > -1) continue;
      if (this.store.hasLanguageSomeTranslations(lngInLngs)) {
        this.resolvedLanguage = lngInLngs;
        break;
      }
    }
    if (!this.resolvedLanguage && this.languages.indexOf(l) < 0 && this.store.hasLanguageSomeTranslations(l)) {
      this.resolvedLanguage = l;
      this.languages.unshift(l);
    }
  }
  changeLanguage(lng, callback) {
    this.isLanguageChangingTo = lng;
    const deferred = defer();
    this.emit('languageChanging', lng);
    const setLngProps = l => {
      this.language = l;
      this.languages = this.services.languageUtils.toResolveHierarchy(l);
      this.resolvedLanguage = undefined;
      this.setResolvedLanguage(l);
    };
    const done = (err, l) => {
      if (l) {
        if (this.isLanguageChangingTo === lng) {
          setLngProps(l);
          this.translator.changeLanguage(l);
          this.isLanguageChangingTo = undefined;
          this.emit('languageChanged', l);
          this.logger.log('languageChanged', l);
        }
      } else {
        this.isLanguageChangingTo = undefined;
      }
      deferred.resolve((...args) => this.t(...args));
      if (callback) callback(err, (...args) => this.t(...args));
    };
    const setLng = lngs => {
      if (!lng && !lngs && this.services.languageDetector) lngs = [];
      const fl = isString(lngs) ? lngs : lngs && lngs[0];
      const l = this.store.hasLanguageSomeTranslations(fl) ? fl : this.services.languageUtils.getBestMatchFromCodes(isString(lngs) ? [lngs] : lngs);
      if (l) {
        if (!this.language) {
          setLngProps(l);
        }
        if (!this.translator.language) this.translator.changeLanguage(l);
        this.services.languageDetector?.cacheUserLanguage?.(l);
      }
      this.loadResources(l, err => {
        done(err, l);
      });
    };
    if (!lng && this.services.languageDetector && !this.services.languageDetector.async) {
      setLng(this.services.languageDetector.detect());
    } else if (!lng && this.services.languageDetector && this.services.languageDetector.async) {
      if (this.services.languageDetector.detect.length === 0) {
        this.services.languageDetector.detect().then(setLng);
      } else {
        this.services.languageDetector.detect(setLng);
      }
    } else {
      setLng(lng);
    }
    return deferred;
  }
  getFixedT(lng, ns, keyPrefix) {
    const fixedT = (key, opts, ...rest) => {
      let o;
      if (typeof opts !== 'object') {
        o = this.options.overloadTranslationOptionHandler([key, opts].concat(rest));
      } else {
        o = {
          ...opts
        };
      }
      o.lng = o.lng || fixedT.lng;
      o.lngs = o.lngs || fixedT.lngs;
      o.ns = o.ns || fixedT.ns;
      if (o.keyPrefix !== '') o.keyPrefix = o.keyPrefix || keyPrefix || fixedT.keyPrefix;
      const keySeparator = this.options.keySeparator || '.';
      let resultKey;
      if (o.keyPrefix && Array.isArray(key)) {
        resultKey = key.map(k => {
          if (typeof k === 'function') k = keysFromSelector(k, {
            ...this.options,
            ...opts
          });
          return `${o.keyPrefix}${keySeparator}${k}`;
        });
      } else {
        if (typeof key === 'function') key = keysFromSelector(key, {
          ...this.options,
          ...opts
        });
        resultKey = o.keyPrefix ? `${o.keyPrefix}${keySeparator}${key}` : key;
      }
      return this.t(resultKey, o);
    };
    if (isString(lng)) {
      fixedT.lng = lng;
    } else {
      fixedT.lngs = lng;
    }
    fixedT.ns = ns;
    fixedT.keyPrefix = keyPrefix;
    return fixedT;
  }
  t(...args) {
    return this.translator?.translate(...args);
  }
  exists(...args) {
    return this.translator?.exists(...args);
  }
  setDefaultNamespace(ns) {
    this.options.defaultNS = ns;
  }
  hasLoadedNamespace(ns, options = {}) {
    if (!this.isInitialized) {
      this.logger.warn('hasLoadedNamespace: i18next was not initialized', this.languages);
      return false;
    }
    if (!this.languages || !this.languages.length) {
      this.logger.warn('hasLoadedNamespace: i18n.languages were undefined or empty', this.languages);
      return false;
    }
    const lng = options.lng || this.resolvedLanguage || this.languages[0];
    const fallbackLng = this.options ? this.options.fallbackLng : false;
    const lastLng = this.languages[this.languages.length - 1];
    if (lng.toLowerCase() === 'cimode') return true;
    const loadNotPending = (l, n) => {
      const loadState = this.services.backendConnector.state[`${l}|${n}`];
      return loadState === -1 || loadState === 0 || loadState === 2;
    };
    if (options.precheck) {
      const preResult = options.precheck(this, loadNotPending);
      if (preResult !== undefined) return preResult;
    }
    if (this.hasResourceBundle(lng, ns)) return true;
    if (!this.services.backendConnector.backend || this.options.resources && !this.options.partialBundledLanguages) return true;
    if (loadNotPending(lng, ns) && (!fallbackLng || loadNotPending(lastLng, ns))) return true;
    return false;
  }
  loadNamespaces(ns, callback) {
    const deferred = defer();
    if (!this.options.ns) {
      if (callback) callback();
      return Promise.resolve();
    }
    if (isString(ns)) ns = [ns];
    ns.forEach(n => {
      if (this.options.ns.indexOf(n) < 0) this.options.ns.push(n);
    });
    this.loadResources(err => {
      deferred.resolve();
      if (callback) callback(err);
    });
    return deferred;
  }
  loadLanguages(lngs, callback) {
    const deferred = defer();
    if (isString(lngs)) lngs = [lngs];
    const preloaded = this.options.preload || [];
    const newLngs = lngs.filter(lng => preloaded.indexOf(lng) < 0 && this.services.languageUtils.isSupportedCode(lng));
    if (!newLngs.length) {
      if (callback) callback();
      return Promise.resolve();
    }
    this.options.preload = preloaded.concat(newLngs);
    this.loadResources(err => {
      deferred.resolve();
      if (callback) callback(err);
    });
    return deferred;
  }
  dir(lng) {
    if (!lng) lng = this.resolvedLanguage || (this.languages?.length > 0 ? this.languages[0] : this.language);
    if (!lng) return 'rtl';
    try {
      const l = new Intl.Locale(lng);
      if (l && l.getTextInfo) {
        const ti = l.getTextInfo();
        if (ti && ti.direction) return ti.direction;
      }
    } catch (e) {}
    const rtlLngs = ['ar', 'shu', 'sqr', 'ssh', 'xaa', 'yhd', 'yud', 'aao', 'abh', 'abv', 'acm', 'acq', 'acw', 'acx', 'acy', 'adf', 'ads', 'aeb', 'aec', 'afb', 'ajp', 'apc', 'apd', 'arb', 'arq', 'ars', 'ary', 'arz', 'auz', 'avl', 'ayh', 'ayl', 'ayn', 'ayp', 'bbz', 'pga', 'he', 'iw', 'ps', 'pbt', 'pbu', 'pst', 'prp', 'prd', 'ug', 'ur', 'ydd', 'yds', 'yih', 'ji', 'yi', 'hbo', 'men', 'xmn', 'fa', 'jpr', 'peo', 'pes', 'prs', 'dv', 'sam', 'ckb'];
    const languageUtils = this.services?.languageUtils || new LanguageUtil(get());
    if (lng.toLowerCase().indexOf('-latn') > 1) return 'ltr';
    return rtlLngs.indexOf(languageUtils.getLanguagePartFromCode(lng)) > -1 || lng.toLowerCase().indexOf('-arab') > 1 ? 'rtl' : 'ltr';
  }
  static createInstance(options = {}, callback) {
    return new I18n(options, callback);
  }
  cloneInstance(options = {}, callback = noop) {
    const forkResourceStore = options.forkResourceStore;
    if (forkResourceStore) delete options.forkResourceStore;
    const mergedOptions = {
      ...this.options,
      ...options,
      ...{
        isClone: true
      }
    };
    const clone = new I18n(mergedOptions);
    if (options.debug !== undefined || options.prefix !== undefined) {
      clone.logger = clone.logger.clone(options);
    }
    const membersToCopy = ['store', 'services', 'language'];
    membersToCopy.forEach(m => {
      clone[m] = this[m];
    });
    clone.services = {
      ...this.services
    };
    clone.services.utils = {
      hasLoadedNamespace: clone.hasLoadedNamespace.bind(clone)
    };
    if (forkResourceStore) {
      const clonedData = Object.keys(this.store.data).reduce((prev, l) => {
        prev[l] = {
          ...this.store.data[l]
        };
        prev[l] = Object.keys(prev[l]).reduce((acc, n) => {
          acc[n] = {
            ...prev[l][n]
          };
          return acc;
        }, prev[l]);
        return prev;
      }, {});
      clone.store = new ResourceStore(clonedData, mergedOptions);
      clone.services.resourceStore = clone.store;
    }
    clone.translator = new Translator(clone.services, mergedOptions);
    clone.translator.on('*', (event, ...args) => {
      clone.emit(event, ...args);
    });
    clone.init(mergedOptions, callback);
    clone.translator.options = mergedOptions;
    clone.translator.backendConnector.services.utils = {
      hasLoadedNamespace: clone.hasLoadedNamespace.bind(clone)
    };
    return clone;
  }
  toJSON() {
    return {
      options: this.options,
      store: this.store,
      language: this.language,
      languages: this.languages,
      resolvedLanguage: this.resolvedLanguage
    };
  }
}
const instance = I18n.createInstance();
instance.createInstance = I18n.createInstance;

const createInstance = instance.createInstance;
const dir = instance.dir;
const init = instance.init;
const loadResources = instance.loadResources;
const reloadResources = instance.reloadResources;
const use = instance.use;
const changeLanguage = instance.changeLanguage;
const getFixedT = instance.getFixedT;
const t = instance.t;
const exists = instance.exists;
const setDefaultNamespace = instance.setDefaultNamespace;
const hasLoadedNamespace = instance.hasLoadedNamespace;
const loadNamespaces = instance.loadNamespaces;
const loadLanguages = instance.loadLanguages;




/***/ }),

/***/ "./node_modules/react-i18next/dist/es/I18nextProvider.js":
/*!***************************************************************!*\
  !*** ./node_modules/react-i18next/dist/es/I18nextProvider.js ***!
  \***************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   I18nextProvider: () => (/* binding */ I18nextProvider)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var _context_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./context.js */ "./node_modules/react-i18next/dist/es/context.js");


function I18nextProvider({
  i18n,
  defaultNS,
  children
}) {
  const value = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => ({
    i18n,
    defaultNS
  }), [i18n, defaultNS]);
  return (0,react__WEBPACK_IMPORTED_MODULE_0__.createElement)(_context_js__WEBPACK_IMPORTED_MODULE_1__.I18nContext.Provider, {
    value
  }, children);
}

/***/ }),

/***/ "./node_modules/react-i18next/dist/es/Trans.js":
/*!*****************************************************!*\
  !*** ./node_modules/react-i18next/dist/es/Trans.js ***!
  \*****************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Trans: () => (/* binding */ Trans),
/* harmony export */   nodesToString: () => (/* reexport safe */ _TransWithoutContext_js__WEBPACK_IMPORTED_MODULE_1__.nodesToString)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var _TransWithoutContext_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./TransWithoutContext.js */ "./node_modules/react-i18next/dist/es/TransWithoutContext.js");
/* harmony import */ var _context_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./context.js */ "./node_modules/react-i18next/dist/es/context.js");




function Trans({
  children,
  count,
  parent,
  i18nKey,
  context,
  tOptions = {},
  values,
  defaults,
  components,
  ns,
  i18n: i18nFromProps,
  t: tFromProps,
  shouldUnescape,
  ...additionalProps
}) {
  const {
    i18n: i18nFromContext,
    defaultNS: defaultNSFromContext
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(_context_js__WEBPACK_IMPORTED_MODULE_2__.I18nContext) || {};
  const i18n = i18nFromProps || i18nFromContext || (0,_context_js__WEBPACK_IMPORTED_MODULE_2__.getI18n)();
  const t = tFromProps || i18n?.t.bind(i18n);
  return (0,_TransWithoutContext_js__WEBPACK_IMPORTED_MODULE_1__.Trans)({
    children,
    count,
    parent,
    i18nKey,
    context,
    tOptions,
    values,
    defaults,
    components,
    ns: ns || t?.ns || defaultNSFromContext || i18n?.options?.defaultNS,
    i18n,
    t: tFromProps,
    shouldUnescape,
    ...additionalProps
  });
}

/***/ }),

/***/ "./node_modules/react-i18next/dist/es/TransWithoutContext.js":
/*!*******************************************************************!*\
  !*** ./node_modules/react-i18next/dist/es/TransWithoutContext.js ***!
  \*******************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Trans: () => (/* binding */ Trans),
/* harmony export */   nodesToString: () => (/* binding */ nodesToString)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var html_parse_stringify__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! html-parse-stringify */ "./node_modules/html-parse-stringify/dist/html-parse-stringify.module.js");
/* harmony import */ var _utils_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./utils.js */ "./node_modules/react-i18next/dist/es/utils.js");
/* harmony import */ var _defaults_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./defaults.js */ "./node_modules/react-i18next/dist/es/defaults.js");
/* harmony import */ var _i18nInstance_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./i18nInstance.js */ "./node_modules/react-i18next/dist/es/i18nInstance.js");





const hasChildren = (node, checkLength) => {
  if (!node) return false;
  const base = node.props?.children ?? node.children;
  if (checkLength) return base.length > 0;
  return !!base;
};
const getChildren = node => {
  if (!node) return [];
  const children = node.props?.children ?? node.children;
  return node.props?.i18nIsDynamicList ? getAsArray(children) : children;
};
const hasValidReactChildren = children => Array.isArray(children) && children.every(react__WEBPACK_IMPORTED_MODULE_0__.isValidElement);
const getAsArray = data => Array.isArray(data) ? data : [data];
const mergeProps = (source, target) => {
  const newTarget = {
    ...target
  };
  newTarget.props = Object.assign(source.props, target.props);
  return newTarget;
};
const nodesToString = (children, i18nOptions, i18n, i18nKey) => {
  if (!children) return '';
  let stringNode = '';
  const childrenArray = getAsArray(children);
  const keepArray = i18nOptions?.transSupportBasicHtmlNodes ? i18nOptions.transKeepBasicHtmlNodesFor ?? [] : [];
  childrenArray.forEach((child, childIndex) => {
    if ((0,_utils_js__WEBPACK_IMPORTED_MODULE_2__.isString)(child)) {
      stringNode += `${child}`;
      return;
    }
    if ((0,react__WEBPACK_IMPORTED_MODULE_0__.isValidElement)(child)) {
      const {
        props,
        type
      } = child;
      const childPropsCount = Object.keys(props).length;
      const shouldKeepChild = keepArray.indexOf(type) > -1;
      const childChildren = props.children;
      if (!childChildren && shouldKeepChild && !childPropsCount) {
        stringNode += `<${type}/>`;
        return;
      }
      if (!childChildren && (!shouldKeepChild || childPropsCount) || props.i18nIsDynamicList) {
        stringNode += `<${childIndex}></${childIndex}>`;
        return;
      }
      if (shouldKeepChild && childPropsCount === 1 && (0,_utils_js__WEBPACK_IMPORTED_MODULE_2__.isString)(childChildren)) {
        stringNode += `<${type}>${childChildren}</${type}>`;
        return;
      }
      const content = nodesToString(childChildren, i18nOptions, i18n, i18nKey);
      stringNode += `<${childIndex}>${content}</${childIndex}>`;
      return;
    }
    if (child === null) {
      (0,_utils_js__WEBPACK_IMPORTED_MODULE_2__.warn)(i18n, 'TRANS_NULL_VALUE', `Passed in a null value as child`, {
        i18nKey
      });
      return;
    }
    if ((0,_utils_js__WEBPACK_IMPORTED_MODULE_2__.isObject)(child)) {
      const {
        format,
        ...clone
      } = child;
      const keys = Object.keys(clone);
      if (keys.length === 1) {
        const value = format ? `${keys[0]}, ${format}` : keys[0];
        stringNode += `{{${value}}}`;
        return;
      }
      (0,_utils_js__WEBPACK_IMPORTED_MODULE_2__.warn)(i18n, 'TRANS_INVALID_OBJ', `Invalid child - Object should only have keys {{ value, format }} (format is optional).`, {
        i18nKey,
        child
      });
      return;
    }
    (0,_utils_js__WEBPACK_IMPORTED_MODULE_2__.warn)(i18n, 'TRANS_INVALID_VAR', `Passed in a variable like {number} - pass variables for interpolation as full objects like {{number}}.`, {
      i18nKey,
      child
    });
  });
  return stringNode;
};
const renderNodes = (children, knownComponentsMap, targetString, i18n, i18nOptions, combinedTOpts, shouldUnescape) => {
  if (targetString === '') return [];
  const keepArray = i18nOptions.transKeepBasicHtmlNodesFor || [];
  const emptyChildrenButNeedsHandling = targetString && new RegExp(keepArray.map(keep => `<${keep}`).join('|')).test(targetString);
  if (!children && !knownComponentsMap && !emptyChildrenButNeedsHandling && !shouldUnescape) return [targetString];
  const data = knownComponentsMap ?? {};
  const getData = childs => {
    const childrenArray = getAsArray(childs);
    childrenArray.forEach(child => {
      if ((0,_utils_js__WEBPACK_IMPORTED_MODULE_2__.isString)(child)) return;
      if (hasChildren(child)) getData(getChildren(child));else if ((0,_utils_js__WEBPACK_IMPORTED_MODULE_2__.isObject)(child) && !(0,react__WEBPACK_IMPORTED_MODULE_0__.isValidElement)(child)) Object.assign(data, child);
    });
  };
  getData(children);
  const ast = html_parse_stringify__WEBPACK_IMPORTED_MODULE_1__["default"].parse(`<0>${targetString}</0>`);
  const opts = {
    ...data,
    ...combinedTOpts
  };
  const renderInner = (child, node, rootReactNode) => {
    const childs = getChildren(child);
    const mappedChildren = mapAST(childs, node.children, rootReactNode);
    return hasValidReactChildren(childs) && mappedChildren.length === 0 || child.props?.i18nIsDynamicList ? childs : mappedChildren;
  };
  const pushTranslatedJSX = (child, inner, mem, i, isVoid) => {
    if (child.dummy) {
      child.children = inner;
      mem.push((0,react__WEBPACK_IMPORTED_MODULE_0__.cloneElement)(child, {
        key: i
      }, isVoid ? undefined : inner));
    } else {
      mem.push(...react__WEBPACK_IMPORTED_MODULE_0__.Children.map([child], c => {
        const props = {
          ...c.props
        };
        delete props.i18nIsDynamicList;
        return (0,react__WEBPACK_IMPORTED_MODULE_0__.createElement)(c.type, {
          ...props,
          key: i,
          ref: c.props.ref ?? c.ref
        }, isVoid ? null : inner);
      }));
    }
  };
  const mapAST = (reactNode, astNode, rootReactNode) => {
    const reactNodes = getAsArray(reactNode);
    const astNodes = getAsArray(astNode);
    return astNodes.reduce((mem, node, i) => {
      const translationContent = node.children?.[0]?.content && i18n.services.interpolator.interpolate(node.children[0].content, opts, i18n.language);
      if (node.type === 'tag') {
        let tmp = reactNodes[parseInt(node.name, 10)];
        if (!tmp && knownComponentsMap) tmp = knownComponentsMap[node.name];
        if (rootReactNode.length === 1 && !tmp) tmp = rootReactNode[0][node.name];
        if (!tmp) tmp = {};
        const child = Object.keys(node.attrs).length !== 0 ? mergeProps({
          props: node.attrs
        }, tmp) : tmp;
        const isElement = (0,react__WEBPACK_IMPORTED_MODULE_0__.isValidElement)(child);
        const isValidTranslationWithChildren = isElement && hasChildren(node, true) && !node.voidElement;
        const isEmptyTransWithHTML = emptyChildrenButNeedsHandling && (0,_utils_js__WEBPACK_IMPORTED_MODULE_2__.isObject)(child) && child.dummy && !isElement;
        const isKnownComponent = (0,_utils_js__WEBPACK_IMPORTED_MODULE_2__.isObject)(knownComponentsMap) && Object.hasOwnProperty.call(knownComponentsMap, node.name);
        if ((0,_utils_js__WEBPACK_IMPORTED_MODULE_2__.isString)(child)) {
          const value = i18n.services.interpolator.interpolate(child, opts, i18n.language);
          mem.push(value);
        } else if (hasChildren(child) || isValidTranslationWithChildren) {
          const inner = renderInner(child, node, rootReactNode);
          pushTranslatedJSX(child, inner, mem, i);
        } else if (isEmptyTransWithHTML) {
          const inner = mapAST(reactNodes, node.children, rootReactNode);
          pushTranslatedJSX(child, inner, mem, i);
        } else if (Number.isNaN(parseFloat(node.name))) {
          if (isKnownComponent) {
            const inner = renderInner(child, node, rootReactNode);
            pushTranslatedJSX(child, inner, mem, i, node.voidElement);
          } else if (i18nOptions.transSupportBasicHtmlNodes && keepArray.indexOf(node.name) > -1) {
            if (node.voidElement) {
              mem.push((0,react__WEBPACK_IMPORTED_MODULE_0__.createElement)(node.name, {
                key: `${node.name}-${i}`
              }));
            } else {
              const inner = mapAST(reactNodes, node.children, rootReactNode);
              mem.push((0,react__WEBPACK_IMPORTED_MODULE_0__.createElement)(node.name, {
                key: `${node.name}-${i}`
              }, inner));
            }
          } else if (node.voidElement) {
            mem.push(`<${node.name} />`);
          } else {
            const inner = mapAST(reactNodes, node.children, rootReactNode);
            mem.push(`<${node.name}>${inner}</${node.name}>`);
          }
        } else if ((0,_utils_js__WEBPACK_IMPORTED_MODULE_2__.isObject)(child) && !isElement) {
          const content = node.children[0] ? translationContent : null;
          if (content) mem.push(content);
        } else {
          pushTranslatedJSX(child, translationContent, mem, i, node.children.length !== 1 || !translationContent);
        }
      } else if (node.type === 'text') {
        const wrapTextNodes = i18nOptions.transWrapTextNodes;
        const content = shouldUnescape ? i18nOptions.unescape(i18n.services.interpolator.interpolate(node.content, opts, i18n.language)) : i18n.services.interpolator.interpolate(node.content, opts, i18n.language);
        if (wrapTextNodes) {
          mem.push((0,react__WEBPACK_IMPORTED_MODULE_0__.createElement)(wrapTextNodes, {
            key: `${node.name}-${i}`
          }, content));
        } else {
          mem.push(content);
        }
      }
      return mem;
    }, []);
  };
  const result = mapAST([{
    dummy: true,
    children: children || []
  }], ast, getAsArray(children || []));
  return getChildren(result[0]);
};
const fixComponentProps = (component, index, translation) => {
  const componentKey = component.key || index;
  const comp = (0,react__WEBPACK_IMPORTED_MODULE_0__.cloneElement)(component, {
    key: componentKey
  });
  if (!comp.props || !comp.props.children || translation.indexOf(`${index}/>`) < 0 && translation.indexOf(`${index} />`) < 0) {
    return comp;
  }
  function Componentized() {
    return (0,react__WEBPACK_IMPORTED_MODULE_0__.createElement)(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, comp);
  }
  return (0,react__WEBPACK_IMPORTED_MODULE_0__.createElement)(Componentized, {
    key: componentKey
  });
};
const generateArrayComponents = (components, translation) => components.map((c, index) => fixComponentProps(c, index, translation));
const generateObjectComponents = (components, translation) => {
  const componentMap = {};
  Object.keys(components).forEach(c => {
    Object.assign(componentMap, {
      [c]: fixComponentProps(components[c], c, translation)
    });
  });
  return componentMap;
};
const generateComponents = (components, translation, i18n, i18nKey) => {
  if (!components) return null;
  if (Array.isArray(components)) {
    return generateArrayComponents(components, translation);
  }
  if ((0,_utils_js__WEBPACK_IMPORTED_MODULE_2__.isObject)(components)) {
    return generateObjectComponents(components, translation);
  }
  (0,_utils_js__WEBPACK_IMPORTED_MODULE_2__.warnOnce)(i18n, 'TRANS_INVALID_COMPONENTS', `<Trans /> "components" prop expects an object or array`, {
    i18nKey
  });
  return null;
};
const isComponentsMap = object => {
  if (!(0,_utils_js__WEBPACK_IMPORTED_MODULE_2__.isObject)(object)) return false;
  if (Array.isArray(object)) return false;
  return Object.keys(object).reduce((acc, key) => acc && Number.isNaN(Number.parseFloat(key)), true);
};
function Trans({
  children,
  count,
  parent,
  i18nKey,
  context,
  tOptions = {},
  values,
  defaults,
  components,
  ns,
  i18n: i18nFromProps,
  t: tFromProps,
  shouldUnescape,
  ...additionalProps
}) {
  const i18n = i18nFromProps || (0,_i18nInstance_js__WEBPACK_IMPORTED_MODULE_4__.getI18n)();
  if (!i18n) {
    (0,_utils_js__WEBPACK_IMPORTED_MODULE_2__.warnOnce)(i18n, 'NO_I18NEXT_INSTANCE', `Trans: You need to pass in an i18next instance using i18nextReactModule`, {
      i18nKey
    });
    return children;
  }
  const t = tFromProps || i18n.t.bind(i18n) || (k => k);
  const reactI18nextOptions = {
    ...(0,_defaults_js__WEBPACK_IMPORTED_MODULE_3__.getDefaults)(),
    ...i18n.options?.react
  };
  let namespaces = ns || t.ns || i18n.options?.defaultNS;
  namespaces = (0,_utils_js__WEBPACK_IMPORTED_MODULE_2__.isString)(namespaces) ? [namespaces] : namespaces || ['translation'];
  const nodeAsString = nodesToString(children, reactI18nextOptions, i18n, i18nKey);
  const defaultValue = defaults || nodeAsString || reactI18nextOptions.transEmptyNodeValue || i18nKey;
  const {
    hashTransKey
  } = reactI18nextOptions;
  const key = i18nKey || (hashTransKey ? hashTransKey(nodeAsString || defaultValue) : nodeAsString || defaultValue);
  if (i18n.options?.interpolation?.defaultVariables) {
    values = values && Object.keys(values).length > 0 ? {
      ...values,
      ...i18n.options.interpolation.defaultVariables
    } : {
      ...i18n.options.interpolation.defaultVariables
    };
  }
  const interpolationOverride = values || count !== undefined && !i18n.options?.interpolation?.alwaysFormat || !children ? tOptions.interpolation : {
    interpolation: {
      ...tOptions.interpolation,
      prefix: '#$?',
      suffix: '?$#'
    }
  };
  const combinedTOpts = {
    ...tOptions,
    context: context || tOptions.context,
    count,
    ...values,
    ...interpolationOverride,
    defaultValue,
    ns: namespaces
  };
  const translation = key ? t(key, combinedTOpts) : defaultValue;
  const generatedComponents = generateComponents(components, translation, i18n, i18nKey);
  let indexedChildren = generatedComponents || children;
  let componentsMap = null;
  if (isComponentsMap(generatedComponents)) {
    componentsMap = generatedComponents;
    indexedChildren = children;
  }
  const content = renderNodes(indexedChildren, componentsMap, translation, i18n, reactI18nextOptions, combinedTOpts, shouldUnescape);
  const useAsParent = parent ?? reactI18nextOptions.defaultTransParent;
  return useAsParent ? (0,react__WEBPACK_IMPORTED_MODULE_0__.createElement)(useAsParent, additionalProps, content) : content;
}

/***/ }),

/***/ "./node_modules/react-i18next/dist/es/Translation.js":
/*!***********************************************************!*\
  !*** ./node_modules/react-i18next/dist/es/Translation.js ***!
  \***********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Translation: () => (/* binding */ Translation)
/* harmony export */ });
/* harmony import */ var _useTranslation_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./useTranslation.js */ "./node_modules/react-i18next/dist/es/useTranslation.js");

const Translation = ({
  ns,
  children,
  ...options
}) => {
  const [t, i18n, ready] = (0,_useTranslation_js__WEBPACK_IMPORTED_MODULE_0__.useTranslation)(ns, options);
  return children(t, {
    i18n,
    lng: i18n.language
  }, ready);
};

/***/ }),

/***/ "./node_modules/react-i18next/dist/es/context.js":
/*!*******************************************************!*\
  !*** ./node_modules/react-i18next/dist/es/context.js ***!
  \*******************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   I18nContext: () => (/* binding */ I18nContext),
/* harmony export */   ReportNamespaces: () => (/* binding */ ReportNamespaces),
/* harmony export */   composeInitialProps: () => (/* binding */ composeInitialProps),
/* harmony export */   getDefaults: () => (/* reexport safe */ _defaults_js__WEBPACK_IMPORTED_MODULE_1__.getDefaults),
/* harmony export */   getI18n: () => (/* reexport safe */ _i18nInstance_js__WEBPACK_IMPORTED_MODULE_2__.getI18n),
/* harmony export */   getInitialProps: () => (/* binding */ getInitialProps),
/* harmony export */   initReactI18next: () => (/* reexport safe */ _initReactI18next_js__WEBPACK_IMPORTED_MODULE_3__.initReactI18next),
/* harmony export */   setDefaults: () => (/* reexport safe */ _defaults_js__WEBPACK_IMPORTED_MODULE_1__.setDefaults),
/* harmony export */   setI18n: () => (/* reexport safe */ _i18nInstance_js__WEBPACK_IMPORTED_MODULE_2__.setI18n)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var _defaults_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./defaults.js */ "./node_modules/react-i18next/dist/es/defaults.js");
/* harmony import */ var _i18nInstance_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./i18nInstance.js */ "./node_modules/react-i18next/dist/es/i18nInstance.js");
/* harmony import */ var _initReactI18next_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./initReactI18next.js */ "./node_modules/react-i18next/dist/es/initReactI18next.js");





const I18nContext = (0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)();
class ReportNamespaces {
  constructor() {
    this.usedNamespaces = {};
  }
  addUsedNamespaces(namespaces) {
    namespaces.forEach(ns => {
      if (!this.usedNamespaces[ns]) this.usedNamespaces[ns] = true;
    });
  }
  getUsedNamespaces() {
    return Object.keys(this.usedNamespaces);
  }
}
const composeInitialProps = ForComponent => async ctx => {
  const componentsInitialProps = (await ForComponent.getInitialProps?.(ctx)) ?? {};
  const i18nInitialProps = getInitialProps();
  return {
    ...componentsInitialProps,
    ...i18nInitialProps
  };
};
const getInitialProps = () => {
  const i18n = (0,_i18nInstance_js__WEBPACK_IMPORTED_MODULE_2__.getI18n)();
  const namespaces = i18n.reportNamespaces?.getUsedNamespaces() ?? [];
  const ret = {};
  const initialI18nStore = {};
  i18n.languages.forEach(l => {
    initialI18nStore[l] = {};
    namespaces.forEach(ns => {
      initialI18nStore[l][ns] = i18n.getResourceBundle(l, ns) || {};
    });
  });
  ret.initialI18nStore = initialI18nStore;
  ret.initialLanguage = i18n.language;
  return ret;
};

/***/ }),

/***/ "./node_modules/react-i18next/dist/es/defaults.js":
/*!********************************************************!*\
  !*** ./node_modules/react-i18next/dist/es/defaults.js ***!
  \********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getDefaults: () => (/* binding */ getDefaults),
/* harmony export */   setDefaults: () => (/* binding */ setDefaults)
/* harmony export */ });
/* harmony import */ var _unescape_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./unescape.js */ "./node_modules/react-i18next/dist/es/unescape.js");

let defaultOptions = {
  bindI18n: 'languageChanged',
  bindI18nStore: '',
  transEmptyNodeValue: '',
  transSupportBasicHtmlNodes: true,
  transWrapTextNodes: '',
  transKeepBasicHtmlNodesFor: ['br', 'strong', 'i', 'p'],
  useSuspense: true,
  unescape: _unescape_js__WEBPACK_IMPORTED_MODULE_0__.unescape
};
const setDefaults = (options = {}) => {
  defaultOptions = {
    ...defaultOptions,
    ...options
  };
};
const getDefaults = () => defaultOptions;

/***/ }),

/***/ "./node_modules/react-i18next/dist/es/i18nInstance.js":
/*!************************************************************!*\
  !*** ./node_modules/react-i18next/dist/es/i18nInstance.js ***!
  \************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getI18n: () => (/* binding */ getI18n),
/* harmony export */   setI18n: () => (/* binding */ setI18n)
/* harmony export */ });
let i18nInstance;
const setI18n = instance => {
  i18nInstance = instance;
};
const getI18n = () => i18nInstance;

/***/ }),

/***/ "./node_modules/react-i18next/dist/es/index.js":
/*!*****************************************************!*\
  !*** ./node_modules/react-i18next/dist/es/index.js ***!
  \*****************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   I18nContext: () => (/* reexport safe */ _context_js__WEBPACK_IMPORTED_MODULE_11__.I18nContext),
/* harmony export */   I18nextProvider: () => (/* reexport safe */ _I18nextProvider_js__WEBPACK_IMPORTED_MODULE_5__.I18nextProvider),
/* harmony export */   Trans: () => (/* reexport safe */ _Trans_js__WEBPACK_IMPORTED_MODULE_0__.Trans),
/* harmony export */   TransWithoutContext: () => (/* reexport safe */ _TransWithoutContext_js__WEBPACK_IMPORTED_MODULE_1__.Trans),
/* harmony export */   Translation: () => (/* reexport safe */ _Translation_js__WEBPACK_IMPORTED_MODULE_4__.Translation),
/* harmony export */   composeInitialProps: () => (/* reexport safe */ _context_js__WEBPACK_IMPORTED_MODULE_11__.composeInitialProps),
/* harmony export */   date: () => (/* binding */ date),
/* harmony export */   getDefaults: () => (/* reexport safe */ _defaults_js__WEBPACK_IMPORTED_MODULE_9__.getDefaults),
/* harmony export */   getI18n: () => (/* reexport safe */ _i18nInstance_js__WEBPACK_IMPORTED_MODULE_10__.getI18n),
/* harmony export */   getInitialProps: () => (/* reexport safe */ _context_js__WEBPACK_IMPORTED_MODULE_11__.getInitialProps),
/* harmony export */   initReactI18next: () => (/* reexport safe */ _initReactI18next_js__WEBPACK_IMPORTED_MODULE_8__.initReactI18next),
/* harmony export */   number: () => (/* binding */ number),
/* harmony export */   plural: () => (/* binding */ plural),
/* harmony export */   select: () => (/* binding */ select),
/* harmony export */   selectOrdinal: () => (/* binding */ selectOrdinal),
/* harmony export */   setDefaults: () => (/* reexport safe */ _defaults_js__WEBPACK_IMPORTED_MODULE_9__.setDefaults),
/* harmony export */   setI18n: () => (/* reexport safe */ _i18nInstance_js__WEBPACK_IMPORTED_MODULE_10__.setI18n),
/* harmony export */   time: () => (/* binding */ time),
/* harmony export */   useSSR: () => (/* reexport safe */ _useSSR_js__WEBPACK_IMPORTED_MODULE_7__.useSSR),
/* harmony export */   useTranslation: () => (/* reexport safe */ _useTranslation_js__WEBPACK_IMPORTED_MODULE_2__.useTranslation),
/* harmony export */   withSSR: () => (/* reexport safe */ _withSSR_js__WEBPACK_IMPORTED_MODULE_6__.withSSR),
/* harmony export */   withTranslation: () => (/* reexport safe */ _withTranslation_js__WEBPACK_IMPORTED_MODULE_3__.withTranslation)
/* harmony export */ });
/* harmony import */ var _Trans_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Trans.js */ "./node_modules/react-i18next/dist/es/Trans.js");
/* harmony import */ var _TransWithoutContext_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./TransWithoutContext.js */ "./node_modules/react-i18next/dist/es/TransWithoutContext.js");
/* harmony import */ var _useTranslation_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./useTranslation.js */ "./node_modules/react-i18next/dist/es/useTranslation.js");
/* harmony import */ var _withTranslation_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./withTranslation.js */ "./node_modules/react-i18next/dist/es/withTranslation.js");
/* harmony import */ var _Translation_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Translation.js */ "./node_modules/react-i18next/dist/es/Translation.js");
/* harmony import */ var _I18nextProvider_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./I18nextProvider.js */ "./node_modules/react-i18next/dist/es/I18nextProvider.js");
/* harmony import */ var _withSSR_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./withSSR.js */ "./node_modules/react-i18next/dist/es/withSSR.js");
/* harmony import */ var _useSSR_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./useSSR.js */ "./node_modules/react-i18next/dist/es/useSSR.js");
/* harmony import */ var _initReactI18next_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./initReactI18next.js */ "./node_modules/react-i18next/dist/es/initReactI18next.js");
/* harmony import */ var _defaults_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./defaults.js */ "./node_modules/react-i18next/dist/es/defaults.js");
/* harmony import */ var _i18nInstance_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./i18nInstance.js */ "./node_modules/react-i18next/dist/es/i18nInstance.js");
/* harmony import */ var _context_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./context.js */ "./node_modules/react-i18next/dist/es/context.js");












const date = () => '';
const time = () => '';
const number = () => '';
const select = () => '';
const plural = () => '';
const selectOrdinal = () => '';

/***/ }),

/***/ "./node_modules/react-i18next/dist/es/initReactI18next.js":
/*!****************************************************************!*\
  !*** ./node_modules/react-i18next/dist/es/initReactI18next.js ***!
  \****************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   initReactI18next: () => (/* binding */ initReactI18next)
/* harmony export */ });
/* harmony import */ var _defaults_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./defaults.js */ "./node_modules/react-i18next/dist/es/defaults.js");
/* harmony import */ var _i18nInstance_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./i18nInstance.js */ "./node_modules/react-i18next/dist/es/i18nInstance.js");


const initReactI18next = {
  type: '3rdParty',
  init(instance) {
    (0,_defaults_js__WEBPACK_IMPORTED_MODULE_0__.setDefaults)(instance.options.react);
    (0,_i18nInstance_js__WEBPACK_IMPORTED_MODULE_1__.setI18n)(instance);
  }
};

/***/ }),

/***/ "./node_modules/react-i18next/dist/es/unescape.js":
/*!********************************************************!*\
  !*** ./node_modules/react-i18next/dist/es/unescape.js ***!
  \********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   unescape: () => (/* binding */ unescape)
/* harmony export */ });
const matchHtmlEntity = /&(?:amp|#38|lt|#60|gt|#62|apos|#39|quot|#34|nbsp|#160|copy|#169|reg|#174|hellip|#8230|#x2F|#47);/g;
const htmlEntities = {
  '&amp;': '&',
  '&#38;': '&',
  '&lt;': '<',
  '&#60;': '<',
  '&gt;': '>',
  '&#62;': '>',
  '&apos;': "'",
  '&#39;': "'",
  '&quot;': '"',
  '&#34;': '"',
  '&nbsp;': ' ',
  '&#160;': ' ',
  '&copy;': '©',
  '&#169;': '©',
  '&reg;': '®',
  '&#174;': '®',
  '&hellip;': '…',
  '&#8230;': '…',
  '&#x2F;': '/',
  '&#47;': '/'
};
const unescapeHtmlEntity = m => htmlEntities[m];
const unescape = text => text.replace(matchHtmlEntity, unescapeHtmlEntity);

/***/ }),

/***/ "./node_modules/react-i18next/dist/es/useSSR.js":
/*!******************************************************!*\
  !*** ./node_modules/react-i18next/dist/es/useSSR.js ***!
  \******************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   useSSR: () => (/* binding */ useSSR)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var _context_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./context.js */ "./node_modules/react-i18next/dist/es/context.js");


const useSSR = (initialI18nStore, initialLanguage, props = {}) => {
  const {
    i18n: i18nFromProps
  } = props;
  const {
    i18n: i18nFromContext
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(_context_js__WEBPACK_IMPORTED_MODULE_1__.I18nContext) || {};
  const i18n = i18nFromProps || i18nFromContext || (0,_context_js__WEBPACK_IMPORTED_MODULE_1__.getI18n)();
  if (i18n.options?.isClone) return;
  if (initialI18nStore && !i18n.initializedStoreOnce) {
    i18n.services.resourceStore.data = initialI18nStore;
    i18n.options.ns = Object.values(initialI18nStore).reduce((mem, lngResources) => {
      Object.keys(lngResources).forEach(ns => {
        if (mem.indexOf(ns) < 0) mem.push(ns);
      });
      return mem;
    }, i18n.options.ns);
    i18n.initializedStoreOnce = true;
    i18n.isInitialized = true;
  }
  if (initialLanguage && !i18n.initializedLanguageOnce) {
    i18n.changeLanguage(initialLanguage);
    i18n.initializedLanguageOnce = true;
  }
};

/***/ }),

/***/ "./node_modules/react-i18next/dist/es/useTranslation.js":
/*!**************************************************************!*\
  !*** ./node_modules/react-i18next/dist/es/useTranslation.js ***!
  \**************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   useTranslation: () => (/* binding */ useTranslation)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var _context_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./context.js */ "./node_modules/react-i18next/dist/es/context.js");
/* harmony import */ var _utils_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./utils.js */ "./node_modules/react-i18next/dist/es/utils.js");



const usePrevious = (value, ignore) => {
  const ref = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    ref.current = ignore ? ref.current : value;
  }, [value, ignore]);
  return ref.current;
};
const alwaysNewT = (i18n, language, namespace, keyPrefix) => i18n.getFixedT(language, namespace, keyPrefix);
const useMemoizedT = (i18n, language, namespace, keyPrefix) => (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(alwaysNewT(i18n, language, namespace, keyPrefix), [i18n, language, namespace, keyPrefix]);
const useTranslation = (ns, props = {}) => {
  const {
    i18n: i18nFromProps
  } = props;
  const {
    i18n: i18nFromContext,
    defaultNS: defaultNSFromContext
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(_context_js__WEBPACK_IMPORTED_MODULE_1__.I18nContext) || {};
  const i18n = i18nFromProps || i18nFromContext || (0,_context_js__WEBPACK_IMPORTED_MODULE_1__.getI18n)();
  if (i18n && !i18n.reportNamespaces) i18n.reportNamespaces = new _context_js__WEBPACK_IMPORTED_MODULE_1__.ReportNamespaces();
  if (!i18n) {
    (0,_utils_js__WEBPACK_IMPORTED_MODULE_2__.warnOnce)(i18n, 'NO_I18NEXT_INSTANCE', 'useTranslation: You will need to pass in an i18next instance by using initReactI18next');
    const notReadyT = (k, optsOrDefaultValue) => {
      if ((0,_utils_js__WEBPACK_IMPORTED_MODULE_2__.isString)(optsOrDefaultValue)) return optsOrDefaultValue;
      if ((0,_utils_js__WEBPACK_IMPORTED_MODULE_2__.isObject)(optsOrDefaultValue) && (0,_utils_js__WEBPACK_IMPORTED_MODULE_2__.isString)(optsOrDefaultValue.defaultValue)) return optsOrDefaultValue.defaultValue;
      return Array.isArray(k) ? k[k.length - 1] : k;
    };
    const retNotReady = [notReadyT, {}, false];
    retNotReady.t = notReadyT;
    retNotReady.i18n = {};
    retNotReady.ready = false;
    return retNotReady;
  }
  if (i18n.options.react?.wait) (0,_utils_js__WEBPACK_IMPORTED_MODULE_2__.warnOnce)(i18n, 'DEPRECATED_OPTION', 'useTranslation: It seems you are still using the old wait option, you may migrate to the new useSuspense behaviour.');
  const i18nOptions = {
    ...(0,_context_js__WEBPACK_IMPORTED_MODULE_1__.getDefaults)(),
    ...i18n.options.react,
    ...props
  };
  const {
    useSuspense,
    keyPrefix
  } = i18nOptions;
  let namespaces = ns || defaultNSFromContext || i18n.options?.defaultNS;
  namespaces = (0,_utils_js__WEBPACK_IMPORTED_MODULE_2__.isString)(namespaces) ? [namespaces] : namespaces || ['translation'];
  i18n.reportNamespaces.addUsedNamespaces?.(namespaces);
  const ready = (i18n.isInitialized || i18n.initializedStoreOnce) && namespaces.every(n => (0,_utils_js__WEBPACK_IMPORTED_MODULE_2__.hasLoadedNamespace)(n, i18n, i18nOptions));
  const memoGetT = useMemoizedT(i18n, props.lng || null, i18nOptions.nsMode === 'fallback' ? namespaces : namespaces[0], keyPrefix);
  const getT = () => memoGetT;
  const getNewT = () => alwaysNewT(i18n, props.lng || null, i18nOptions.nsMode === 'fallback' ? namespaces : namespaces[0], keyPrefix);
  const [t, setT] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(getT);
  let joinedNS = namespaces.join();
  if (props.lng) joinedNS = `${props.lng}${joinedNS}`;
  const previousJoinedNS = usePrevious(joinedNS);
  const isMounted = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(true);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    const {
      bindI18n,
      bindI18nStore
    } = i18nOptions;
    isMounted.current = true;
    if (!ready && !useSuspense) {
      if (props.lng) {
        (0,_utils_js__WEBPACK_IMPORTED_MODULE_2__.loadLanguages)(i18n, props.lng, namespaces, () => {
          if (isMounted.current) setT(getNewT);
        });
      } else {
        (0,_utils_js__WEBPACK_IMPORTED_MODULE_2__.loadNamespaces)(i18n, namespaces, () => {
          if (isMounted.current) setT(getNewT);
        });
      }
    }
    if (ready && previousJoinedNS && previousJoinedNS !== joinedNS && isMounted.current) {
      setT(getNewT);
    }
    const boundReset = () => {
      if (isMounted.current) setT(getNewT);
    };
    if (bindI18n) i18n?.on(bindI18n, boundReset);
    if (bindI18nStore) i18n?.store.on(bindI18nStore, boundReset);
    return () => {
      isMounted.current = false;
      if (i18n && bindI18n) bindI18n?.split(' ').forEach(e => i18n.off(e, boundReset));
      if (bindI18nStore && i18n) bindI18nStore.split(' ').forEach(e => i18n.store.off(e, boundReset));
    };
  }, [i18n, joinedNS]);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (isMounted.current && ready) {
      setT(getT);
    }
  }, [i18n, keyPrefix, ready]);
  const ret = [t, i18n, ready];
  ret.t = t;
  ret.i18n = i18n;
  ret.ready = ready;
  if (ready) return ret;
  if (!ready && !useSuspense) return ret;
  throw new Promise(resolve => {
    if (props.lng) {
      (0,_utils_js__WEBPACK_IMPORTED_MODULE_2__.loadLanguages)(i18n, props.lng, namespaces, () => resolve());
    } else {
      (0,_utils_js__WEBPACK_IMPORTED_MODULE_2__.loadNamespaces)(i18n, namespaces, () => resolve());
    }
  });
};

/***/ }),

/***/ "./node_modules/react-i18next/dist/es/utils.js":
/*!*****************************************************!*\
  !*** ./node_modules/react-i18next/dist/es/utils.js ***!
  \*****************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getDisplayName: () => (/* binding */ getDisplayName),
/* harmony export */   hasLoadedNamespace: () => (/* binding */ hasLoadedNamespace),
/* harmony export */   isObject: () => (/* binding */ isObject),
/* harmony export */   isString: () => (/* binding */ isString),
/* harmony export */   loadLanguages: () => (/* binding */ loadLanguages),
/* harmony export */   loadNamespaces: () => (/* binding */ loadNamespaces),
/* harmony export */   warn: () => (/* binding */ warn),
/* harmony export */   warnOnce: () => (/* binding */ warnOnce)
/* harmony export */ });
const warn = (i18n, code, msg, rest) => {
  const args = [msg, {
    code,
    ...(rest || {})
  }];
  if (i18n?.services?.logger?.forward) {
    return i18n.services.logger.forward(args, 'warn', 'react-i18next::', true);
  }
  if (isString(args[0])) args[0] = `react-i18next:: ${args[0]}`;
  if (i18n?.services?.logger?.warn) {
    i18n.services.logger.warn(...args);
  } else if (console?.warn) {
    console.warn(...args);
  }
};
const alreadyWarned = {};
const warnOnce = (i18n, code, msg, rest) => {
  if (isString(msg) && alreadyWarned[msg]) return;
  if (isString(msg)) alreadyWarned[msg] = new Date();
  warn(i18n, code, msg, rest);
};
const loadedClb = (i18n, cb) => () => {
  if (i18n.isInitialized) {
    cb();
  } else {
    const initialized = () => {
      setTimeout(() => {
        i18n.off('initialized', initialized);
      }, 0);
      cb();
    };
    i18n.on('initialized', initialized);
  }
};
const loadNamespaces = (i18n, ns, cb) => {
  i18n.loadNamespaces(ns, loadedClb(i18n, cb));
};
const loadLanguages = (i18n, lng, ns, cb) => {
  if (isString(ns)) ns = [ns];
  if (i18n.options.preload && i18n.options.preload.indexOf(lng) > -1) return loadNamespaces(i18n, ns, cb);
  ns.forEach(n => {
    if (i18n.options.ns.indexOf(n) < 0) i18n.options.ns.push(n);
  });
  i18n.loadLanguages(lng, loadedClb(i18n, cb));
};
const hasLoadedNamespace = (ns, i18n, options = {}) => {
  if (!i18n.languages || !i18n.languages.length) {
    warnOnce(i18n, 'NO_LANGUAGES', 'i18n.languages were undefined or empty', {
      languages: i18n.languages
    });
    return true;
  }
  return i18n.hasLoadedNamespace(ns, {
    lng: options.lng,
    precheck: (i18nInstance, loadNotPending) => {
      if (options.bindI18n && options.bindI18n.indexOf('languageChanging') > -1 && i18nInstance.services.backendConnector.backend && i18nInstance.isLanguageChangingTo && !loadNotPending(i18nInstance.isLanguageChangingTo, ns)) return false;
    }
  });
};
const getDisplayName = Component => Component.displayName || Component.name || (isString(Component) && Component.length > 0 ? Component : 'Unknown');
const isString = obj => typeof obj === 'string';
const isObject = obj => typeof obj === 'object' && obj !== null;

/***/ }),

/***/ "./node_modules/react-i18next/dist/es/withSSR.js":
/*!*******************************************************!*\
  !*** ./node_modules/react-i18next/dist/es/withSSR.js ***!
  \*******************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   withSSR: () => (/* binding */ withSSR)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var _useSSR_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./useSSR.js */ "./node_modules/react-i18next/dist/es/useSSR.js");
/* harmony import */ var _context_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./context.js */ "./node_modules/react-i18next/dist/es/context.js");
/* harmony import */ var _utils_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./utils.js */ "./node_modules/react-i18next/dist/es/utils.js");




const withSSR = () => function Extend(WrappedComponent) {
  function I18nextWithSSR({
    initialI18nStore,
    initialLanguage,
    ...rest
  }) {
    (0,_useSSR_js__WEBPACK_IMPORTED_MODULE_1__.useSSR)(initialI18nStore, initialLanguage);
    return (0,react__WEBPACK_IMPORTED_MODULE_0__.createElement)(WrappedComponent, {
      ...rest
    });
  }
  I18nextWithSSR.getInitialProps = (0,_context_js__WEBPACK_IMPORTED_MODULE_2__.composeInitialProps)(WrappedComponent);
  I18nextWithSSR.displayName = `withI18nextSSR(${(0,_utils_js__WEBPACK_IMPORTED_MODULE_3__.getDisplayName)(WrappedComponent)})`;
  I18nextWithSSR.WrappedComponent = WrappedComponent;
  return I18nextWithSSR;
};

/***/ }),

/***/ "./node_modules/react-i18next/dist/es/withTranslation.js":
/*!***************************************************************!*\
  !*** ./node_modules/react-i18next/dist/es/withTranslation.js ***!
  \***************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   withTranslation: () => (/* binding */ withTranslation)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var _useTranslation_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./useTranslation.js */ "./node_modules/react-i18next/dist/es/useTranslation.js");
/* harmony import */ var _utils_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./utils.js */ "./node_modules/react-i18next/dist/es/utils.js");



const withTranslation = (ns, options = {}) => function Extend(WrappedComponent) {
  function I18nextWithTranslation({
    forwardedRef,
    ...rest
  }) {
    const [t, i18n, ready] = (0,_useTranslation_js__WEBPACK_IMPORTED_MODULE_1__.useTranslation)(ns, {
      ...rest,
      keyPrefix: options.keyPrefix
    });
    const passDownProps = {
      ...rest,
      t,
      i18n,
      tReady: ready
    };
    if (options.withRef && forwardedRef) {
      passDownProps.ref = forwardedRef;
    } else if (!options.withRef && forwardedRef) {
      passDownProps.forwardedRef = forwardedRef;
    }
    return (0,react__WEBPACK_IMPORTED_MODULE_0__.createElement)(WrappedComponent, passDownProps);
  }
  I18nextWithTranslation.displayName = `withI18nextTranslation(${(0,_utils_js__WEBPACK_IMPORTED_MODULE_2__.getDisplayName)(WrappedComponent)})`;
  I18nextWithTranslation.WrappedComponent = WrappedComponent;
  const forwardRef = (props, ref) => (0,react__WEBPACK_IMPORTED_MODULE_0__.createElement)(I18nextWithTranslation, Object.assign({}, props, {
    forwardedRef: ref
  }));
  return options.withRef ? (0,react__WEBPACK_IMPORTED_MODULE_0__.forwardRef)(forwardRef) : I18nextWithTranslation;
};

/***/ }),

/***/ "./node_modules/react/cjs/react.development.js":
/*!*****************************************************!*\
  !*** ./node_modules/react/cjs/react.development.js ***!
  \*****************************************************/
/***/ ((module, exports, __webpack_require__) => {

"use strict";
/* module decorator */ module = __webpack_require__.nmd(module);
/**
 * @license React
 * react.development.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */



if (true) {
  (function() {

          'use strict';

/* global __REACT_DEVTOOLS_GLOBAL_HOOK__ */
if (
  typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ !== 'undefined' &&
  typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart ===
    'function'
) {
  __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(new Error());
}
          var ReactVersion = '18.3.1';

// ATTENTION
// When adding new symbols to this file,
// Please consider also adding to 'react-devtools-shared/src/backend/ReactSymbols'
// The Symbol used to tag the ReactElement-like types.
var REACT_ELEMENT_TYPE = Symbol.for('react.element');
var REACT_PORTAL_TYPE = Symbol.for('react.portal');
var REACT_FRAGMENT_TYPE = Symbol.for('react.fragment');
var REACT_STRICT_MODE_TYPE = Symbol.for('react.strict_mode');
var REACT_PROFILER_TYPE = Symbol.for('react.profiler');
var REACT_PROVIDER_TYPE = Symbol.for('react.provider');
var REACT_CONTEXT_TYPE = Symbol.for('react.context');
var REACT_FORWARD_REF_TYPE = Symbol.for('react.forward_ref');
var REACT_SUSPENSE_TYPE = Symbol.for('react.suspense');
var REACT_SUSPENSE_LIST_TYPE = Symbol.for('react.suspense_list');
var REACT_MEMO_TYPE = Symbol.for('react.memo');
var REACT_LAZY_TYPE = Symbol.for('react.lazy');
var REACT_OFFSCREEN_TYPE = Symbol.for('react.offscreen');
var MAYBE_ITERATOR_SYMBOL = Symbol.iterator;
var FAUX_ITERATOR_SYMBOL = '@@iterator';
function getIteratorFn(maybeIterable) {
  if (maybeIterable === null || typeof maybeIterable !== 'object') {
    return null;
  }

  var maybeIterator = MAYBE_ITERATOR_SYMBOL && maybeIterable[MAYBE_ITERATOR_SYMBOL] || maybeIterable[FAUX_ITERATOR_SYMBOL];

  if (typeof maybeIterator === 'function') {
    return maybeIterator;
  }

  return null;
}

/**
 * Keeps track of the current dispatcher.
 */
var ReactCurrentDispatcher = {
  /**
   * @internal
   * @type {ReactComponent}
   */
  current: null
};

/**
 * Keeps track of the current batch's configuration such as how long an update
 * should suspend for if it needs to.
 */
var ReactCurrentBatchConfig = {
  transition: null
};

var ReactCurrentActQueue = {
  current: null,
  // Used to reproduce behavior of `batchedUpdates` in legacy mode.
  isBatchingLegacy: false,
  didScheduleLegacyUpdate: false
};

/**
 * Keeps track of the current owner.
 *
 * The current owner is the component who should own any components that are
 * currently being constructed.
 */
var ReactCurrentOwner = {
  /**
   * @internal
   * @type {ReactComponent}
   */
  current: null
};

var ReactDebugCurrentFrame = {};
var currentExtraStackFrame = null;
function setExtraStackFrame(stack) {
  {
    currentExtraStackFrame = stack;
  }
}

{
  ReactDebugCurrentFrame.setExtraStackFrame = function (stack) {
    {
      currentExtraStackFrame = stack;
    }
  }; // Stack implementation injected by the current renderer.


  ReactDebugCurrentFrame.getCurrentStack = null;

  ReactDebugCurrentFrame.getStackAddendum = function () {
    var stack = ''; // Add an extra top frame while an element is being validated

    if (currentExtraStackFrame) {
      stack += currentExtraStackFrame;
    } // Delegate to the injected renderer-specific implementation


    var impl = ReactDebugCurrentFrame.getCurrentStack;

    if (impl) {
      stack += impl() || '';
    }

    return stack;
  };
}

// -----------------------------------------------------------------------------

var enableScopeAPI = false; // Experimental Create Event Handle API.
var enableCacheElement = false;
var enableTransitionTracing = false; // No known bugs, but needs performance testing

var enableLegacyHidden = false; // Enables unstable_avoidThisFallback feature in Fiber
// stuff. Intended to enable React core members to more easily debug scheduling
// issues in DEV builds.

var enableDebugTracing = false; // Track which Fiber(s) schedule render work.

var ReactSharedInternals = {
  ReactCurrentDispatcher: ReactCurrentDispatcher,
  ReactCurrentBatchConfig: ReactCurrentBatchConfig,
  ReactCurrentOwner: ReactCurrentOwner
};

{
  ReactSharedInternals.ReactDebugCurrentFrame = ReactDebugCurrentFrame;
  ReactSharedInternals.ReactCurrentActQueue = ReactCurrentActQueue;
}

// by calls to these methods by a Babel plugin.
//
// In PROD (or in packages without access to React internals),
// they are left as they are instead.

function warn(format) {
  {
    {
      for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
        args[_key - 1] = arguments[_key];
      }

      printWarning('warn', format, args);
    }
  }
}
function error(format) {
  {
    {
      for (var _len2 = arguments.length, args = new Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {
        args[_key2 - 1] = arguments[_key2];
      }

      printWarning('error', format, args);
    }
  }
}

function printWarning(level, format, args) {
  // When changing this logic, you might want to also
  // update consoleWithStackDev.www.js as well.
  {
    var ReactDebugCurrentFrame = ReactSharedInternals.ReactDebugCurrentFrame;
    var stack = ReactDebugCurrentFrame.getStackAddendum();

    if (stack !== '') {
      format += '%s';
      args = args.concat([stack]);
    } // eslint-disable-next-line react-internal/safe-string-coercion


    var argsWithFormat = args.map(function (item) {
      return String(item);
    }); // Careful: RN currently depends on this prefix

    argsWithFormat.unshift('Warning: ' + format); // We intentionally don't use spread (or .apply) directly because it
    // breaks IE9: https://github.com/facebook/react/issues/13610
    // eslint-disable-next-line react-internal/no-production-logging

    Function.prototype.apply.call(console[level], console, argsWithFormat);
  }
}

var didWarnStateUpdateForUnmountedComponent = {};

function warnNoop(publicInstance, callerName) {
  {
    var _constructor = publicInstance.constructor;
    var componentName = _constructor && (_constructor.displayName || _constructor.name) || 'ReactClass';
    var warningKey = componentName + "." + callerName;

    if (didWarnStateUpdateForUnmountedComponent[warningKey]) {
      return;
    }

    error("Can't call %s on a component that is not yet mounted. " + 'This is a no-op, but it might indicate a bug in your application. ' + 'Instead, assign to `this.state` directly or define a `state = {};` ' + 'class property with the desired state in the %s component.', callerName, componentName);

    didWarnStateUpdateForUnmountedComponent[warningKey] = true;
  }
}
/**
 * This is the abstract API for an update queue.
 */


var ReactNoopUpdateQueue = {
  /**
   * Checks whether or not this composite component is mounted.
   * @param {ReactClass} publicInstance The instance we want to test.
   * @return {boolean} True if mounted, false otherwise.
   * @protected
   * @final
   */
  isMounted: function (publicInstance) {
    return false;
  },

  /**
   * Forces an update. This should only be invoked when it is known with
   * certainty that we are **not** in a DOM transaction.
   *
   * You may want to call this when you know that some deeper aspect of the
   * component's state has changed but `setState` was not called.
   *
   * This will not invoke `shouldComponentUpdate`, but it will invoke
   * `componentWillUpdate` and `componentDidUpdate`.
   *
   * @param {ReactClass} publicInstance The instance that should rerender.
   * @param {?function} callback Called after component is updated.
   * @param {?string} callerName name of the calling function in the public API.
   * @internal
   */
  enqueueForceUpdate: function (publicInstance, callback, callerName) {
    warnNoop(publicInstance, 'forceUpdate');
  },

  /**
   * Replaces all of the state. Always use this or `setState` to mutate state.
   * You should treat `this.state` as immutable.
   *
   * There is no guarantee that `this.state` will be immediately updated, so
   * accessing `this.state` after calling this method may return the old value.
   *
   * @param {ReactClass} publicInstance The instance that should rerender.
   * @param {object} completeState Next state.
   * @param {?function} callback Called after component is updated.
   * @param {?string} callerName name of the calling function in the public API.
   * @internal
   */
  enqueueReplaceState: function (publicInstance, completeState, callback, callerName) {
    warnNoop(publicInstance, 'replaceState');
  },

  /**
   * Sets a subset of the state. This only exists because _pendingState is
   * internal. This provides a merging strategy that is not available to deep
   * properties which is confusing. TODO: Expose pendingState or don't use it
   * during the merge.
   *
   * @param {ReactClass} publicInstance The instance that should rerender.
   * @param {object} partialState Next partial state to be merged with state.
   * @param {?function} callback Called after component is updated.
   * @param {?string} Name of the calling function in the public API.
   * @internal
   */
  enqueueSetState: function (publicInstance, partialState, callback, callerName) {
    warnNoop(publicInstance, 'setState');
  }
};

var assign = Object.assign;

var emptyObject = {};

{
  Object.freeze(emptyObject);
}
/**
 * Base class helpers for the updating state of a component.
 */


function Component(props, context, updater) {
  this.props = props;
  this.context = context; // If a component has string refs, we will assign a different object later.

  this.refs = emptyObject; // We initialize the default updater but the real one gets injected by the
  // renderer.

  this.updater = updater || ReactNoopUpdateQueue;
}

Component.prototype.isReactComponent = {};
/**
 * Sets a subset of the state. Always use this to mutate
 * state. You should treat `this.state` as immutable.
 *
 * There is no guarantee that `this.state` will be immediately updated, so
 * accessing `this.state` after calling this method may return the old value.
 *
 * There is no guarantee that calls to `setState` will run synchronously,
 * as they may eventually be batched together.  You can provide an optional
 * callback that will be executed when the call to setState is actually
 * completed.
 *
 * When a function is provided to setState, it will be called at some point in
 * the future (not synchronously). It will be called with the up to date
 * component arguments (state, props, context). These values can be different
 * from this.* because your function may be called after receiveProps but before
 * shouldComponentUpdate, and this new state, props, and context will not yet be
 * assigned to this.
 *
 * @param {object|function} partialState Next partial state or function to
 *        produce next partial state to be merged with current state.
 * @param {?function} callback Called after state is updated.
 * @final
 * @protected
 */

Component.prototype.setState = function (partialState, callback) {
  if (typeof partialState !== 'object' && typeof partialState !== 'function' && partialState != null) {
    throw new Error('setState(...): takes an object of state variables to update or a ' + 'function which returns an object of state variables.');
  }

  this.updater.enqueueSetState(this, partialState, callback, 'setState');
};
/**
 * Forces an update. This should only be invoked when it is known with
 * certainty that we are **not** in a DOM transaction.
 *
 * You may want to call this when you know that some deeper aspect of the
 * component's state has changed but `setState` was not called.
 *
 * This will not invoke `shouldComponentUpdate`, but it will invoke
 * `componentWillUpdate` and `componentDidUpdate`.
 *
 * @param {?function} callback Called after update is complete.
 * @final
 * @protected
 */


Component.prototype.forceUpdate = function (callback) {
  this.updater.enqueueForceUpdate(this, callback, 'forceUpdate');
};
/**
 * Deprecated APIs. These APIs used to exist on classic React classes but since
 * we would like to deprecate them, we're not going to move them over to this
 * modern base class. Instead, we define a getter that warns if it's accessed.
 */


{
  var deprecatedAPIs = {
    isMounted: ['isMounted', 'Instead, make sure to clean up subscriptions and pending requests in ' + 'componentWillUnmount to prevent memory leaks.'],
    replaceState: ['replaceState', 'Refactor your code to use setState instead (see ' + 'https://github.com/facebook/react/issues/3236).']
  };

  var defineDeprecationWarning = function (methodName, info) {
    Object.defineProperty(Component.prototype, methodName, {
      get: function () {
        warn('%s(...) is deprecated in plain JavaScript React classes. %s', info[0], info[1]);

        return undefined;
      }
    });
  };

  for (var fnName in deprecatedAPIs) {
    if (deprecatedAPIs.hasOwnProperty(fnName)) {
      defineDeprecationWarning(fnName, deprecatedAPIs[fnName]);
    }
  }
}

function ComponentDummy() {}

ComponentDummy.prototype = Component.prototype;
/**
 * Convenience component with default shallow equality check for sCU.
 */

function PureComponent(props, context, updater) {
  this.props = props;
  this.context = context; // If a component has string refs, we will assign a different object later.

  this.refs = emptyObject;
  this.updater = updater || ReactNoopUpdateQueue;
}

var pureComponentPrototype = PureComponent.prototype = new ComponentDummy();
pureComponentPrototype.constructor = PureComponent; // Avoid an extra prototype jump for these methods.

assign(pureComponentPrototype, Component.prototype);
pureComponentPrototype.isPureReactComponent = true;

// an immutable object with a single mutable value
function createRef() {
  var refObject = {
    current: null
  };

  {
    Object.seal(refObject);
  }

  return refObject;
}

var isArrayImpl = Array.isArray; // eslint-disable-next-line no-redeclare

function isArray(a) {
  return isArrayImpl(a);
}

/*
 * The `'' + value` pattern (used in in perf-sensitive code) throws for Symbol
 * and Temporal.* types. See https://github.com/facebook/react/pull/22064.
 *
 * The functions in this module will throw an easier-to-understand,
 * easier-to-debug exception with a clear errors message message explaining the
 * problem. (Instead of a confusing exception thrown inside the implementation
 * of the `value` object).
 */
// $FlowFixMe only called in DEV, so void return is not possible.
function typeName(value) {
  {
    // toStringTag is needed for namespaced types like Temporal.Instant
    var hasToStringTag = typeof Symbol === 'function' && Symbol.toStringTag;
    var type = hasToStringTag && value[Symbol.toStringTag] || value.constructor.name || 'Object';
    return type;
  }
} // $FlowFixMe only called in DEV, so void return is not possible.


function willCoercionThrow(value) {
  {
    try {
      testStringCoercion(value);
      return false;
    } catch (e) {
      return true;
    }
  }
}

function testStringCoercion(value) {
  // If you ended up here by following an exception call stack, here's what's
  // happened: you supplied an object or symbol value to React (as a prop, key,
  // DOM attribute, CSS property, string ref, etc.) and when React tried to
  // coerce it to a string using `'' + value`, an exception was thrown.
  //
  // The most common types that will cause this exception are `Symbol` instances
  // and Temporal objects like `Temporal.Instant`. But any object that has a
  // `valueOf` or `[Symbol.toPrimitive]` method that throws will also cause this
  // exception. (Library authors do this to prevent users from using built-in
  // numeric operators like `+` or comparison operators like `>=` because custom
  // methods are needed to perform accurate arithmetic or comparison.)
  //
  // To fix the problem, coerce this object or symbol value to a string before
  // passing it to React. The most reliable way is usually `String(value)`.
  //
  // To find which value is throwing, check the browser or debugger console.
  // Before this exception was thrown, there should be `console.error` output
  // that shows the type (Symbol, Temporal.PlainDate, etc.) that caused the
  // problem and how that type was used: key, atrribute, input value prop, etc.
  // In most cases, this console output also shows the component and its
  // ancestor components where the exception happened.
  //
  // eslint-disable-next-line react-internal/safe-string-coercion
  return '' + value;
}
function checkKeyStringCoercion(value) {
  {
    if (willCoercionThrow(value)) {
      error('The provided key is an unsupported type %s.' + ' This value must be coerced to a string before before using it here.', typeName(value));

      return testStringCoercion(value); // throw (to help callers find troubleshooting comments)
    }
  }
}

function getWrappedName(outerType, innerType, wrapperName) {
  var displayName = outerType.displayName;

  if (displayName) {
    return displayName;
  }

  var functionName = innerType.displayName || innerType.name || '';
  return functionName !== '' ? wrapperName + "(" + functionName + ")" : wrapperName;
} // Keep in sync with react-reconciler/getComponentNameFromFiber


function getContextName(type) {
  return type.displayName || 'Context';
} // Note that the reconciler package should generally prefer to use getComponentNameFromFiber() instead.


function getComponentNameFromType(type) {
  if (type == null) {
    // Host root, text node or just invalid type.
    return null;
  }

  {
    if (typeof type.tag === 'number') {
      error('Received an unexpected object in getComponentNameFromType(). ' + 'This is likely a bug in React. Please file an issue.');
    }
  }

  if (typeof type === 'function') {
    return type.displayName || type.name || null;
  }

  if (typeof type === 'string') {
    return type;
  }

  switch (type) {
    case REACT_FRAGMENT_TYPE:
      return 'Fragment';

    case REACT_PORTAL_TYPE:
      return 'Portal';

    case REACT_PROFILER_TYPE:
      return 'Profiler';

    case REACT_STRICT_MODE_TYPE:
      return 'StrictMode';

    case REACT_SUSPENSE_TYPE:
      return 'Suspense';

    case REACT_SUSPENSE_LIST_TYPE:
      return 'SuspenseList';

  }

  if (typeof type === 'object') {
    switch (type.$$typeof) {
      case REACT_CONTEXT_TYPE:
        var context = type;
        return getContextName(context) + '.Consumer';

      case REACT_PROVIDER_TYPE:
        var provider = type;
        return getContextName(provider._context) + '.Provider';

      case REACT_FORWARD_REF_TYPE:
        return getWrappedName(type, type.render, 'ForwardRef');

      case REACT_MEMO_TYPE:
        var outerName = type.displayName || null;

        if (outerName !== null) {
          return outerName;
        }

        return getComponentNameFromType(type.type) || 'Memo';

      case REACT_LAZY_TYPE:
        {
          var lazyComponent = type;
          var payload = lazyComponent._payload;
          var init = lazyComponent._init;

          try {
            return getComponentNameFromType(init(payload));
          } catch (x) {
            return null;
          }
        }

      // eslint-disable-next-line no-fallthrough
    }
  }

  return null;
}

var hasOwnProperty = Object.prototype.hasOwnProperty;

var RESERVED_PROPS = {
  key: true,
  ref: true,
  __self: true,
  __source: true
};
var specialPropKeyWarningShown, specialPropRefWarningShown, didWarnAboutStringRefs;

{
  didWarnAboutStringRefs = {};
}

function hasValidRef(config) {
  {
    if (hasOwnProperty.call(config, 'ref')) {
      var getter = Object.getOwnPropertyDescriptor(config, 'ref').get;

      if (getter && getter.isReactWarning) {
        return false;
      }
    }
  }

  return config.ref !== undefined;
}

function hasValidKey(config) {
  {
    if (hasOwnProperty.call(config, 'key')) {
      var getter = Object.getOwnPropertyDescriptor(config, 'key').get;

      if (getter && getter.isReactWarning) {
        return false;
      }
    }
  }

  return config.key !== undefined;
}

function defineKeyPropWarningGetter(props, displayName) {
  var warnAboutAccessingKey = function () {
    {
      if (!specialPropKeyWarningShown) {
        specialPropKeyWarningShown = true;

        error('%s: `key` is not a prop. Trying to access it will result ' + 'in `undefined` being returned. If you need to access the same ' + 'value within the child component, you should pass it as a different ' + 'prop. (https://reactjs.org/link/special-props)', displayName);
      }
    }
  };

  warnAboutAccessingKey.isReactWarning = true;
  Object.defineProperty(props, 'key', {
    get: warnAboutAccessingKey,
    configurable: true
  });
}

function defineRefPropWarningGetter(props, displayName) {
  var warnAboutAccessingRef = function () {
    {
      if (!specialPropRefWarningShown) {
        specialPropRefWarningShown = true;

        error('%s: `ref` is not a prop. Trying to access it will result ' + 'in `undefined` being returned. If you need to access the same ' + 'value within the child component, you should pass it as a different ' + 'prop. (https://reactjs.org/link/special-props)', displayName);
      }
    }
  };

  warnAboutAccessingRef.isReactWarning = true;
  Object.defineProperty(props, 'ref', {
    get: warnAboutAccessingRef,
    configurable: true
  });
}

function warnIfStringRefCannotBeAutoConverted(config) {
  {
    if (typeof config.ref === 'string' && ReactCurrentOwner.current && config.__self && ReactCurrentOwner.current.stateNode !== config.__self) {
      var componentName = getComponentNameFromType(ReactCurrentOwner.current.type);

      if (!didWarnAboutStringRefs[componentName]) {
        error('Component "%s" contains the string ref "%s". ' + 'Support for string refs will be removed in a future major release. ' + 'This case cannot be automatically converted to an arrow function. ' + 'We ask you to manually fix this case by using useRef() or createRef() instead. ' + 'Learn more about using refs safely here: ' + 'https://reactjs.org/link/strict-mode-string-ref', componentName, config.ref);

        didWarnAboutStringRefs[componentName] = true;
      }
    }
  }
}
/**
 * Factory method to create a new React element. This no longer adheres to
 * the class pattern, so do not use new to call it. Also, instanceof check
 * will not work. Instead test $$typeof field against Symbol.for('react.element') to check
 * if something is a React Element.
 *
 * @param {*} type
 * @param {*} props
 * @param {*} key
 * @param {string|object} ref
 * @param {*} owner
 * @param {*} self A *temporary* helper to detect places where `this` is
 * different from the `owner` when React.createElement is called, so that we
 * can warn. We want to get rid of owner and replace string `ref`s with arrow
 * functions, and as long as `this` and owner are the same, there will be no
 * change in behavior.
 * @param {*} source An annotation object (added by a transpiler or otherwise)
 * indicating filename, line number, and/or other information.
 * @internal
 */


var ReactElement = function (type, key, ref, self, source, owner, props) {
  var element = {
    // This tag allows us to uniquely identify this as a React Element
    $$typeof: REACT_ELEMENT_TYPE,
    // Built-in properties that belong on the element
    type: type,
    key: key,
    ref: ref,
    props: props,
    // Record the component responsible for creating this element.
    _owner: owner
  };

  {
    // The validation flag is currently mutative. We put it on
    // an external backing store so that we can freeze the whole object.
    // This can be replaced with a WeakMap once they are implemented in
    // commonly used development environments.
    element._store = {}; // To make comparing ReactElements easier for testing purposes, we make
    // the validation flag non-enumerable (where possible, which should
    // include every environment we run tests in), so the test framework
    // ignores it.

    Object.defineProperty(element._store, 'validated', {
      configurable: false,
      enumerable: false,
      writable: true,
      value: false
    }); // self and source are DEV only properties.

    Object.defineProperty(element, '_self', {
      configurable: false,
      enumerable: false,
      writable: false,
      value: self
    }); // Two elements created in two different places should be considered
    // equal for testing purposes and therefore we hide it from enumeration.

    Object.defineProperty(element, '_source', {
      configurable: false,
      enumerable: false,
      writable: false,
      value: source
    });

    if (Object.freeze) {
      Object.freeze(element.props);
      Object.freeze(element);
    }
  }

  return element;
};
/**
 * Create and return a new ReactElement of the given type.
 * See https://reactjs.org/docs/react-api.html#createelement
 */

function createElement(type, config, children) {
  var propName; // Reserved names are extracted

  var props = {};
  var key = null;
  var ref = null;
  var self = null;
  var source = null;

  if (config != null) {
    if (hasValidRef(config)) {
      ref = config.ref;

      {
        warnIfStringRefCannotBeAutoConverted(config);
      }
    }

    if (hasValidKey(config)) {
      {
        checkKeyStringCoercion(config.key);
      }

      key = '' + config.key;
    }

    self = config.__self === undefined ? null : config.__self;
    source = config.__source === undefined ? null : config.__source; // Remaining properties are added to a new props object

    for (propName in config) {
      if (hasOwnProperty.call(config, propName) && !RESERVED_PROPS.hasOwnProperty(propName)) {
        props[propName] = config[propName];
      }
    }
  } // Children can be more than one argument, and those are transferred onto
  // the newly allocated props object.


  var childrenLength = arguments.length - 2;

  if (childrenLength === 1) {
    props.children = children;
  } else if (childrenLength > 1) {
    var childArray = Array(childrenLength);

    for (var i = 0; i < childrenLength; i++) {
      childArray[i] = arguments[i + 2];
    }

    {
      if (Object.freeze) {
        Object.freeze(childArray);
      }
    }

    props.children = childArray;
  } // Resolve default props


  if (type && type.defaultProps) {
    var defaultProps = type.defaultProps;

    for (propName in defaultProps) {
      if (props[propName] === undefined) {
        props[propName] = defaultProps[propName];
      }
    }
  }

  {
    if (key || ref) {
      var displayName = typeof type === 'function' ? type.displayName || type.name || 'Unknown' : type;

      if (key) {
        defineKeyPropWarningGetter(props, displayName);
      }

      if (ref) {
        defineRefPropWarningGetter(props, displayName);
      }
    }
  }

  return ReactElement(type, key, ref, self, source, ReactCurrentOwner.current, props);
}
function cloneAndReplaceKey(oldElement, newKey) {
  var newElement = ReactElement(oldElement.type, newKey, oldElement.ref, oldElement._self, oldElement._source, oldElement._owner, oldElement.props);
  return newElement;
}
/**
 * Clone and return a new ReactElement using element as the starting point.
 * See https://reactjs.org/docs/react-api.html#cloneelement
 */

function cloneElement(element, config, children) {
  if (element === null || element === undefined) {
    throw new Error("React.cloneElement(...): The argument must be a React element, but you passed " + element + ".");
  }

  var propName; // Original props are copied

  var props = assign({}, element.props); // Reserved names are extracted

  var key = element.key;
  var ref = element.ref; // Self is preserved since the owner is preserved.

  var self = element._self; // Source is preserved since cloneElement is unlikely to be targeted by a
  // transpiler, and the original source is probably a better indicator of the
  // true owner.

  var source = element._source; // Owner will be preserved, unless ref is overridden

  var owner = element._owner;

  if (config != null) {
    if (hasValidRef(config)) {
      // Silently steal the ref from the parent.
      ref = config.ref;
      owner = ReactCurrentOwner.current;
    }

    if (hasValidKey(config)) {
      {
        checkKeyStringCoercion(config.key);
      }

      key = '' + config.key;
    } // Remaining properties override existing props


    var defaultProps;

    if (element.type && element.type.defaultProps) {
      defaultProps = element.type.defaultProps;
    }

    for (propName in config) {
      if (hasOwnProperty.call(config, propName) && !RESERVED_PROPS.hasOwnProperty(propName)) {
        if (config[propName] === undefined && defaultProps !== undefined) {
          // Resolve default props
          props[propName] = defaultProps[propName];
        } else {
          props[propName] = config[propName];
        }
      }
    }
  } // Children can be more than one argument, and those are transferred onto
  // the newly allocated props object.


  var childrenLength = arguments.length - 2;

  if (childrenLength === 1) {
    props.children = children;
  } else if (childrenLength > 1) {
    var childArray = Array(childrenLength);

    for (var i = 0; i < childrenLength; i++) {
      childArray[i] = arguments[i + 2];
    }

    props.children = childArray;
  }

  return ReactElement(element.type, key, ref, self, source, owner, props);
}
/**
 * Verifies the object is a ReactElement.
 * See https://reactjs.org/docs/react-api.html#isvalidelement
 * @param {?object} object
 * @return {boolean} True if `object` is a ReactElement.
 * @final
 */

function isValidElement(object) {
  return typeof object === 'object' && object !== null && object.$$typeof === REACT_ELEMENT_TYPE;
}

var SEPARATOR = '.';
var SUBSEPARATOR = ':';
/**
 * Escape and wrap key so it is safe to use as a reactid
 *
 * @param {string} key to be escaped.
 * @return {string} the escaped key.
 */

function escape(key) {
  var escapeRegex = /[=:]/g;
  var escaperLookup = {
    '=': '=0',
    ':': '=2'
  };
  var escapedString = key.replace(escapeRegex, function (match) {
    return escaperLookup[match];
  });
  return '$' + escapedString;
}
/**
 * TODO: Test that a single child and an array with one item have the same key
 * pattern.
 */


var didWarnAboutMaps = false;
var userProvidedKeyEscapeRegex = /\/+/g;

function escapeUserProvidedKey(text) {
  return text.replace(userProvidedKeyEscapeRegex, '$&/');
}
/**
 * Generate a key string that identifies a element within a set.
 *
 * @param {*} element A element that could contain a manual key.
 * @param {number} index Index that is used if a manual key is not provided.
 * @return {string}
 */


function getElementKey(element, index) {
  // Do some typechecking here since we call this blindly. We want to ensure
  // that we don't block potential future ES APIs.
  if (typeof element === 'object' && element !== null && element.key != null) {
    // Explicit key
    {
      checkKeyStringCoercion(element.key);
    }

    return escape('' + element.key);
  } // Implicit key determined by the index in the set


  return index.toString(36);
}

function mapIntoArray(children, array, escapedPrefix, nameSoFar, callback) {
  var type = typeof children;

  if (type === 'undefined' || type === 'boolean') {
    // All of the above are perceived as null.
    children = null;
  }

  var invokeCallback = false;

  if (children === null) {
    invokeCallback = true;
  } else {
    switch (type) {
      case 'string':
      case 'number':
        invokeCallback = true;
        break;

      case 'object':
        switch (children.$$typeof) {
          case REACT_ELEMENT_TYPE:
          case REACT_PORTAL_TYPE:
            invokeCallback = true;
        }

    }
  }

  if (invokeCallback) {
    var _child = children;
    var mappedChild = callback(_child); // If it's the only child, treat the name as if it was wrapped in an array
    // so that it's consistent if the number of children grows:

    var childKey = nameSoFar === '' ? SEPARATOR + getElementKey(_child, 0) : nameSoFar;

    if (isArray(mappedChild)) {
      var escapedChildKey = '';

      if (childKey != null) {
        escapedChildKey = escapeUserProvidedKey(childKey) + '/';
      }

      mapIntoArray(mappedChild, array, escapedChildKey, '', function (c) {
        return c;
      });
    } else if (mappedChild != null) {
      if (isValidElement(mappedChild)) {
        {
          // The `if` statement here prevents auto-disabling of the safe
          // coercion ESLint rule, so we must manually disable it below.
          // $FlowFixMe Flow incorrectly thinks React.Portal doesn't have a key
          if (mappedChild.key && (!_child || _child.key !== mappedChild.key)) {
            checkKeyStringCoercion(mappedChild.key);
          }
        }

        mappedChild = cloneAndReplaceKey(mappedChild, // Keep both the (mapped) and old keys if they differ, just as
        // traverseAllChildren used to do for objects as children
        escapedPrefix + ( // $FlowFixMe Flow incorrectly thinks React.Portal doesn't have a key
        mappedChild.key && (!_child || _child.key !== mappedChild.key) ? // $FlowFixMe Flow incorrectly thinks existing element's key can be a number
        // eslint-disable-next-line react-internal/safe-string-coercion
        escapeUserProvidedKey('' + mappedChild.key) + '/' : '') + childKey);
      }

      array.push(mappedChild);
    }

    return 1;
  }

  var child;
  var nextName;
  var subtreeCount = 0; // Count of children found in the current subtree.

  var nextNamePrefix = nameSoFar === '' ? SEPARATOR : nameSoFar + SUBSEPARATOR;

  if (isArray(children)) {
    for (var i = 0; i < children.length; i++) {
      child = children[i];
      nextName = nextNamePrefix + getElementKey(child, i);
      subtreeCount += mapIntoArray(child, array, escapedPrefix, nextName, callback);
    }
  } else {
    var iteratorFn = getIteratorFn(children);

    if (typeof iteratorFn === 'function') {
      var iterableChildren = children;

      {
        // Warn about using Maps as children
        if (iteratorFn === iterableChildren.entries) {
          if (!didWarnAboutMaps) {
            warn('Using Maps as children is not supported. ' + 'Use an array of keyed ReactElements instead.');
          }

          didWarnAboutMaps = true;
        }
      }

      var iterator = iteratorFn.call(iterableChildren);
      var step;
      var ii = 0;

      while (!(step = iterator.next()).done) {
        child = step.value;
        nextName = nextNamePrefix + getElementKey(child, ii++);
        subtreeCount += mapIntoArray(child, array, escapedPrefix, nextName, callback);
      }
    } else if (type === 'object') {
      // eslint-disable-next-line react-internal/safe-string-coercion
      var childrenString = String(children);
      throw new Error("Objects are not valid as a React child (found: " + (childrenString === '[object Object]' ? 'object with keys {' + Object.keys(children).join(', ') + '}' : childrenString) + "). " + 'If you meant to render a collection of children, use an array ' + 'instead.');
    }
  }

  return subtreeCount;
}

/**
 * Maps children that are typically specified as `props.children`.
 *
 * See https://reactjs.org/docs/react-api.html#reactchildrenmap
 *
 * The provided mapFunction(child, index) will be called for each
 * leaf child.
 *
 * @param {?*} children Children tree container.
 * @param {function(*, int)} func The map function.
 * @param {*} context Context for mapFunction.
 * @return {object} Object containing the ordered map of results.
 */
function mapChildren(children, func, context) {
  if (children == null) {
    return children;
  }

  var result = [];
  var count = 0;
  mapIntoArray(children, result, '', '', function (child) {
    return func.call(context, child, count++);
  });
  return result;
}
/**
 * Count the number of children that are typically specified as
 * `props.children`.
 *
 * See https://reactjs.org/docs/react-api.html#reactchildrencount
 *
 * @param {?*} children Children tree container.
 * @return {number} The number of children.
 */


function countChildren(children) {
  var n = 0;
  mapChildren(children, function () {
    n++; // Don't return anything
  });
  return n;
}

/**
 * Iterates through children that are typically specified as `props.children`.
 *
 * See https://reactjs.org/docs/react-api.html#reactchildrenforeach
 *
 * The provided forEachFunc(child, index) will be called for each
 * leaf child.
 *
 * @param {?*} children Children tree container.
 * @param {function(*, int)} forEachFunc
 * @param {*} forEachContext Context for forEachContext.
 */
function forEachChildren(children, forEachFunc, forEachContext) {
  mapChildren(children, function () {
    forEachFunc.apply(this, arguments); // Don't return anything.
  }, forEachContext);
}
/**
 * Flatten a children object (typically specified as `props.children`) and
 * return an array with appropriately re-keyed children.
 *
 * See https://reactjs.org/docs/react-api.html#reactchildrentoarray
 */


function toArray(children) {
  return mapChildren(children, function (child) {
    return child;
  }) || [];
}
/**
 * Returns the first child in a collection of children and verifies that there
 * is only one child in the collection.
 *
 * See https://reactjs.org/docs/react-api.html#reactchildrenonly
 *
 * The current implementation of this function assumes that a single child gets
 * passed without a wrapper, but the purpose of this helper function is to
 * abstract away the particular structure of children.
 *
 * @param {?object} children Child collection structure.
 * @return {ReactElement} The first and only `ReactElement` contained in the
 * structure.
 */


function onlyChild(children) {
  if (!isValidElement(children)) {
    throw new Error('React.Children.only expected to receive a single React element child.');
  }

  return children;
}

function createContext(defaultValue) {
  // TODO: Second argument used to be an optional `calculateChangedBits`
  // function. Warn to reserve for future use?
  var context = {
    $$typeof: REACT_CONTEXT_TYPE,
    // As a workaround to support multiple concurrent renderers, we categorize
    // some renderers as primary and others as secondary. We only expect
    // there to be two concurrent renderers at most: React Native (primary) and
    // Fabric (secondary); React DOM (primary) and React ART (secondary).
    // Secondary renderers store their context values on separate fields.
    _currentValue: defaultValue,
    _currentValue2: defaultValue,
    // Used to track how many concurrent renderers this context currently
    // supports within in a single renderer. Such as parallel server rendering.
    _threadCount: 0,
    // These are circular
    Provider: null,
    Consumer: null,
    // Add these to use same hidden class in VM as ServerContext
    _defaultValue: null,
    _globalName: null
  };
  context.Provider = {
    $$typeof: REACT_PROVIDER_TYPE,
    _context: context
  };
  var hasWarnedAboutUsingNestedContextConsumers = false;
  var hasWarnedAboutUsingConsumerProvider = false;
  var hasWarnedAboutDisplayNameOnConsumer = false;

  {
    // A separate object, but proxies back to the original context object for
    // backwards compatibility. It has a different $$typeof, so we can properly
    // warn for the incorrect usage of Context as a Consumer.
    var Consumer = {
      $$typeof: REACT_CONTEXT_TYPE,
      _context: context
    }; // $FlowFixMe: Flow complains about not setting a value, which is intentional here

    Object.defineProperties(Consumer, {
      Provider: {
        get: function () {
          if (!hasWarnedAboutUsingConsumerProvider) {
            hasWarnedAboutUsingConsumerProvider = true;

            error('Rendering <Context.Consumer.Provider> is not supported and will be removed in ' + 'a future major release. Did you mean to render <Context.Provider> instead?');
          }

          return context.Provider;
        },
        set: function (_Provider) {
          context.Provider = _Provider;
        }
      },
      _currentValue: {
        get: function () {
          return context._currentValue;
        },
        set: function (_currentValue) {
          context._currentValue = _currentValue;
        }
      },
      _currentValue2: {
        get: function () {
          return context._currentValue2;
        },
        set: function (_currentValue2) {
          context._currentValue2 = _currentValue2;
        }
      },
      _threadCount: {
        get: function () {
          return context._threadCount;
        },
        set: function (_threadCount) {
          context._threadCount = _threadCount;
        }
      },
      Consumer: {
        get: function () {
          if (!hasWarnedAboutUsingNestedContextConsumers) {
            hasWarnedAboutUsingNestedContextConsumers = true;

            error('Rendering <Context.Consumer.Consumer> is not supported and will be removed in ' + 'a future major release. Did you mean to render <Context.Consumer> instead?');
          }

          return context.Consumer;
        }
      },
      displayName: {
        get: function () {
          return context.displayName;
        },
        set: function (displayName) {
          if (!hasWarnedAboutDisplayNameOnConsumer) {
            warn('Setting `displayName` on Context.Consumer has no effect. ' + "You should set it directly on the context with Context.displayName = '%s'.", displayName);

            hasWarnedAboutDisplayNameOnConsumer = true;
          }
        }
      }
    }); // $FlowFixMe: Flow complains about missing properties because it doesn't understand defineProperty

    context.Consumer = Consumer;
  }

  {
    context._currentRenderer = null;
    context._currentRenderer2 = null;
  }

  return context;
}

var Uninitialized = -1;
var Pending = 0;
var Resolved = 1;
var Rejected = 2;

function lazyInitializer(payload) {
  if (payload._status === Uninitialized) {
    var ctor = payload._result;
    var thenable = ctor(); // Transition to the next state.
    // This might throw either because it's missing or throws. If so, we treat it
    // as still uninitialized and try again next time. Which is the same as what
    // happens if the ctor or any wrappers processing the ctor throws. This might
    // end up fixing it if the resolution was a concurrency bug.

    thenable.then(function (moduleObject) {
      if (payload._status === Pending || payload._status === Uninitialized) {
        // Transition to the next state.
        var resolved = payload;
        resolved._status = Resolved;
        resolved._result = moduleObject;
      }
    }, function (error) {
      if (payload._status === Pending || payload._status === Uninitialized) {
        // Transition to the next state.
        var rejected = payload;
        rejected._status = Rejected;
        rejected._result = error;
      }
    });

    if (payload._status === Uninitialized) {
      // In case, we're still uninitialized, then we're waiting for the thenable
      // to resolve. Set it as pending in the meantime.
      var pending = payload;
      pending._status = Pending;
      pending._result = thenable;
    }
  }

  if (payload._status === Resolved) {
    var moduleObject = payload._result;

    {
      if (moduleObject === undefined) {
        error('lazy: Expected the result of a dynamic imp' + 'ort() call. ' + 'Instead received: %s\n\nYour code should look like: \n  ' + // Break up imports to avoid accidentally parsing them as dependencies.
        'const MyComponent = lazy(() => imp' + "ort('./MyComponent'))\n\n" + 'Did you accidentally put curly braces around the import?', moduleObject);
      }
    }

    {
      if (!('default' in moduleObject)) {
        error('lazy: Expected the result of a dynamic imp' + 'ort() call. ' + 'Instead received: %s\n\nYour code should look like: \n  ' + // Break up imports to avoid accidentally parsing them as dependencies.
        'const MyComponent = lazy(() => imp' + "ort('./MyComponent'))", moduleObject);
      }
    }

    return moduleObject.default;
  } else {
    throw payload._result;
  }
}

function lazy(ctor) {
  var payload = {
    // We use these fields to store the result.
    _status: Uninitialized,
    _result: ctor
  };
  var lazyType = {
    $$typeof: REACT_LAZY_TYPE,
    _payload: payload,
    _init: lazyInitializer
  };

  {
    // In production, this would just set it on the object.
    var defaultProps;
    var propTypes; // $FlowFixMe

    Object.defineProperties(lazyType, {
      defaultProps: {
        configurable: true,
        get: function () {
          return defaultProps;
        },
        set: function (newDefaultProps) {
          error('React.lazy(...): It is not supported to assign `defaultProps` to ' + 'a lazy component import. Either specify them where the component ' + 'is defined, or create a wrapping component around it.');

          defaultProps = newDefaultProps; // Match production behavior more closely:
          // $FlowFixMe

          Object.defineProperty(lazyType, 'defaultProps', {
            enumerable: true
          });
        }
      },
      propTypes: {
        configurable: true,
        get: function () {
          return propTypes;
        },
        set: function (newPropTypes) {
          error('React.lazy(...): It is not supported to assign `propTypes` to ' + 'a lazy component import. Either specify them where the component ' + 'is defined, or create a wrapping component around it.');

          propTypes = newPropTypes; // Match production behavior more closely:
          // $FlowFixMe

          Object.defineProperty(lazyType, 'propTypes', {
            enumerable: true
          });
        }
      }
    });
  }

  return lazyType;
}

function forwardRef(render) {
  {
    if (render != null && render.$$typeof === REACT_MEMO_TYPE) {
      error('forwardRef requires a render function but received a `memo` ' + 'component. Instead of forwardRef(memo(...)), use ' + 'memo(forwardRef(...)).');
    } else if (typeof render !== 'function') {
      error('forwardRef requires a render function but was given %s.', render === null ? 'null' : typeof render);
    } else {
      if (render.length !== 0 && render.length !== 2) {
        error('forwardRef render functions accept exactly two parameters: props and ref. %s', render.length === 1 ? 'Did you forget to use the ref parameter?' : 'Any additional parameter will be undefined.');
      }
    }

    if (render != null) {
      if (render.defaultProps != null || render.propTypes != null) {
        error('forwardRef render functions do not support propTypes or defaultProps. ' + 'Did you accidentally pass a React component?');
      }
    }
  }

  var elementType = {
    $$typeof: REACT_FORWARD_REF_TYPE,
    render: render
  };

  {
    var ownName;
    Object.defineProperty(elementType, 'displayName', {
      enumerable: false,
      configurable: true,
      get: function () {
        return ownName;
      },
      set: function (name) {
        ownName = name; // The inner component shouldn't inherit this display name in most cases,
        // because the component may be used elsewhere.
        // But it's nice for anonymous functions to inherit the name,
        // so that our component-stack generation logic will display their frames.
        // An anonymous function generally suggests a pattern like:
        //   React.forwardRef((props, ref) => {...});
        // This kind of inner function is not used elsewhere so the side effect is okay.

        if (!render.name && !render.displayName) {
          render.displayName = name;
        }
      }
    });
  }

  return elementType;
}

var REACT_MODULE_REFERENCE;

{
  REACT_MODULE_REFERENCE = Symbol.for('react.module.reference');
}

function isValidElementType(type) {
  if (typeof type === 'string' || typeof type === 'function') {
    return true;
  } // Note: typeof might be other than 'symbol' or 'number' (e.g. if it's a polyfill).


  if (type === REACT_FRAGMENT_TYPE || type === REACT_PROFILER_TYPE || enableDebugTracing  || type === REACT_STRICT_MODE_TYPE || type === REACT_SUSPENSE_TYPE || type === REACT_SUSPENSE_LIST_TYPE || enableLegacyHidden  || type === REACT_OFFSCREEN_TYPE || enableScopeAPI  || enableCacheElement  || enableTransitionTracing ) {
    return true;
  }

  if (typeof type === 'object' && type !== null) {
    if (type.$$typeof === REACT_LAZY_TYPE || type.$$typeof === REACT_MEMO_TYPE || type.$$typeof === REACT_PROVIDER_TYPE || type.$$typeof === REACT_CONTEXT_TYPE || type.$$typeof === REACT_FORWARD_REF_TYPE || // This needs to include all possible module reference object
    // types supported by any Flight configuration anywhere since
    // we don't know which Flight build this will end up being used
    // with.
    type.$$typeof === REACT_MODULE_REFERENCE || type.getModuleId !== undefined) {
      return true;
    }
  }

  return false;
}

function memo(type, compare) {
  {
    if (!isValidElementType(type)) {
      error('memo: The first argument must be a component. Instead ' + 'received: %s', type === null ? 'null' : typeof type);
    }
  }

  var elementType = {
    $$typeof: REACT_MEMO_TYPE,
    type: type,
    compare: compare === undefined ? null : compare
  };

  {
    var ownName;
    Object.defineProperty(elementType, 'displayName', {
      enumerable: false,
      configurable: true,
      get: function () {
        return ownName;
      },
      set: function (name) {
        ownName = name; // The inner component shouldn't inherit this display name in most cases,
        // because the component may be used elsewhere.
        // But it's nice for anonymous functions to inherit the name,
        // so that our component-stack generation logic will display their frames.
        // An anonymous function generally suggests a pattern like:
        //   React.memo((props) => {...});
        // This kind of inner function is not used elsewhere so the side effect is okay.

        if (!type.name && !type.displayName) {
          type.displayName = name;
        }
      }
    });
  }

  return elementType;
}

function resolveDispatcher() {
  var dispatcher = ReactCurrentDispatcher.current;

  {
    if (dispatcher === null) {
      error('Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for' + ' one of the following reasons:\n' + '1. You might have mismatching versions of React and the renderer (such as React DOM)\n' + '2. You might be breaking the Rules of Hooks\n' + '3. You might have more than one copy of React in the same app\n' + 'See https://reactjs.org/link/invalid-hook-call for tips about how to debug and fix this problem.');
    }
  } // Will result in a null access error if accessed outside render phase. We
  // intentionally don't throw our own error because this is in a hot path.
  // Also helps ensure this is inlined.


  return dispatcher;
}
function useContext(Context) {
  var dispatcher = resolveDispatcher();

  {
    // TODO: add a more generic warning for invalid values.
    if (Context._context !== undefined) {
      var realContext = Context._context; // Don't deduplicate because this legitimately causes bugs
      // and nobody should be using this in existing code.

      if (realContext.Consumer === Context) {
        error('Calling useContext(Context.Consumer) is not supported, may cause bugs, and will be ' + 'removed in a future major release. Did you mean to call useContext(Context) instead?');
      } else if (realContext.Provider === Context) {
        error('Calling useContext(Context.Provider) is not supported. ' + 'Did you mean to call useContext(Context) instead?');
      }
    }
  }

  return dispatcher.useContext(Context);
}
function useState(initialState) {
  var dispatcher = resolveDispatcher();
  return dispatcher.useState(initialState);
}
function useReducer(reducer, initialArg, init) {
  var dispatcher = resolveDispatcher();
  return dispatcher.useReducer(reducer, initialArg, init);
}
function useRef(initialValue) {
  var dispatcher = resolveDispatcher();
  return dispatcher.useRef(initialValue);
}
function useEffect(create, deps) {
  var dispatcher = resolveDispatcher();
  return dispatcher.useEffect(create, deps);
}
function useInsertionEffect(create, deps) {
  var dispatcher = resolveDispatcher();
  return dispatcher.useInsertionEffect(create, deps);
}
function useLayoutEffect(create, deps) {
  var dispatcher = resolveDispatcher();
  return dispatcher.useLayoutEffect(create, deps);
}
function useCallback(callback, deps) {
  var dispatcher = resolveDispatcher();
  return dispatcher.useCallback(callback, deps);
}
function useMemo(create, deps) {
  var dispatcher = resolveDispatcher();
  return dispatcher.useMemo(create, deps);
}
function useImperativeHandle(ref, create, deps) {
  var dispatcher = resolveDispatcher();
  return dispatcher.useImperativeHandle(ref, create, deps);
}
function useDebugValue(value, formatterFn) {
  {
    var dispatcher = resolveDispatcher();
    return dispatcher.useDebugValue(value, formatterFn);
  }
}
function useTransition() {
  var dispatcher = resolveDispatcher();
  return dispatcher.useTransition();
}
function useDeferredValue(value) {
  var dispatcher = resolveDispatcher();
  return dispatcher.useDeferredValue(value);
}
function useId() {
  var dispatcher = resolveDispatcher();
  return dispatcher.useId();
}
function useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot) {
  var dispatcher = resolveDispatcher();
  return dispatcher.useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
}

// Helpers to patch console.logs to avoid logging during side-effect free
// replaying on render function. This currently only patches the object
// lazily which won't cover if the log function was extracted eagerly.
// We could also eagerly patch the method.
var disabledDepth = 0;
var prevLog;
var prevInfo;
var prevWarn;
var prevError;
var prevGroup;
var prevGroupCollapsed;
var prevGroupEnd;

function disabledLog() {}

disabledLog.__reactDisabledLog = true;
function disableLogs() {
  {
    if (disabledDepth === 0) {
      /* eslint-disable react-internal/no-production-logging */
      prevLog = console.log;
      prevInfo = console.info;
      prevWarn = console.warn;
      prevError = console.error;
      prevGroup = console.group;
      prevGroupCollapsed = console.groupCollapsed;
      prevGroupEnd = console.groupEnd; // https://github.com/facebook/react/issues/19099

      var props = {
        configurable: true,
        enumerable: true,
        value: disabledLog,
        writable: true
      }; // $FlowFixMe Flow thinks console is immutable.

      Object.defineProperties(console, {
        info: props,
        log: props,
        warn: props,
        error: props,
        group: props,
        groupCollapsed: props,
        groupEnd: props
      });
      /* eslint-enable react-internal/no-production-logging */
    }

    disabledDepth++;
  }
}
function reenableLogs() {
  {
    disabledDepth--;

    if (disabledDepth === 0) {
      /* eslint-disable react-internal/no-production-logging */
      var props = {
        configurable: true,
        enumerable: true,
        writable: true
      }; // $FlowFixMe Flow thinks console is immutable.

      Object.defineProperties(console, {
        log: assign({}, props, {
          value: prevLog
        }),
        info: assign({}, props, {
          value: prevInfo
        }),
        warn: assign({}, props, {
          value: prevWarn
        }),
        error: assign({}, props, {
          value: prevError
        }),
        group: assign({}, props, {
          value: prevGroup
        }),
        groupCollapsed: assign({}, props, {
          value: prevGroupCollapsed
        }),
        groupEnd: assign({}, props, {
          value: prevGroupEnd
        })
      });
      /* eslint-enable react-internal/no-production-logging */
    }

    if (disabledDepth < 0) {
      error('disabledDepth fell below zero. ' + 'This is a bug in React. Please file an issue.');
    }
  }
}

var ReactCurrentDispatcher$1 = ReactSharedInternals.ReactCurrentDispatcher;
var prefix;
function describeBuiltInComponentFrame(name, source, ownerFn) {
  {
    if (prefix === undefined) {
      // Extract the VM specific prefix used by each line.
      try {
        throw Error();
      } catch (x) {
        var match = x.stack.trim().match(/\n( *(at )?)/);
        prefix = match && match[1] || '';
      }
    } // We use the prefix to ensure our stacks line up with native stack frames.


    return '\n' + prefix + name;
  }
}
var reentry = false;
var componentFrameCache;

{
  var PossiblyWeakMap = typeof WeakMap === 'function' ? WeakMap : Map;
  componentFrameCache = new PossiblyWeakMap();
}

function describeNativeComponentFrame(fn, construct) {
  // If something asked for a stack inside a fake render, it should get ignored.
  if ( !fn || reentry) {
    return '';
  }

  {
    var frame = componentFrameCache.get(fn);

    if (frame !== undefined) {
      return frame;
    }
  }

  var control;
  reentry = true;
  var previousPrepareStackTrace = Error.prepareStackTrace; // $FlowFixMe It does accept undefined.

  Error.prepareStackTrace = undefined;
  var previousDispatcher;

  {
    previousDispatcher = ReactCurrentDispatcher$1.current; // Set the dispatcher in DEV because this might be call in the render function
    // for warnings.

    ReactCurrentDispatcher$1.current = null;
    disableLogs();
  }

  try {
    // This should throw.
    if (construct) {
      // Something should be setting the props in the constructor.
      var Fake = function () {
        throw Error();
      }; // $FlowFixMe


      Object.defineProperty(Fake.prototype, 'props', {
        set: function () {
          // We use a throwing setter instead of frozen or non-writable props
          // because that won't throw in a non-strict mode function.
          throw Error();
        }
      });

      if (typeof Reflect === 'object' && Reflect.construct) {
        // We construct a different control for this case to include any extra
        // frames added by the construct call.
        try {
          Reflect.construct(Fake, []);
        } catch (x) {
          control = x;
        }

        Reflect.construct(fn, [], Fake);
      } else {
        try {
          Fake.call();
        } catch (x) {
          control = x;
        }

        fn.call(Fake.prototype);
      }
    } else {
      try {
        throw Error();
      } catch (x) {
        control = x;
      }

      fn();
    }
  } catch (sample) {
    // This is inlined manually because closure doesn't do it for us.
    if (sample && control && typeof sample.stack === 'string') {
      // This extracts the first frame from the sample that isn't also in the control.
      // Skipping one frame that we assume is the frame that calls the two.
      var sampleLines = sample.stack.split('\n');
      var controlLines = control.stack.split('\n');
      var s = sampleLines.length - 1;
      var c = controlLines.length - 1;

      while (s >= 1 && c >= 0 && sampleLines[s] !== controlLines[c]) {
        // We expect at least one stack frame to be shared.
        // Typically this will be the root most one. However, stack frames may be
        // cut off due to maximum stack limits. In this case, one maybe cut off
        // earlier than the other. We assume that the sample is longer or the same
        // and there for cut off earlier. So we should find the root most frame in
        // the sample somewhere in the control.
        c--;
      }

      for (; s >= 1 && c >= 0; s--, c--) {
        // Next we find the first one that isn't the same which should be the
        // frame that called our sample function and the control.
        if (sampleLines[s] !== controlLines[c]) {
          // In V8, the first line is describing the message but other VMs don't.
          // If we're about to return the first line, and the control is also on the same
          // line, that's a pretty good indicator that our sample threw at same line as
          // the control. I.e. before we entered the sample frame. So we ignore this result.
          // This can happen if you passed a class to function component, or non-function.
          if (s !== 1 || c !== 1) {
            do {
              s--;
              c--; // We may still have similar intermediate frames from the construct call.
              // The next one that isn't the same should be our match though.

              if (c < 0 || sampleLines[s] !== controlLines[c]) {
                // V8 adds a "new" prefix for native classes. Let's remove it to make it prettier.
                var _frame = '\n' + sampleLines[s].replace(' at new ', ' at '); // If our component frame is labeled "<anonymous>"
                // but we have a user-provided "displayName"
                // splice it in to make the stack more readable.


                if (fn.displayName && _frame.includes('<anonymous>')) {
                  _frame = _frame.replace('<anonymous>', fn.displayName);
                }

                {
                  if (typeof fn === 'function') {
                    componentFrameCache.set(fn, _frame);
                  }
                } // Return the line we found.


                return _frame;
              }
            } while (s >= 1 && c >= 0);
          }

          break;
        }
      }
    }
  } finally {
    reentry = false;

    {
      ReactCurrentDispatcher$1.current = previousDispatcher;
      reenableLogs();
    }

    Error.prepareStackTrace = previousPrepareStackTrace;
  } // Fallback to just using the name if we couldn't make it throw.


  var name = fn ? fn.displayName || fn.name : '';
  var syntheticFrame = name ? describeBuiltInComponentFrame(name) : '';

  {
    if (typeof fn === 'function') {
      componentFrameCache.set(fn, syntheticFrame);
    }
  }

  return syntheticFrame;
}
function describeFunctionComponentFrame(fn, source, ownerFn) {
  {
    return describeNativeComponentFrame(fn, false);
  }
}

function shouldConstruct(Component) {
  var prototype = Component.prototype;
  return !!(prototype && prototype.isReactComponent);
}

function describeUnknownElementTypeFrameInDEV(type, source, ownerFn) {

  if (type == null) {
    return '';
  }

  if (typeof type === 'function') {
    {
      return describeNativeComponentFrame(type, shouldConstruct(type));
    }
  }

  if (typeof type === 'string') {
    return describeBuiltInComponentFrame(type);
  }

  switch (type) {
    case REACT_SUSPENSE_TYPE:
      return describeBuiltInComponentFrame('Suspense');

    case REACT_SUSPENSE_LIST_TYPE:
      return describeBuiltInComponentFrame('SuspenseList');
  }

  if (typeof type === 'object') {
    switch (type.$$typeof) {
      case REACT_FORWARD_REF_TYPE:
        return describeFunctionComponentFrame(type.render);

      case REACT_MEMO_TYPE:
        // Memo may contain any component type so we recursively resolve it.
        return describeUnknownElementTypeFrameInDEV(type.type, source, ownerFn);

      case REACT_LAZY_TYPE:
        {
          var lazyComponent = type;
          var payload = lazyComponent._payload;
          var init = lazyComponent._init;

          try {
            // Lazy may contain any component type so we recursively resolve it.
            return describeUnknownElementTypeFrameInDEV(init(payload), source, ownerFn);
          } catch (x) {}
        }
    }
  }

  return '';
}

var loggedTypeFailures = {};
var ReactDebugCurrentFrame$1 = ReactSharedInternals.ReactDebugCurrentFrame;

function setCurrentlyValidatingElement(element) {
  {
    if (element) {
      var owner = element._owner;
      var stack = describeUnknownElementTypeFrameInDEV(element.type, element._source, owner ? owner.type : null);
      ReactDebugCurrentFrame$1.setExtraStackFrame(stack);
    } else {
      ReactDebugCurrentFrame$1.setExtraStackFrame(null);
    }
  }
}

function checkPropTypes(typeSpecs, values, location, componentName, element) {
  {
    // $FlowFixMe This is okay but Flow doesn't know it.
    var has = Function.call.bind(hasOwnProperty);

    for (var typeSpecName in typeSpecs) {
      if (has(typeSpecs, typeSpecName)) {
        var error$1 = void 0; // Prop type validation may throw. In case they do, we don't want to
        // fail the render phase where it didn't fail before. So we log it.
        // After these have been cleaned up, we'll let them throw.

        try {
          // This is intentionally an invariant that gets caught. It's the same
          // behavior as without this statement except with a better message.
          if (typeof typeSpecs[typeSpecName] !== 'function') {
            // eslint-disable-next-line react-internal/prod-error-codes
            var err = Error((componentName || 'React class') + ': ' + location + ' type `' + typeSpecName + '` is invalid; ' + 'it must be a function, usually from the `prop-types` package, but received `' + typeof typeSpecs[typeSpecName] + '`.' + 'This often happens because of typos such as `PropTypes.function` instead of `PropTypes.func`.');
            err.name = 'Invariant Violation';
            throw err;
          }

          error$1 = typeSpecs[typeSpecName](values, typeSpecName, componentName, location, null, 'SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED');
        } catch (ex) {
          error$1 = ex;
        }

        if (error$1 && !(error$1 instanceof Error)) {
          setCurrentlyValidatingElement(element);

          error('%s: type specification of %s' + ' `%s` is invalid; the type checker ' + 'function must return `null` or an `Error` but returned a %s. ' + 'You may have forgotten to pass an argument to the type checker ' + 'creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and ' + 'shape all require an argument).', componentName || 'React class', location, typeSpecName, typeof error$1);

          setCurrentlyValidatingElement(null);
        }

        if (error$1 instanceof Error && !(error$1.message in loggedTypeFailures)) {
          // Only monitor this failure once because there tends to be a lot of the
          // same error.
          loggedTypeFailures[error$1.message] = true;
          setCurrentlyValidatingElement(element);

          error('Failed %s type: %s', location, error$1.message);

          setCurrentlyValidatingElement(null);
        }
      }
    }
  }
}

function setCurrentlyValidatingElement$1(element) {
  {
    if (element) {
      var owner = element._owner;
      var stack = describeUnknownElementTypeFrameInDEV(element.type, element._source, owner ? owner.type : null);
      setExtraStackFrame(stack);
    } else {
      setExtraStackFrame(null);
    }
  }
}

var propTypesMisspellWarningShown;

{
  propTypesMisspellWarningShown = false;
}

function getDeclarationErrorAddendum() {
  if (ReactCurrentOwner.current) {
    var name = getComponentNameFromType(ReactCurrentOwner.current.type);

    if (name) {
      return '\n\nCheck the render method of `' + name + '`.';
    }
  }

  return '';
}

function getSourceInfoErrorAddendum(source) {
  if (source !== undefined) {
    var fileName = source.fileName.replace(/^.*[\\\/]/, '');
    var lineNumber = source.lineNumber;
    return '\n\nCheck your code at ' + fileName + ':' + lineNumber + '.';
  }

  return '';
}

function getSourceInfoErrorAddendumForProps(elementProps) {
  if (elementProps !== null && elementProps !== undefined) {
    return getSourceInfoErrorAddendum(elementProps.__source);
  }

  return '';
}
/**
 * Warn if there's no key explicitly set on dynamic arrays of children or
 * object keys are not valid. This allows us to keep track of children between
 * updates.
 */


var ownerHasKeyUseWarning = {};

function getCurrentComponentErrorInfo(parentType) {
  var info = getDeclarationErrorAddendum();

  if (!info) {
    var parentName = typeof parentType === 'string' ? parentType : parentType.displayName || parentType.name;

    if (parentName) {
      info = "\n\nCheck the top-level render call using <" + parentName + ">.";
    }
  }

  return info;
}
/**
 * Warn if the element doesn't have an explicit key assigned to it.
 * This element is in an array. The array could grow and shrink or be
 * reordered. All children that haven't already been validated are required to
 * have a "key" property assigned to it. Error statuses are cached so a warning
 * will only be shown once.
 *
 * @internal
 * @param {ReactElement} element Element that requires a key.
 * @param {*} parentType element's parent's type.
 */


function validateExplicitKey(element, parentType) {
  if (!element._store || element._store.validated || element.key != null) {
    return;
  }

  element._store.validated = true;
  var currentComponentErrorInfo = getCurrentComponentErrorInfo(parentType);

  if (ownerHasKeyUseWarning[currentComponentErrorInfo]) {
    return;
  }

  ownerHasKeyUseWarning[currentComponentErrorInfo] = true; // Usually the current owner is the offender, but if it accepts children as a
  // property, it may be the creator of the child that's responsible for
  // assigning it a key.

  var childOwner = '';

  if (element && element._owner && element._owner !== ReactCurrentOwner.current) {
    // Give the component that originally created this child.
    childOwner = " It was passed a child from " + getComponentNameFromType(element._owner.type) + ".";
  }

  {
    setCurrentlyValidatingElement$1(element);

    error('Each child in a list should have a unique "key" prop.' + '%s%s See https://reactjs.org/link/warning-keys for more information.', currentComponentErrorInfo, childOwner);

    setCurrentlyValidatingElement$1(null);
  }
}
/**
 * Ensure that every element either is passed in a static location, in an
 * array with an explicit keys property defined, or in an object literal
 * with valid key property.
 *
 * @internal
 * @param {ReactNode} node Statically passed child of any type.
 * @param {*} parentType node's parent's type.
 */


function validateChildKeys(node, parentType) {
  if (typeof node !== 'object') {
    return;
  }

  if (isArray(node)) {
    for (var i = 0; i < node.length; i++) {
      var child = node[i];

      if (isValidElement(child)) {
        validateExplicitKey(child, parentType);
      }
    }
  } else if (isValidElement(node)) {
    // This element was passed in a valid location.
    if (node._store) {
      node._store.validated = true;
    }
  } else if (node) {
    var iteratorFn = getIteratorFn(node);

    if (typeof iteratorFn === 'function') {
      // Entry iterators used to provide implicit keys,
      // but now we print a separate warning for them later.
      if (iteratorFn !== node.entries) {
        var iterator = iteratorFn.call(node);
        var step;

        while (!(step = iterator.next()).done) {
          if (isValidElement(step.value)) {
            validateExplicitKey(step.value, parentType);
          }
        }
      }
    }
  }
}
/**
 * Given an element, validate that its props follow the propTypes definition,
 * provided by the type.
 *
 * @param {ReactElement} element
 */


function validatePropTypes(element) {
  {
    var type = element.type;

    if (type === null || type === undefined || typeof type === 'string') {
      return;
    }

    var propTypes;

    if (typeof type === 'function') {
      propTypes = type.propTypes;
    } else if (typeof type === 'object' && (type.$$typeof === REACT_FORWARD_REF_TYPE || // Note: Memo only checks outer props here.
    // Inner props are checked in the reconciler.
    type.$$typeof === REACT_MEMO_TYPE)) {
      propTypes = type.propTypes;
    } else {
      return;
    }

    if (propTypes) {
      // Intentionally inside to avoid triggering lazy initializers:
      var name = getComponentNameFromType(type);
      checkPropTypes(propTypes, element.props, 'prop', name, element);
    } else if (type.PropTypes !== undefined && !propTypesMisspellWarningShown) {
      propTypesMisspellWarningShown = true; // Intentionally inside to avoid triggering lazy initializers:

      var _name = getComponentNameFromType(type);

      error('Component %s declared `PropTypes` instead of `propTypes`. Did you misspell the property assignment?', _name || 'Unknown');
    }

    if (typeof type.getDefaultProps === 'function' && !type.getDefaultProps.isReactClassApproved) {
      error('getDefaultProps is only used on classic React.createClass ' + 'definitions. Use a static property named `defaultProps` instead.');
    }
  }
}
/**
 * Given a fragment, validate that it can only be provided with fragment props
 * @param {ReactElement} fragment
 */


function validateFragmentProps(fragment) {
  {
    var keys = Object.keys(fragment.props);

    for (var i = 0; i < keys.length; i++) {
      var key = keys[i];

      if (key !== 'children' && key !== 'key') {
        setCurrentlyValidatingElement$1(fragment);

        error('Invalid prop `%s` supplied to `React.Fragment`. ' + 'React.Fragment can only have `key` and `children` props.', key);

        setCurrentlyValidatingElement$1(null);
        break;
      }
    }

    if (fragment.ref !== null) {
      setCurrentlyValidatingElement$1(fragment);

      error('Invalid attribute `ref` supplied to `React.Fragment`.');

      setCurrentlyValidatingElement$1(null);
    }
  }
}
function createElementWithValidation(type, props, children) {
  var validType = isValidElementType(type); // We warn in this case but don't throw. We expect the element creation to
  // succeed and there will likely be errors in render.

  if (!validType) {
    var info = '';

    if (type === undefined || typeof type === 'object' && type !== null && Object.keys(type).length === 0) {
      info += ' You likely forgot to export your component from the file ' + "it's defined in, or you might have mixed up default and named imports.";
    }

    var sourceInfo = getSourceInfoErrorAddendumForProps(props);

    if (sourceInfo) {
      info += sourceInfo;
    } else {
      info += getDeclarationErrorAddendum();
    }

    var typeString;

    if (type === null) {
      typeString = 'null';
    } else if (isArray(type)) {
      typeString = 'array';
    } else if (type !== undefined && type.$$typeof === REACT_ELEMENT_TYPE) {
      typeString = "<" + (getComponentNameFromType(type.type) || 'Unknown') + " />";
      info = ' Did you accidentally export a JSX literal instead of a component?';
    } else {
      typeString = typeof type;
    }

    {
      error('React.createElement: type is invalid -- expected a string (for ' + 'built-in components) or a class/function (for composite ' + 'components) but got: %s.%s', typeString, info);
    }
  }

  var element = createElement.apply(this, arguments); // The result can be nullish if a mock or a custom function is used.
  // TODO: Drop this when these are no longer allowed as the type argument.

  if (element == null) {
    return element;
  } // Skip key warning if the type isn't valid since our key validation logic
  // doesn't expect a non-string/function type and can throw confusing errors.
  // We don't want exception behavior to differ between dev and prod.
  // (Rendering will throw with a helpful message and as soon as the type is
  // fixed, the key warnings will appear.)


  if (validType) {
    for (var i = 2; i < arguments.length; i++) {
      validateChildKeys(arguments[i], type);
    }
  }

  if (type === REACT_FRAGMENT_TYPE) {
    validateFragmentProps(element);
  } else {
    validatePropTypes(element);
  }

  return element;
}
var didWarnAboutDeprecatedCreateFactory = false;
function createFactoryWithValidation(type) {
  var validatedFactory = createElementWithValidation.bind(null, type);
  validatedFactory.type = type;

  {
    if (!didWarnAboutDeprecatedCreateFactory) {
      didWarnAboutDeprecatedCreateFactory = true;

      warn('React.createFactory() is deprecated and will be removed in ' + 'a future major release. Consider using JSX ' + 'or use React.createElement() directly instead.');
    } // Legacy hook: remove it


    Object.defineProperty(validatedFactory, 'type', {
      enumerable: false,
      get: function () {
        warn('Factory.type is deprecated. Access the class directly ' + 'before passing it to createFactory.');

        Object.defineProperty(this, 'type', {
          value: type
        });
        return type;
      }
    });
  }

  return validatedFactory;
}
function cloneElementWithValidation(element, props, children) {
  var newElement = cloneElement.apply(this, arguments);

  for (var i = 2; i < arguments.length; i++) {
    validateChildKeys(arguments[i], newElement.type);
  }

  validatePropTypes(newElement);
  return newElement;
}

function startTransition(scope, options) {
  var prevTransition = ReactCurrentBatchConfig.transition;
  ReactCurrentBatchConfig.transition = {};
  var currentTransition = ReactCurrentBatchConfig.transition;

  {
    ReactCurrentBatchConfig.transition._updatedFibers = new Set();
  }

  try {
    scope();
  } finally {
    ReactCurrentBatchConfig.transition = prevTransition;

    {
      if (prevTransition === null && currentTransition._updatedFibers) {
        var updatedFibersCount = currentTransition._updatedFibers.size;

        if (updatedFibersCount > 10) {
          warn('Detected a large number of updates inside startTransition. ' + 'If this is due to a subscription please re-write it to use React provided hooks. ' + 'Otherwise concurrent mode guarantees are off the table.');
        }

        currentTransition._updatedFibers.clear();
      }
    }
  }
}

var didWarnAboutMessageChannel = false;
var enqueueTaskImpl = null;
function enqueueTask(task) {
  if (enqueueTaskImpl === null) {
    try {
      // read require off the module object to get around the bundlers.
      // we don't want them to detect a require and bundle a Node polyfill.
      var requireString = ('require' + Math.random()).slice(0, 7);
      var nodeRequire = module && module[requireString]; // assuming we're in node, let's try to get node's
      // version of setImmediate, bypassing fake timers if any.

      enqueueTaskImpl = nodeRequire.call(module, 'timers').setImmediate;
    } catch (_err) {
      // we're in a browser
      // we can't use regular timers because they may still be faked
      // so we try MessageChannel+postMessage instead
      enqueueTaskImpl = function (callback) {
        {
          if (didWarnAboutMessageChannel === false) {
            didWarnAboutMessageChannel = true;

            if (typeof MessageChannel === 'undefined') {
              error('This browser does not have a MessageChannel implementation, ' + 'so enqueuing tasks via await act(async () => ...) will fail. ' + 'Please file an issue at https://github.com/facebook/react/issues ' + 'if you encounter this warning.');
            }
          }
        }

        var channel = new MessageChannel();
        channel.port1.onmessage = callback;
        channel.port2.postMessage(undefined);
      };
    }
  }

  return enqueueTaskImpl(task);
}

var actScopeDepth = 0;
var didWarnNoAwaitAct = false;
function act(callback) {
  {
    // `act` calls can be nested, so we track the depth. This represents the
    // number of `act` scopes on the stack.
    var prevActScopeDepth = actScopeDepth;
    actScopeDepth++;

    if (ReactCurrentActQueue.current === null) {
      // This is the outermost `act` scope. Initialize the queue. The reconciler
      // will detect the queue and use it instead of Scheduler.
      ReactCurrentActQueue.current = [];
    }

    var prevIsBatchingLegacy = ReactCurrentActQueue.isBatchingLegacy;
    var result;

    try {
      // Used to reproduce behavior of `batchedUpdates` in legacy mode. Only
      // set to `true` while the given callback is executed, not for updates
      // triggered during an async event, because this is how the legacy
      // implementation of `act` behaved.
      ReactCurrentActQueue.isBatchingLegacy = true;
      result = callback(); // Replicate behavior of original `act` implementation in legacy mode,
      // which flushed updates immediately after the scope function exits, even
      // if it's an async function.

      if (!prevIsBatchingLegacy && ReactCurrentActQueue.didScheduleLegacyUpdate) {
        var queue = ReactCurrentActQueue.current;

        if (queue !== null) {
          ReactCurrentActQueue.didScheduleLegacyUpdate = false;
          flushActQueue(queue);
        }
      }
    } catch (error) {
      popActScope(prevActScopeDepth);
      throw error;
    } finally {
      ReactCurrentActQueue.isBatchingLegacy = prevIsBatchingLegacy;
    }

    if (result !== null && typeof result === 'object' && typeof result.then === 'function') {
      var thenableResult = result; // The callback is an async function (i.e. returned a promise). Wait
      // for it to resolve before exiting the current scope.

      var wasAwaited = false;
      var thenable = {
        then: function (resolve, reject) {
          wasAwaited = true;
          thenableResult.then(function (returnValue) {
            popActScope(prevActScopeDepth);

            if (actScopeDepth === 0) {
              // We've exited the outermost act scope. Recursively flush the
              // queue until there's no remaining work.
              recursivelyFlushAsyncActWork(returnValue, resolve, reject);
            } else {
              resolve(returnValue);
            }
          }, function (error) {
            // The callback threw an error.
            popActScope(prevActScopeDepth);
            reject(error);
          });
        }
      };

      {
        if (!didWarnNoAwaitAct && typeof Promise !== 'undefined') {
          // eslint-disable-next-line no-undef
          Promise.resolve().then(function () {}).then(function () {
            if (!wasAwaited) {
              didWarnNoAwaitAct = true;

              error('You called act(async () => ...) without await. ' + 'This could lead to unexpected testing behaviour, ' + 'interleaving multiple act calls and mixing their ' + 'scopes. ' + 'You should - await act(async () => ...);');
            }
          });
        }
      }

      return thenable;
    } else {
      var returnValue = result; // The callback is not an async function. Exit the current scope
      // immediately, without awaiting.

      popActScope(prevActScopeDepth);

      if (actScopeDepth === 0) {
        // Exiting the outermost act scope. Flush the queue.
        var _queue = ReactCurrentActQueue.current;

        if (_queue !== null) {
          flushActQueue(_queue);
          ReactCurrentActQueue.current = null;
        } // Return a thenable. If the user awaits it, we'll flush again in
        // case additional work was scheduled by a microtask.


        var _thenable = {
          then: function (resolve, reject) {
            // Confirm we haven't re-entered another `act` scope, in case
            // the user does something weird like await the thenable
            // multiple times.
            if (ReactCurrentActQueue.current === null) {
              // Recursively flush the queue until there's no remaining work.
              ReactCurrentActQueue.current = [];
              recursivelyFlushAsyncActWork(returnValue, resolve, reject);
            } else {
              resolve(returnValue);
            }
          }
        };
        return _thenable;
      } else {
        // Since we're inside a nested `act` scope, the returned thenable
        // immediately resolves. The outer scope will flush the queue.
        var _thenable2 = {
          then: function (resolve, reject) {
            resolve(returnValue);
          }
        };
        return _thenable2;
      }
    }
  }
}

function popActScope(prevActScopeDepth) {
  {
    if (prevActScopeDepth !== actScopeDepth - 1) {
      error('You seem to have overlapping act() calls, this is not supported. ' + 'Be sure to await previous act() calls before making a new one. ');
    }

    actScopeDepth = prevActScopeDepth;
  }
}

function recursivelyFlushAsyncActWork(returnValue, resolve, reject) {
  {
    var queue = ReactCurrentActQueue.current;

    if (queue !== null) {
      try {
        flushActQueue(queue);
        enqueueTask(function () {
          if (queue.length === 0) {
            // No additional work was scheduled. Finish.
            ReactCurrentActQueue.current = null;
            resolve(returnValue);
          } else {
            // Keep flushing work until there's none left.
            recursivelyFlushAsyncActWork(returnValue, resolve, reject);
          }
        });
      } catch (error) {
        reject(error);
      }
    } else {
      resolve(returnValue);
    }
  }
}

var isFlushing = false;

function flushActQueue(queue) {
  {
    if (!isFlushing) {
      // Prevent re-entrance.
      isFlushing = true;
      var i = 0;

      try {
        for (; i < queue.length; i++) {
          var callback = queue[i];

          do {
            callback = callback(true);
          } while (callback !== null);
        }

        queue.length = 0;
      } catch (error) {
        // If something throws, leave the remaining callbacks on the queue.
        queue = queue.slice(i + 1);
        throw error;
      } finally {
        isFlushing = false;
      }
    }
  }
}

var createElement$1 =  createElementWithValidation ;
var cloneElement$1 =  cloneElementWithValidation ;
var createFactory =  createFactoryWithValidation ;
var Children = {
  map: mapChildren,
  forEach: forEachChildren,
  count: countChildren,
  toArray: toArray,
  only: onlyChild
};

exports.Children = Children;
exports.Component = Component;
exports.Fragment = REACT_FRAGMENT_TYPE;
exports.Profiler = REACT_PROFILER_TYPE;
exports.PureComponent = PureComponent;
exports.StrictMode = REACT_STRICT_MODE_TYPE;
exports.Suspense = REACT_SUSPENSE_TYPE;
exports.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = ReactSharedInternals;
exports.act = act;
exports.cloneElement = cloneElement$1;
exports.createContext = createContext;
exports.createElement = createElement$1;
exports.createFactory = createFactory;
exports.createRef = createRef;
exports.forwardRef = forwardRef;
exports.isValidElement = isValidElement;
exports.lazy = lazy;
exports.memo = memo;
exports.startTransition = startTransition;
exports.unstable_act = act;
exports.useCallback = useCallback;
exports.useContext = useContext;
exports.useDebugValue = useDebugValue;
exports.useDeferredValue = useDeferredValue;
exports.useEffect = useEffect;
exports.useId = useId;
exports.useImperativeHandle = useImperativeHandle;
exports.useInsertionEffect = useInsertionEffect;
exports.useLayoutEffect = useLayoutEffect;
exports.useMemo = useMemo;
exports.useReducer = useReducer;
exports.useRef = useRef;
exports.useState = useState;
exports.useSyncExternalStore = useSyncExternalStore;
exports.useTransition = useTransition;
exports.version = ReactVersion;
          /* global __REACT_DEVTOOLS_GLOBAL_HOOK__ */
if (
  typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ !== 'undefined' &&
  typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop ===
    'function'
) {
  __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(new Error());
}
        
  })();
}


/***/ }),

/***/ "./node_modules/react/index.js":
/*!*************************************!*\
  !*** ./node_modules/react/index.js ***!
  \*************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


if (false) // removed by dead control flow
{} else {
  module.exports = __webpack_require__(/*! ./cjs/react.development.js */ "./node_modules/react/cjs/react.development.js");
}


/***/ }),

/***/ "./node_modules/void-elements/index.js":
/*!*********************************************!*\
  !*** ./node_modules/void-elements/index.js ***!
  \*********************************************/
/***/ ((module) => {

/**
 * This file automatically generated from `pre-publish.js`.
 * Do not manually edit.
 */

module.exports = {
  "area": true,
  "base": true,
  "br": true,
  "col": true,
  "embed": true,
  "hr": true,
  "img": true,
  "input": true,
  "link": true,
  "meta": true,
  "param": true,
  "source": true,
  "track": true,
  "wbr": true
};


/***/ }),

/***/ "./src/i18n.js":
/*!*********************!*\
  !*** ./src/i18n.js ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var i18next__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! i18next */ "./node_modules/i18next/dist/esm/i18next.js");
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-i18next */ "./node_modules/react-i18next/dist/es/index.js");
/* harmony import */ var i18next_http_backend__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! i18next-http-backend */ "./node_modules/i18next-http-backend/esm/index.js");





i18next__WEBPACK_IMPORTED_MODULE_0__["default"].use(i18next_http_backend__WEBPACK_IMPORTED_MODULE_2__["default"])
    .use(react_i18next__WEBPACK_IMPORTED_MODULE_1__.initReactI18next)
    .init({
        fallbackLng: 'en-US',
        supportedLngs: ['en-US', 'es', 'he'],
        debug: false,
        useSuspense: false,
        backend: {
            loadPath: "/internalAssets/locales/{{lng}}/translation.json"
        }

    });

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (i18next__WEBPACK_IMPORTED_MODULE_0__["default"]);

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			id: moduleId,
/******/ 			loaded: false,
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/create fake namespace object */
/******/ 	(() => {
/******/ 		var getProto = Object.getPrototypeOf ? (obj) => (Object.getPrototypeOf(obj)) : (obj) => (obj.__proto__);
/******/ 		var leafPrototypes;
/******/ 		// create a fake namespace object
/******/ 		// mode & 1: value is a module id, require it
/******/ 		// mode & 2: merge all properties of value into the ns
/******/ 		// mode & 4: return value when already ns object
/******/ 		// mode & 16: return value when it's Promise-like
/******/ 		// mode & 8|1: behave like require
/******/ 		__webpack_require__.t = function(value, mode) {
/******/ 			if(mode & 1) value = this(value);
/******/ 			if(mode & 8) return value;
/******/ 			if(typeof value === 'object' && value) {
/******/ 				if((mode & 4) && value.__esModule) return value;
/******/ 				if((mode & 16) && typeof value.then === 'function') return value;
/******/ 			}
/******/ 			var ns = Object.create(null);
/******/ 			__webpack_require__.r(ns);
/******/ 			var def = {};
/******/ 			leafPrototypes = leafPrototypes || [null, getProto({}), getProto([]), getProto(getProto)];
/******/ 			for(var current = mode & 2 && value; (typeof current == 'object' || typeof current == 'function') && !~leafPrototypes.indexOf(current); current = getProto(current)) {
/******/ 				Object.getOwnPropertyNames(current).forEach((key) => (def[key] = () => (value[key])));
/******/ 			}
/******/ 			def['default'] = () => (value);
/******/ 			__webpack_require__.d(ns, def);
/******/ 			return ns;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/ensure chunk */
/******/ 	(() => {
/******/ 		__webpack_require__.f = {};
/******/ 		// This file contains only the entry chunk.
/******/ 		// The chunk loading function for additional chunks
/******/ 		__webpack_require__.e = (chunkId) => {
/******/ 			return Promise.all(Object.keys(__webpack_require__.f).reduce((promises, key) => {
/******/ 				__webpack_require__.f[key](chunkId, promises);
/******/ 				return promises;
/******/ 			}, []));
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/get javascript chunk filename */
/******/ 	(() => {
/******/ 		// This function allow to reference async chunks
/******/ 		__webpack_require__.u = (chunkId) => {
/******/ 			// return url for filenames based on template
/******/ 			return "" + chunkId + ".bundle." + __webpack_require__.h() + ".js";
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/getFullHash */
/******/ 	(() => {
/******/ 		__webpack_require__.h = () => ("c4d58e528ac603cfbda4")
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/load script */
/******/ 	(() => {
/******/ 		var inProgress = {};
/******/ 		var dataWebpackPrefix = "fabric-frontend-developer-sample:";
/******/ 		// loadScript function to load a script via script tag
/******/ 		__webpack_require__.l = (url, done, key, chunkId) => {
/******/ 			if(inProgress[url]) { inProgress[url].push(done); return; }
/******/ 			var script, needAttach;
/******/ 			if(key !== undefined) {
/******/ 				var scripts = document.getElementsByTagName("script");
/******/ 				for(var i = 0; i < scripts.length; i++) {
/******/ 					var s = scripts[i];
/******/ 					if(s.getAttribute("src") == url || s.getAttribute("data-webpack") == dataWebpackPrefix + key) { script = s; break; }
/******/ 				}
/******/ 			}
/******/ 			if(!script) {
/******/ 				needAttach = true;
/******/ 				script = document.createElement('script');
/******/ 		
/******/ 				script.charset = 'utf-8';
/******/ 				if (__webpack_require__.nc) {
/******/ 					script.setAttribute("nonce", __webpack_require__.nc);
/******/ 				}
/******/ 				script.setAttribute("data-webpack", dataWebpackPrefix + key);
/******/ 		
/******/ 				script.src = url;
/******/ 			}
/******/ 			inProgress[url] = [done];
/******/ 			var onScriptComplete = (prev, event) => {
/******/ 				// avoid mem leaks in IE.
/******/ 				script.onerror = script.onload = null;
/******/ 				clearTimeout(timeout);
/******/ 				var doneFns = inProgress[url];
/******/ 				delete inProgress[url];
/******/ 				script.parentNode && script.parentNode.removeChild(script);
/******/ 				doneFns && doneFns.forEach((fn) => (fn(event)));
/******/ 				if(prev) return prev(event);
/******/ 			}
/******/ 			var timeout = setTimeout(onScriptComplete.bind(null, undefined, { type: 'timeout', target: script }), 120000);
/******/ 			script.onerror = onScriptComplete.bind(null, script.onerror);
/******/ 			script.onload = onScriptComplete.bind(null, script.onload);
/******/ 			needAttach && document.head.appendChild(script);
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/node module decorator */
/******/ 	(() => {
/******/ 		__webpack_require__.nmd = (module) => {
/******/ 			module.paths = [];
/******/ 			if (!module.children) module.children = [];
/******/ 			return module;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/publicPath */
/******/ 	(() => {
/******/ 		__webpack_require__.p = "/";
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			"main": 0
/******/ 		};
/******/ 		
/******/ 		__webpack_require__.f.j = (chunkId, promises) => {
/******/ 				// JSONP chunk loading for javascript
/******/ 				var installedChunkData = __webpack_require__.o(installedChunks, chunkId) ? installedChunks[chunkId] : undefined;
/******/ 				if(installedChunkData !== 0) { // 0 means "already installed".
/******/ 		
/******/ 					// a Promise means "currently loading".
/******/ 					if(installedChunkData) {
/******/ 						promises.push(installedChunkData[2]);
/******/ 					} else {
/******/ 						if(true) { // all chunks have JS
/******/ 							// setup Promise in chunk cache
/******/ 							var promise = new Promise((resolve, reject) => (installedChunkData = installedChunks[chunkId] = [resolve, reject]));
/******/ 							promises.push(installedChunkData[2] = promise);
/******/ 		
/******/ 							// start chunk loading
/******/ 							var url = __webpack_require__.p + __webpack_require__.u(chunkId);
/******/ 							// create error before stack unwound to get useful stacktrace later
/******/ 							var error = new Error();
/******/ 							var loadingEnded = (event) => {
/******/ 								if(__webpack_require__.o(installedChunks, chunkId)) {
/******/ 									installedChunkData = installedChunks[chunkId];
/******/ 									if(installedChunkData !== 0) installedChunks[chunkId] = undefined;
/******/ 									if(installedChunkData) {
/******/ 										var errorType = event && (event.type === 'load' ? 'missing' : event.type);
/******/ 										var realSrc = event && event.target && event.target.src;
/******/ 										error.message = 'Loading chunk ' + chunkId + ' failed.\n(' + errorType + ': ' + realSrc + ')';
/******/ 										error.name = 'ChunkLoadError';
/******/ 										error.type = errorType;
/******/ 										error.request = realSrc;
/******/ 										installedChunkData[1](error);
/******/ 									}
/******/ 								}
/******/ 							};
/******/ 							__webpack_require__.l(url, loadingEnded, "chunk-" + chunkId, chunkId);
/******/ 						}
/******/ 					}
/******/ 				}
/******/ 		};
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		// no on chunks loaded
/******/ 		
/******/ 		// install a JSONP callback for chunk loading
/******/ 		var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
/******/ 			var [chunkIds, moreModules, runtime] = data;
/******/ 			// add "moreModules" to the modules object,
/******/ 			// then flag all "chunkIds" as loaded and fire callback
/******/ 			var moduleId, chunkId, i = 0;
/******/ 			if(chunkIds.some((id) => (installedChunks[id] !== 0))) {
/******/ 				for(moduleId in moreModules) {
/******/ 					if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 						__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 					}
/******/ 				}
/******/ 				if(runtime) var result = runtime(__webpack_require__);
/******/ 			}
/******/ 			if(parentChunkLoadingFunction) parentChunkLoadingFunction(data);
/******/ 			for(;i < chunkIds.length; i++) {
/******/ 				chunkId = chunkIds[i];
/******/ 				if(__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 					installedChunks[chunkId][0]();
/******/ 				}
/******/ 				installedChunks[chunkId] = 0;
/******/ 			}
/******/ 		
/******/ 		}
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunkfabric_frontend_developer_sample"] = self["webpackChunkfabric_frontend_developer_sample"] || [];
/******/ 		chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
/******/ 		chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/nonce */
/******/ 	(() => {
/******/ 		__webpack_require__.nc = undefined;
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it needs to be in strict mode.
(() => {
"use strict";
/*!**********************!*\
  !*** ./src/index.ts ***!
  \**********************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ms-fabric/workload-client */ "./node_modules/@ms-fabric/workload-client/src/workload-client.js");
/* harmony import */ var _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _i18n__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./i18n */ "./src/i18n.js");
var _a, _b;


function printFormattedAADErrorMessage(hashMessage) {
    const hashString = hashMessage.slice(1);
    // Decode URL encoding and parse key-value pairs
    const searchParams = new URLSearchParams(hashString);
    const formattedMessage = {};
    searchParams.forEach((value, key) => {
        formattedMessage[key] = decodeURIComponent(value);
    });
    // Print formatted message
    document.documentElement.innerHTML = "There was a problem with the consent, open browser debug console for more details";
    for (const key in formattedMessage) {
        if (Object.prototype.hasOwnProperty.call(formattedMessage, key)) {
            console.log(`${key}: ${formattedMessage[key]}`);
        }
    }
}
/** This is used for authentication API as a redirect URI.
 * Delete this code if you do not plan on using authentication API.
 * You can change the redirectUriPath to whatever suits you.
 */
const redirectUriPath = '/close';
const url = new URL(window.location.href);
if ((_a = url.pathname) === null || _a === void 0 ? void 0 : _a.startsWith(redirectUriPath)) {
    // Handle errors, Please refer to https://learn.microsoft.com/en-us/entra/identity-platform/reference-error-codes
    if ((_b = url === null || url === void 0 ? void 0 : url.hash) === null || _b === void 0 ? void 0 : _b.includes("error")) {
        // Handle missing service principal error
        if (url.hash.includes("AADSTS650052")) {
            printFormattedAADErrorMessage(url === null || url === void 0 ? void 0 : url.hash);
            // handle user declined the consent error
        }
        else if (url.hash.includes("AADSTS65004")) {
            printFormattedAADErrorMessage(url === null || url === void 0 ? void 0 : url.hash);
        }
        else {
            window.close();
        }
    }
    else {
        // close the window in case there are no errors
        window.close();
    }
}
console.log('****Runtime: Environment Variables****');
console.log('process.env.WORKLOAD_NAME: ' + "");
console.log('process.env.WORKLOAD_BE_URL: ' + "");
console.log('**************************************');
(0,_ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_0__.bootstrap)({
    initializeWorker: (params) => Promise.all(/*! import() */[__webpack_require__.e("src_controller_SampleWorkloadController_ts"), __webpack_require__.e("src_index_worker_ts-node_modules_uuid_dist_esm-browser_v4_js")]).then(__webpack_require__.bind(__webpack_require__, /*! ./index.worker */ "./src/index.worker.ts")).then(({ initialize }) => initialize(params)),
    initializeUI: (params) => Promise.all(/*! import() */[__webpack_require__.e("vendors-node_modules_fluentui_react-badge_lib_components_Badge_Badge_js-node_modules_fluentui-bf3c62"), __webpack_require__.e("src_controller_SampleWorkloadController_ts"), __webpack_require__.e("src_index_ui_tsx")]).then(__webpack_require__.bind(__webpack_require__, /*! ./index.ui */ "./src/index.ui.tsx")).then(({ initialize }) => initialize(params)),
});

})();

/******/ })()
;
//# sourceMappingURL=bundle.c4d58e528ac603cfbda4.js.map
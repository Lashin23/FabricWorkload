window.env = {
  workloadName: "Org.FabricAdminAgent",
  workloadBEURL: "https://deployadminagentapi.maqsoftware.com",
  DEV_AAD_CONFIG_AUDIENCE:
    "https://maqsoftware.com/deployadminagent/deployadminagentapi/Org.FabricAdminAgent",
  DEV_AAD_CONFIG_APPID: "12a32b3b-fad6-44e3-9729-d5dd131b49f9",
  DEV_AAD_CONFIG_REDIRECT_URI: "https://deployadminagent.maqsoftware.com/close",
};
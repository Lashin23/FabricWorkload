window.env = {
  workloadName: "",
  workloadBEURL: "",
  DEV_AAD_CONFIG_AUDIENCE:
    "",
  DEV_AAD_CONFIG_APPID: "",
  DEV_AAD_CONFIG_REDIRECT_URI: "",
};
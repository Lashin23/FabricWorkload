window.env = {
    BaseUrl: "",
    clientId: "",
    tenantId: "",
    subscriptionId:"",
    resourceGroupName:"",
    Clusters: ""
};
  
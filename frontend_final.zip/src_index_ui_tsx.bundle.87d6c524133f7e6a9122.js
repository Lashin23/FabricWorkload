"use strict";
(self["webpackChunkfabric_frontend_developer_sample"] = self["webpackChunkfabric_frontend_developer_sample"] || []).push([["src_index_ui_tsx"],{

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/sass-loader/dist/cjs.js!./src/styles.scss":
/*!******************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/sass-loader/dist/cjs.js!./src/styles.scss ***!
  \******************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, `.editor {
  background: #f3f2f1;
  padding: 8px;
  height: 100%;
}

.editor .main {
  border-radius: 8px;
  background: white;
  box-shadow: 0 0 2px rgba(0, 0, 0, 0.12), 0 2px 4px rgba(0, 0, 0, 0.14);
  margin: 5px 0;
  padding: 5px;
}

.description {
  white-space: pre-wrap;
}

.editor h2 {
  padding: 0 0 0 20px;
}

.editor .field {
  flex-grow: 1;
}

.margin-top {
  margin-top: 16px;
}

.editor .section {
  padding: 0 0 30px 20px;
  display: flex;
  flex-direction: column;
  row-gap: 10px;
  width: 400px;
}

.ribbon .toolbarContainer {
  height: 40px;
  border-radius: 8px;
  background: white;
  box-shadow: 0 0 2px rgba(0, 0, 0, 0.12), 0 2px 4px rgba(0, 0, 0, 0.14);
  margin: 5px 0;
}

.tablistContainer {
  margin: 10px 0;
}

.collabContainer {
  float: right;
  padding-top: 10px;
}

.collabContainer button {
  height: 25px;
  margin: 0 5px;
}

.authButton {
  margin-right: 40%;
  margin-left: 40%;
  margin-top: 5px;
}

.ribbon .comboboxLabel {
  padding-right: 8px;
}

.shared-state-dialog,
.create-dialog {
  width: 360px;
  padding: 16px 24px 24px 24px;
  white-space: pre-wrap;
}
.shared-state-dialog h2,
.create-dialog h2 {
  padding: 0;
  margin: 0;
  white-space: inherit;
  font-size: 20px;
  font-weight: 600;
}
.shared-state-dialog .section,
.create-dialog .section {
  display: flex;
  flex-direction: column;
  row-gap: 10px;
  white-space: inherit;
}
.shared-state-dialog .shared-state-iframe-buttons,
.shared-state-dialog .create-buttons,
.create-dialog .shared-state-iframe-buttons,
.create-dialog .create-buttons {
  justify-content: right;
}

.panel {
  padding: 8px;
}

.panel .section {
  margin: 5px;
}

.panel .field {
  flex-grow: 1;
}

.explorer {
  min-width: 200px;
  width: 25vw;
  height: 70vh;
  vertical-align: middle;
  border-radius: 8px;
  background: white;
  box-shadow: 0 0 2px rgba(0, 0, 0, 0.12), 0 2px 4px rgba(0, 0, 0, 0.14);
  margin: 5px 0;
  padding: 5px;
  display: flex;
}
.explorer .top {
  padding: 5px 10px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
}
.explorer .top h1 {
  font-family: "Segoe UI", sans-serif;
  font-size: 16px;
  font-weight: 600;
  margin: 10px;
}
.explorer .selector-body {
  display: flex;
  align-items: start;
  overflow: hidden;
}
.explorer .selector-body .tree-container {
  width: 100%;
  overflow-y: auto;
}
.explorer .selector-tree-item {
  display: flex;
  width: 100%;
}
.explorer .fui-TreeItemLayout__main {
  text-overflow: ellipsis;
  overflow: hidden;
  white-space: nowrap;
}
.explorer .main-body {
  display: flex;
  height: 100%;
  align-items: center;
  justify-content: center;
  text-align: center;
  flex-direction: column;
}
.explorer .main-body .add-button {
  margin: 0;
  width: 51px;
  min-width: auto;
  height: 32px;
  font-size: 14px;
}
.explorer .main-body .add {
  font-size: 20px;
  font-weight: 600;
  margin: 0px;
  padding: 24px 0;
}

.hidden-explorer {
  width: max-content;
  min-width: auto;
}

.vertical-text {
  writing-mode: vertical-lr;
}

.tree {
  --spacingHorizontalXXL: 16px;
}
.tree .selected {
  background-color: var(--colorNeutralBackground1Selected);
}

.spinner {
  justify-content: center;
}

.rtl > * {
  direction: rtl;
  text-align: start;
}

.message-bar-body {
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.card {
  margin-bottom: 10px;
}

.card-content {
  padding: 5px;
}

.field-group {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.api-authentication-field {
  display: flex;
  align-items: center;
  margin-bottom: 10px;
}

.api-authentication-field-label {
  flex: 0 0 250px;
  margin-right: 10px;
}

.api-authentication-input {
  flex: 1;
  width: 100%;
  max-width: 500px;
}

.authButton {
  margin-top: 10px;
  margin-bottom: 20px;
  align-self: center;
  display: flex;
  justify-content: center;
}

.api-authentication-textarea {
  resize: both;
  overflow: auto;
  width: 500px;
  min-height: 100px;
  font-size: 14px;
  font-weight: normal;
}`, "",{"version":3,"sources":["webpack://./src/styles.scss"],"names":[],"mappings":"AAAA;EACI,mBAAA;EACA,YAAA;EACA,YAAA;AACJ;;AAEA;EACI,kBAAA;EACA,iBAAA;EACA,sEAAA;EACA,aAAA;EACA,YAAA;AACJ;;AACA;EACI,qBAAA;AAEJ;;AACA;EACI,mBAAA;AAEJ;;AACA;EACI,YAAA;AAEJ;;AACA;EACI,gBAAA;AAEJ;;AACA;EACI,sBAAA;EACA,aAAA;EACA,sBAAA;EACA,aAAA;EACA,YAAA;AAEJ;;AACA;EACI,YAAA;EACA,kBAAA;EACA,iBAAA;EACA,sEAAA;EACA,aAAA;AAEJ;;AACA;EACI,cAAA;AAEJ;;AACA;EACI,YAAA;EACA,iBAAA;AAEJ;;AACA;EACI,YAAA;EACA,aAAA;AAEJ;;AACA;EACI,iBAAA;EACA,gBAAA;EACA,eAAA;AAEJ;;AACA;EACI,kBAAA;AAEJ;;AACA;;EAEI,YAAA;EACA,4BAAA;EACA,qBAAA;AAEJ;AAAI;;EACI,UAAA;EACA,SAAA;EACA,oBAAA;EACA,eAAA;EACA,gBAAA;AAGR;AAAI;;EACI,aAAA;EACA,sBAAA;EACA,aAAA;EACA,oBAAA;AAGR;AAAI;;;;EAEI,sBAAA;AAIR;;AADA;EACI,YAAA;AAIJ;;AAFA;EACI,WAAA;AAKJ;;AAHA;EACI,YAAA;AAMJ;;AAFA;EACI,gBAAA;EACA,WAAA;EACA,YAAA;EACA,sBAAA;EACA,kBAAA;EACA,iBAAA;EACA,sEAAA;EACA,aAAA;EACA,YAAA;EACA,aAAA;AAKJ;AAHI;EACI,iBAAA;EACA,aAAA;EACA,mBAAA;EACA,8BAAA;AAKR;AAJQ;EACI,mCAAA;EACA,eAAA;EACA,gBAAA;EACA,YAAA;AAMZ;AAFI;EACI,aAAA;EACA,kBAAA;EACA,gBAAA;AAIR;AAHQ;EACI,WAAA;EACA,gBAAA;AAKZ;AADI;EACI,aAAA;EACA,WAAA;AAGR;AAAI;EACI,uBAAA;EACA,gBAAA;EACA,mBAAA;AAER;AACI;EACI,aAAA;EACA,YAAA;EACA,mBAAA;EACA,uBAAA;EACA,kBAAA;EACA,sBAAA;AACR;AACQ;EACI,SAAA;EACA,WAAA;EACA,eAAA;EACA,YAAA;EACA,eAAA;AACZ;AAEQ;EACI,eAAA;EACA,gBAAA;EACA,WAAA;EACA,eAAA;AAAZ;;AAMA;EACI,kBAAA;EACA,eAAA;AAHJ;;AAKA;EACI,yBAAA;AAFJ;;AAIA;EACI,4BAAA;AADJ;AAEI;EACI,wDAAA;AAAR;;AAIA;EACI,uBAAA;AADJ;;AAKA;EACI,cAAA;EACA,iBAAA;AAFJ;;AAKA;EACI,aAAA;EACA,mBAAA;EACA,WAAA;AAFJ;;AAKA;EACI,mBAAA;AAFJ;;AAKA;EACI,YAAA;AAFJ;;AAKA;EACI,aAAA;EACA,sBAAA;EACA,SAAA;AAFJ;;AAKA;EACI,aAAA;EACA,mBAAA;EACA,mBAAA;AAFJ;;AAKA;EACI,eAAA;EACA,kBAAA;AAFJ;;AAKA;EACI,OAAA;EACA,WAAA;EACA,gBAAA;AAFJ;;AAKA;EACI,gBAAA;EACA,mBAAA;EACA,kBAAA;EACA,aAAA;EACA,uBAAA;AAFJ;;AAKA;EACI,YAAA;EACA,cAAA;EACA,YAAA;EACA,iBAAA;EACA,eAAA;EACA,mBAAA;AAFJ","sourcesContent":[".editor {\n    background: #f3f2f1;\n    padding: 8px;\n    height: 100%;\n}\n\n.editor .main {\n    border-radius: 8px;\n    background: white; \n    box-shadow: 0 0 2px rgba(0,0,0,0.12), 0 2px 4px rgba(0,0,0,0.14);\n    margin: 5px 0;\n    padding: 5px;\n}\n.description {\n    white-space: pre-wrap;\n}\n\n.editor h2 {\n    padding: 0 0 0 20px\n}\n\n.editor .field {\n    flex-grow: 1;\n}\n\n.margin-top {\n    margin-top: 16px;\n}\n\n.editor .section {\n    padding: 0 0 30px 20px;\n    display: flex;\n    flex-direction: column;\n    row-gap: 10px;\n    width: 400px;\n}\n\n.ribbon .toolbarContainer {\n    height: 40px;\n    border-radius:8px;\n    background:white;\n    box-shadow: 0 0 2px rgba(0,0,0,0.12), 0 2px 4px rgba(0,0,0,0.14);\n    margin:5px 0;\n}\n\n.tablistContainer {\n    margin:10px 0;\n}\n\n.collabContainer {\n    float:right;\n    padding-top: 10px;\n}\n\n.collabContainer button {\n    height:25px;\n    margin: 0 5px;\n}\n\n.authButton {\n    margin-right: 40%;\n    margin-left: 40%;\n    margin-top: 5px;\n}\n\n.ribbon .comboboxLabel {\n    padding-right: 8px;\n}\n\n.shared-state-dialog,\n.create-dialog {\n    width: 360px;\n    padding: 16px 24px 24px 24px;\n    white-space: pre-wrap;\n\n    h2 {\n        padding: 0;\n        margin:0;\n        white-space: inherit;\n        font-size: 20px;\n        font-weight: 600;\n    }\n\n    .section {\n        display: flex;\n        flex-direction: column;\n        row-gap: 10px;\n        white-space: inherit;\n    }\n    \n    .shared-state-iframe-buttons,\n    .create-buttons {\n        justify-content: right;\n    }\n}\n.panel {\n    padding:8px;\n}\n.panel .section {\n    margin: 5px;\n}\n.panel .field {\n    flex-grow: 1;\n}\n\n\n.explorer {\n    min-width: 200px;\n    width:25vw;\n    height: 70vh;\n    vertical-align: middle;\n    border-radius: 8px;\n    background: white; \n    box-shadow: 0 0 2px rgba(0,0,0,0.12), 0 2px 4px rgba(0,0,0,0.14);\n    margin: 5px 0;\n    padding: 5px;\n    display: flex;\n\n    .top {\n        padding: 5px 10px;\n        display: flex;\n        flex-direction: row;\n        justify-content: space-between;\n        h1 {\n            font-family: 'Segoe UI', sans-serif;\n            font-size: 16px;\n            font-weight: 600;\n            margin:10px;\n        }\n    }\n\n    .selector-body {\n        display: flex;\n        align-items: start;\n        overflow:hidden;\n        .tree-container {\n            width:100%;\n            overflow-y: auto;\n        }\n    }\n    \n    .selector-tree-item {\n        display:flex;\n        width: 100%;\n    }\n    \n    .fui-TreeItemLayout__main  {\n        text-overflow: ellipsis;\n        overflow:hidden;\n        white-space: nowrap;\n    }\n\n    .main-body {\n        display: flex;\n        height: 100%;\n        align-items: center;\n        justify-content: center;\n        text-align: center;\n        flex-direction: column;\n \n        .add-button {\n            margin: 0;\n            width: 51px;\n            min-width: auto;\n            height: 32px;\n            font-size: 14px;\n        }\n        \n        .add {\n            font-size: 20px;\n            font-weight: 600;\n            margin: 0px;\n            padding: 24px 0;\n        }\n    }\n}\n    \n\n.hidden-explorer {\n    width: max-content;\n    min-width: auto;\n}\n.vertical-text {\n    writing-mode: vertical-lr;\n}\n.tree {\n    --spacingHorizontalXXL: 16px;\n    .selected {\n        background-color: var(--colorNeutralBackground1Selected);\n    }    \n}\n\n.spinner {\n    justify-content: center;\n}\n\n\n.rtl > * {\n    direction: rtl;\n    text-align: start;\n}\n\n.message-bar-body {\n    display: flex;\n    align-items: center;\n    gap: 0.5rem\n}\n\n.card {\n    margin-bottom: 10px;\n}\n\n.card-content {\n    padding: 5px;\n}\n\n.field-group {\n    display: flex;\n    flex-direction: column;\n    gap: 10px;\n}\n\n.api-authentication-field {\n    display: flex;\n    align-items: center;\n    margin-bottom: 10px;\n}\n\n.api-authentication-field-label {\n    flex: 0 0 250px;\n    margin-right: 10px;\n}\n\n.api-authentication-input {\n    flex: 1;\n    width: 100%; \n    max-width: 500px;\n}\n\n.authButton {\n    margin-top: 10px;\n    margin-bottom: 20px;\n    align-self: center;\n    display: flex;\n    justify-content: center;\n}\n\n.api-authentication-textarea {\n    resize: both;\n    overflow: auto;\n    width: 500px;\n    min-height: 100px; \n    font-size: 14px;\n    font-weight: normal;\n}"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./src/App.tsx":
/*!*********************!*\
  !*** ./src/App.tsx ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   App: () => (/* binding */ App)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/dist/react-redux.mjs");
/* harmony import */ var _ClientSDKPlaygroundStore_Store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ClientSDKPlaygroundStore/Store */ "./src/ClientSDKPlaygroundStore/Store.ts");
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router/esm/react-router.js");
/* harmony import */ var _components_SampleWorkloadPanel_SampleWorkloadPanel__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/SampleWorkloadPanel/SampleWorkloadPanel */ "./src/components/SampleWorkloadPanel/SampleWorkloadPanel.tsx");
/* harmony import */ var _components_SampleWorkloadCreateDialog_SampleWorkloadCreateDialog__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./components/SampleWorkloadCreateDialog/SampleWorkloadCreateDialog */ "./src/components/SampleWorkloadCreateDialog/SampleWorkloadCreateDialog.tsx");
/* harmony import */ var _components_CustomItemSettings_CustomAbout__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./components/CustomItemSettings/CustomAbout */ "./src/components/CustomItemSettings/CustomAbout.tsx");
/* harmony import */ var _components_SampleWorkloadSharedState_SharedStatePage__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./components/SampleWorkloadSharedState/SharedStatePage */ "./src/components/SampleWorkloadSharedState/SharedStatePage.tsx");
/* harmony import */ var _components_ClientSDKPlayground_ClientSDKPlayground__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./components/ClientSDKPlayground/ClientSDKPlayground */ "./src/components/ClientSDKPlayground/ClientSDKPlayground.tsx");
/* harmony import */ var _components_DataPlayground_DataPlayground__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./components/DataPlayground/DataPlayground */ "./src/components/DataPlayground/DataPlayground.tsx");
/* harmony import */ var _components_AppLayout_AppLayout__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./components/AppLayout/AppLayout */ "./src/components/AppLayout/AppLayout.tsx");
/* harmony import */ var _contexts_SettingsContext__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./contexts/SettingsContext */ "./src/contexts/SettingsContext.tsx");
/* harmony import */ var _contexts_FabricFindingsContext__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./contexts/FabricFindingsContext */ "./src/contexts/FabricFindingsContext.tsx");
/* harmony import */ var _contexts_McpContext__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./contexts/McpContext */ "./src/contexts/McpContext.tsx");
/* harmony import */ var _components_CustomItemSettings_CustomWorkspaceSettings__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./components/CustomItemSettings/CustomWorkspaceSettings */ "./src/components/CustomItemSettings/CustomWorkspaceSettings.tsx");
/* harmony import */ var _components_CustomItemSettings_CustomSemanticModelSettings__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./components/CustomItemSettings/CustomSemanticModelSettings */ "./src/components/CustomItemSettings/CustomSemanticModelSettings.tsx");
/* harmony import */ var _components_CustomItemSettings_CustomReportSettings__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./components/CustomItemSettings/CustomReportSettings */ "./src/components/CustomItemSettings/CustomReportSettings.tsx");
/* harmony import */ var _contexts_SuppressedFindingsContext__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./contexts/SuppressedFindingsContext */ "./src/contexts/SuppressedFindingsContext.tsx");


















function App({ history, workloadClient }) {
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_contexts_SuppressedFindingsContext__WEBPACK_IMPORTED_MODULE_17__.SuppressedFindingsProvider, null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_contexts_McpContext__WEBPACK_IMPORTED_MODULE_13__.McpProvider, null,
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_contexts_FabricFindingsContext__WEBPACK_IMPORTED_MODULE_12__.FabricFindingsProvider, null,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_contexts_SettingsContext__WEBPACK_IMPORTED_MODULE_11__.AdminProvider, null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_3__.Router, { history: history },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_3__.Switch, null,
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_3__.Route, { path: "/sample-workload-editor/:itemObjectId" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_AppLayout_AppLayout__WEBPACK_IMPORTED_MODULE_10__.AppLayout, { workloadClient: workloadClient, "data-testid": "sample-workload-editor" })),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_3__.Route, { path: "/sample-workload-frontend-only" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_AppLayout_AppLayout__WEBPACK_IMPORTED_MODULE_10__.AppLayout, { workloadClient: workloadClient, "data-testid": "sample-workload-frontend-only" })),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_3__.Route, { path: "/sample-workload-create-dialog/:workspaceObjectId" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_SampleWorkloadCreateDialog_SampleWorkloadCreateDialog__WEBPACK_IMPORTED_MODULE_5__.SaveAsDialog, { workloadClient: workloadClient, isImmediateSave: true, "data-testid": "sample-workload-create-dialog" })),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_3__.Route, { path: "/panel" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_SampleWorkloadPanel_SampleWorkloadPanel__WEBPACK_IMPORTED_MODULE_4__.Panel, { workloadClient: workloadClient, "data-testid": "sample-workload-panel" })),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_3__.Route, { path: "/custom-about" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_CustomItemSettings_CustomAbout__WEBPACK_IMPORTED_MODULE_6__["default"], null)),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_3__.Route, { path: "/workspace-settings" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_CustomItemSettings_CustomWorkspaceSettings__WEBPACK_IMPORTED_MODULE_14__["default"], null)),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_3__.Route, { path: "/semantic-model-settings" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_CustomItemSettings_CustomSemanticModelSettings__WEBPACK_IMPORTED_MODULE_15__["default"], null)),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_3__.Route, { path: "/report-settings" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_CustomItemSettings_CustomReportSettings__WEBPACK_IMPORTED_MODULE_16__["default"], null)),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_3__.Route, { path: "/shared-state-page" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_SampleWorkloadSharedState_SharedStatePage__WEBPACK_IMPORTED_MODULE_7__["default"], { workloadClient: workloadClient })),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_3__.Route, { path: "/client-sdk-playground" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_redux__WEBPACK_IMPORTED_MODULE_1__.Provider, { store: _ClientSDKPlaygroundStore_Store__WEBPACK_IMPORTED_MODULE_2__.ClientSDKStore },
                                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_ClientSDKPlayground_ClientSDKPlayground__WEBPACK_IMPORTED_MODULE_8__.ClientSDKPlayground, { workloadClient: workloadClient }))),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_3__.Route, { path: "/sample-page" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_ClientSDKPlayground_ClientSDKPlayground__WEBPACK_IMPORTED_MODULE_8__.SamplePage, { workloadClient: workloadClient })),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_3__.Route, { path: "/data-playground" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_components_DataPlayground_DataPlayground__WEBPACK_IMPORTED_MODULE_9__.DataPlayground, { workloadClient: workloadClient })))))))));
}


/***/ }),

/***/ "./src/ClientSDKPlaygroundStore/Store.ts":
/*!***********************************************!*\
  !*** ./src/ClientSDKPlaygroundStore/Store.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ClientSDKStore: () => (/* binding */ ClientSDKStore)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @reduxjs/toolkit */ "./node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs");
/* harmony import */ var _tabsSlice__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tabsSlice */ "./src/ClientSDKPlaygroundStore/tabsSlice.ts");
/* harmony import */ var _notificationSlice__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./notificationSlice */ "./src/ClientSDKPlaygroundStore/notificationSlice.ts");
/* harmony import */ var _actionDialogSlice__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./actionDialogSlice */ "./src/ClientSDKPlaygroundStore/actionDialogSlice.ts");
/* harmony import */ var _apiDataSlice__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./apiDataSlice */ "./src/ClientSDKPlaygroundStore/apiDataSlice.ts");
/* harmony import */ var _apiPanelSettingsSlice__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./apiPanelSettingsSlice */ "./src/ClientSDKPlaygroundStore/apiPanelSettingsSlice.ts");
/* harmony import */ var _apiAuthenticationSlice__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./apiAuthenticationSlice */ "./src/ClientSDKPlaygroundStore/apiAuthenticationSlice.ts");
/* harmony import */ var _uiComponentsSlice__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./uiComponentsSlice */ "./src/ClientSDKPlaygroundStore/uiComponentsSlice.ts");








const ClientSDKStore = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.configureStore)({
    reducer: {
        tabs: _tabsSlice__WEBPACK_IMPORTED_MODULE_1__["default"],
        notification: _notificationSlice__WEBPACK_IMPORTED_MODULE_2__["default"],
        actionDialog: _actionDialogSlice__WEBPACK_IMPORTED_MODULE_3__["default"],
        apiData: _apiDataSlice__WEBPACK_IMPORTED_MODULE_4__["default"],
        apiPanelSettings: _apiPanelSettingsSlice__WEBPACK_IMPORTED_MODULE_5__["default"],
        apiAuthentication: _apiAuthenticationSlice__WEBPACK_IMPORTED_MODULE_6__["default"],
        uiComponents: _uiComponentsSlice__WEBPACK_IMPORTED_MODULE_7__["default"],
    },
});


/***/ }),

/***/ "./src/ClientSDKPlaygroundStore/actionDialogSlice.ts":
/*!***********************************************************!*\
  !*** ./src/ClientSDKPlaygroundStore/actionDialogSlice.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   actionDialogSlice: () => (/* binding */ actionDialogSlice),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   setLocalSharedStateMessage: () => (/* binding */ setLocalSharedStateMessage),
/* harmony export */   updateApiErrorFailureCode: () => (/* binding */ updateApiErrorFailureCode),
/* harmony export */   updateApiErrorFailureMessage: () => (/* binding */ updateApiErrorFailureMessage),
/* harmony export */   updateApiErrorMessage: () => (/* binding */ updateApiErrorMessage),
/* harmony export */   updateApiErrorRequestId: () => (/* binding */ updateApiErrorRequestId),
/* harmony export */   updateApiErrorStackTrace: () => (/* binding */ updateApiErrorStackTrace),
/* harmony export */   updateApiErrorStatusCode: () => (/* binding */ updateApiErrorStatusCode),
/* harmony export */   updateApiErrorTitle: () => (/* binding */ updateApiErrorTitle),
/* harmony export */   updateButtonCount: () => (/* binding */ updateButtonCount),
/* harmony export */   updateMessageBoxLink: () => (/* binding */ updateMessageBoxLink),
/* harmony export */   updateMessageBoxMessage: () => (/* binding */ updateMessageBoxMessage),
/* harmony export */   updateMessageBoxTitle: () => (/* binding */ updateMessageBoxTitle)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @reduxjs/toolkit */ "./node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs");

const initialState = {
    apiDialogMsgboxTitle: "",
    apiDialogMsgboxContent: "",
    apiDialogMsgboxLink: "",
    apiDialogMsgboxButtonCount: 0,
    sharedStateMessage: "",
    apiErrorTitle: "",
    apiErrorStatusCode: "",
    apiErrorMessage: "",
    apiErrorFailureMessage: "",
    apiErrorFailureCode: 1,
    apiErrorRequestId: "",
    apiErrorStackTrace: "",
};
const actionDialogSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "actionDialog",
    initialState,
    reducers: {
        updateMessageBoxTitle: (state, action) => {
            state.apiDialogMsgboxTitle = action.payload;
        },
        updateMessageBoxMessage: (state, action) => {
            state.apiDialogMsgboxContent = action.payload;
        },
        updateMessageBoxLink: (state, action) => {
            state.apiDialogMsgboxLink = action.payload;
        },
        updateButtonCount: (state, action) => {
            state.apiDialogMsgboxButtonCount = action.payload;
        },
        setLocalSharedStateMessage: (state, action) => {
            state.sharedStateMessage = action.payload;
        },
        updateApiErrorTitle: (state, action) => {
            state.apiErrorTitle = action.payload;
        },
        updateApiErrorStatusCode: (state, action) => {
            state.apiErrorStatusCode = action.payload;
        },
        updateApiErrorMessage: (state, action) => {
            state.apiErrorMessage = action.payload;
        },
        updateApiErrorFailureMessage: (state, action) => {
            state.apiErrorFailureMessage = action.payload;
        },
        updateApiErrorFailureCode: (state, action) => {
            state.apiErrorFailureCode = action.payload;
        },
        updateApiErrorRequestId: (state, action) => {
            state.apiErrorRequestId = action.payload;
        },
        updateApiErrorStackTrace: (state, action) => {
            state.apiErrorStackTrace = action.payload;
        },
    },
});
const { updateMessageBoxTitle, updateMessageBoxMessage, updateMessageBoxLink, updateButtonCount, setLocalSharedStateMessage, updateApiErrorTitle, updateApiErrorStatusCode, updateApiErrorMessage, updateApiErrorFailureMessage, updateApiErrorFailureCode, updateApiErrorRequestId, updateApiErrorStackTrace, } = actionDialogSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (actionDialogSlice.reducer);


/***/ }),

/***/ "./src/ClientSDKPlaygroundStore/apiAuthenticationSlice.ts":
/*!****************************************************************!*\
  !*** ./src/ClientSDKPlaygroundStore/apiAuthenticationSlice.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   apiAuthenticationSlice: () => (/* binding */ apiAuthenticationSlice),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   setAcquireTokenError: () => (/* binding */ setAcquireTokenError),
/* harmony export */   setAdditionalScopesToConsent: () => (/* binding */ setAdditionalScopesToConsent),
/* harmony export */   setClaimsForConditionalAccessPolicy: () => (/* binding */ setClaimsForConditionalAccessPolicy),
/* harmony export */   setHttpMethod: () => (/* binding */ setHttpMethod),
/* harmony export */   setRequestBody: () => (/* binding */ setRequestBody),
/* harmony export */   setRequestDefaultConsent: () => (/* binding */ setRequestDefaultConsent),
/* harmony export */   setServerResponse: () => (/* binding */ setServerResponse),
/* harmony export */   setServerUrl: () => (/* binding */ setServerUrl),
/* harmony export */   setToken: () => (/* binding */ setToken)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @reduxjs/toolkit */ "./node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs");

const initialState = {
    claimsForConditionalAccessPolicy: '',
    additionalScopesToConsent: '',
    token: '',
    acquireTokenError: '',
    serverUrl: '',
    serverResponse: '',
    httpMethod: '',
    requestBody: '',
    requestDefaultConsent: false,
};
const apiAuthenticationSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "apiAuthentication",
    initialState,
    reducers: {
        setClaimsForConditionalAccessPolicy: (state, action) => {
            state.claimsForConditionalAccessPolicy = action.payload;
        },
        setAdditionalScopesToConsent: (state, action) => {
            state.additionalScopesToConsent = action.payload;
        },
        setToken: (state, action) => {
            state.token = action.payload;
        },
        setAcquireTokenError: (state, action) => {
            state.acquireTokenError = action.payload;
        },
        setServerUrl: (state, action) => {
            state.serverUrl = action.payload;
        },
        setServerResponse: (state, action) => {
            state.serverResponse = action.payload;
        },
        setHttpMethod: (state, action) => {
            state.httpMethod = action.payload;
        },
        setRequestBody: (state, action) => {
            state.requestBody = action.payload;
        },
        setRequestDefaultConsent: (state, action) => {
            state.requestDefaultConsent = action.payload;
        },
    },
});
const { setClaimsForConditionalAccessPolicy, setAdditionalScopesToConsent, setToken, setAcquireTokenError, setServerUrl, setServerResponse, setHttpMethod, setRequestBody, setRequestDefaultConsent, } = apiAuthenticationSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (apiAuthenticationSlice.reducer);


/***/ }),

/***/ "./src/ClientSDKPlaygroundStore/apiDataSlice.ts":
/*!******************************************************!*\
  !*** ./src/ClientSDKPlaygroundStore/apiDataSlice.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   apiDataSlice: () => (/* binding */ apiDataSlice),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   initializeApiData: () => (/* binding */ initializeApiData),
/* harmony export */   setDataHubMsgBoxType: () => (/* binding */ setDataHubMsgBoxType),
/* harmony export */   setDatahubDialogDescription: () => (/* binding */ setDatahubDialogDescription),
/* harmony export */   setMultiSelectionEnabled: () => (/* binding */ setMultiSelectionEnabled),
/* harmony export */   setSelectedLinkedItem: () => (/* binding */ setSelectedLinkedItem),
/* harmony export */   setWorkspaceExplorerPresented: () => (/* binding */ setWorkspaceExplorerPresented)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @reduxjs/toolkit */ "./node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs");

const initialState = {
    datahubDialogDescription: "Dialog description",
    dataHubMsgBoxType: "",
    isWorkspaceExplorerPresented: false,
    isMultiSelectionEnabled: false,
    selectedLinkedItem: null,
};
const apiDataSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "apiData",
    initialState,
    reducers: {
        initializeApiData: (state, action) => {
            state.dataHubMsgBoxType = action.payload;
        },
        setDatahubDialogDescription: (state, action) => {
            state.datahubDialogDescription = action.payload;
        },
        setDataHubMsgBoxType: (state, action) => {
            state.dataHubMsgBoxType = action.payload;
        },
        setWorkspaceExplorerPresented: (state, action) => {
            state.isWorkspaceExplorerPresented = action.payload;
        },
        setMultiSelectionEnabled: (state, action) => {
            state.isMultiSelectionEnabled = action.payload;
        },
        setSelectedLinkedItem: (state, action) => {
            state.selectedLinkedItem = action.payload;
        },
    },
});
const { initializeApiData, setDatahubDialogDescription, setDataHubMsgBoxType, setWorkspaceExplorerPresented, setMultiSelectionEnabled, setSelectedLinkedItem, } = apiDataSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (apiDataSlice.reducer);


/***/ }),

/***/ "./src/ClientSDKPlaygroundStore/apiPanelSettingsSlice.ts":
/*!***************************************************************!*\
  !*** ./src/ClientSDKPlaygroundStore/apiPanelSettingsSlice.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   apiPanelSettingsSlice: () => (/* binding */ apiPanelSettingsSlice),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   setApiPanelIsLightDismiss: () => (/* binding */ setApiPanelIsLightDismiss)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @reduxjs/toolkit */ "./node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs");

const initialState = {
    apiPanelIsLightDismiss: false,
};
const apiPanelSettingsSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "apiPanelSettings",
    initialState,
    reducers: {
        setApiPanelIsLightDismiss: (state, action) => {
            state.apiPanelIsLightDismiss = action.payload;
        },
    },
});
const { setApiPanelIsLightDismiss } = apiPanelSettingsSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (apiPanelSettingsSlice.reducer);


/***/ }),

/***/ "./src/ClientSDKPlaygroundStore/notificationSlice.ts":
/*!***********************************************************!*\
  !*** ./src/ClientSDKPlaygroundStore/notificationSlice.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   notificationSlice: () => (/* binding */ notificationSlice),
/* harmony export */   setMessage: () => (/* binding */ setMessage),
/* harmony export */   setTitle: () => (/* binding */ setTitle)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @reduxjs/toolkit */ "./node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs");

const initialState = {
    apiNotificationTitle: "",
    apiNotificationMessage: "",
};
const notificationSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "notification",
    initialState,
    reducers: {
        setTitle: (state, action) => {
            state.apiNotificationTitle = action.payload;
        },
        setMessage: (state, action) => {
            state.apiNotificationMessage = action.payload;
        },
    },
});
const { setTitle, setMessage } = notificationSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (notificationSlice.reducer);


/***/ }),

/***/ "./src/ClientSDKPlaygroundStore/tabsSlice.ts":
/*!***************************************************!*\
  !*** ./src/ClientSDKPlaygroundStore/tabsSlice.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   setSelectedTab: () => (/* binding */ setSelectedTab),
/* harmony export */   tabsSlice: () => (/* binding */ tabsSlice)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @reduxjs/toolkit */ "./node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs");

const initialState = {
    selectedTab: "apiNotification",
};
const tabsSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "tabs",
    initialState,
    reducers: {
        setSelectedTab: (state, action) => {
            state.selectedTab = action.payload;
        },
    },
});
const { setSelectedTab } = tabsSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (tabsSlice.reducer);


/***/ }),

/***/ "./src/ClientSDKPlaygroundStore/uiComponentsSlice.ts":
/*!***********************************************************!*\
  !*** ./src/ClientSDKPlaygroundStore/uiComponentsSlice.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   setCheckboxChecked: () => (/* binding */ setCheckboxChecked),
/* harmony export */   setSampleInput: () => (/* binding */ setSampleInput),
/* harmony export */   setSelectedRadio: () => (/* binding */ setSelectedRadio),
/* harmony export */   setSwitchChecked: () => (/* binding */ setSwitchChecked),
/* harmony export */   uiComponentsSlice: () => (/* binding */ uiComponentsSlice)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @reduxjs/toolkit */ "./node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs");

const initialState = {
    sampleInput: '',
    checkboxChecked: false,
    selectedRadio: 'option1',
    switchChecked: false,
};
const uiComponentsSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "uiComponents",
    initialState,
    reducers: {
        setSampleInput: (state, action) => {
            state.sampleInput = action.payload;
        },
        setCheckboxChecked: (state, action) => {
            state.checkboxChecked = action.payload;
        },
        setSelectedRadio: (state, action) => {
            state.selectedRadio = action.payload;
        },
        setSwitchChecked: (state, action) => {
            state.switchChecked = action.payload;
        },
    },
});
const { setSampleInput, setCheckboxChecked, setSelectedRadio, setSwitchChecked } = uiComponentsSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (uiComponentsSlice.reducer);


/***/ }),

/***/ "./src/assets/MAQ_LOGO.jpg":
/*!*********************************!*\
  !*** ./src/assets/MAQ_LOGO.jpg ***!
  \*********************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "80778ce2e71052f6bc97.jpg";

/***/ }),

/***/ "./src/components/AppLayout/AppLayout.tsx":
/*!************************************************!*\
  !*** ./src/components/AppLayout/AppLayout.tsx ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppLayout: () => (/* binding */ AppLayout)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Header_Header__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../Header/Header */ "./src/components/Header/Header.tsx");
/* harmony import */ var _Dashboard_Dashboard__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../Dashboard/Dashboard */ "./src/components/Dashboard/Dashboard.tsx");
/* harmony import */ var _ReviewFindings_ReviewFindings__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../ReviewFindings/ReviewFindings */ "./src/components/ReviewFindings/ReviewFindings.tsx");
/* harmony import */ var _EventHistory_EventHistory__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../EventHistory/EventHistory */ "./src/components/EventHistory/EventHistory.tsx");
/* harmony import */ var _controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../controller/SampleWorkloadController */ "./src/controller/SampleWorkloadController.ts");
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router/esm/react-router.js");
// AppLayout.tsx







function AppLayout(props) {
    const [selectedTab, setSelectedTab] = react__WEBPACK_IMPORTED_MODULE_0___default().useState('dashboard');
    const { itemObjectId } = (0,react_router_dom__WEBPACK_IMPORTED_MODULE_6__.useParams)();
    const renderContent = () => {
        switch (selectedTab) {
            case 'dashboard':
                return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_Dashboard_Dashboard__WEBPACK_IMPORTED_MODULE_2__.Dashboard, { workloadClient: props.workloadClient, setSelectedTab: setSelectedTab });
            case 'review':
                return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ReviewFindings_ReviewFindings__WEBPACK_IMPORTED_MODULE_3__.ReviewFindings, { workloadClient: props.workloadClient });
            case 'history':
                return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_EventHistory_EventHistory__WEBPACK_IMPORTED_MODULE_4__.EventHistory, { workloadClient: props.workloadClient });
            default:
                return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ReviewFindings_ReviewFindings__WEBPACK_IMPORTED_MODULE_3__.ReviewFindings, { workloadClient: props.workloadClient });
        }
    };
    const handleSettings = async () => {
        try {
            const item = await (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_5__.callItemGet)(itemObjectId, props.workloadClient);
            await (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_5__.callOpenSettings)(item, props.workloadClient, 'About');
        }
        catch (error) {
            console.error('Failed to open settings:', error);
        }
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: rootGridStyle },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: headerStyle },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_Header_Header__WEBPACK_IMPORTED_MODULE_1__.Header, { selectedTab: selectedTab, onTabChange: setSelectedTab, onSettings: handleSettings })),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("main", { style: contentScrollStyle }, renderContent())));
}
// Styles
const rootGridStyle = {
    display: 'grid',
    gridTemplateRows: 'auto 1fr',
    height: '100vh',
    overflow: 'hidden',
};
const headerStyle = {
    position: 'sticky',
    top: 0,
    zIndex: 1,
};
const contentScrollStyle = {
    overflowY: 'auto',
    overflowX: 'hidden',
};


/***/ }),

/***/ "./src/components/ClientSDKPlayground/ActionDialog/ActionExample.tsx":
/*!***************************************************************************!*\
  !*** ./src/components/ClientSDKPlayground/ActionDialog/ActionExample.tsx ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ActionExample: () => (/* binding */ ActionExample)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-button/lib/components/Button/Button.js");
/* harmony import */ var _fluentui_react_icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @fluentui/react-icons */ "./node_modules/@fluentui/react-icons/lib/sizedIcons/chunk-9.js");
/* harmony import */ var _controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../controller/SampleWorkloadController */ "./src/controller/SampleWorkloadController.ts");
/* harmony import */ var _styles_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../styles.scss */ "./src/styles.scss");





function ActionExample(props) {
    const { sampleWorkloadName, workloadClient } = props;
    async function onCallExecuteAction() {
        (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_3__.callActionExecute)("sample.Action", sampleWorkloadName, workloadClient);
    }
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "section" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Button, { appearance: "primary", icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_2__.PanelRightExpand20Regular, null), onClick: onCallExecuteAction }, "Execute an Action")));
}
;


/***/ }),

/***/ "./src/components/ClientSDKPlayground/ActionDialog/ApiActionDialog.tsx":
/*!*****************************************************************************!*\
  !*** ./src/components/ClientSDKPlayground/ActionDialog/ApiActionDialog.tsx ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ApiActionDialog: () => (/* binding */ ApiActionDialog),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-divider/lib/components/Divider/Divider.js");
/* harmony import */ var _ActionExample__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ActionExample */ "./src/components/ClientSDKPlayground/ActionDialog/ActionExample.tsx");
/* harmony import */ var _MessageBoxExample__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./MessageBoxExample */ "./src/components/ClientSDKPlayground/ActionDialog/MessageBoxExample.tsx");
/* harmony import */ var _SharedStateExample__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./SharedStateExample */ "./src/components/ClientSDKPlayground/ActionDialog/SharedStateExample.tsx");
/* harmony import */ var _ErrorMessageExample__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./ErrorMessageExample */ "./src/components/ClientSDKPlayground/ActionDialog/ErrorMessageExample.tsx");
/* harmony import */ var _styles_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../styles.scss */ "./src/styles.scss");







function ApiActionDialog(props) {
    const { sampleWorkloadName, workloadClient } = props;
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Divider, { alignContent: "start" }, "Action"),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ActionExample__WEBPACK_IMPORTED_MODULE_2__.ActionExample, { sampleWorkloadName: sampleWorkloadName, workloadClient: workloadClient }),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Divider, { alignContent: "start" }, "Dialog Message Box"),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_MessageBoxExample__WEBPACK_IMPORTED_MODULE_3__.MessageBoxExample, { sampleWorkloadName: sampleWorkloadName, workloadClient: workloadClient }),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Divider, { alignContent: "start" }, "Shared State"),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_SharedStateExample__WEBPACK_IMPORTED_MODULE_4__.SharedStateExample, { sampleWorkloadName: sampleWorkloadName, workloadClient: workloadClient }),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Divider, { alignContent: "start" }, "Error Handling"),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ErrorMessageExample__WEBPACK_IMPORTED_MODULE_5__.ErrorMessageExample, { sampleWorkloadName: sampleWorkloadName, workloadClient: workloadClient })));
}
;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ApiActionDialog);


/***/ }),

/***/ "./src/components/ClientSDKPlayground/ActionDialog/ErrorMessageExample.tsx":
/*!*********************************************************************************!*\
  !*** ./src/components/ClientSDKPlayground/ActionDialog/ErrorMessageExample.tsx ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ErrorMessageExample: () => (/* binding */ ErrorMessageExample)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/dist/react-redux.mjs");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-field/lib/components/Field/Field.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-input/lib/components/Input/Input.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-button/lib/components/Button/Button.js");
/* harmony import */ var _fluentui_react_icons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @fluentui/react-icons */ "./node_modules/@fluentui/react-icons/lib/sizedIcons/chunk-9.js");
/* harmony import */ var _ClientSDKPlaygroundStore_actionDialogSlice__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../ClientSDKPlaygroundStore/actionDialogSlice */ "./src/ClientSDKPlaygroundStore/actionDialogSlice.ts");
/* harmony import */ var _controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../controller/SampleWorkloadController */ "./src/controller/SampleWorkloadController.ts");
/* harmony import */ var _styles_scss__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../styles.scss */ "./src/styles.scss");







function ErrorMessageExample(props) {
    const { workloadClient } = props;
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useDispatch)();
    const { apiErrorTitle, apiErrorMessage, apiErrorRequestId, apiErrorStatusCode, apiErrorStackTrace, apiErrorFailureMessage, apiErrorFailureCode, } = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state) => state.actionDialog);
    async function onCallOpenError() {
        await (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_7__.callErrorHandlingOpenDialog)(apiErrorMessage, apiErrorTitle, apiErrorStatusCode, apiErrorStackTrace, apiErrorRequestId, workloadClient);
    }
    async function onCallErrorFailureHandling() {
        await (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_7__.callErrorHandlingRequestFailure)(apiErrorFailureMessage, apiErrorFailureCode, workloadClient);
    }
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "section" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Field, { label: "Error Title", orientation: "horizontal", className: "field" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Input, { size: "small", placeholder: "Error title", value: apiErrorTitle, onChange: (e) => dispatch((0,_ClientSDKPlaygroundStore_actionDialogSlice__WEBPACK_IMPORTED_MODULE_6__.updateApiErrorTitle)(e.target.value)) })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Field, { label: "Error Message", orientation: "horizontal", className: "field" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Input, { size: "small", placeholder: "Error message", value: apiErrorMessage, onChange: (e) => dispatch((0,_ClientSDKPlaygroundStore_actionDialogSlice__WEBPACK_IMPORTED_MODULE_6__.updateApiErrorMessage)(e.target.value)) })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Field, { label: "Error Request ID", orientation: "horizontal", className: "field" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Input, { size: "small", placeholder: "Request ID", value: apiErrorRequestId, onChange: (e) => dispatch((0,_ClientSDKPlaygroundStore_actionDialogSlice__WEBPACK_IMPORTED_MODULE_6__.updateApiErrorRequestId)(e.target.value)) })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Field, { label: "Error Status Code", orientation: "horizontal", className: "field" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Input, { size: "small", placeholder: "Status Code", value: apiErrorStatusCode, onChange: (e) => dispatch((0,_ClientSDKPlaygroundStore_actionDialogSlice__WEBPACK_IMPORTED_MODULE_6__.updateApiErrorStatusCode)(e.target.value)) })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Field, { label: "Error Stack Trace", orientation: "horizontal", className: "field" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Input, { size: "small", placeholder: "Stack Trace", value: apiErrorStackTrace, onChange: (e) => dispatch((0,_ClientSDKPlaygroundStore_actionDialogSlice__WEBPACK_IMPORTED_MODULE_6__.updateApiErrorStackTrace)(e.target.value)) })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.Button, { appearance: "primary", icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_5__.PanelRightExpand20Regular, null), onClick: onCallOpenError }, "Open Error")),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "section" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Field, { label: "Error", orientation: "horizontal", className: "field" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Input, { size: "small", placeholder: "Error message", value: apiErrorFailureMessage, onChange: (e) => dispatch((0,_ClientSDKPlaygroundStore_actionDialogSlice__WEBPACK_IMPORTED_MODULE_6__.updateApiErrorFailureMessage)(e.target.value)) })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Field, { label: "Error Status Code", orientation: "horizontal", className: "field" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Input, { size: "small", type: "number", placeholder: "Error Status Code", value: apiErrorFailureCode.toString(), onChange: (e) => dispatch((0,_ClientSDKPlaygroundStore_actionDialogSlice__WEBPACK_IMPORTED_MODULE_6__.updateApiErrorFailureCode)(e.target.valueAsNumber)) })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.Button, { appearance: "primary", icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_5__.PanelRightExpand20Regular, null), onClick: onCallErrorFailureHandling }, "Call Request Failure Handling"))));
}
;


/***/ }),

/***/ "./src/components/ClientSDKPlayground/ActionDialog/MessageBoxExample.tsx":
/*!*******************************************************************************!*\
  !*** ./src/components/ClientSDKPlayground/ActionDialog/MessageBoxExample.tsx ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MessageBoxExample: () => (/* binding */ MessageBoxExample)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/dist/react-redux.mjs");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-field/lib/components/Field/Field.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-input/lib/components/Input/Input.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-tooltip/lib/components/Tooltip/Tooltip.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-combobox/lib/components/Combobox/Combobox.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-combobox/lib/components/Option/Option.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-button/lib/components/Button/Button.js");
/* harmony import */ var _fluentui_react_icons__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @fluentui/react-icons */ "./node_modules/@fluentui/react-icons/lib/sizedIcons/chunk-9.js");
/* harmony import */ var _ClientSDKPlaygroundStore_actionDialogSlice__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../ClientSDKPlaygroundStore/actionDialogSlice */ "./src/ClientSDKPlaygroundStore/actionDialogSlice.ts");
/* harmony import */ var _controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../controller/SampleWorkloadController */ "./src/controller/SampleWorkloadController.ts");
/* harmony import */ var _styles_scss__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../styles.scss */ "./src/styles.scss");







function MessageBoxExample(props) {
    const { workloadClient } = props;
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useDispatch)();
    const { apiDialogMsgboxTitle, apiDialogMsgboxContent, apiDialogMsgboxLink, apiDialogMsgboxButtonCount, } = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state) => state.actionDialog);
    const msgboxButtonCountOptions = ["0", "1", "2", "3"];
    async function onCallOpenMessageBox() {
        const buttonNames = [];
        for (let i = 1; i <= apiDialogMsgboxButtonCount; ++i) {
            buttonNames.push(`Button ${i}`);
        }
        (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_10__.callDialogOpenMsgBox)(apiDialogMsgboxTitle, apiDialogMsgboxContent, buttonNames, workloadClient, apiDialogMsgboxLink);
    }
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "section" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Field, { label: "Message Box Title", orientation: "horizontal", className: "field" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Input, { size: "small", placeholder: "Title", value: apiDialogMsgboxTitle, onChange: (e) => dispatch((0,_ClientSDKPlaygroundStore_actionDialogSlice__WEBPACK_IMPORTED_MODULE_9__.updateMessageBoxTitle)(e.target.value)) })),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Field, { label: "Message Box Content", orientation: "horizontal", className: "field" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Input, { size: "small", placeholder: "Content...", value: apiDialogMsgboxContent, onChange: (e) => dispatch((0,_ClientSDKPlaygroundStore_actionDialogSlice__WEBPACK_IMPORTED_MODULE_9__.updateMessageBoxMessage)(e.target.value)) })),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.Tooltip, { content: "Link must start with 'https://', and can't be window's origin or belong to one of Fabric's known domains (such as 'powerbi.com', 'fabric.microsoft.com' or 'analysis.windows.net')", relationship: "label" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Field, { label: "Message Box Link", orientation: "horizontal", className: "field" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Input, { size: "small", placeholder: "Link", value: apiDialogMsgboxLink, onChange: (e) => dispatch((0,_ClientSDKPlaygroundStore_actionDialogSlice__WEBPACK_IMPORTED_MODULE_9__.updateMessageBoxLink)(e.target.value)) }))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.Combobox, { placeholder: "Buttons count", value: apiDialogMsgboxButtonCount.toString(), onOptionSelect: (_, opt) => dispatch((0,_ClientSDKPlaygroundStore_actionDialogSlice__WEBPACK_IMPORTED_MODULE_9__.updateButtonCount)(parseInt(opt.optionValue))) }, msgboxButtonCountOptions.map((option) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__.Option, { key: option }, option)))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_7__.Button, { appearance: "primary", icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_8__.PanelRightExpand20Regular, null), onClick: onCallOpenMessageBox }, "Open Dialog Message Box")));
}
;


/***/ }),

/***/ "./src/components/ClientSDKPlayground/ActionDialog/SharedStateExample.tsx":
/*!********************************************************************************!*\
  !*** ./src/components/ClientSDKPlayground/ActionDialog/SharedStateExample.tsx ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SharedStateExample: () => (/* binding */ SharedStateExample)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/dist/react-redux.mjs");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-field/lib/components/Field/Field.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-input/lib/components/Input/Input.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-button/lib/components/Button/Button.js");
/* harmony import */ var _fluentui_react_icons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @fluentui/react-icons */ "./node_modules/@fluentui/react-icons/lib/sizedIcons/chunk-9.js");
/* harmony import */ var _ClientSDKPlaygroundStore_actionDialogSlice__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../ClientSDKPlaygroundStore/actionDialogSlice */ "./src/ClientSDKPlaygroundStore/actionDialogSlice.ts");
/* harmony import */ var _controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../controller/SampleWorkloadController */ "./src/controller/SampleWorkloadController.ts");
/* harmony import */ var _styles_scss__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../styles.scss */ "./src/styles.scss");







function SharedStateExample(props) {
    const { workloadClient, sampleWorkloadName } = props;
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useDispatch)();
    const sharedState = workloadClient.state.sharedState;
    const localSharedStateMessage = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state) => state.actionDialog.sharedStateMessage);
    async function onCallSharedStatePage() {
        sharedState.message = localSharedStateMessage;
        await (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_7__.callDialogOpen)(sampleWorkloadName, '/shared-state-page', 360 /* width */, 165 /* height */, false /* hasCloseButton */, workloadClient);
        if (localSharedStateMessage != sharedState.message) {
            dispatch((0,_ClientSDKPlaygroundStore_actionDialogSlice__WEBPACK_IMPORTED_MODULE_6__.setLocalSharedStateMessage)(sharedState.message));
        }
    }
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "section" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Field, { label: "Shared State", orientation: "horizontal", className: "field" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Input, { size: "small", placeholder: "Message", value: localSharedStateMessage, onChange: (e) => dispatch((0,_ClientSDKPlaygroundStore_actionDialogSlice__WEBPACK_IMPORTED_MODULE_6__.setLocalSharedStateMessage)(e.target.value)), "data-testid": "shared-state-input" })),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.Button, { appearance: "primary", icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_5__.PanelRightExpand20Regular, null), onClick: onCallSharedStatePage }, "Open Shared State Page")));
}
;


/***/ }),

/***/ "./src/components/ClientSDKPlayground/ApiAuthentication.tsx":
/*!******************************************************************!*\
  !*** ./src/components/ClientSDKPlayground/ApiAuthentication.tsx ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ApiAuthentication: () => (/* binding */ ApiAuthentication)
/* harmony export */ });
/* harmony import */ var jwt_decode__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jwt-decode */ "./node_modules/jwt-decode/build/jwt-decode.esm.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/dist/react-redux.mjs");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-card/lib/components/Card/Card.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-input/lib/components/Input/Input.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-checkbox/lib/components/Checkbox/Checkbox.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-button/lib/components/Button/Button.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-combobox/lib/components/Combobox/Combobox.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-combobox/lib/components/Option/Option.js");
/* harmony import */ var _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ms-fabric/workload-client */ "./node_modules/@ms-fabric/workload-client/src/workload-client.js");
/* harmony import */ var _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _ClientSDKPlaygroundStore_apiAuthenticationSlice__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../ClientSDKPlaygroundStore/apiAuthenticationSlice */ "./src/ClientSDKPlaygroundStore/apiAuthenticationSlice.ts");
/* harmony import */ var _controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../controller/SampleWorkloadController */ "./src/controller/SampleWorkloadController.ts");
/* harmony import */ var _styles_scss__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./../../styles.scss */ "./src/styles.scss");








function ApiAuthentication({ workloadClient }) {
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useDispatch)();
    const { claimsForConditionalAccessPolicy, additionalScopesToConsent, token, acquireTokenError, serverUrl, serverResponse, httpMethod, requestBody, requestDefaultConsent, } = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useSelector)((state) => state.apiAuthentication);
    const httpMethods = ['GET', 'PUT', 'POST'];
    return (react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "api-authentication" },
        react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Card, { className: "card" },
            react__WEBPACK_IMPORTED_MODULE_1___default().createElement("h3", null, "Description"),
            react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "card-content" },
                react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "description" },
                    "Welcome to the authentication section!\nFor this to work please make sure to add your AAD application configuration to your workload manifest or localWorkloadManifest.json under \"workload\" for dev:\n",
                    react__WEBPACK_IMPORTED_MODULE_1___default().createElement("b", null, "devAADAppConfig:\n \u2003\u2003appId: your app id\n \u2003\u2003redirectUri: a redirect URI that returns an html containing close() javascript function\n \u2003\u2003audience: your audience"),
                    "\n"))),
        react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Card, { className: "card" },
            react__WEBPACK_IMPORTED_MODULE_1___default().createElement("h3", null, "Generate a token"),
            react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "card-content" },
                react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "field-group" },
                    react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "api-authentication-field" },
                        react__WEBPACK_IMPORTED_MODULE_1___default().createElement("label", { className: "api-authentication-field-label" },
                            "Additional scopes to consent",
                            react__WEBPACK_IMPORTED_MODULE_1___default().createElement("br", null),
                            "(separated by a space):"),
                        react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.Input, { className: "api-authentication-input", size: "medium", placeholder: "Scopes", value: additionalScopesToConsent, onChange: e => dispatch((0,_ClientSDKPlaygroundStore_apiAuthenticationSlice__WEBPACK_IMPORTED_MODULE_10__.setAdditionalScopesToConsent)(e.target.value)) })),
                    react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "api-authentication-field" },
                        react__WEBPACK_IMPORTED_MODULE_1___default().createElement("label", { className: "api-authentication-field-label" }, "Claims for conditional access:"),
                        react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.Input, { className: "api-authentication-input", size: "medium", placeholder: "Claims", value: claimsForConditionalAccessPolicy, onChange: e => dispatch((0,_ClientSDKPlaygroundStore_apiAuthenticationSlice__WEBPACK_IMPORTED_MODULE_10__.setClaimsForConditionalAccessPolicy)(e.target.value)) })),
                    react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.Checkbox, { label: "Request Initial Consent", checked: requestDefaultConsent, onChange: (v) => dispatch((0,_ClientSDKPlaygroundStore_apiAuthenticationSlice__WEBPACK_IMPORTED_MODULE_10__.setRequestDefaultConsent)(v.target.checked)) }),
                    react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "api-authentication-field" },
                        react__WEBPACK_IMPORTED_MODULE_1___default().createElement("label", { className: "api-authentication-field-label" }),
                        react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__.Button, { className: "authButton", appearance: "primary", onClick: () => (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_11__.callAuthAcquireAccessToken)(workloadClient, requestDefaultConsent ? '.default' : additionalScopesToConsent, claimsForConditionalAccessPolicy)
                                .then(result => dispatch((0,_ClientSDKPlaygroundStore_apiAuthenticationSlice__WEBPACK_IMPORTED_MODULE_10__.setToken)(result.token)))
                                .catch((errorResult) => {
                                dispatch((0,_ClientSDKPlaygroundStore_apiAuthenticationSlice__WEBPACK_IMPORTED_MODULE_10__.setToken)(''));
                                switch (errorResult.error) {
                                    case _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_9__.WorkloadAuthError.WorkloadConfigError:
                                        dispatch((0,_ClientSDKPlaygroundStore_apiAuthenticationSlice__WEBPACK_IMPORTED_MODULE_10__.setAcquireTokenError)("Workload config error - make sure that you have added the right configuration for your AAD app!"));
                                        break;
                                    case _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_9__.WorkloadAuthError.UserInteractionFailedError:
                                        dispatch((0,_ClientSDKPlaygroundStore_apiAuthenticationSlice__WEBPACK_IMPORTED_MODULE_10__.setAcquireTokenError)("User interaction failed!"));
                                        break;
                                    case _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_9__.WorkloadAuthError.UnsupportedError:
                                        dispatch((0,_ClientSDKPlaygroundStore_apiAuthenticationSlice__WEBPACK_IMPORTED_MODULE_10__.setAcquireTokenError)("Authentication is not supported in this environment!"));
                                        break;
                                    default:
                                        dispatch((0,_ClientSDKPlaygroundStore_apiAuthenticationSlice__WEBPACK_IMPORTED_MODULE_10__.setAcquireTokenError)("Failed to fetch token"));
                                }
                            }) }, "Get access token")),
                    react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "api-authentication-field" },
                        react__WEBPACK_IMPORTED_MODULE_1___default().createElement("label", { className: "api-authentication-field-label" }, "Token:"),
                        react__WEBPACK_IMPORTED_MODULE_1___default().createElement("textarea", { className: "api-authentication-textarea", rows: 10, readOnly: true, value: token ? JSON.stringify((0,jwt_decode__WEBPACK_IMPORTED_MODULE_0__["default"])(token), null, "\t") : acquireTokenError }))))),
        react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Card, { className: "card" },
            react__WEBPACK_IMPORTED_MODULE_1___default().createElement("h3", null, "Call your server with the token generated below"),
            react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "card-content" },
                react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "field-group" },
                    react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "api-authentication-field" },
                        react__WEBPACK_IMPORTED_MODULE_1___default().createElement("label", { className: "api-authentication-field-label" }, "Server endpoint:"),
                        react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.Input, { className: "api-authentication-input", size: "medium", placeholder: "Your server's endpoint (e.g. https://localhost:5001/getLakehouseFile?source=...)", value: serverUrl, onChange: e => dispatch((0,_ClientSDKPlaygroundStore_apiAuthenticationSlice__WEBPACK_IMPORTED_MODULE_10__.setServerUrl)(e.target.value)) })),
                    react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "api-authentication-field" },
                        react__WEBPACK_IMPORTED_MODULE_1___default().createElement("label", { className: "api-authentication-field-label" }, "Http method:"),
                        react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_7__.Combobox, { className: "api-authentication-input", placeholder: "method", value: httpMethod, onOptionSelect: (_, opt) => dispatch((0,_ClientSDKPlaygroundStore_apiAuthenticationSlice__WEBPACK_IMPORTED_MODULE_10__.setHttpMethod)(opt.optionValue)) }, httpMethods.map((option) => (react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_8__.Option, { key: option }, option))))),
                    react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "api-authentication-field" },
                        react__WEBPACK_IMPORTED_MODULE_1___default().createElement("label", { className: "api-authentication-field-label" }, "Request body:"),
                        react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.Input, { className: "api-authentication-input", size: "medium", placeholder: "Content", value: requestBody, onChange: e => dispatch((0,_ClientSDKPlaygroundStore_apiAuthenticationSlice__WEBPACK_IMPORTED_MODULE_10__.setRequestBody)(e.target.value)) })),
                    react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "api-authentication-field" },
                        react__WEBPACK_IMPORTED_MODULE_1___default().createElement("label", { className: "api-authentication-field-label" }),
                        react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__.Button, { className: "authButton", appearance: "primary", onClick: () => sendWorkloadServerRequest(serverUrl, token, httpMethod, requestBody).then(result => dispatch((0,_ClientSDKPlaygroundStore_apiAuthenticationSlice__WEBPACK_IMPORTED_MODULE_10__.setServerResponse)(result))) }, "Call server's API")),
                    react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "api-authentication-field" },
                        react__WEBPACK_IMPORTED_MODULE_1___default().createElement("label", { className: "api-authentication-field-label" }, "Response:"),
                        react__WEBPACK_IMPORTED_MODULE_1___default().createElement("textarea", { className: "api-authentication-textarea", rows: 10, readOnly: true, value: serverResponse })))))));
}
function sendWorkloadServerRequest(url, token, httpMethod, requestBody) {
    if (url.length == 0) {
        return Promise.resolve('Please provide a valid url');
    }
    if (httpMethod == 'PUT') {
        return fetch(url, { method: httpMethod, body: requestBody, headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token } }).then(response => response.text());
    }
    return fetch(url, { method: httpMethod, headers: { 'Authorization': 'Bearer ' + token } }).then(response => response.text());
}


/***/ }),

/***/ "./src/components/ClientSDKPlayground/ApiData.tsx":
/*!********************************************************!*\
  !*** ./src/components/ClientSDKPlayground/ApiData.tsx ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ApiData: () => (/* binding */ ApiData)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/dist/react-redux.mjs");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-divider/lib/components/Divider/Divider.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-field/lib/components/Field/Field.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-input/lib/components/Input/Input.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-combobox/lib/components/Combobox/Combobox.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-combobox/lib/components/Option/Option.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-switch/lib/components/Switch/Switch.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-button/lib/components/Button/Button.js");
/* harmony import */ var _fluentui_react_icons__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @fluentui/react-icons */ "./node_modules/@fluentui/react-icons/lib/sizedIcons/chunk-4.js");
/* harmony import */ var _ClientSDKPlaygroundStore_apiDataSlice__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../ClientSDKPlaygroundStore/apiDataSlice */ "./src/ClientSDKPlaygroundStore/apiDataSlice.ts");
/* harmony import */ var _controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../controller/SampleWorkloadController */ "./src/controller/SampleWorkloadController.ts");
/* harmony import */ var _styles_scss__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./../../styles.scss */ "./src/styles.scss");







function ApiData(props) {
    const { sampleWorkloadName, workloadClient } = props;
    const sampleItemType = sampleWorkloadName + ".SampleWorkloadItem";
    const dataHubMsgBoxTypes = ["Lakehouse", sampleItemType];
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useDispatch)();
    const { datahubDialogDescription, dataHubMsgBoxType, isWorkspaceExplorerPresented, isMultiSelectionEnabled, selectedLinkedItem, } = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state) => state.apiData);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (!dataHubMsgBoxType) {
            dispatch((0,_ClientSDKPlaygroundStore_apiDataSlice__WEBPACK_IMPORTED_MODULE_10__.initializeApiData)(sampleItemType));
        }
    }, [dispatch, sampleItemType, dataHubMsgBoxType]);
    async function onCallDatahubFromPlayground() {
        const result = await (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_11__.callDatahubOpen)([dataHubMsgBoxType], datahubDialogDescription, isMultiSelectionEnabled, workloadClient, isWorkspaceExplorerPresented);
        if (result) {
            dispatch((0,_ClientSDKPlaygroundStore_apiDataSlice__WEBPACK_IMPORTED_MODULE_10__.setSelectedLinkedItem)(result));
        }
    }
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Divider, { alignContent: "start" }, "Selected item settings"),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "section" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Field, { label: "Dialog description", orientation: "horizontal", className: "field" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.Input, { size: "small", placeholder: "Dialog description", style: { marginLeft: "10px" }, value: datahubDialogDescription !== null && datahubDialogDescription !== void 0 ? datahubDialogDescription : "", onChange: (e) => dispatch((0,_ClientSDKPlaygroundStore_apiDataSlice__WEBPACK_IMPORTED_MODULE_10__.setDatahubDialogDescription)(e.target.value)), "data-testid": "api-playground-data-hub-description" })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Field, { label: "Supported types", orientation: "horizontal", className: "field" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.Combobox, { placeholder: "Item types", value: dataHubMsgBoxType, "data-testid": "api-playground-data-hub-supported-types", onOptionSelect: (_, opt) => dispatch((0,_ClientSDKPlaygroundStore_apiDataSlice__WEBPACK_IMPORTED_MODULE_10__.setDataHubMsgBoxType)(opt.optionValue)) }, dataHubMsgBoxTypes.map((option) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__.Option, { key: option }, option))))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_7__.Switch, { label: "Present workspace explorer", "data-testid": "api-playground-data-hub-workspace-explorer-switch", checked: isWorkspaceExplorerPresented, onChange: (e) => dispatch((0,_ClientSDKPlaygroundStore_apiDataSlice__WEBPACK_IMPORTED_MODULE_10__.setWorkspaceExplorerPresented)(e.target.checked)) }),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_7__.Switch, { label: "Allow multiselection", checked: isMultiSelectionEnabled, onChange: (e) => dispatch((0,_ClientSDKPlaygroundStore_apiDataSlice__WEBPACK_IMPORTED_MODULE_10__.setMultiSelectionEnabled)(e.target.checked)), "data-testid": "api-playground-data-hub-multiselection-switch" }),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_8__.Button, { icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_9__.Database16Regular, null), appearance: "primary", onClick: onCallDatahubFromPlayground, "data-testid": "api-playground-open-data-hub-btn" }, "Open Data Hub")),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "section" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Divider, { alignContent: "start" }, "Selected item"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Field, { label: "Item name", orientation: "horizontal", className: "field" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.Input, { size: "small", placeholder: "Item name", value: selectedLinkedItem ? selectedLinkedItem.displayName : "", "data-testid": `api-playground-data-hub-selected-name-${selectedLinkedItem === null || selectedLinkedItem === void 0 ? void 0 : selectedLinkedItem.displayName}` })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Field, { label: "Item ID", orientation: "horizontal", className: "field" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.Input, { size: "small", placeholder: "Item ID", value: selectedLinkedItem ? selectedLinkedItem.id : "", "data-testid": `api-playground-data-hub-selected-id-${selectedLinkedItem === null || selectedLinkedItem === void 0 ? void 0 : selectedLinkedItem.id}` })))));
}
;


/***/ }),

/***/ "./src/components/ClientSDKPlayground/ApiNavigation.tsx":
/*!**************************************************************!*\
  !*** ./src/components/ClientSDKPlayground/ApiNavigation.tsx ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ApiNavigation: () => (/* binding */ ApiNavigation)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-divider/lib/components/Divider/Divider.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-button/lib/components/Button/Button.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-label/lib/components/Label/Label.js");
/* harmony import */ var _fluentui_react_icons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @fluentui/react-icons */ "./node_modules/@fluentui/react-icons/lib/sizedIcons/chunk-9.js");
/* harmony import */ var _controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../controller/SampleWorkloadController */ "./src/controller/SampleWorkloadController.ts");
/* harmony import */ var _styles_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./../../styles.scss */ "./src/styles.scss");





function ApiNavigation(props) {
    const { sampleWorkloadName, workloadClient } = props;
    async function onCallOpenPage() {
        await (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_5__.callPageOpen)(sampleWorkloadName, `/sample-page`, workloadClient);
    }
    async function onCallNavigate(path) {
        await (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_5__.callNavigationNavigate)("workload", path, workloadClient);
    }
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Divider, { alignContent: "start" }, "Navigation"),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "section" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Button, { appearance: "primary", icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_4__.PanelRightExpand20Regular, null), onClick: () => onCallOpenPage() }, "Open Sample Page"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Button, { appearance: "primary", icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_4__.PanelRightExpand20Regular, null), onClick: () => onCallNavigate(`/sample-page`) }, "Navigate to Sample Page"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Label, null),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Label, null, "BeforeNavigateAway callback has been registered to block navigation to a 'forbidden-url'. Clicking the below should NOT navigate away"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Button, { appearance: "primary", icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_4__.PanelRightExpand20Regular, null), onClick: () => onCallNavigate("/sample-forbidden-url-page") }, "Attempt to navigate to a Forbidden URL"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Button, { appearance: "primary", icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_4__.PanelRightExpand20Regular, null), onClick: () => (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_5__.CallOpenInNewBrowserTab)("https://example.com/help", workloadClient) }, "Open a link in a new tab"))));
}


/***/ }),

/***/ "./src/components/ClientSDKPlayground/ApiNotification.tsx":
/*!****************************************************************!*\
  !*** ./src/components/ClientSDKPlayground/ApiNotification.tsx ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ApiNotification: () => (/* binding */ ApiNotification)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/dist/react-redux.mjs");
/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @fluentui/react */ "./node_modules/@fluentui/react/lib/components/Stack/Stack.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-field/lib/components/Field/Field.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-input/lib/components/Input/Input.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-button/lib/components/Button/Button.js");
/* harmony import */ var _fluentui_react_icons__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @fluentui/react-icons */ "./node_modules/@fluentui/react-icons/lib/sizedIcons/chunk-0.js");
/* harmony import */ var _ClientSDKPlaygroundStore_notificationSlice__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../ClientSDKPlaygroundStore/notificationSlice */ "./src/ClientSDKPlaygroundStore/notificationSlice.ts");
/* harmony import */ var _controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../controller/SampleWorkloadController */ "./src/controller/SampleWorkloadController.ts");
/* harmony import */ var _styles_scss__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./../../styles.scss */ "./src/styles.scss");








function ApiNotification(props) {
    const workloadClient = props.workloadClient;
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useDispatch)();
    const [notificationValidationMessage, setNotificationValidationMessage] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
    const [notificationId, setNotificationId] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
    const { apiNotificationTitle, apiNotificationMessage, } = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state) => state.notification);
    function onCallNotification() {
        if (apiNotificationTitle.trim() == "") {
            setNotificationValidationMessage("Notification title is required");
            return;
        }
        setNotificationValidationMessage("");
        (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_8__.callNotificationOpen)(apiNotificationTitle, apiNotificationMessage, undefined, undefined, workloadClient, setNotificationId);
    }
    function onCallNotificationHide() {
        (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_8__.callNotificationHide)(notificationId, workloadClient, setNotificationId);
    }
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "section" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Field, { label: "Title", validationMessage: notificationValidationMessage, orientation: "horizontal", className: "field" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.Input, { size: "small", placeholder: "Notification Title", value: apiNotificationTitle, onChange: (e) => dispatch((0,_ClientSDKPlaygroundStore_notificationSlice__WEBPACK_IMPORTED_MODULE_7__.setTitle)(e.target.value)) })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Field, { label: "Message", orientation: "horizontal", className: "field" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.Input, { size: "small", placeholder: "Notification Message", value: apiNotificationMessage, onChange: (e) => dispatch((0,_ClientSDKPlaygroundStore_notificationSlice__WEBPACK_IMPORTED_MODULE_7__.setMessage)(e.target.value)) })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_2__.Stack, { horizontal: true, tokens: { childrenGap: 10 } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.Button, { icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_6__.AlertOn24Regular, null), appearance: "primary", onClick: () => onCallNotification() }, "Send Notification"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.Button, { onClick: () => onCallNotificationHide() }, "Hide Notification")))));
}


/***/ }),

/***/ "./src/components/ClientSDKPlayground/ApiPanelSettings.tsx":
/*!*****************************************************************!*\
  !*** ./src/components/ClientSDKPlayground/ApiPanelSettings.tsx ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ApiPanelSettings: () => (/* binding */ ApiPanelSettings)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/dist/react-redux.mjs");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-divider/lib/components/Divider/Divider.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-switch/lib/components/Switch/Switch.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-button/lib/components/Button/Button.js");
/* harmony import */ var _fluentui_react_icons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @fluentui/react-icons */ "./node_modules/@fluentui/react-icons/lib/sizedIcons/chunk-9.js");
/* harmony import */ var _ClientSDKPlaygroundStore_apiPanelSettingsSlice__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../ClientSDKPlaygroundStore/apiPanelSettingsSlice */ "./src/ClientSDKPlaygroundStore/apiPanelSettingsSlice.ts");
/* harmony import */ var _controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../controller/SampleWorkloadController */ "./src/controller/SampleWorkloadController.ts");
/* harmony import */ var _styles_scss__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./../../styles.scss */ "./src/styles.scss");







function ApiPanelSettings(props) {
    const { sampleWorkloadName, workloadClient } = props;
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useDispatch)();
    const apiPanelIsLightDismiss = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state) => state.apiPanelSettings.apiPanelIsLightDismiss);
    async function onCallOpenPanel() {
        (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_7__.callPanelOpen)(sampleWorkloadName, "/panel", apiPanelIsLightDismiss, workloadClient);
    }
    async function onCallThemeGet() {
        const themeString = (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_7__.themeToView)(await (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_7__.callThemeGet)(workloadClient));
        (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_7__.callDialogOpenMsgBox)("Theme Configuration", themeString, ["OK"], workloadClient);
    }
    async function onCallSettingsGet() {
        const settingsString = (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_7__.settingsToView)(await (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_7__.callSettingsGet)(workloadClient));
        (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_7__.callDialogOpenMsgBox)("Settings Configuration", settingsString, ["OK"], workloadClient);
    }
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Divider, { alignContent: "start" }, "Panel"),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "section" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Switch, { label: "Clicking outside of Panel closes it", checked: apiPanelIsLightDismiss, onChange: (e) => dispatch((0,_ClientSDKPlaygroundStore_apiPanelSettingsSlice__WEBPACK_IMPORTED_MODULE_6__.setApiPanelIsLightDismiss)(e.target.checked)) }),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.Button, { appearance: "primary", icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_5__.PanelRightExpand20Regular, null), onClick: onCallOpenPanel }, "Open Panel")),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Divider, { alignContent: "start" }, "Theme"),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "section" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.Button, { appearance: "primary", icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_5__.PanelRightExpand20Regular, null), onClick: onCallThemeGet }, "Get Theme Settings")),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Divider, { alignContent: "start" }, "Settings"),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "section" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.Button, { appearance: "primary", icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_5__.PanelRightExpand20Regular, null), onClick: onCallSettingsGet }, "Get Host Settings"))));
}
;


/***/ }),

/***/ "./src/components/ClientSDKPlayground/ClientSDKPlayground.tsx":
/*!********************************************************************!*\
  !*** ./src/components/ClientSDKPlayground/ClientSDKPlayground.tsx ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ClientSDKPlayground: () => (/* binding */ ClientSDKPlayground),
/* harmony export */   SamplePage: () => (/* binding */ SamplePage)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/dist/react-redux.mjs");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-tabs/lib/components/TabList/TabList.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-tabs/lib/components/Tab/Tab.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-button/lib/components/Button/Button.js");
/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @fluentui/react */ "./node_modules/@fluentui/react/lib/components/Stack/Stack.js");
/* harmony import */ var _ClientSDKPlaygroundStore_tabsSlice__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../ClientSDKPlaygroundStore/tabsSlice */ "./src/ClientSDKPlaygroundStore/tabsSlice.ts");
/* harmony import */ var _ApiNotification__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./ApiNotification */ "./src/components/ClientSDKPlayground/ApiNotification.tsx");
/* harmony import */ var _ActionDialog_ApiActionDialog__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./ActionDialog/ApiActionDialog */ "./src/components/ClientSDKPlayground/ActionDialog/ApiActionDialog.tsx");
/* harmony import */ var _ApiPanelSettings__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./ApiPanelSettings */ "./src/components/ClientSDKPlayground/ApiPanelSettings.tsx");
/* harmony import */ var _ApiNavigation__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./ApiNavigation */ "./src/components/ClientSDKPlayground/ApiNavigation.tsx");
/* harmony import */ var _ApiData__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./ApiData */ "./src/components/ClientSDKPlayground/ApiData.tsx");
/* harmony import */ var _UIComponents__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./UIComponents */ "./src/components/ClientSDKPlayground/UIComponents.tsx");
/* harmony import */ var _ApiAuthentication__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./ApiAuthentication */ "./src/components/ClientSDKPlayground/ApiAuthentication.tsx");
/* harmony import */ var _controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../controller/SampleWorkloadController */ "./src/controller/SampleWorkloadController.ts");
/* harmony import */ var _styles_scss__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./../../styles.scss */ "./src/styles.scss");
/* harmony import */ var _env__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./../../env */ "./src/env.ts");















function ClientSDKPlayground(props) {
    const { workloadClient } = props;
    const sampleWorkloadName = _env__WEBPACK_IMPORTED_MODULE_16__.workloadName;
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useDispatch)();
    const selectedApiTab = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state) => state.tabs.selectedTab);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        // Controller callbacks registrations:
        // register Blocking in Navigate.BeforeNavigateAway (for a forbidden url)
        (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_14__.callNavigationBeforeNavigateAway)(workloadClient);
    }, [workloadClient]);
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_5__.Stack, { className: "editor" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.TabList, { className: "tabListContainer", selectedValue: selectedApiTab, "data-testid": "item-editor-selected-tab-btn", onTabSelect: (_, data) => dispatch((0,_ClientSDKPlaygroundStore_tabsSlice__WEBPACK_IMPORTED_MODULE_6__.setSelectedTab)(data.value)) },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Tab, { value: "apiNotification" }, "Notification"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Tab, { value: "apiActionDialog" }, "Action & Dialog"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Tab, { value: "apiPanelSettings" }, "Panel & Settings"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Tab, { value: "apiNavigation" }, "Navigation"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Tab, { value: "dataHub" }, "Data Hub"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Tab, { value: "uiComponents" }, "UI Components"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Tab, { value: "authentication" }, "Authentication")),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_5__.Stack, { className: "main" },
            selectedApiTab === 'apiNotification' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ApiNotification__WEBPACK_IMPORTED_MODULE_7__.ApiNotification, { workloadClient: workloadClient })),
            selectedApiTab === 'apiActionDialog' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ActionDialog_ApiActionDialog__WEBPACK_IMPORTED_MODULE_8__.ApiActionDialog, { workloadClient: workloadClient, sampleWorkloadName: sampleWorkloadName })),
            selectedApiTab === 'apiPanelSettings' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ApiPanelSettings__WEBPACK_IMPORTED_MODULE_9__.ApiPanelSettings, { workloadClient: workloadClient, sampleWorkloadName: sampleWorkloadName })),
            selectedApiTab === 'apiNavigation' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ApiNavigation__WEBPACK_IMPORTED_MODULE_10__.ApiNavigation, { workloadClient: workloadClient, sampleWorkloadName: sampleWorkloadName })),
            selectedApiTab === 'dataHub' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ApiData__WEBPACK_IMPORTED_MODULE_11__.ApiData, { workloadClient: workloadClient, sampleWorkloadName: sampleWorkloadName })),
            selectedApiTab === 'uiComponents' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_UIComponents__WEBPACK_IMPORTED_MODULE_12__.UIComponentsExample, { workloadClient: workloadClient })),
            selectedApiTab === 'authentication' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ApiAuthentication__WEBPACK_IMPORTED_MODULE_13__.ApiAuthentication, { workloadClient: workloadClient })))));
}
;
function SamplePage({ workloadClient, history }) {
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_5__.Stack, { className: "editor" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_5__.Stack, { className: "main" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.Button, { onClick: () => {
                    (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_14__.callNavigationNavigate)("workload", "/client-sdk-playground/", workloadClient);
                } }, "Navigate Back"))));
}


/***/ }),

/***/ "./src/components/ClientSDKPlayground/UIComponents.tsx":
/*!*************************************************************!*\
  !*** ./src/components/ClientSDKPlayground/UIComponents.tsx ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   UIComponentsExample: () => (/* binding */ UIComponentsExample)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react */ "./node_modules/@fluentui/react/lib/components/Stack/Stack.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/dist/react-redux.mjs");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-message-bar/lib/components/MessageBar/MessageBar.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-message-bar/lib/components/MessageBarBody/MessageBarBody.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-message-bar/lib/components/MessageBarTitle/MessageBarTitle.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-divider/lib/components/Divider/Divider.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-label/lib/components/Label/Label.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-input/lib/components/Input/Input.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-button/lib/components/Button/Button.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-checkbox/lib/components/Checkbox/Checkbox.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-switch/lib/components/Switch/Switch.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-radio/lib/components/RadioGroup/RadioGroup.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-radio/lib/components/Radio/Radio.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-utilities/lib/hooks/useId.js");
/* harmony import */ var _fluentui_react_icons__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @fluentui/react-icons */ "./node_modules/@fluentui/react-icons/lib/sizedIcons/chunk-11.js");
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! react-i18next */ "./node_modules/react-i18next/dist/es/index.js");
/* harmony import */ var _controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../../controller/SampleWorkloadController */ "./src/controller/SampleWorkloadController.ts");
/* harmony import */ var _ClientSDKPlaygroundStore_uiComponentsSlice__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../../ClientSDKPlaygroundStore/uiComponentsSlice */ "./src/ClientSDKPlaygroundStore/uiComponentsSlice.ts");
/* harmony import */ var _styles_scss__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./../../styles.scss */ "./src/styles.scss");









function UIComponentsExample(props) {
    const { workloadClient } = props;
    const { t, i18n } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_16__.useTranslation)();
    const [lang, setLang] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('en-US');
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useDispatch)();
    const { sampleInput, checkboxChecked, selectedRadio, switchChecked, } = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useSelector)((state) => state.uiComponents);
    const radioName = (0,_fluentui_react_components__WEBPACK_IMPORTED_MODULE_14__.useId)("radio");
    const labelId = (0,_fluentui_react_components__WEBPACK_IMPORTED_MODULE_14__.useId)("label");
    const inputId = (0,_fluentui_react_components__WEBPACK_IMPORTED_MODULE_14__.useId)("input");
    document.body.dir = i18n.dir();
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_17__.callLanguageGet)(workloadClient).then((lang) => setLang(lang));
        // register Settings.onChange
        (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_17__.callSettingsOnChange)(workloadClient, i18n.changeLanguage);
    }, []);
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: i18n.dir() },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.MessageBar, null,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.MessageBarBody, null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.MessageBarTitle, null, lang !== "en-US" ? t("Language_Changed_Title") : t("Default_Language_Title")),
                    t("Language_Changed_Message"),
                    " ",
                    lang))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__.Divider, { alignContent: "start", className: "margin-top" }, "Components"),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "section" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.Stack, { horizontal: true, tokens: { childrenGap: 10 }, style: { padding: "10px" } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_7__.Label, { htmlFor: inputId }, "Sample input"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_8__.Input, { id: inputId, size: "small", placeholder: "hint", value: sampleInput, onChange: (e) => dispatch((0,_ClientSDKPlaygroundStore_uiComponentsSlice__WEBPACK_IMPORTED_MODULE_18__.setSampleInput)(e.target.value)) })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.Stack, { horizontal: true, tokens: { childrenGap: 10 }, style: { padding: "10px" } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_9__.Button, { icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_15__.Save24Regular, null), appearance: "primary" }, "Primary"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_9__.Button, { icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_15__.Save24Regular, null), appearance: "secondary" }, "Default"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_9__.Button, { icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_15__.Save24Regular, null), appearance: "outline" }, "Outline"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_9__.Button, { icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_15__.Save24Regular, null), appearance: "subtle" }, "Subtle")),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_10__.Checkbox, { title: "my title", label: "Checkbox sample", checked: checkboxChecked, onChange: (e) => dispatch((0,_ClientSDKPlaygroundStore_uiComponentsSlice__WEBPACK_IMPORTED_MODULE_18__.setCheckboxChecked)(e.target.checked)) }),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_11__.Switch, { label: "Switch sample", checked: switchChecked, onChange: (e) => dispatch((0,_ClientSDKPlaygroundStore_uiComponentsSlice__WEBPACK_IMPORTED_MODULE_18__.setSwitchChecked)(e.target.checked)) }),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_7__.Label, { id: labelId }, "Radio group"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_12__.RadioGroup, { "aria-labelledby": labelId, value: selectedRadio, onChange: (e, data) => dispatch((0,_ClientSDKPlaygroundStore_uiComponentsSlice__WEBPACK_IMPORTED_MODULE_18__.setSelectedRadio)(data.value)) },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_13__.Radio, { name: radioName, value: "option1", label: "Option 1" }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_13__.Radio, { name: radioName, value: "option2", label: "Option 2" }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_13__.Radio, { name: radioName, value: "option3", label: "Option 3" })))));
}
;


/***/ }),

/***/ "./src/components/CommonLoader/CommonLoader.tsx":
/*!******************************************************!*\
  !*** ./src/components/CommonLoader/CommonLoader.tsx ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-spinner/lib/components/Spinner/Spinner.js");


const CommonLoader = ({ size = 'medium', appearance = 'primary', label = '', }) => {
    // Map custom sizes to Fluent UI Spinner sizes
    const getFluentSize = (customSize) => {
        const sizeMap = {
            'extra-tiny': 'tiny',
            'tiny': 'tiny',
            'extra-small': 'extra-small',
            'small': 'small',
            'medium': 'medium',
            'large': 'large',
            'extra-large': 'extra-large',
            'huge': 'huge'
        };
        return sizeMap[customSize];
    };
    // Map appearance to Fluent UI appearance
    const getFluentAppearance = (customAppearance) => {
        return customAppearance;
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: {
            display: 'inline-flex',
            flexDirection: 'column',
            alignItems: 'center',
            gap: '8px'
        } },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Spinner, { size: getFluentSize(size), appearance: getFluentAppearance(appearance), label: label, labelPosition: "below" })));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CommonLoader);


/***/ }),

/***/ "./src/components/CustomItemSettings/CustomAbout.tsx":
/*!***********************************************************!*\
  !*** ./src/components/CustomItemSettings/CustomAbout.tsx ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CustomAbout: () => (/* binding */ CustomAbout),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

function CustomAbout() {
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { "data-testid": "custom-about-settings" }));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CustomAbout);


/***/ }),

/***/ "./src/components/CustomItemSettings/CustomReportSettings.tsx":
/*!********************************************************************!*\
  !*** ./src/components/CustomItemSettings/CustomReportSettings.tsx ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ CustomReportSettings)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-switch/lib/components/Switch/Switch.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-button/lib/components/Button/Button.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-spinner/lib/components/Spinner/Spinner.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@griffel/react/makeStyles.esm.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/tokens/lib/tokens.js");
/* harmony import */ var _fluentui_react_icons__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @fluentui/react-icons */ "./node_modules/@fluentui/react-icons/lib/sizedIcons/chunk-7.js");
/* harmony import */ var _contexts_SettingsContext__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../contexts/SettingsContext */ "./src/contexts/SettingsContext.tsx");
/* harmony import */ var _contexts_FabricFindingsContext__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../contexts/FabricFindingsContext */ "./src/contexts/FabricFindingsContext.tsx");
/* harmony import */ var _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ms-fabric/workload-client */ "./node_modules/@ms-fabric/workload-client/src/workload-client.js");
/* harmony import */ var _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../controller/SampleWorkloadController */ "./src/controller/SampleWorkloadController.ts");







const useStyles = (0,_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.makeStyles)({
    content: { flex: 1, padding: "20px", overflowY: "auto" },
    card: { border: `1px solid ${_fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.tokens.colorNeutralStroke2}`, borderRadius: "8px", padding: "16px", background: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.tokens.colorNeutralBackground1 },
    cardTitle: { fontWeight: 600 },
    cardSubtitle: { color: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.tokens.colorNeutralForeground3, marginBottom: "12px", marginTop: "8px" },
    toggleRow: { display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: "8px" },
    toggleText: { fontWeight: 600, display: "flex", alignItems: "center", gap: "6px" },
    toggleDescription: { fontSize: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.tokens.fontSizeBase200, color: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.tokens.colorNeutralForeground3 },
    footer: { borderTop: `1px solid ${_fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.tokens.colorNeutralStroke2}`, padding: "12px 0", display: "flex", justifyContent: "flex-end", gap: "12px" },
    error: { color: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.tokens.colorPaletteRedForeground1, textAlign: "center", marginTop: "20px", fontWeight: 600 },
    saveButton: {
        backgroundColor: "#117865",
        color: "#ffffff",
        fontWeight: 600,
        textTransform: "none",
        fontSize: "14px",
        cursor: "pointer",
        borderRadius: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.tokens.borderRadiusMedium,
        transition: "all 0.2s ease",
        "&:hover:not(:disabled)": {
            backgroundColor: "#0f6b5a",
        },
        "&:disabled": {
            backgroundColor: "#f3f2f1",
            color: "#a19f9d",
            cursor: "not-allowed",
            "&:hover": {
                backgroundColor: "#f3f2f1",
            },
        },
    },
});
function CustomReportSettings() {
    const workloadClient = (0,_ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_9__.createWorkloadClient)();
    const styles = useStyles();
    const { settings, updateSettings, settingsLoaded } = (0,_contexts_SettingsContext__WEBPACK_IMPORTED_MODULE_7__.useAdmin)();
    const { triggerGlobalRefresh } = (0,_contexts_FabricFindingsContext__WEBPACK_IMPORTED_MODULE_8__.useFabricFindings)();
    const defaultSettings = [
        { title: "Delete Report", description: "Automatically delete unused or outdated reports.", suppressFinding: false, agentAction: false, key: "deleteReport" },
        { title: "Notify Owner", description: "Automatically notify report owner about changes.", suppressFinding: false, agentAction: false, key: "notifyOwnerReport" },
    ];
    const [localSettings, setLocalSettings] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(defaultSettings);
    const [originalSettings, setOriginalSettings] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(defaultSettings);
    const [hasChanges, setHasChanges] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [saving, setSaving] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (settingsLoaded && (settings === null || settings === void 0 ? void 0 : settings.suggestedAction)) {
            const loaded = defaultSettings.map((s) => (Object.assign(Object.assign({}, s), { suppressFinding: settings.suggestedAction[s.key], agentAction: settings.automaticAgentAction[s.key] })));
            setLocalSettings(loaded);
            setOriginalSettings(loaded);
        }
    }, [settingsLoaded, settings]);
    // Check for changes whenever localSettings updates
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        const changed = JSON.stringify(localSettings) !== JSON.stringify(originalSettings);
        setHasChanges(changed);
    }, [localSettings, originalSettings]);
    const handleCancel = () => {
        setLocalSettings(originalSettings);
        setHasChanges(false);
    };
    const handleToggleSuppress = react__WEBPACK_IMPORTED_MODULE_0___default().useCallback((title, value) => {
        setLocalSettings((prev) => prev.map((s) => s.title === title ? Object.assign(Object.assign({}, s), { suppressFinding: value, agentAction: value ? false : s.agentAction }) : s));
    }, []);
    const handleToggleAgent = react__WEBPACK_IMPORTED_MODULE_0___default().useCallback((title, value) => {
        setLocalSettings((prev) => prev.map((s) => (s.title === title ? Object.assign(Object.assign({}, s), { agentAction: value }) : s)));
    }, []);
    const handleSave = async () => {
        setSaving(true);
        try {
            const updated = Object.assign(Object.assign({}, settings), { suggestedAction: Object.assign(Object.assign({}, settings.suggestedAction), localSettings.reduce((acc, s) => (Object.assign(Object.assign({}, acc), { [s.key]: s.suppressFinding })), {})), automaticAgentAction: Object.assign(Object.assign({}, settings.automaticAgentAction), localSettings.reduce((acc, s) => (Object.assign(Object.assign({}, acc), { [s.key]: s.agentAction })), {})) });
            const response = await updateSettings(updated);
            if (response.success) {
                // refetch() will fetch the updated settings from backend and call suppressfindings with complete payload
                try {
                    await (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_10__.callNotificationOpen)('Success', 'Settings Saved Successfully', _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_9__.NotificationType.Success, _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_9__.NotificationToastDuration.Short, workloadClient);
                    await triggerGlobalRefresh();
                }
                catch (error) {
                    console.error("Error refreshing findings after settings save:", error);
                    // Continue anyway - user can manually refresh if needed
                }
            }
            else {
                await (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_10__.callNotificationOpen)('Error', response.error, _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_9__.NotificationType.Error, _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_9__.NotificationToastDuration.Short, workloadClient);
            }
        }
        finally {
            setSaving(false);
        }
        ;
    };
    if (!settingsLoaded || !(settings === null || settings === void 0 ? void 0 : settings.suggestedAction)) {
        return react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.error }, "\u26A0\uFE0F Settings not loaded from KQL DB. Please try again later.");
    }
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.content },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { display: "grid", gap: 16 } }, localSettings.map((setting) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { key: setting.title, className: styles.card },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { display: "flex", alignItems: "center", gap: 8 } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.cardTitle }, setting.title),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: { width: 8, height: 8, borderRadius: "50%", background: "#f97316", display: "inline-block" } })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.cardSubtitle }, setting.description),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.toggleRow },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.toggleText },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, "Suppress Suggested Action"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_6__.Info24Regular, { style: { color: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.tokens.colorNeutralForeground3, width: 16, height: 16 } })),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.toggleDescription }, "Prevent the agent from considering this action.")),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Switch, { checked: setting.suppressFinding, onChange: (_, d) => handleToggleSuppress(setting.title, d.checked) })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.toggleRow, style: { opacity: setting.suppressFinding ? 0.5 : 1 } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.toggleText },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, "Agent Action"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_6__.Info24Regular, { style: { color: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.tokens.colorNeutralForeground3, width: 16, height: 16 } })),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.toggleDescription }, "Allow the agent to automatically take action.")),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Switch, { checked: setting.agentAction, disabled: setting.suppressFinding, onChange: (_, d) => handleToggleAgent(setting.title, d.checked) })))))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.footer },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Button, { appearance: "secondary", onClick: handleCancel, disabled: !hasChanges || saving }, "Cancel"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Button, { appearance: "primary", onClick: handleSave, disabled: !hasChanges || saving, className: styles.saveButton, icon: saving ? react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Spinner, { size: "tiny" }) : undefined }, saving ? "Saving..." : "Save"))));
}


/***/ }),

/***/ "./src/components/CustomItemSettings/CustomSemanticModelSettings.tsx":
/*!***************************************************************************!*\
  !*** ./src/components/CustomItemSettings/CustomSemanticModelSettings.tsx ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ CustomSemanticModelSettings)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-switch/lib/components/Switch/Switch.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-button/lib/components/Button/Button.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-spinner/lib/components/Spinner/Spinner.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@griffel/react/makeStyles.esm.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/tokens/lib/tokens.js");
/* harmony import */ var _fluentui_react_icons__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @fluentui/react-icons */ "./node_modules/@fluentui/react-icons/lib/sizedIcons/chunk-7.js");
/* harmony import */ var _contexts_SettingsContext__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../contexts/SettingsContext */ "./src/contexts/SettingsContext.tsx");
/* harmony import */ var _contexts_FabricFindingsContext__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../contexts/FabricFindingsContext */ "./src/contexts/FabricFindingsContext.tsx");
/* harmony import */ var _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ms-fabric/workload-client */ "./node_modules/@ms-fabric/workload-client/src/workload-client.js");
/* harmony import */ var _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../controller/SampleWorkloadController */ "./src/controller/SampleWorkloadController.ts");







const useStyles = (0,_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.makeStyles)({
    content: { flex: 1, padding: "20px", overflowY: "auto" },
    card: { border: `1px solid ${_fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.tokens.colorNeutralStroke2}`, borderRadius: "8px", padding: "16px", background: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.tokens.colorNeutralBackground1 },
    cardTitle: { fontWeight: 600 },
    cardSubtitle: { color: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.tokens.colorNeutralForeground3, marginBottom: "12px", marginTop: "8px" },
    toggleRow: { display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: "8px" },
    toggleText: { fontWeight: 600, display: "flex", alignItems: "center", gap: "6px" },
    toggleDescription: { fontSize: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.tokens.fontSizeBase200, color: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.tokens.colorNeutralForeground3 },
    footer: { borderTop: `1px solid ${_fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.tokens.colorNeutralStroke2}`, padding: "12px 0", display: "flex", justifyContent: "flex-end", gap: "12px" },
    error: { color: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.tokens.colorPaletteRedForeground1, textAlign: "center", marginTop: "20px", fontWeight: 600 },
    saveButton: {
        backgroundColor: "#117865",
        color: "#ffffff",
        fontWeight: 600,
        textTransform: "none",
        fontSize: "14px",
        cursor: "pointer",
        borderRadius: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.tokens.borderRadiusMedium,
        transition: "all 0.2s ease",
        "&:hover:not(:disabled)": {
            backgroundColor: "#0f6b5a",
        },
        "&:disabled": {
            backgroundColor: "#f3f2f1",
            color: "#a19f9d",
            cursor: "not-allowed",
            "&:hover": {
                backgroundColor: "#f3f2f1",
            },
        },
    },
});
function CustomSemanticModelSettings() {
    const workloadClient = (0,_ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_9__.createWorkloadClient)();
    const styles = useStyles();
    const { settings, updateSettings, settingsLoaded } = (0,_contexts_SettingsContext__WEBPACK_IMPORTED_MODULE_7__.useAdmin)();
    const { triggerGlobalRefresh } = (0,_contexts_FabricFindingsContext__WEBPACK_IMPORTED_MODULE_8__.useFabricFindings)();
    const defaultSettings = [
        { title: "Delete Semantic Model", description: "Automatically delete unused semantic models.", suppressFinding: false, agentAction: false, key: "deleteSemanticModel" },
        { title: "Notify Owner", description: "Automatically notify semantic model owner of updates.", suppressFinding: false, agentAction: false, key: "notifyOwnerSemanticModel" },
        { title: "Disable Refresh", description: "Automatically disable scheduled refresh.", suppressFinding: false, agentAction: false, key: "disableRefreshSemanticModel" },
    ];
    const [localSettings, setLocalSettings] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(defaultSettings);
    const [originalSettings, setOriginalSettings] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(defaultSettings);
    const [hasChanges, setHasChanges] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [saving, setSaving] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (settingsLoaded && (settings === null || settings === void 0 ? void 0 : settings.suggestedAction)) {
            const loaded = defaultSettings.map((s) => (Object.assign(Object.assign({}, s), { suppressFinding: settings.suggestedAction[s.key], agentAction: settings.automaticAgentAction[s.key] })));
            setLocalSettings(loaded);
            setOriginalSettings(loaded);
        }
    }, [settingsLoaded, settings]);
    // Check for changes whenever localSettings updates
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        const changed = JSON.stringify(localSettings) !== JSON.stringify(originalSettings);
        setHasChanges(changed);
    }, [localSettings, originalSettings]);
    const handleCancel = () => {
        setLocalSettings(originalSettings);
        setHasChanges(false);
    };
    const handleToggleSuppress = react__WEBPACK_IMPORTED_MODULE_0___default().useCallback((title, value) => {
        setLocalSettings((prev) => prev.map((s) => s.title === title ? Object.assign(Object.assign({}, s), { suppressFinding: value, agentAction: value ? false : s.agentAction }) : s));
    }, []);
    const handleToggleAgent = react__WEBPACK_IMPORTED_MODULE_0___default().useCallback((title, value) => {
        setLocalSettings((prev) => prev.map((s) => (s.title === title ? Object.assign(Object.assign({}, s), { agentAction: value }) : s)));
    }, []);
    const handleSave = async () => {
        setSaving(true);
        try {
            const updated = Object.assign(Object.assign({}, settings), { suggestedAction: Object.assign(Object.assign({}, settings.suggestedAction), localSettings.reduce((acc, s) => (Object.assign(Object.assign({}, acc), { [s.key]: s.suppressFinding })), {})), automaticAgentAction: Object.assign(Object.assign({}, settings.automaticAgentAction), localSettings.reduce((acc, s) => (Object.assign(Object.assign({}, acc), { [s.key]: s.agentAction })), {})) });
            const response = await updateSettings(updated);
            if (response.success) {
                // refetch() will fetch the updated settings from backend and call suppressfindings with complete payload
                try {
                    await (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_10__.callNotificationOpen)('Success', 'Settings Saved Successfully', _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_9__.NotificationType.Success, _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_9__.NotificationToastDuration.Short, workloadClient);
                    await triggerGlobalRefresh();
                }
                catch (error) {
                    console.error("Error refreshing findings after settings save:", error);
                    // Continue anyway - user can manually refresh if needed
                }
            }
            else {
                await (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_10__.callNotificationOpen)('Error', response.error, _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_9__.NotificationType.Error, _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_9__.NotificationToastDuration.Short, workloadClient);
            }
        }
        finally {
            setSaving(false);
        }
        ;
    };
    if (!settingsLoaded || !(settings === null || settings === void 0 ? void 0 : settings.suggestedAction)) {
        return react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.error }, "\u26A0\uFE0F Settings not loaded from KQL DB. Please try again later.");
    }
    console.log(settingsLoaded);
    console.log(settings);
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.content },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { display: "grid", gap: 16 } }, localSettings.map((setting) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { key: setting.title, className: styles.card },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { display: "flex", alignItems: "center", gap: 8 } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.cardTitle }, setting.title),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: { width: 8, height: 8, borderRadius: "50%", background: "#f97316", display: "inline-block" } })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.cardSubtitle }, setting.description),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.toggleRow },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.toggleText },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, "Suppress Suggested Action"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_6__.Info24Regular, { style: { color: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.tokens.colorNeutralForeground3, width: 16, height: 16 } })),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.toggleDescription }, "Prevent the agent from considering this action.")),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Switch, { checked: setting.suppressFinding, onChange: (_, d) => handleToggleSuppress(setting.title, d.checked) })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.toggleRow, style: { opacity: setting.suppressFinding ? 0.5 : 1 } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.toggleText },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, "Agent Action"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_6__.Info24Regular, { style: { color: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.tokens.colorNeutralForeground3, width: 16, height: 16 } })),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.toggleDescription }, "Allow the agent to automatically take action.")),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Switch, { checked: setting.agentAction, disabled: setting.suppressFinding, onChange: (_, d) => handleToggleAgent(setting.title, d.checked) })))))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.footer },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Button, { appearance: "secondary", onClick: handleCancel, disabled: !hasChanges || saving }, "Cancel"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Button, { appearance: "primary", onClick: handleSave, disabled: !hasChanges || saving, className: styles.saveButton, icon: saving ? react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Spinner, { size: "tiny" }) : undefined }, saving ? "Saving..." : "Save"))));
}


/***/ }),

/***/ "./src/components/CustomItemSettings/CustomWorkspaceSettings.tsx":
/*!***********************************************************************!*\
  !*** ./src/components/CustomItemSettings/CustomWorkspaceSettings.tsx ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ CustomWorkspaceSettings)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-switch/lib/components/Switch/Switch.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-button/lib/components/Button/Button.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-spinner/lib/components/Spinner/Spinner.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@griffel/react/makeStyles.esm.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/tokens/lib/tokens.js");
/* harmony import */ var _fluentui_react_icons__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @fluentui/react-icons */ "./node_modules/@fluentui/react-icons/lib/sizedIcons/chunk-7.js");
/* harmony import */ var _contexts_SettingsContext__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../contexts/SettingsContext */ "./src/contexts/SettingsContext.tsx");
/* harmony import */ var _contexts_FabricFindingsContext__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../contexts/FabricFindingsContext */ "./src/contexts/FabricFindingsContext.tsx");
/* harmony import */ var _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ms-fabric/workload-client */ "./node_modules/@ms-fabric/workload-client/src/workload-client.js");
/* harmony import */ var _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../controller/SampleWorkloadController */ "./src/controller/SampleWorkloadController.ts");







const useStyles = (0,_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.makeStyles)({
    content: { flex: 1, padding: "20px", overflowY: "auto" },
    card: { border: `1px solid ${_fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.tokens.colorNeutralStroke2}`, borderRadius: "8px", padding: "16px", background: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.tokens.colorNeutralBackground1 },
    cardTitle: { fontWeight: 600 },
    cardSubtitle: { color: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.tokens.colorNeutralForeground3, marginBottom: "12px", marginTop: "8px" },
    toggleRow: { display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: "8px" },
    toggleText: { fontWeight: 600, display: "flex", alignItems: "center", gap: "6px" },
    toggleDescription: { fontSize: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.tokens.fontSizeBase200, color: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.tokens.colorNeutralForeground3 },
    footer: { borderTop: `1px solid ${_fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.tokens.colorNeutralStroke2}`, padding: "12px 0", display: "flex", justifyContent: "flex-end", gap: "12px" },
    error: { color: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.tokens.colorPaletteRedForeground1, textAlign: "center", marginTop: "20px", fontWeight: 600 },
    saveButton: {
        backgroundColor: "#117865",
        color: "#ffffff",
        fontWeight: 600,
        textTransform: "none",
        fontSize: "14px",
        cursor: "pointer",
        borderRadius: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.tokens.borderRadiusMedium,
        transition: "all 0.2s ease",
        "&:hover:not(:disabled)": {
            backgroundColor: "#0f6b5a",
        },
        "&:disabled": {
            backgroundColor: "#f3f2f1",
            color: "#a19f9d",
            cursor: "not-allowed",
            "&:hover": {
                backgroundColor: "#f3f2f1",
            },
        },
    },
});
function CustomWorkspaceSettings() {
    const workloadClient = (0,_ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_9__.createWorkloadClient)();
    const styles = useStyles();
    const { settings, updateSettings, settingsLoaded } = (0,_contexts_SettingsContext__WEBPACK_IMPORTED_MODULE_7__.useAdmin)();
    const { triggerGlobalRefresh } = (0,_contexts_FabricFindingsContext__WEBPACK_IMPORTED_MODULE_8__.useFabricFindings)();
    const defaultSettings = [
        { title: "Notify Workspace Admins", description: "Automatically notify workspace admins of changes.", suppressFinding: false, agentAction: false, key: "notifyWorkspaceAdmins" },
        { title: "Delete Workspace", description: "Automatically delete unused or inactive workspaces.", suppressFinding: false, agentAction: false, key: "deleteWorkspace" },
    ];
    const [localSettings, setLocalSettings] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(defaultSettings);
    const [originalSettings, setOriginalSettings] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(defaultSettings);
    const [hasChanges, setHasChanges] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [saving, setSaving] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (settingsLoaded && (settings === null || settings === void 0 ? void 0 : settings.suggestedAction)) {
            const loaded = defaultSettings.map((s) => (Object.assign(Object.assign({}, s), { suppressFinding: settings.suggestedAction[s.key], agentAction: settings.automaticAgentAction[s.key] })));
            setLocalSettings(loaded);
            setOriginalSettings(loaded);
        }
    }, [settingsLoaded, settings]);
    // Check for changes whenever localSettings updates
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        const changed = JSON.stringify(localSettings) !== JSON.stringify(originalSettings);
        setHasChanges(changed);
    }, [localSettings, originalSettings]);
    const handleToggleSuppress = react__WEBPACK_IMPORTED_MODULE_0___default().useCallback((title, value) => {
        setLocalSettings((prev) => prev.map((s) => s.title === title ? Object.assign(Object.assign({}, s), { suppressFinding: value, agentAction: value ? false : s.agentAction }) : s));
    }, []);
    const handleToggleAgent = react__WEBPACK_IMPORTED_MODULE_0___default().useCallback((title, value) => {
        setLocalSettings((prev) => prev.map((s) => (s.title === title ? Object.assign(Object.assign({}, s), { agentAction: value }) : s)));
    }, []);
    const handleCancel = () => {
        setLocalSettings(originalSettings);
        setHasChanges(false);
    };
    const handleSave = async () => {
        setSaving(true);
        try {
            const updated = Object.assign(Object.assign({}, settings), { suggestedAction: Object.assign(Object.assign({}, settings.suggestedAction), localSettings.reduce((acc, s) => (Object.assign(Object.assign({}, acc), { [s.key]: s.suppressFinding })), {})), automaticAgentAction: Object.assign(Object.assign({}, settings.automaticAgentAction), localSettings.reduce((acc, s) => (Object.assign(Object.assign({}, acc), { [s.key]: s.agentAction })), {})) });
            const response = await updateSettings(updated);
            if (response.success) {
                // refetch() will fetch the updated settings from backend and call suppressfindings with complete payload
                try {
                    await (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_10__.callNotificationOpen)('Success', 'Settings Saved Successfully', _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_9__.NotificationType.Success, _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_9__.NotificationToastDuration.Short, workloadClient);
                    await triggerGlobalRefresh();
                }
                catch (error) {
                    console.error("Error refreshing findings after settings save:", error);
                    // Continue anyway - user can manually refresh if needed
                }
            }
            else {
                await (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_10__.callNotificationOpen)('Error', response.error, _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_9__.NotificationType.Error, _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_9__.NotificationToastDuration.Short, workloadClient);
            }
        }
        finally {
            setSaving(false);
        }
        ;
    };
    if (!settingsLoaded || !(settings === null || settings === void 0 ? void 0 : settings.suggestedAction)) {
        return react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.error }, "\u26A0\uFE0F Settings not loaded from KQL DB. Please try again later.");
    }
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.content },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { display: "grid", gap: 16 } }, localSettings.map((setting) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { key: setting.title, className: styles.card },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { display: "flex", alignItems: "center", gap: 8 } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.cardTitle }, setting.title),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: { width: 8, height: 8, borderRadius: "50%", background: "#f97316", display: "inline-block" } })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.cardSubtitle }, setting.description),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.toggleRow },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.toggleText },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, "Suppress Suggested Action"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_6__.Info24Regular, { style: { color: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.tokens.colorNeutralForeground3, width: 16, height: 16 } })),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.toggleDescription }, "Prevent the agent from considering this action.")),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Switch, { checked: setting.suppressFinding, onChange: (_, d) => handleToggleSuppress(setting.title, d.checked) })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.toggleRow, style: { opacity: setting.suppressFinding ? 0.5 : 1 } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.toggleText },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, "Agent Action"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_6__.Info24Regular, { style: { color: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.tokens.colorNeutralForeground3, width: 16, height: 16 } })),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.toggleDescription }, "Allow the agent to automatically take action.")),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Switch, { checked: setting.agentAction, disabled: setting.suppressFinding, onChange: (_, d) => handleToggleAgent(setting.title, d.checked) })))))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.footer },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Button, { appearance: "secondary", onClick: handleCancel, disabled: !hasChanges || saving }, "Cancel"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Button, { appearance: "primary", onClick: handleSave, disabled: !hasChanges || saving, className: styles.saveButton, icon: saving ? react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Spinner, { size: "tiny" }) : undefined }, saving ? "Saving..." : "Save"))));
}


/***/ }),

/***/ "./src/components/Dashboard/Dashboard.tsx":
/*!************************************************!*\
  !*** ./src/components/Dashboard/Dashboard.tsx ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Dashboard: () => (/* binding */ Dashboard)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@griffel/core/index.esm.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-spinner/lib/components/Spinner/Spinner.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-text/lib/components/Text/Text.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-button/lib/components/Button/Button.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@griffel/react/makeStyles.esm.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/tokens/lib/tokens.js");
/* harmony import */ var _fluentui_react_icons__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @fluentui/react-icons */ "./node_modules/@fluentui/react-icons/lib/sizedIcons/chunk-0.js");
/* harmony import */ var _fluentui_react_icons__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @fluentui/react-icons */ "./node_modules/@fluentui/react-icons/lib/sizedIcons/chunk-3.js");
/* harmony import */ var _fluentui_react_icons__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @fluentui/react-icons */ "./node_modules/@fluentui/react-icons/lib/sizedIcons/chunk-4.js");
/* harmony import */ var _fluentui_react_icons__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @fluentui/react-icons */ "./node_modules/@fluentui/react-icons/lib/sizedIcons/chunk-5.js");
/* harmony import */ var _fluentui_react_icons__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @fluentui/react-icons */ "./node_modules/@fluentui/react-icons/lib/sizedIcons/chunk-11.js");
/* harmony import */ var _MetricCard__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./MetricCard */ "./src/components/Dashboard/MetricCard.tsx");
/* harmony import */ var _contexts_SettingsContext__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../contexts/SettingsContext */ "./src/contexts/SettingsContext.tsx");
/* harmony import */ var _contexts_FabricFindingsContext__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../contexts/FabricFindingsContext */ "./src/contexts/FabricFindingsContext.tsx");
/* harmony import */ var _env__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./../../env */ "./src/env.ts");







const useStyles = (0,_fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.makeStyles)({
    container: Object.assign(Object.assign({}, _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.shorthands.padding("24px", "24px")), { backgroundColor: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__.tokens.colorNeutralBackground2, minHeight: "calc(100vh - 96px)" }),
    header: {
        display: "flex",
        justifyContent: "space-between",
        alignItems: "flex-start",
        marginBottom: "24px",
        "@media (max-width: 768px)": Object.assign({ flexDirection: "column" }, _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.shorthands.gap("16px")),
    },
    headerLeft: Object.assign({ display: "flex", flexDirection: "column" }, _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.shorthands.gap("4px")),
    title: {
        fontSize: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__.tokens.fontSizeHero700,
        fontWeight: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__.tokens.fontWeightSemibold,
        lineHeight: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__.tokens.lineHeightHero700,
    },
    subtitle: {
        fontSize: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__.tokens.fontSizeBase300,
        color: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__.tokens.colorNeutralForeground3,
    },
    headerRight: Object.assign({ display: "flex", flexDirection: "column", alignItems: "flex-end" }, _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.shorthands.gap("8px")),
    refreshInfo: Object.assign({ fontSize: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__.tokens.fontSizeBase200, color: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__.tokens.colorNeutralForeground3, display: "flex", alignItems: "center" }, _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.shorthands.gap("4px")),
    grid: Object.assign(Object.assign({ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(380px, 1fr))" }, _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.shorthands.gap("24px")), { "@media (max-width: 1024px)": {
            gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))",
        }, "@media (max-width: 768px)": {
            gridTemplateColumns: "1fr",
        } }),
});
function Dashboard(props) {
    const styles = useStyles();
    // ⭐ UPDATED — make this a string and controlled by API
    const [lastRefreshed, setLastRefreshed] = react__WEBPACK_IMPORTED_MODULE_0___default().useState("Loading...");
    const { dashboardStats, dashboardLoading, refreshDashboardStats } = (0,_contexts_SettingsContext__WEBPACK_IMPORTED_MODULE_13__.useAdmin)();
    const { loading: findingsLoading, refetch: refreshFindings } = (0,_contexts_FabricFindingsContext__WEBPACK_IMPORTED_MODULE_14__.useFabricFindings)();
    const isLoading = dashboardLoading || findingsLoading;
    // ⭐ ADDED — Fetch timestamp from API
    const fetchLastRunTime = async () => {
        try {
            const res = await fetch(`${_env__WEBPACK_IMPORTED_MODULE_15__.workloadBEURL}/api/fabricFindings/latest`);
            const json = await res.json();
            console.log("⏱️ Dashboard API timestamp:", json);
            if (json.success && json.data) {
                const formatted = new Date(json.data).toLocaleString("en-US", {
                    month: "2-digit",
                    day: "2-digit",
                    year: "numeric",
                    hour: "2-digit",
                    minute: "2-digit",
                    second: "2-digit",
                    hour12: true,
                });
                setLastRefreshed(formatted);
            }
            else {
                setLastRefreshed("Unavailable");
            }
        }
        catch (err) {
            console.error("❌ Error fetching dashboard pipeline time:", err);
            setLastRefreshed("Unavailable");
        }
    };
    // ⭐ ADDED — get timestamp on mount
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        fetchLastRunTime();
    }, []);
    // Load dashboard stats on component mount
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (!dashboardStats.totalAdmins && !dashboardLoading) {
            refreshDashboardStats();
        }
    }, [dashboardStats.totalAdmins, dashboardLoading, refreshDashboardStats]);
    // ⭐ UPDATED — refresh now updates timestamp via API
    const handleRefresh = async () => {
        try {
            await Promise.all([
                refreshFindings(),
                refreshDashboardStats(),
                fetchLastRunTime(), // ⭐ ADDED
            ]);
        }
        catch (error) {
            console.error("❌ Error refreshing dashboard:", error);
        }
    };
    const metrics = [
        {
            icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_11__.Search24Regular, null),
            label: "Total Findings",
            value: dashboardLoading || findingsLoading ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Spinner, { size: "tiny" })) : (dashboardStats === null || dashboardStats === void 0 ? void 0 : dashboardStats.totalFindings) !== undefined ? (dashboardStats.totalFindings.toLocaleString()) : ("0"),
            iconColor: "#0EA5E9",
            iconBackgroundColor: "#E0F2FE",
        },
        {
            icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_8__.CheckmarkCircle24Regular, null),
            label: "Approved Actions",
            value: dashboardLoading || findingsLoading ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Spinner, { size: "tiny" })) : (dashboardStats === null || dashboardStats === void 0 ? void 0 : dashboardStats.totalApprovedActions) !== undefined ? (dashboardStats.totalApprovedActions.toLocaleString()) : ("0"),
            iconColor: "#10B981",
            iconBackgroundColor: "#D1FAE5",
        },
        {
            icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_9__.DismissCircle24Regular, null),
            label: "Rejected Actions",
            value: dashboardLoading || findingsLoading ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Spinner, { size: "tiny" })) : (dashboardStats === null || dashboardStats === void 0 ? void 0 : dashboardStats.totalRejectedActions) !== undefined ? (dashboardStats.totalRejectedActions.toLocaleString()) : ("0"),
            iconColor: "#EF4444",
            iconBackgroundColor: "#FEE2E2",
        },
        {
            icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_9__.Desktop24Regular, null),
            label: "Impacted Workspaces",
            value: dashboardLoading || findingsLoading ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Spinner, { size: "tiny" })) : (dashboardStats === null || dashboardStats === void 0 ? void 0 : dashboardStats.uniqueWorkspacesCount) !== undefined ? (dashboardStats.uniqueWorkspacesCount.toLocaleString()) : ("0"),
            iconColor: "#06B6D4",
            iconBackgroundColor: "#CFFAFE",
        },
        {
            icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_10__.DocumentError24Regular, null),
            label: "Impacted Artifacts",
            value: dashboardLoading || findingsLoading ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Spinner, { size: "tiny" })) : (dashboardStats === null || dashboardStats === void 0 ? void 0 : dashboardStats.uniqueArtifactsCount) !== undefined ? (dashboardStats.uniqueArtifactsCount.toLocaleString()) : ("0"),
            iconColor: "#EC4899",
            iconBackgroundColor: "#FCE7F3",
        },
    ];
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.container },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.header },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.headerLeft },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Text, { className: styles.title }, "Dashboard"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Text, { className: styles.subtitle }, "Overview of system metrics and key performance indicators")),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.headerRight },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Text, { className: styles.refreshInfo },
                    "Last Refreshed Data: ",
                    lastRefreshed),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.Button, { appearance: "primary", icon: !isLoading ? react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_7__.ArrowClockwise24Regular, null) : undefined, onClick: handleRefresh, disabled: isLoading }, isLoading ? "Refreshing..." : "Refresh"))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.grid }, metrics.map((metric, index) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_MetricCard__WEBPACK_IMPORTED_MODULE_12__.MetricCard, { key: index, icon: metric.icon, label: metric.label, value: metric.value, iconColor: metric.iconColor, iconBackgroundColor: metric.iconBackgroundColor, onClick: () => {
                if (metric.label === "Impacted Artifacts" ||
                    metric.label === "Impacted Workspaces" ||
                    metric.label === "Total Findings") {
                    props.setSelectedTab("review");
                }
                if (metric.label === "Approved Actions" ||
                    metric.label === "Rejected Actions") {
                    props.setSelectedTab("history");
                }
            } }))))));
}


/***/ }),

/***/ "./src/components/Dashboard/MetricCard.tsx":
/*!*************************************************!*\
  !*** ./src/components/Dashboard/MetricCard.tsx ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MetricCard: () => (/* binding */ MetricCard)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@griffel/core/index.esm.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-card/lib/components/Card/Card.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-text/lib/components/Text/Text.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@griffel/react/makeStyles.esm.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/tokens/lib/tokens.js");


const useCardStyles = (0,_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.makeStyles)({
    card: Object.assign(Object.assign({ height: '100%', cursor: 'pointer' }, _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.shorthands.transition('all', '0.2s', 'ease')), { ':hover': {
            boxShadow: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.tokens.shadow8,
            transform: 'translateY(-2px)',
        } }),
    cardContent: Object.assign(Object.assign({ display: 'flex', alignItems: 'center' }, _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.shorthands.gap('16px')), _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.shorthands.padding('16px')),
    iconContainer: Object.assign(Object.assign({ width: '48px', height: '48px' }, _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.shorthands.borderRadius(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.tokens.borderRadiusMedium)), { display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }),
    textContainer: Object.assign(Object.assign({ display: 'flex', flexDirection: 'column' }, _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.shorthands.gap('4px')), { flex: 1 }),
    label: {
        fontSize: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.tokens.fontSizeBase300,
        color: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.tokens.colorNeutralForeground3,
    },
    value: {
        fontSize: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.tokens.fontSizeHero800,
        fontWeight: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.tokens.fontWeightSemibold,
        lineHeight: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.tokens.lineHeightHero800,
    },
});
function MetricCard({ icon, label, value, iconColor, iconBackgroundColor, onClick }) {
    const styles = useCardStyles();
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Card, { className: styles.card, onClick: onClick },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.cardContent },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.iconContainer, style: {
                    backgroundColor: iconBackgroundColor,
                    color: iconColor
                } }, icon),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.textContainer },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Text, { className: styles.label }, label),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Text, { className: styles.value }, value)))));
}


/***/ }),

/***/ "./src/components/DataPlayground/DataPlayground.tsx":
/*!**********************************************************!*\
  !*** ./src/components/DataPlayground/DataPlayground.tsx ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DataPlayground: () => (/* binding */ DataPlayground)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-tabs/lib/components/TabList/TabList.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-tabs/lib/components/Tab/Tab.js");
/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @fluentui/react */ "./node_modules/@fluentui/react/lib/components/Stack/Stack.js");
/* harmony import */ var _SampleWorkloadEventhouseExplorer_SampleWorkloadEventhouseExplorer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../SampleWorkloadEventhouseExplorer/SampleWorkloadEventhouseExplorer */ "./src/components/SampleWorkloadEventhouseExplorer/SampleWorkloadEventhouseExplorer.tsx");
/* harmony import */ var _SampleWorkloadLakehouseExplorer_SampleWorkloadLakehouseExplorer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../SampleWorkloadLakehouseExplorer/SampleWorkloadLakehouseExplorer */ "./src/components/SampleWorkloadLakehouseExplorer/SampleWorkloadLakehouseExplorer.tsx");
/* harmony import */ var _styles_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./../../styles.scss */ "./src/styles.scss");






function DataPlayground(props) {
    const { workloadClient } = props;
    const [selectedTab, setSelectedTab] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("lakehouseExplorer");
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_3__.Stack, { className: "editor" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.TabList, { className: "tabListContainer", defaultSelectedValue: selectedTab, "data-testid": "item-editor-selected-tab-btn", onTabSelect: (_, data) => setSelectedTab(data.value) },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Tab, { value: "lakehouseExplorer" }, "Lakehouse"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Tab, { value: "dataEventHouse" }, "Eventhouse")),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_3__.Stack, { className: "main" },
            selectedTab === 'lakehouseExplorer' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_SampleWorkloadLakehouseExplorer_SampleWorkloadLakehouseExplorer__WEBPACK_IMPORTED_MODULE_5__.LakehouseExplorerComponent, { workloadClient: workloadClient })),
            selectedTab === 'dataEventHouse' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_SampleWorkloadEventhouseExplorer_SampleWorkloadEventhouseExplorer__WEBPACK_IMPORTED_MODULE_4__.EventhouseExplorerComponent, { workloadClient: workloadClient })))));
}
;


/***/ }),

/***/ "./src/components/EventHistory/EventHistory.tsx":
/*!******************************************************!*\
  !*** ./src/components/EventHistory/EventHistory.tsx ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   EventHistory: () => (/* binding */ EventHistory)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@griffel/core/index.esm.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-badge/lib/components/Badge/Badge.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-text/lib/components/Text/Text.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-field/lib/components/Field/Field.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-combobox/lib/components/Dropdown/Dropdown.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-combobox/lib/components/Option/Option.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-input/lib/components/Input/Input.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-button/lib/components/Button/Button.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-spinner/lib/components/Spinner/Spinner.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-table/lib/components/Table/Table.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-table/lib/components/TableHeader/TableHeader.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-table/lib/components/TableRow/TableRow.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-table/lib/components/TableHeaderCell/TableHeaderCell.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-table/lib/components/TableBody/TableBody.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-table/lib/components/TableCell/TableCell.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-table/lib/components/TableCellLayout/TableCellLayout.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@griffel/react/makeStyles.esm.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/tokens/lib/tokens.js");
/* harmony import */ var _fluentui_react_icons__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @fluentui/react-icons */ "./node_modules/@fluentui/react-icons/lib/sizedIcons/chunk-0.js");
/* harmony import */ var _fluentui_react_icons__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @fluentui/react-icons */ "./node_modules/@fluentui/react-icons/lib/sizedIcons/chunk-2.js");
/* harmony import */ var _fluentui_react_icons__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @fluentui/react-icons */ "./node_modules/@fluentui/react-icons/lib/sizedIcons/chunk-3.js");
/* harmony import */ var _fluentui_react_icons__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @fluentui/react-icons */ "./node_modules/@fluentui/react-icons/lib/sizedIcons/chunk-4.js");
/* harmony import */ var _contexts_SettingsContext__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ../../contexts/SettingsContext */ "./src/contexts/SettingsContext.tsx");




const useStyles = (0,_fluentui_react_components__WEBPACK_IMPORTED_MODULE_17__.makeStyles)({
    container: Object.assign(Object.assign({ display: "flex", flexDirection: "column", gap: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_18__.tokens.spacingVerticalL }, _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.shorthands.padding("24px", "24px")), { backgroundColor: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_18__.tokens.colorNeutralBackground2, minHeight: 'calc(100vh - 96px)' }),
    header: {
        display: "flex",
        flexDirection: "column",
        rowGap: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_18__.tokens.spacingVerticalXXS,
    },
    title: {
        fontSize: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_18__.tokens.fontSizeHero700,
        fontWeight: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_18__.tokens.fontWeightSemibold,
        lineHeight: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_18__.tokens.lineHeightHero700,
    },
    subtitle: {
        fontSize: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_18__.tokens.fontSizeBase300,
        color: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_18__.tokens.colorNeutralForeground3,
    },
    filters: {
        display: "flex",
        alignItems: "end",
        gap: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_18__.tokens.spacingHorizontalM,
        flexWrap: "wrap",
        backgroundColor: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_18__.tokens.colorNeutralBackground1,
        padding: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_18__.tokens.spacingHorizontalL,
        borderRadius: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_18__.tokens.borderRadiusXLarge,
        boxShadow: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_18__.tokens.shadow4,
    },
    field: { minWidth: "180px" },
    dateInput: {
        display: "flex",
        alignItems: "center",
        gap: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_18__.tokens.spacingHorizontalXS,
    },
    buttonGroup: {
        display: "flex",
        gap: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_18__.tokens.spacingHorizontalS,
        marginLeft: "auto",
    },
    tableRoot: {
        borderRadius: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_18__.tokens.borderRadiusMedium,
        overflow: "hidden",
        border: `1px solid ${_fluentui_react_components__WEBPACK_IMPORTED_MODULE_18__.tokens.colorNeutralStroke1}`,
    },
    thead: {
        backgroundColor: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_18__.tokens.colorSubtleBackgroundHover,
    },
    row: {
        ":hover": {
            backgroundColor: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_18__.tokens.colorSubtleBackgroundHover,
        },
    },
    zebra: {
        ":nth-child(even)": {
            backgroundColor: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_18__.tokens.colorNeutralBackground2,
        },
    },
    cell: {
        paddingTop: "8px",
        paddingBottom: "8px",
        verticalAlign: "top",
    },
    wrapCell: {
        whiteSpace: "normal",
        overflowWrap: "anywhere",
        wordBreak: "break-word",
    },
    footer: {
        display: "flex",
        alignItems: "center",
        gap: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_18__.tokens.spacingHorizontalM,
    },
    footerSpacer: { flex: 1 },
    rowsPerPage: { width: "90px" },
    countText: { minWidth: "150px", textAlign: "right" },
});
function EventHistory(props) {
    const styles = useStyles();
    const admin = (0,_contexts_SettingsContext__WEBPACK_IMPORTED_MODULE_23__.useAdmin)();
    const [filters, setFilters] = react__WEBPACK_IMPORTED_MODULE_0__.useState({
        submittedBy: "All",
        workspaceName: "All",
        artifactName: "All",
        finding: "All",
        startDate: "",
        endDate: "",
    });
    const [page, setPage] = react__WEBPACK_IMPORTED_MODULE_0__.useState(1);
    const [pageSize, setPageSize] = react__WEBPACK_IMPORTED_MODULE_0__.useState(10);
    const getUniqueValues = (key) => {
        const values = (admin.eventHistory || []).map((item) => { var _a; return (_a = item[key]) !== null && _a !== void 0 ? _a : ""; });
        return Array.from(new Set(values)).filter(Boolean);
    };
    const handleFilterChange = (key, value) => {
        setPage(1);
        setFilters((prev) => (Object.assign(Object.assign({}, prev), { [key]: value })));
    };
    const toStartOfDay = (v) => (v ? new Date(`${v}T00:00:00`) : null);
    const toStartOfNextDay = (v) => {
        if (!v)
            return null;
        const d = new Date(`${v}T00:00:00`);
        d.setDate(d.getDate() + 1);
        return d;
    };
    const filteredData = react__WEBPACK_IMPORTED_MODULE_0__.useMemo(() => {
        const startInclusive = toStartOfDay(filters.startDate);
        const endExclusive = toStartOfNextDay(filters.endDate);
        return (admin.eventHistory || []).filter((d) => {
            if (filters.submittedBy !== "All" && d.submittedBy !== filters.submittedBy)
                return false;
            if (filters.workspaceName !== "All" && d.workspaceName !== filters.workspaceName)
                return false;
            if (filters.artifactName !== "All" && d.artifactName !== filters.artifactName)
                return false;
            if (filters.finding !== "All" && d.finding !== filters.finding)
                return false;
            const t = new Date(d.lastUpdatedAt);
            if (Number.isNaN(t.getTime()))
                return false;
            if (startInclusive && t < startInclusive)
                return false;
            if (endExclusive && t >= endExclusive)
                return false;
            return true;
        });
    }, [filters, admin.eventHistory]);
    const pageCount = Math.max(1, Math.ceil(filteredData.length / pageSize));
    react__WEBPACK_IMPORTED_MODULE_0__.useEffect(() => {
        if (page > pageCount)
            setPage(1);
    }, [page, pageCount]);
    const pagedData = react__WEBPACK_IMPORTED_MODULE_0__.useMemo(() => {
        const startIdx = (page - 1) * pageSize;
        return filteredData.slice(startIdx, startIdx + pageSize);
    }, [filteredData, page, pageSize]);
    const clearFilters = () => {
        setFilters({
            submittedBy: "All",
            workspaceName: "All",
            artifactName: "All",
            finding: "All",
            startDate: "",
            endDate: "",
        });
        setPage(1);
    };
    const renderActionBadge = (action) => {
        const v = (action || "").toLowerCase().trim();
        if (v === "approved")
            return react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Badge, { appearance: "filled", color: "success" }, "Approved");
        if (v === "rejected" || v === "declined")
            return react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Badge, { appearance: "filled", color: "danger" }, "Rejected");
        if (v === "pending" || v === "in review")
            return react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Badge, { appearance: "tint", color: "warning" }, "Pending");
        return react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Badge, { appearance: "ghost", color: "informative" }, action || "—");
    };
    const total = filteredData.length;
    const startRow = total === 0 ? 0 : (page - 1) * pageSize + 1;
    const endRow = Math.min(total, page * pageSize);
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: styles.container },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: styles.header },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Text, { className: styles.title }, "Event History"),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Text, { className: styles.subtitle }, "View all past admin actions and decisions")),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: styles.filters },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.Field, { label: "Submitted By", className: styles.field },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.Dropdown, { value: filters.submittedBy, onOptionSelect: (_, data) => handleFilterChange("submittedBy", data.optionValue) },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__.Option, { value: "All", text: "All" }, "All"),
                    getUniqueValues("submittedBy").map((val) => (react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__.Option, { key: val, value: val, text: val }, val))))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.Field, { label: "Workspace Name", className: styles.field },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.Dropdown, { value: filters.workspaceName, onOptionSelect: (_, data) => handleFilterChange("workspaceName", data.optionValue) },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__.Option, { value: "All", text: "All" }, "All"),
                    getUniqueValues("workspaceName").map((val) => (react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__.Option, { key: val, value: val, text: val }, val))))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.Field, { label: "Artifact Name", className: styles.field },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.Dropdown, { value: filters.artifactName, onOptionSelect: (_, data) => handleFilterChange("artifactName", data.optionValue) },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__.Option, { value: "All", text: "All" }, "All"),
                    getUniqueValues("artifactName").map((val) => (react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__.Option, { key: val, value: val, text: val }, val))))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.Field, { label: "Finding", className: styles.field },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.Dropdown, { value: filters.finding, onOptionSelect: (_, data) => handleFilterChange("finding", data.optionValue) },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__.Option, { value: "All", text: "All" }, "All"),
                    getUniqueValues("finding").map((val) => (react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__.Option, { key: val, value: val, text: val }, val))))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.Field, { label: "Event Time", className: styles.field },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: styles.dateInput },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_7__.Input, { type: "date", value: filters.startDate, max: filters.endDate || undefined, onChange: (e) => {
                            handleFilterChange("startDate", e.target.value);
                            setPage(1);
                        }, contentBefore: react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_20__.Calendar24Regular, null) }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "\u2013"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_7__.Input, { type: "date", value: filters.endDate, min: filters.startDate || undefined, onChange: (e) => {
                            handleFilterChange("endDate", e.target.value);
                            setPage(1);
                        }, contentBefore: react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_20__.Calendar24Regular, null) }))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: styles.buttonGroup },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_8__.Button, { appearance: "secondary", icon: react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_22__.Dismiss24Regular, null), onClick: clearFilters }, "Clear Filters"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_8__.Button, { appearance: "primary", icon: react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_19__.ArrowClockwise24Regular, null), disabled: admin.eventHistoryLoading, onClick: async () => {
                        try {
                            setPage(1);
                            await admin.refreshEventHistory();
                        }
                        catch (err) {
                            console.error("Failed to refresh event history:", err);
                        }
                    } }, "Refresh"))),
        admin.eventHistoryLoading ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { style: { padding: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_18__.tokens.spacingHorizontalL, minHeight: 200, display: "flex", alignItems: "center", justifyContent: "center" } },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_9__.Spinner, null))) : (react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null,
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: styles.tableRoot },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_10__.Table, { "aria-label": "Event History Table" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_11__.TableHeader, null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_12__.TableRow, { className: styles.thead },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_13__.TableHeaderCell, null, "Submitted By"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_13__.TableHeaderCell, null, "Workspace Name"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_13__.TableHeaderCell, null, "Artifact Name"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_13__.TableHeaderCell, null, "Finding"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_13__.TableHeaderCell, null, "Suggested Action"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_13__.TableHeaderCell, null, "Action"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_13__.TableHeaderCell, null, "Event Time"))),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_14__.TableBody, null, pagedData.map((item, index) => (react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_12__.TableRow, { key: `${item.lastUpdatedAt}-${index}`, className: `${styles.row} ${styles.zebra}` },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_15__.TableCell, { className: styles.cell },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_16__.TableCellLayout, null,
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: styles.wrapCell }, item.submittedBy))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_15__.TableCell, { className: styles.cell },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_16__.TableCellLayout, null,
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: styles.wrapCell }, item.workspaceName))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_15__.TableCell, { className: styles.cell },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_16__.TableCellLayout, null,
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: styles.wrapCell }, item.artifactName || "—"))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_15__.TableCell, { className: styles.cell },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_16__.TableCellLayout, null,
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: styles.wrapCell }, item.finding))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_15__.TableCell, { className: styles.cell },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_16__.TableCellLayout, null,
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: styles.wrapCell }, item.suggestedAction || "—"))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_15__.TableCell, { className: styles.cell },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_16__.TableCellLayout, null, renderActionBadge(item.action))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_15__.TableCell, { className: styles.cell },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_16__.TableCellLayout, null,
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: styles.wrapCell }, new Date(item.lastUpdatedAt).toLocaleString()))))))))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: styles.footer },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Text, null, "Rows per page:"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.Dropdown, { className: styles.rowsPerPage, value: String(pageSize), onOptionSelect: (_, data) => {
                        const newSize = Number(data.optionValue);
                        setPageSize(newSize);
                        setPage(1);
                    } }, [10, 20, 30, 40, 50].map((n) => (react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__.Option, { key: n, value: String(n), text: String(n) }, String(n))))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: styles.footerSpacer }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Text, { className: styles.countText },
                    startRow,
                    "-",
                    endRow,
                    " of ",
                    total),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_8__.Button, { icon: react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_19__.ArrowPrevious24Regular, null), appearance: "subtle", "aria-label": "First page", disabled: page <= 1, onClick: () => setPage(1) }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_8__.Button, { icon: react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_21__.ChevronLeft24Regular, null), appearance: "subtle", "aria-label": "Previous page", disabled: page <= 1, onClick: () => setPage((p) => Math.max(1, p - 1)) }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_8__.Button, { icon: react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_21__.ChevronRight24Regular, null), appearance: "subtle", "aria-label": "Next page", disabled: page >= pageCount, onClick: () => setPage((p) => Math.min(pageCount, p + 1)) }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_8__.Button, { icon: react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_19__.ArrowNext24Regular, null), appearance: "subtle", "aria-label": "Last page", disabled: page >= pageCount, onClick: () => setPage(pageCount) }))))));
}


/***/ }),

/***/ "./src/components/Header/Header.tsx":
/*!******************************************!*\
  !*** ./src/components/Header/Header.tsx ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Header: () => (/* binding */ Header)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@griffel/core/index.esm.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-button/lib/components/Button/Button.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-tabs/lib/components/TabList/TabList.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-tabs/lib/components/Tab/Tab.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-menu/lib/components/Menu/Menu.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-menu/lib/components/MenuTrigger/MenuTrigger.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-menu/lib/components/MenuPopover/MenuPopover.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-menu/lib/components/MenuList/MenuList.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-menu/lib/components/MenuItem/MenuItem.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@griffel/react/makeStyles.esm.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/tokens/lib/tokens.js");
/* harmony import */ var _fluentui_react_icons__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @fluentui/react-icons */ "./node_modules/@fluentui/react-icons/lib/sizedIcons/chunk-1.js");
/* harmony import */ var _fluentui_react_icons__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @fluentui/react-icons */ "./node_modules/@fluentui/react-icons/lib/sizedIcons/chunk-5.js");
/* harmony import */ var _fluentui_react_icons__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @fluentui/react-icons */ "./node_modules/@fluentui/react-icons/lib/sizedIcons/chunk-7.js");
/* harmony import */ var _fluentui_react_icons__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @fluentui/react-icons */ "./node_modules/@fluentui/react-icons/lib/sizedIcons/chunk-9.js");
/* harmony import */ var _fluentui_react_icons__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @fluentui/react-icons */ "./node_modules/@fluentui/react-icons/lib/sizedIcons/chunk-11.js");
/* harmony import */ var _SettingsPanel_SettingsPanel__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../SettingsPanel/SettingsPanel */ "./src/components/SettingsPanel/SettingsPanel.tsx");




const MAQ_LOGO = __webpack_require__(/*! ./../../assets/MAQ_LOGO.jpg */ "./src/assets/MAQ_LOGO.jpg");
const useStyles = (0,_fluentui_react_components__WEBPACK_IMPORTED_MODULE_10__.makeStyles)({
    headerContainer: {
        backgroundColor: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_11__.tokens.colorNeutralBackground1,
        borderBottom: `1px solid ${_fluentui_react_components__WEBPACK_IMPORTED_MODULE_11__.tokens.colorNeutralStroke2}`,
    },
    topBar: Object.assign(Object.assign({ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }, _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.shorthands.padding('0', '24px')), { height: '48px', borderBottom: `1px solid ${_fluentui_react_components__WEBPACK_IMPORTED_MODULE_11__.tokens.colorNeutralStroke2}`, '@media (max-width: 768px)': Object.assign({}, _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.shorthands.padding('0', '12px')) }),
    logo: Object.assign(Object.assign({ display: 'flex', alignItems: 'center' }, _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.shorthands.gap('8px')), { fontWeight: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_11__.tokens.fontWeightSemibold, fontSize: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_11__.tokens.fontSizeBase400, whiteSpace: 'nowrap', '@media (max-width: 768px)': {
            fontSize: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_11__.tokens.fontSizeBase300,
        } }),
    logoImage: {
        height: '20px',
        width: 'auto',
        objectFit: 'contain',
        '@media (max-width: 768px)': {
            height: '16px',
        },
    },
    separator: Object.assign(Object.assign({ color: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_11__.tokens.colorNeutralForeground3 }, _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.shorthands.margin('0', '8px')), { '@media (max-width: 640px)': {
            display: 'none',
        } }),
    agentName: {
        '@media (max-width: 640px)': {
            display: 'none',
        },
    },
    rightSection: Object.assign(Object.assign({ display: 'flex', alignItems: 'center' }, _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.shorthands.gap('12px')), { '@media (max-width: 768px)': Object.assign({}, _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.shorthands.gap('4px')) }),
    iconButton: {
        '@media (max-width: 480px)': {
            minWidth: '32px',
            width: '32px',
            height: '32px',
        },
    },
    settingsButton: {
        '@media (max-width: 640px)': {
            display: 'none',
        },
    },
    navigationBar: Object.assign(Object.assign({ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }, _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.shorthands.padding('0', '24px')), { height: '48px', '@media (max-width: 768px)': Object.assign({}, _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.shorthands.padding('0', '12px')) }),
    navigation: {
        display: 'flex',
        alignItems: 'center',
        height: '100%',
        '@media (max-width: 900px)': {
            display: 'none',
        },
    },
    mobileMenu: {
        display: 'none',
        '@media (max-width: 900px)': {
            display: 'block',
        },
    },
    tabText: {
        '@media (max-width: 1024px)': {
            display: 'none',
        },
    },
});
function Header({ selectedTab, onTabChange, onSettings }) {
    const styles = useStyles();
    const [settingsOpen, setSettingsOpen] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const topBarRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const [topOffset, setTopOffset] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(96);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        const updateOffset = () => {
            var _a, _b;
            const h = (_b = (_a = topBarRef.current) === null || _a === void 0 ? void 0 : _a.offsetHeight) !== null && _b !== void 0 ? _b : 0;
            setTopOffset(h + 1);
        };
        updateOffset();
        window.addEventListener('resize', updateOffset);
        return () => window.removeEventListener('resize', updateOffset);
    }, []);
    const navigationItems = [
        { value: 'dashboard', label: 'Dashboard', icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_12__.Board24Regular, null) },
        { value: 'review', label: 'Review Findings', icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_13__.DocumentSearch24Regular, null) },
        { value: 'history', label: 'Event History', icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_14__.History24Regular, null) },
    ];
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("header", { className: styles.headerContainer },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { ref: topBarRef, className: styles.topBar },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.logo },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("img", { src: MAQ_LOGO, alt: "MAQ Software", className: styles.logoImage }),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: styles.separator }, "|"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: styles.agentName }, "Fabric Admin Agent")),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.rightSection },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Button, { appearance: "subtle", icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_16__.Settings24Regular, null), className: `${styles.iconButton} ${styles.settingsButton}`, onClick: onSettings }))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.navigationBar },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("nav", { className: styles.navigation },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.TabList, { selectedValue: selectedTab, onTabSelect: (_, data) => onTabChange(data.value) }, navigationItems.map((item) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.Tab, { key: item.value, icon: item.icon, value: item.value },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: styles.tabText }, item.label)))))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.mobileMenu },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.Menu, null,
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__.MenuTrigger, { disableButtonEnhancement: true },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Button, { appearance: "subtle", icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_15__.Navigation24Regular, null), className: styles.iconButton })),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_7__.MenuPopover, null,
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_8__.MenuList, null, navigationItems.map((item) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_9__.MenuItem, { key: item.value, icon: item.icon, onClick: () => onTabChange(item.value) }, item.label))))))))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_SettingsPanel_SettingsPanel__WEBPACK_IMPORTED_MODULE_17__["default"], { open: settingsOpen, onClose: () => setSettingsOpen(false), topOffset: topOffset })));
}


/***/ }),

/***/ "./src/components/ReviewFindings/FilterDropdownComponent.tsx":
/*!*******************************************************************!*\
  !*** ./src/components/ReviewFindings/FilterDropdownComponent.tsx ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FilterDropdown: () => (/* binding */ FilterDropdown),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-text/lib/components/Text/Text.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-combobox/lib/components/Dropdown/Dropdown.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-combobox/lib/components/Option/Option.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@griffel/react/makeStyles.esm.js");


const useStyles = (0,_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.makeStyles)({
    container: {
        display: "flex",
        alignItems: "center",
        columnGap: "12px",
    },
    label: {
        fontWeight: 500,
        minWidth: "fit-content",
        flexShrink: 0,
        whiteSpace: "nowrap",
    },
    dropdownWrapper: {
        width: "240px",
        maxWidth: "240px",
        "& button": {
            height: "32px !important",
            minHeight: "32px !important",
            width: "100%",
        },
    },
    buttonContent: {
        overflow: "hidden",
        textOverflow: "ellipsis",
        whiteSpace: "nowrap",
        display: "block",
        width: "100%",
    },
    listbox: {
        height: "300px",
        overflowY: "auto",
        overflowX: "auto",
        width: "320px",
        padding: "4px 0",
    },
    option: {
        padding: "8px 12px",
        minHeight: "36px",
        textOverflow: "ellipsis",
        whiteSpace: "nowrap",
        cursor: "pointer",
        "&:hover": {
            backgroundColor: "#f3f2f1",
        },
        "&:focus": {
            backgroundColor: "#edebe9",
        },
    },
});
const FilterDropdown = ({ label, options, selectedValue, onValueChange, placeholder = "All", width = "240px", }) => {
    const styles = useStyles();
    const handleSelect = (_, data) => {
        onValueChange(data.optionValue);
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.container },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Text, { className: styles.label }, label),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Dropdown, { className: styles.dropdownWrapper, style: { width }, "aria-label": `${label} Filter`, placeholder: placeholder, selectedOptions: selectedValue ? [selectedValue] : [], onOptionSelect: handleSelect, listbox: {
                className: styles.listbox,
                style: { width: "320px" }, // Override default width
            }, button: {
                children: (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: styles.buttonContent, title: selectedValue || placeholder }, selectedValue || placeholder)),
            } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Option, { value: "", className: styles.option }, placeholder),
            options.map((opt) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Option, { key: opt, value: opt, className: styles.option, title: opt }, opt))))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FilterDropdown);


/***/ }),

/***/ "./src/components/ReviewFindings/ReviewFindings.tsx":
/*!**********************************************************!*\
  !*** ./src/components/ReviewFindings/ReviewFindings.tsx ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ReviewFindings: () => (/* binding */ ReviewFindings)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@griffel/core/index.esm.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-badge/lib/components/Badge/Badge.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-text/lib/components/Text/Text.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-table/lib/components/Table/Table.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-table/lib/components/TableHeader/TableHeader.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-table/lib/components/TableRow/TableRow.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-table/lib/components/TableHeaderCell/TableHeaderCell.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-table/lib/components/TableBody/TableBody.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-table/lib/components/TableCell/TableCell.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-combobox/lib/components/Dropdown/Dropdown.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-combobox/lib/components/Option/Option.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-button/lib/components/Button/Button.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-text/lib/components/presets/Caption1/Caption1.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-spinner/lib/components/Spinner/Spinner.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@griffel/react/makeStyles.esm.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/tokens/lib/tokens.js");
/* harmony import */ var _fluentui_react_icons__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @fluentui/react-icons */ "./node_modules/@fluentui/react-icons/lib/sizedIcons/chunk-0.js");
/* harmony import */ var _fluentui_react_icons__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @fluentui/react-icons */ "./node_modules/@fluentui/react-icons/lib/sizedIcons/chunk-1.js");
/* harmony import */ var _fluentui_react_icons__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @fluentui/react-icons */ "./node_modules/@fluentui/react-icons/lib/sizedIcons/chunk-3.js");
/* harmony import */ var _fluentui_react_icons__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @fluentui/react-icons */ "./node_modules/@fluentui/react-icons/lib/sizedIcons/chunk-4.js");
/* harmony import */ var _controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ../../controller/SampleWorkloadController */ "./src/controller/SampleWorkloadController.ts");
/* harmony import */ var _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @ms-fabric/workload-client */ "./node_modules/@ms-fabric/workload-client/src/workload-client.js");
/* harmony import */ var _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(_ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var _controller_UserDetail__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ../../controller/UserDetail */ "./src/controller/UserDetail.ts");
/* harmony import */ var _contexts_FabricFindingsContext__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ../../contexts/FabricFindingsContext */ "./src/contexts/FabricFindingsContext.tsx");
/* harmony import */ var _contexts_SettingsContext__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ../../contexts/SettingsContext */ "./src/contexts/SettingsContext.tsx");
/* harmony import */ var _CommonLoader_CommonLoader__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./../CommonLoader/CommonLoader */ "./src/components/CommonLoader/CommonLoader.tsx");
/* harmony import */ var _FilterDropdownComponent__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./FilterDropdownComponent */ "./src/components/ReviewFindings/FilterDropdownComponent.tsx");
/* harmony import */ var _env__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./../../env */ "./src/env.ts");











// ---------- Global ResizeObserver Error Suppression ----------
const debounce = (callback, delay) => {
    let tid;
    return function (...args) {
        const ctx = this;
        clearTimeout(tid);
        tid = setTimeout(() => {
            callback.apply(ctx, args);
        }, delay);
    };
};
if (typeof window !== "undefined" && window.ResizeObserver) {
    const OriginalResizeObserver = window.ResizeObserver;
    window.ResizeObserver = class ResizeObserver extends OriginalResizeObserver {
        constructor(callback) {
            const debouncedCallback = debounce(callback, 20);
            super(debouncedCallback);
        }
    };
}
// ---------- Styles ----------
const useStyles = (0,_fluentui_react_components__WEBPACK_IMPORTED_MODULE_15__.makeStyles)({
    container: Object.assign(Object.assign({ display: "flex", flexDirection: "column" }, _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.shorthands.padding("24px", "24px")), { backgroundColor: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_16__.tokens.colorNeutralBackground2, rowGap: "20px", minHeight: 'calc(100vh - 96px)' }),
    headerSection: {
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
    },
    headerTitle: {
        display: "flex",
        flexDirection: "column",
        rowGap: "4px",
    },
    title: {
        fontSize: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_16__.tokens.fontSizeHero700,
        fontWeight: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_16__.tokens.fontWeightSemibold,
        lineHeight: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_16__.tokens.lineHeightHero700,
    },
    subtitle: {
        fontSize: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_16__.tokens.fontSizeBase300,
        color: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_16__.tokens.colorNeutralForeground3,
    },
    refreshedLabel: Object.assign(Object.assign({ display: "flex", alignItems: "center", columnGap: "6px", backgroundColor: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_16__.tokens.colorNeutralBackground3 }, _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.shorthands.padding("6px", "12px")), { borderRadius: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_16__.tokens.borderRadiusCircular }),
    tabButtons: {
        display: "flex",
        gap: "8px",
        marginTop: "4px",
    },
    tabButton: Object.assign(Object.assign({ backgroundColor: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_16__.tokens.colorNeutralBackground1, color: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_16__.tokens.colorNeutralForeground1, border: `1px solid ${_fluentui_react_components__WEBPACK_IMPORTED_MODULE_16__.tokens.colorNeutralStroke1}` }, _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.shorthands.padding("8px", "16px")), { cursor: "pointer", fontSize: "14px", fontWeight: 400, borderRadius: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_16__.tokens.borderRadiusMedium, transition: "all 0.2s ease", "&:hover": {
            backgroundColor: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_16__.tokens.colorNeutralBackground1Hover,
        } }),
    tabButtonActive: {
        backgroundColor: "#117865",
        color: "#ffffff",
        border: "1px solid #117865",
        fontWeight: 600,
        "&:hover": {
            backgroundColor: "#117865",
        },
    },
    filtersRow: {
        display: "flex",
        alignItems: "center",
        columnGap: "8px",
    },
    actionButtonsRow: {
        display: "flex",
        justifyContent: "flex-end",
        columnGap: "8px",
    },
    saveButton: Object.assign(Object.assign({ backgroundColor: "#117865", color: "#ffffff", fontWeight: 600, textTransform: "none", fontSize: "14px", cursor: "pointer", borderRadius: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_16__.tokens.borderRadiusMedium }, _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.shorthands.padding("8px", "24px")), { transition: "all 0.2s ease", "&:hover:not(:disabled)": {
            backgroundColor: "#0f6b5a",
        }, "&:disabled": {
            backgroundColor: "#f3f2f1",
            color: "#a19f9d",
            cursor: "not-allowed",
            "&:hover": {
                backgroundColor: "#f3f2f1",
            },
        } }),
    tableWrapper: {
        border: `1px solid ${_fluentui_react_components__WEBPACK_IMPORTED_MODULE_16__.tokens.colorNeutralStroke1}`,
        borderRadius: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_16__.tokens.borderRadiusLarge,
        overflow: "hidden",
    },
    pagination: {
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        marginTop: "12px",
        columnGap: "8px",
    },
    paginationLeft: {
        display: "flex",
        alignItems: "center",
        columnGap: "8px",
    },
    paginationRight: {
        display: "flex",
        alignItems: "center",
        columnGap: "4px",
    },
    nestedRow: {
        backgroundColor: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_16__.tokens.colorNeutralBackground2,
    },
    actionCell: {
        display: "flex",
        alignItems: "center",
        gap: "8px",
    },
    iconButton: {
        cursor: "pointer",
        display: "flex",
        alignItems: "center",
    },
    suggestedActionCell: {
        paddingLeft: "32px",
    },
    loadingWrapper: {
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        marginTop: "40px",
    },
    errorWrapper: {
        color: "red",
        marginTop: "20px",
        fontWeight: 600,
    },
});
// ---------- Reusable Paginated Table ----------
function FindingsTable({ findings, isLoading = false, pageSize = 5, onStateChange, onUndo, changedStates, onPageSizeChange, }) {
    const styles = useStyles();
    const [page, setPage] = react__WEBPACK_IMPORTED_MODULE_0__.useState(1);
    react__WEBPACK_IMPORTED_MODULE_0__.useEffect(() => {
        setPage(1);
    }, [pageSize]);
    const totalItems = findings.length;
    const totalPages = Math.max(1, Math.ceil(totalItems / pageSize));
    const startIndex = totalItems === 0 ? 0 : (page - 1) * pageSize;
    const endIndex = totalItems === 0 ? 0 : Math.min(startIndex + pageSize, totalItems);
    const paginatedFindings = findings.slice(startIndex, endIndex);
    const getStateKey = (findingId, actionIndex) => `${findingId}-${actionIndex}`;
    const renderActionButtons = (finding, actionIndex) => {
        const state = finding.state[actionIndex];
        const stateKey = getStateKey(finding.id, actionIndex);
        const hasChanged = changedStates.has(stateKey);
        if (state === "approved") {
            return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: styles.actionCell },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Badge, { color: "success", appearance: "filled" }, "APPROVED"),
                hasChanged && (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: styles.iconButton, onClick: () => onUndo(finding.id, actionIndex), title: "Undo" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_18__.ArrowUndo16Regular, null)))));
        }
        if (state === "rejected") {
            return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: styles.actionCell },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Badge, { color: "danger", appearance: "filled" }, "REJECTED"),
                hasChanged && (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: styles.iconButton, onClick: () => onUndo(finding.id, actionIndex), title: "Undo" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_18__.ArrowUndo16Regular, null)))));
        }
        return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: styles.actionCell },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: styles.iconButton, onClick: () => onStateChange(finding.id, actionIndex, "approved"), title: "Approve" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_19__.CheckmarkCircle16Regular, { color: "green" }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Text, { size: 200 }, "APPROVE")),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: styles.iconButton, onClick: () => onStateChange(finding.id, actionIndex, "rejected"), title: "Reject" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_20__.DismissCircle16Regular, { color: "red" }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Text, { size: 200 }, "REJECT"))));
    };
    // Pagination handlers
    const goFirst = () => setPage(1);
    const goPrev = () => setPage((p) => Math.max(1, p - 1));
    const goNext = () => setPage((p) => Math.min(totalPages, p + 1));
    const goLast = () => setPage(totalPages);
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: styles.tableWrapper }, isLoading ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: styles.loadingWrapper },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(_CommonLoader_CommonLoader__WEBPACK_IMPORTED_MODULE_26__["default"], { size: "large", label: "Loading findings..." }))) : (react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.Table, { "aria-label": "Findings table" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.TableHeader, null,
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__.TableRow, null,
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_7__.TableHeaderCell, null, "Capacity"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_7__.TableHeaderCell, null, "Workspace"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_7__.TableHeaderCell, null, "Artifact"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_7__.TableHeaderCell, null, "Finding"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_7__.TableHeaderCell, null, "Suggested Action"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_7__.TableHeaderCell, null, "Action"))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_8__.TableBody, null, paginatedFindings.map((finding) => (react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, { key: finding.id }, finding.suggestedActions.map((action, actionIndex) => (react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__.TableRow, { key: `${finding.id}-${actionIndex}`, className: actionIndex > 0 ? styles.nestedRow : "" },
                actionIndex === 0 ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null,
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_9__.TableCell, { rowSpan: finding.suggestedActions.length }, finding.capacityName),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_9__.TableCell, { rowSpan: finding.suggestedActions.length }, finding.workspaceName),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_9__.TableCell, { rowSpan: finding.suggestedActions.length }, finding.artifactName),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_9__.TableCell, { rowSpan: finding.suggestedActions.length }, finding.finding))) : null,
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_9__.TableCell, { className: styles.suggestedActionCell }, action),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_9__.TableCell, null, renderActionButtons(finding, actionIndex)))))))))))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: styles.pagination },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: styles.paginationLeft },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Text, { size: 200 }, "Rows per page:"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_10__.Dropdown, { size: "small", selectedOptions: [String(pageSize)], value: String(pageSize), onOptionSelect: (_, data) => {
                        const newSize = Number(data.optionValue);
                        onPageSizeChange === null || onPageSizeChange === void 0 ? void 0 : onPageSizeChange(newSize);
                    } },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_11__.Option, { value: "10", text: "10" }, "10"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_11__.Option, { value: "20", text: "20" }, "20"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_11__.Option, { value: "30", text: "30" }, "30"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_11__.Option, { value: "40", text: "40" }, "40"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_11__.Option, { value: "50", text: "50" }, "50")),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Text, { size: 200 },
                    totalItems === 0 ? "0–0" : `${startIndex + 1}–${endIndex}`,
                    " of",
                    " ",
                    totalItems)),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: styles.paginationRight },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_12__.Button, { appearance: "subtle", "aria-label": "First page", disabled: page <= 1 || totalItems === 0, icon: react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_17__.ArrowPrevious16Regular, null), onClick: goFirst }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_12__.Button, { appearance: "subtle", "aria-label": "Previous page", disabled: page <= 1 || totalItems === 0, icon: react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_19__.ChevronLeft16Regular, null), onClick: goPrev }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_12__.Button, { appearance: "subtle", "aria-label": "Next page", disabled: page >= totalPages || totalItems === 0, icon: react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_19__.ChevronRight16Regular, null), onClick: goNext }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_12__.Button, { appearance: "subtle", "aria-label": "Last page", disabled: page >= totalPages || totalItems === 0, icon: react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_17__.ArrowNext16Regular, null), onClick: goLast })))));
}
// ---------- Main Component ----------
const ReviewFindings = (props) => {
    const styles = useStyles();
    const [selectedTab, setSelectedTab] = react__WEBPACK_IMPORTED_MODULE_0__.useState("all");
    const [lastRefreshed, setLastRefreshed] = react__WEBPACK_IMPORTED_MODULE_0__.useState("Loading...");
    const [findings, setFindings] = react__WEBPACK_IMPORTED_MODULE_0__.useState([]);
    const [isLoading, setIsLoading] = react__WEBPACK_IMPORTED_MODULE_0__.useState(false);
    const [changedStates, setChangedStates] = react__WEBPACK_IMPORTED_MODULE_0__.useState(new Map());
    const [selectedCapacity, setSelectedCapacity] = react__WEBPACK_IMPORTED_MODULE_0__.useState("");
    const [selectedWorkspace, setSelectedWorkspace] = react__WEBPACK_IMPORTED_MODULE_0__.useState("");
    const [selectedArtifact, setSelectedArtifact] = react__WEBPACK_IMPORTED_MODULE_0__.useState("");
    const [selectedFinding, setSelectedFinding] = react__WEBPACK_IMPORTED_MODULE_0__.useState("");
    const [pageSize, setPageSize] = react__WEBPACK_IMPORTED_MODULE_0__.useState(10);
    const [saving, setSaving] = react__WEBPACK_IMPORTED_MODULE_0__.useState(false);
    // Get current user info
    const { upn } = (0,_controller_UserDetail__WEBPACK_IMPORTED_MODULE_23__.useUserDetails)();
    const { sampleData, loading, error, isInitialized, refetch, refreshVersion } = (0,_contexts_FabricFindingsContext__WEBPACK_IMPORTED_MODULE_24__.useFabricFindings)();
    console.log("SampleData from Context:", sampleData);
    const { refreshEventHistory } = (0,_contexts_SettingsContext__WEBPACK_IMPORTED_MODULE_25__.useAdmin)();
    const fetchLastRunTime = async () => {
        try {
            const res = await fetch(`${_env__WEBPACK_IMPORTED_MODULE_28__.workloadBEURL}/api/fabricFindings/latest`);
            const json = await res.json();
            console.log("⏱️ API timestamp:", json); // debug
            if (json.success && json.data) {
                const formatted = new Date(json.data).toLocaleString("en-US", {
                    month: "2-digit",
                    day: "2-digit",
                    year: "numeric",
                    hour: "2-digit",
                    minute: "2-digit",
                    second: "2-digit",
                    hour12: true,
                });
                setLastRefreshed(formatted);
            }
            else {
                setLastRefreshed("Unavailable");
            }
        }
        catch (err) {
            console.error("❌ Error fetching pipeline run time:", err);
            setLastRefreshed("Unavailable");
        }
    };
    react__WEBPACK_IMPORTED_MODULE_0__.useEffect(() => {
        fetchLastRunTime();
    }, []);
    react__WEBPACK_IMPORTED_MODULE_0__.useEffect(() => {
        const errorHandler = (e) => {
            if (e.message && (e.message.includes("ResizeObserver") || e.message.includes("ResizeObserver loop"))) {
                e.stopImmediatePropagation();
                e.preventDefault();
                return;
            }
        };
        window.addEventListener("error", errorHandler);
        return () => window.removeEventListener("error", errorHandler);
    }, []);
    react__WEBPACK_IMPORTED_MODULE_0__.useEffect(() => {
        if (isInitialized) {
            console.log("🔄 ReviewFindings detected refreshVersion change, reloading findings...");
            loadFindings();
        }
    }, [refreshVersion]);
    const loadFindings = react__WEBPACK_IMPORTED_MODULE_0__.useCallback(() => {
        setIsLoading(true);
        try {
            const source = sampleData;
            const combinedArray = source
                ? Object.values(source).flat()
                : [];
            setFindings(combinedArray);
        }
        catch (_a) {
            setFindings([]);
        }
        finally {
            setIsLoading(false);
        }
    }, [sampleData]);
    react__WEBPACK_IMPORTED_MODULE_0__.useEffect(() => {
        if (!loading && isInitialized) {
            loadFindings();
            setChangedStates(new Map());
        }
    }, [isInitialized, loading, loadFindings]);
    const hasChangesToSave = () => {
        return findings.some((finding) => {
            return finding.state.some((_, actionIndex) => {
                const key = `${finding.id}-${actionIndex}`;
                const changed = changedStates.get(key);
                if (!changed)
                    return false;
                const { oldState, newState } = changed;
                return (newState !== oldState &&
                    (newState === "approved" || newState === "rejected"));
            });
        });
    };
    const handleSave = async () => {
        try {
            setSaving(true);
            const submittedBy = upn;
            const allEvents = [];
            const allDatabaseUpdates = [];
            findings.forEach((finding) => {
                finding.state.forEach((_, actionIndex) => {
                    const key = `${finding.id}-${actionIndex}`;
                    const changed = changedStates.get(key);
                    if (!changed)
                        return;
                    const { newState } = changed;
                    if (newState === "approved" || newState === "rejected") {
                        allEvents.push({
                            workspaceName: finding.workspaceName,
                            artifactName: finding.artifactName,
                            finding: finding.finding,
                            suggestedAction: finding.suggestedActions[actionIndex],
                            action: newState,
                        });
                        allDatabaseUpdates.push({
                            findingId: finding.id,
                            actionIndex: actionIndex,
                            status: newState,
                            timestamp: new Date().toISOString(),
                        });
                    }
                });
            });
            if (allEvents.length === 0) {
                alert("No approved or rejected actions to save. Please approve or reject at least one action before saving.");
                return;
            }
            console.log("🚀 Starting save process with correct flow:");
            console.log(`📊 Total events to process: ${allEvents.length}`);
            const mcpExecutionResults = await executeApprovedActions(allEvents);
            console.log(mcpExecutionResults);
            const successfulEvents = [];
            const successfulDatabaseUpdates = [];
            const failedActions = [];
            allEvents.forEach((event, index) => {
                const databaseUpdate = allDatabaseUpdates[index];
                if (event.action === "rejected") {
                    successfulEvents.push(event);
                    successfulDatabaseUpdates.push(databaseUpdate);
                    (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_21__.callNotificationOpen)("Success", "Action executed successfully", _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_22__.NotificationType.Success, _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_22__.NotificationToastDuration.Short, props.workloadClient);
                }
                else if (event.action === "approved") {
                    const mcpResult = mcpExecutionResults.find((result) => result.workspaceName === event.workspaceName &&
                        result.artifactName === event.artifactName &&
                        result.actionText === event.suggestedAction);
                    if (mcpResult && mcpResult.success) {
                        successfulEvents.push(event);
                        successfulDatabaseUpdates.push(databaseUpdate);
                        console.log(`✅ MCP success for: ${event.suggestedAction}`);
                    }
                    else {
                        failedActions.push({
                            event,
                            reason: mcpResult
                                ? mcpResult.message || mcpResult.errorDetails || "Unknown error"
                                : "MCP execution failed",
                        });
                        console.log(`❌ MCP failed for: ${event.suggestedAction} - ${(mcpResult === null || mcpResult === void 0 ? void 0 : mcpResult.message) || "Unknown error"}`);
                    }
                }
            });
            console.log(`📈 Results: ${successfulEvents.length} successful, ${failedActions.length} failed`);
            if (failedActions.length > 0) {
                const failedActionsList = failedActions
                    .map((f) => `• ${f.event.suggestedAction}: ${f.reason}`)
                    .join("\n");
                alert(`MCP Actions completed:\n` +
                    `✅ ${successfulEvents.length} actions succeeded\n` +
                    `❌ ${failedActions.length} actions failed\n\n` +
                    `Failed actions:\n${failedActionsList}\n\n` +
                    `Only successful actions will be saved to the database.`);
            }
            else if (successfulEvents.length > 0) {
                console.log(`🎉 All ${successfulEvents.length} actions executed successfully!`);
            }
            if (successfulDatabaseUpdates.length > 0) {
                console.log(`💾 Updating database for ${successfulDatabaseUpdates.length} successful actions`);
                const bulkUpdateResponse = await fetch(`${_env__WEBPACK_IMPORTED_MODULE_28__.workloadBEURL}/api/fabricfindings/actions/status/bulk`, {
                    method: "PATCH",
                    headers: {
                        "Content-Type": "application/json",
                    },
                    body: JSON.stringify({
                        updates: successfulDatabaseUpdates,
                    }),
                });
                if (!bulkUpdateResponse.ok) {
                    const errorData = await bulkUpdateResponse.json();
                    throw new Error(`Failed to bulk update findings: ${errorData.message || bulkUpdateResponse.statusText}`);
                }
                console.log("💾 Database update completed successfully");
                if (successfulEvents.length > 0) {
                    console.log(`📝 Saving event history for ${successfulEvents.length} successful actions`);
                    const eventResponse = await fetch(`${_env__WEBPACK_IMPORTED_MODULE_28__.workloadBEURL}/api/EventHistory`, {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json",
                        },
                        body: JSON.stringify({
                            submittedBy: submittedBy,
                            events: successfulEvents,
                        }),
                    });
                    if (!eventResponse.ok) {
                        const errorData = await eventResponse.json();
                        console.error("Failed to save event history:", errorData);
                        alert("MCP actions executed and database updated successfully, but failed to save event history. Please try again.");
                        return;
                    }
                    console.log("📝 Event history saved successfully");
                    try {
                        await refreshEventHistory(submittedBy);
                        console.log("🔄 Event history refreshed in EventHistory component");
                    }
                    catch (error) {
                        console.error("⚠️ Failed to refresh event history:", error);
                    }
                }
                if (failedActions.length === 0) {
                    alert(`✅ All ${successfulEvents.length} actions completed successfully!`);
                }
                handleRefresh();
            }
            else {
                alert("❌ No actions were successfully executed. Database was not updated.");
            }
        }
        catch (error) {
            console.error("Error during save operation:", error);
            alert(`An error occurred while saving: ${error.message}. Please try again.`);
        }
        finally {
            setSaving(false);
        }
    };
    const executeApprovedActions = async (events) => {
        try {
            console.log("🚀 executeApprovedActions called with events:", events);
            const actionsToExecute = events
                .filter((event) => event.action === "approved" &&
                (event.suggestedAction.includes("Notify Workspace Admins") ||
                    event.suggestedAction.includes("Notify Owner") ||
                    event.suggestedAction.includes("Unassign Capacity") ||
                    event.suggestedAction.includes("Delete Dataset") ||
                    event.suggestedAction.includes("Delete SemanticModel") ||
                    event.suggestedAction.includes("Delete Item") ||
                    event.suggestedAction.includes("Remove Dataset") ||
                    event.suggestedAction.includes("Delete Report") ||
                    event.suggestedAction.includes("Remove Item") ||
                    event.suggestedAction.includes("Delete Workspace") ||
                    event.suggestedAction.includes("Assign to smaller replacement capacity so production environment is not affected")))
                .map((event) => ({
                workspaceName: event.workspaceName,
                actionText: event.suggestedAction,
                artifactName: event.artifactName,
                finding: event.finding,
            }));
            console.log("🎯 Filtered actionsToExecute:", actionsToExecute);
            if (actionsToExecute.length === 0) {
                console.log("⚠️ No approved actions requiring MCP execution");
                return [];
            }
            console.log(`🔥 Executing ${actionsToExecute.length} MCP actions...`);
            let accessToken = null;
            try {
                let tokenResponse = await (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_21__.callAuthAcquireAccessToken)(props.workloadClient);
                if (tokenResponse && tokenResponse.token) {
                    accessToken = tokenResponse.token;
                    console.log("✅ Successfully acquired access token");
                }
                else {
                    console.error("❌ No token returned from callAuthAcquireAccessToken:", tokenResponse);
                }
            }
            catch (error) {
                console.error("💥 Error getting access token from Fabric:", (error === null || error === void 0 ? void 0 : error.message) || error);
            }
            if (!accessToken) {
                console.error("❌ No valid access token available for operations");
            }
            const headers = {
                "Content-Type": "application/json",
            };
            if (accessToken) {
                headers["Authorization"] = `Bearer ${accessToken}`;
            }
            const executeResponse = await fetch(`${_env__WEBPACK_IMPORTED_MODULE_28__.workloadBEURL}/api/FabricFindings/actions/execute`, {
                method: "POST",
                headers: headers,
                body: JSON.stringify({
                    actions: actionsToExecute,
                }),
            });
            if (executeResponse.ok) {
                const executeResult = await executeResponse.json();
                console.log("🎯 MCP execution response:", executeResult);
                if (executeResult.data && executeResult.data.length > 0) {
                    const successCount = executeResult.data.filter((r) => r.success).length;
                    const failureCount = executeResult.data.filter((r) => !r.success).length;
                    console.log(`📊 MCP Execution Summary: ${successCount} succeeded, ${failureCount} failed`);
                    executeResult.data.forEach((result) => {
                        if (result.success) {
                            (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_21__.callNotificationOpen)("Success", "Action executed successfully", _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_22__.NotificationType.Success, _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_22__.NotificationToastDuration.Short, props.workloadClient);
                            console.log(`✅ MCP Success: ${result.actionText} for ${result.workspaceName}`);
                        }
                        else {
                            const errMsg = `❌ MCP Failed: ${result.actionText} for ${result.workspaceName} - ${result.message || result.errorDetails}`;
                            console.error(errMsg);
                            // show toast only for MCP failures
                            (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_21__.callNotificationOpen)("Error", errMsg, _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_22__.NotificationType.Error, _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_22__.NotificationToastDuration.Short, props.workloadClient);
                        }
                    });
                    return executeResult.data;
                }
                else {
                    console.warn("⚠️ No execution results returned from backend");
                    return [];
                }
            }
            else {
                const errorData = await executeResponse.json();
                console.error("❌ MCP execution API call failed:", errorData);
                return actionsToExecute.map((action) => ({
                    workspaceName: action.workspaceName,
                    actionText: action.actionText,
                    artifactName: action.artifactName,
                    finding: action.finding,
                    success: false,
                    message: `API call failed: ${errorData.message || executeResponse.statusText}`,
                    errorDetails: errorData.message || executeResponse.statusText,
                }));
            }
        }
        catch (error) {
            console.error("💥 Error during MCP action execution:", error);
            const actionsToExecute = events
                .filter((event) => event.action === "approved")
                .map((event) => ({
                workspaceName: event.workspaceName,
                actionText: event.suggestedAction,
                artifactName: event.artifactName,
                finding: event.finding,
                success: false,
                message: `Execution error: ${error.message}`,
                errorDetails: error.message,
            }));
            return actionsToExecute;
        }
    };
    const handleRefresh = async () => {
        console.log("🔄 Refresh clicked");
        await fetchLastRunTime();
        try {
            await refetch();
        }
        catch (error) {
            console.error("❌ Error during refresh:", error);
        }
    };
    const handleStateChange = (findingId, actionIndex, newState) => {
        const stateKey = `${findingId}-${actionIndex}`;
        const finding = findings.find((f) => f.id === findingId);
        if (!finding)
            return;
        const oldState = finding.state[actionIndex];
        setFindings((prevFindings) => prevFindings.map((f) => {
            if (f.id === findingId) {
                const newStates = [...f.state];
                newStates[actionIndex] = newState;
                return Object.assign(Object.assign({}, f), { state: newStates });
            }
            return f;
        }));
        setChangedStates((prev) => {
            const newMap = new Map(prev);
            newMap.set(stateKey, { oldState, newState });
            return newMap;
        });
    };
    const handleUndo = (findingId, actionIndex) => {
        const stateKey = `${findingId}-${actionIndex}`;
        const change = changedStates.get(stateKey);
        if (!change)
            return;
        setFindings((prevFindings) => prevFindings.map((f) => {
            if (f.id === findingId) {
                const newStates = [...f.state];
                newStates[actionIndex] = change.oldState;
                return Object.assign(Object.assign({}, f), { state: newStates });
            }
            return f;
        }));
        setChangedStates((prev) => {
            const newMap = new Map(prev);
            newMap.delete(stateKey);
            return newMap;
        });
    };
    // All unique capacities (top-level, unchanged by other filters)
    const uniqueCapacities = react__WEBPACK_IMPORTED_MODULE_0__.useMemo(() => {
        const set = new Set();
        for (const f of findings)
            if (f.capacityName)
                set.add(f.capacityName);
        return Array.from(set).sort();
    }, [findings]);
    const uniqueWorkspaces = react__WEBPACK_IMPORTED_MODULE_0__.useMemo(() => {
        const set = new Set();
        for (const f of findings) {
            if (selectedCapacity && f.capacityName !== selectedCapacity)
                continue;
            if (f.workspaceName)
                set.add(f.workspaceName);
        }
        return Array.from(set).sort();
    }, [findings, selectedCapacity]);
    // Unique artifacts — depends on selectedWorkspace (and optionally selectedCapacity)
    const uniqueArtifacts = react__WEBPACK_IMPORTED_MODULE_0__.useMemo(() => {
        const set = new Set();
        for (const f of findings) {
            if (selectedCapacity && f.capacityName !== selectedCapacity)
                continue; // optional
            if (selectedWorkspace && f.workspaceName !== selectedWorkspace)
                continue;
            if (f.artifactName && f.artifactName !== "-")
                set.add(f.artifactName);
        }
        return Array.from(set).sort();
    }, [findings, selectedWorkspace, selectedCapacity]);
    // Unique findings — depends on selectedWorkspace and selectedArtifact
    const uniqueFindings = react__WEBPACK_IMPORTED_MODULE_0__.useMemo(() => {
        const set = new Set();
        for (const f of findings) {
            if (selectedCapacity && f.capacityName !== selectedCapacity)
                continue; // optional
            if (selectedWorkspace && f.workspaceName !== selectedWorkspace)
                continue;
            if (selectedArtifact && f.artifactName !== selectedArtifact)
                continue;
            if (f.finding)
                set.add(f.finding);
        }
        return Array.from(set).sort();
    }, [findings, selectedWorkspace, selectedArtifact, selectedCapacity]);
    // If selectedWorkspace changes, reset artifact & finding if they are no longer valid
    react__WEBPACK_IMPORTED_MODULE_0__.useEffect(() => {
        if (selectedWorkspace && !uniqueWorkspaces.includes(selectedWorkspace)) {
            setSelectedWorkspace("");
        }
        if (selectedArtifact && !uniqueArtifacts.includes(selectedArtifact)) {
            setSelectedArtifact("");
        }
        if (selectedFinding && !uniqueFindings.includes(selectedFinding)) {
            setSelectedFinding("");
        }
    }, [selectedCapacity, uniqueWorkspaces, uniqueArtifacts, uniqueFindings]);
    // If selectedWorkspace changes, reset artifact & finding if they are no longer valid
    react__WEBPACK_IMPORTED_MODULE_0__.useEffect(() => {
        if (selectedArtifact && !uniqueArtifacts.includes(selectedArtifact)) {
            setSelectedArtifact("");
        }
        if (selectedFinding && !uniqueFindings.includes(selectedFinding)) {
            setSelectedFinding("");
        }
    }, [selectedWorkspace, uniqueArtifacts, uniqueFindings]);
    // If selectedArtifact changes, reset finding if invalid
    react__WEBPACK_IMPORTED_MODULE_0__.useEffect(() => {
        if (selectedFinding && !uniqueFindings.includes(selectedFinding)) {
            setSelectedFinding("");
        }
    }, [selectedArtifact, uniqueFindings]);
    const filteredFindings = react__WEBPACK_IMPORTED_MODULE_0__.useMemo(() => {
        const results = [];
        const byTab = (f) => {
            if (selectedTab === "governance")
                return f.category === "governance";
            if (selectedTab === "performance")
                return f.category === "performance";
            if (selectedTab === "capacity")
                return f.category === "capacity_optimization";
            return true;
        };
        for (const f of findings) {
            if (!byTab(f))
                continue;
            if (selectedCapacity && f.capacityName !== selectedCapacity)
                continue;
            if (selectedWorkspace && f.workspaceName !== selectedWorkspace)
                continue;
            if (selectedArtifact && f.artifactName !== selectedArtifact)
                continue;
            if (selectedFinding && f.finding !== selectedFinding)
                continue;
            results.push(f);
        }
        return results;
    }, [
        findings,
        selectedTab,
        selectedCapacity,
        selectedWorkspace,
        selectedArtifact,
        selectedFinding,
    ]);
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: styles.container },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: styles.headerSection },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: styles.headerTitle },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Text, { className: styles.title }, "Review Findings"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Text, { className: styles.subtitle }, "Review and manage findings from your agents")),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: styles.refreshedLabel },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_19__.Clock16Regular, null),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_13__.Caption1, null,
                    "Last Refreshed Data: ",
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("b", null, lastRefreshed)))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: styles.tabButtons },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { className: `${styles.tabButton} ${selectedTab === "all" ? styles.tabButtonActive : ""}`, onClick: () => setSelectedTab("all") }, "All Findings"),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { className: `${styles.tabButton} ${selectedTab === "governance" ? styles.tabButtonActive : ""}`, onClick: () => setSelectedTab("governance") }, "Governance Agent"),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { className: `${styles.tabButton} ${selectedTab === "performance" ? styles.tabButtonActive : ""}`, onClick: () => setSelectedTab("performance") }, "Performance Agent"),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { className: `${styles.tabButton} ${selectedTab === "capacity" ? styles.tabButtonActive : ""}`, onClick: () => setSelectedTab("capacity") }, "Capacity Optimisation Agent")),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: styles.filtersRow },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(_FilterDropdownComponent__WEBPACK_IMPORTED_MODULE_27__["default"], { label: "Capacity", options: uniqueCapacities, selectedValue: selectedCapacity, onValueChange: setSelectedCapacity }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(_FilterDropdownComponent__WEBPACK_IMPORTED_MODULE_27__["default"], { label: "Workspace", options: uniqueWorkspaces, selectedValue: selectedWorkspace, onValueChange: setSelectedWorkspace }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(_FilterDropdownComponent__WEBPACK_IMPORTED_MODULE_27__["default"], { label: "Artifact", options: uniqueArtifacts, selectedValue: selectedArtifact, onValueChange: setSelectedArtifact }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(_FilterDropdownComponent__WEBPACK_IMPORTED_MODULE_27__["default"], { label: "Finding", options: uniqueFindings, selectedValue: selectedFinding, onValueChange: setSelectedFinding }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_12__.Button, { appearance: "secondary", onClick: () => {
                    setSelectedCapacity("");
                    setSelectedWorkspace("");
                    setSelectedArtifact("");
                    setSelectedFinding("");
                } }, "Clear Filters")),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: styles.actionButtonsRow },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_12__.Button, { appearance: "primary", onClick: handleSave, disabled: saving || !hasChangesToSave(), className: styles.saveButton, icon: saving ? react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_14__.Spinner, { size: "tiny" }) : undefined }, saving ? "Saving..." : "Save Changes"),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_12__.Button, { appearance: "primary", icon: react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_17__.ArrowClockwise16Regular, null), onClick: handleRefresh, disabled: loading }, loading ? "Refreshing..." : "Refresh")),
        loading ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: styles.loadingWrapper },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(_CommonLoader_CommonLoader__WEBPACK_IMPORTED_MODULE_26__["default"], { size: "large", label: "Loading data..." }))) : error ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: styles.errorWrapper },
            "Error loading data: ",
            error)) : (react__WEBPACK_IMPORTED_MODULE_0__.createElement(FindingsTable, { findings: filteredFindings, isLoading: isLoading, pageSize: pageSize, onStateChange: handleStateChange, onUndo: handleUndo, changedStates: changedStates, onPageSizeChange: setPageSize }))));
};


/***/ }),

/***/ "./src/components/SampleWorkloadCreateDialog/SampleWorkloadCreateDialog.tsx":
/*!**********************************************************************************!*\
  !*** ./src/components/SampleWorkloadCreateDialog/SampleWorkloadCreateDialog.tsx ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SaveAsDialog: () => (/* binding */ SaveAsDialog)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router/esm/react-router.js");
/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @fluentui/react */ "./node_modules/@fluentui/react/lib/components/Stack/Stack.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-field/lib/components/Field/Field.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-input/lib/components/Input/Input.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-checkbox/lib/components/Checkbox/Checkbox.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-button/lib/components/Button/Button.js");
/* harmony import */ var _controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../controller/SampleWorkloadController */ "./src/controller/SampleWorkloadController.ts");
/* harmony import */ var _env__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./../../env */ "./src/env.ts");






function SaveAsDialog({ workloadClient, isImmediateSave }) {
    const sampleWorkloadName = _env__WEBPACK_IMPORTED_MODULE_8__.workloadName;
    // The type of the item in fabric is {workloadName}/{itemName}
    const sampleItemType = sampleWorkloadName + ".SampleWorkloadItem";
    const sampleItemDisplayName = "Sample Workload Item";
    const sampleItemEditorPath = "/sample-workload-editor";
    const EMPTY_GUID = '00000000-0000-0000-0000-000000000000';
    const [displayName, setDisplayName] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
    const [description, setDescription] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
    const [isSaveDisabled, setIsSaveDisabled] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [isSaveInProgress, setIsSaveInProgress] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [validationMessage, setValidationMessage] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [promptFullConsent, setPromptFullConsent] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const pageContext = (0,react_router_dom__WEBPACK_IMPORTED_MODULE_1__.useParams)();
    async function onSaveClicked() {
        let createResult;
        if (isImmediateSave) {
            try {
                setIsSaveInProgress(true);
                setIsSaveDisabled(true);
                // raise consent dialog for the user
                await (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_7__.callAuthAcquireAccessToken)(workloadClient, null /*additionalScopesToConsent*/, null /*claimsForConditionalAccessPolicy*/, promptFullConsent);
                createResult = await handleCreateSampleItem(pageContext.workspaceObjectId, displayName, description);
            }
            finally {
                setIsSaveInProgress(false);
                setIsSaveDisabled(false);
            }
        }
        if (createResult || !isImmediateSave) {
            (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_7__.callDialogClose)(workloadClient);
        }
    }
    async function onCancelClicked() {
        (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_7__.callDialogClose)(workloadClient);
    }
    function onDisplayNameChanged(newValue) {
        setDisplayName(newValue);
        setIsSaveDisabled(newValue.trim() == "" || isSaveInProgress);
    }
    function onDescriptionChanged(newValue) {
        setDescription(newValue);
    }
    const handleCreateSampleItem = async (workspaceObjectId, displayName, description) => {
        var _a, _b, _c, _d, _e, _f;
        try {
            const createItemPayload = {
                item1Metadata: {
                    lakehouse: { id: EMPTY_GUID, workspaceId: EMPTY_GUID },
                    useOneLake: false
                }
            };
            const createdItem = await (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_7__.callItemCreate)(workspaceObjectId, sampleItemType, displayName, description, createItemPayload, workloadClient);
            // open editor for the new item
            await (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_7__.callPageOpen)(sampleWorkloadName, `${sampleItemEditorPath}/${createdItem.id}`, workloadClient);
        }
        catch (createError) {
            // name is already in use
            if (((_b = (_a = createError.error) === null || _a === void 0 ? void 0 : _a.message) === null || _b === void 0 ? void 0 : _b.code) === "PowerBIMetadataArtifactDisplayNameInUseException") {
                setValidationMessage(`${sampleItemDisplayName} name is already in use.`);
            }
            // capacity does not support this item type 
            else if (((_d = (_c = createError.error) === null || _c === void 0 ? void 0 : _c.message) === null || _d === void 0 ? void 0 : _d.code) === "UnknownArtifactType") {
                setValidationMessage(`Workspace capacity does not allow ${sampleItemDisplayName} creation`);
            }
            else if (((_f = (_e = createError.error) === null || _e === void 0 ? void 0 : _e.message) === null || _f === void 0 ? void 0 : _f.code) === "PowerBICapacityValidationFailed") {
                setValidationMessage(`Your workspace is assigned to invalid capacity.\n` +
                    `Please verify that the workspace has a valid and active capacity assigned, and try again.`);
            }
            else {
                setValidationMessage(`There was an error while trying to create a new ${sampleItemDisplayName}`);
            }
            console.error(createError);
            return false;
        }
        return true;
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_2__.Stack, { className: "create-dialog", "data-testid": "create-item-dialog" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_2__.Stack, { className: "section" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h2", null,
                "Create ",
                sampleItemDisplayName),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Field, { label: "Name:", validationMessage: validationMessage },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.Input, { "data-testid": "create-dialog-name-input", onChange: e => onDisplayNameChanged(e.target.value), defaultValue: displayName, disabled: isSaveInProgress })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Field, { label: "Sample description:" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.Input, { onChange: e => onDescriptionChanged(e.target.value), defaultValue: description, disabled: isSaveInProgress })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.Checkbox, { label: "Request Initial Consent (Mark this if this is the first time you're working with this workload)", onChange: (v) => setPromptFullConsent(v.target.checked) }),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_2__.Stack, { className: "create-buttons", horizontal: true, tokens: { childrenGap: 10 } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__.Button, { appearance: "primary", onClick: () => onSaveClicked(), "data-testid": "create-3p-item-button", disabled: isSaveDisabled }, "Create"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__.Button, { appearance: "secondary", onClick: () => onCancelClicked() }, "Cancel")))));
}


/***/ }),

/***/ "./src/components/SampleWorkloadEventhouseExplorer/SampleWorkloadEventhouseExplorer.tsx":
/*!**********************************************************************************************!*\
  !*** ./src/components/SampleWorkloadEventhouseExplorer/SampleWorkloadEventhouseExplorer.tsx ***!
  \**********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   EventhouseExplorerComponent: () => (/* binding */ EventhouseExplorerComponent)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react */ "./node_modules/@fluentui/react/lib/components/Stack/Stack.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-divider/lib/components/Divider/Divider.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-field/lib/components/Field/Field.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-input/lib/components/Input/Input.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-button/lib/components/Button/Button.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-combobox/lib/components/Combobox/Combobox.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-combobox/lib/components/Option/Option.js");
/* harmony import */ var _fluentui_react_icons__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @fluentui/react-icons */ "./node_modules/@fluentui/react-icons/lib/sizedIcons/chunk-4.js");
/* harmony import */ var _fluentui_react_icons__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @fluentui/react-icons */ "./node_modules/@fluentui/react-icons/lib/sizedIcons/chunk-14.js");
/* harmony import */ var _controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../controller/SampleWorkloadController */ "./src/controller/SampleWorkloadController.ts");
/* harmony import */ var _env__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./../../env */ "./src/env.ts");






function EventhouseExplorerComponent({ workloadClient }) {
    var _a;
    const sampleWorkloadBEUrl = _env__WEBPACK_IMPORTED_MODULE_11__.workloadBEURL;
    const [selectedEventhouse, setSelectedEventhouse] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(undefined);
    const [selectedEventhouseItemMetadata, setSelectedEventhouseItemMetadata] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(undefined);
    const [isDirtyEventhouse, setDirtyEventhouse] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [selectedDatabaseForQuery, setSelectedDatabaseForQuery] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(undefined);
    const [selectedQueryToExecute, setSelectedQueryToExecute] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(undefined);
    const [queryClientRequestId, setQueryClientRequestId] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(undefined);
    const [queryResult, setQueryResult] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (selectedEventhouse) {
            loadKqlDatabasesWhenEventhouseSelected();
        }
    }, [selectedEventhouse]);
    async function onLoadDatahubForEventhouse() {
        const result = await (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_10__.callDatahubOpen)(["KustoEventHouse"], "Select an Eventhouse to use for Sample Workload", false, workloadClient);
        if (result) {
            setSelectedEventhouse(result);
        }
    }
    async function loadKqlDatabasesWhenEventhouseSelected() {
        console.log(`loadKqlDatabasesWhenEventhouseSelected: ${selectedEventhouse}`);
        if (selectedEventhouse) {
            const result = await (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_10__.callGetEventhouseItem)(sampleWorkloadBEUrl, selectedEventhouse.workspaceId, selectedEventhouse.id, workloadClient);
            if (result) {
                setSelectedEventhouseItemMetadata(result);
                setSelectedDatabaseForQuery(result.properties.databasesItemIds[0]);
                setDirtyEventhouse(true);
            }
        }
    }
    function isDisabledExecuteQueryButton() {
        if (queryClientRequestId !== undefined) {
            return true;
        }
        if (isDirtyEventhouse === false) {
            return true;
        }
        if (selectedDatabaseForQuery === undefined) {
            return true;
        }
        if (!selectedQueryToExecute) {
            return true;
        }
        return false;
    }
    function isDisabledCancelButton() {
        return queryClientRequestId === undefined;
    }
    async function onExecuteQueryButtonClick() {
        if (selectedEventhouse) {
            const result = await (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_10__.CallExecuteQuery)(sampleWorkloadBEUrl, selectedEventhouseItemMetadata === null || selectedEventhouseItemMetadata === void 0 ? void 0 : selectedEventhouseItemMetadata.properties.queryServiceUri, selectedDatabaseForQuery, selectedQueryToExecute, setQueryClientRequestId, workloadClient);
            if (result) {
                setQueryResult(JSON.stringify(result));
            }
        }
    }
    async function onCancelQueryButtonClick() {
        if (queryClientRequestId) {
            console.log(`Cancelling query with requestId: ${queryClientRequestId}`);
            const query = `.cancel query '${queryClientRequestId}'`;
            const result = await (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_10__.CallExecuteQuery)(sampleWorkloadBEUrl, selectedEventhouseItemMetadata === null || selectedEventhouseItemMetadata === void 0 ? void 0 : selectedEventhouseItemMetadata.properties.queryServiceUri, selectedDatabaseForQuery, query, setQueryClientRequestId, workloadClient);
            if (result) {
                setQueryResult(JSON.stringify(result));
                console.log(`Query cancelled with result: ${result}`);
            }
        }
    }
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Divider, { alignContent: "start" }, "Selected Eventhouse Details"),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "section" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.Stack, { horizontal: true },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Field, { label: "Eventhouse", orientation: "horizontal", className: "field" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.Input, { size: "small", placeholder: "Eventhouse Name", style: { marginLeft: "10px" }, value: selectedEventhouse ? selectedEventhouse.displayName : "" })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.Button, { style: { width: "24px", height: "24px" }, icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_8__.Database16Regular, null), appearance: "primary", onClick: onLoadDatahubForEventhouse })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Field, { label: "Eventhouse ID", orientation: "horizontal", className: "field" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.Input, { size: "small", placeholder: "Eventhouse ID", value: selectedEventhouse ? selectedEventhouse.id : "" }))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Divider, { alignContent: "start" }, "Query"),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "section" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { marginTop: '10px' } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Field, { label: "Database", orientation: "horizontal", className: "field" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__.Combobox, { placeholder: "", value: selectedDatabaseForQuery !== null && selectedDatabaseForQuery !== void 0 ? selectedDatabaseForQuery : '', onOptionSelect: (_, opt) => setSelectedDatabaseForQuery(opt.optionValue), size: "small" }, (((_a = selectedEventhouseItemMetadata === null || selectedEventhouseItemMetadata === void 0 ? void 0 : selectedEventhouseItemMetadata.properties) === null || _a === void 0 ? void 0 : _a.databasesItemIds) || []).map((item, index) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_7__.Option, { key: index, value: item }, item)))))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Field, { label: "Query Uri", orientation: "horizontal", className: "field" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.Input, { size: "small", placeholder: "Query Uri", value: (selectedEventhouseItemMetadata === null || selectedEventhouseItemMetadata === void 0 ? void 0 : selectedEventhouseItemMetadata.properties) ? selectedEventhouseItemMetadata === null || selectedEventhouseItemMetadata === void 0 ? void 0 : selectedEventhouseItemMetadata.properties.queryServiceUri : "", style: { width: '400px' }, disabled: true })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Field, { label: "Query", orientation: "horizontal", className: "field" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("textarea", { placeholder: "Enter your query here", style: { minWidth: '400px', minHeight: '100px', textAlign: 'left' }, onChange: (e) => setSelectedQueryToExecute(e.target.value) }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { display: 'flex', gap: '10px', marginTop: '10px' } },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.Button, { appearance: "primary", style: { marginTop: "10px" }, icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_9__.TriangleRight20Regular, null), disabled: isDisabledExecuteQueryButton(), onClick: onExecuteQueryButtonClick }, "Execute Query"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.Button, { appearance: "primary", style: { marginTop: "10px" }, icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_9__.TriangleRight20Regular, null), disabled: isDisabledCancelButton(), onClick: onCancelQueryButtonClick }, "Cancel Query"))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Field, { label: "Result", orientation: "horizontal", className: "field" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("textarea", { value: queryResult, style: { minWidth: '400px', minHeight: '100px', textAlign: 'left' }, readOnly: true })))));
}


/***/ }),

/***/ "./src/components/SampleWorkloadLakehouseExplorer/FileTree.tsx":
/*!*********************************************************************!*\
  !*** ./src/components/SampleWorkloadLakehouseExplorer/FileTree.tsx ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FileTree: () => (/* binding */ FileTree)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _fluentui_react_icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react-icons */ "./node_modules/@fluentui/react-icons/lib/icons/chunk-2.js");
/* harmony import */ var _fluentui_react_icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @fluentui/react-icons */ "./node_modules/@fluentui/react-icons/lib/sizedIcons/chunk-4.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-tree/lib/components/TreeItem/TreeItem.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-tooltip/lib/components/Tooltip/Tooltip.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-tree/lib/components/TreeItemLayout/TreeItemLayout.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-tree/lib/components/Tree/Tree.js");



function FileTree(props) {
    const { allFilesInLakehouse, onSelectFileCallback } = props;
    const buildFileTree = (files) => {
        const root = [];
        const folders = new Map();
        // Helper function to add a node (file or folder) to the tree
        const addNode = (metadata) => {
            const node = {
                metadata: metadata,
                children: []
            };
            // If it's a directory, store it in our folders map for later reference
            if (metadata.isDirectory) {
                folders.set(metadata.path, node);
            }
            // Add to parent folder or root
            const segments = metadata.path.split('/').filter(s => s);
            if (segments.length > 1) {
                const parentPath = segments.slice(0, -1).join('/');
                const parent = folders.get(parentPath);
                if (parent) {
                    parent.children.push(node);
                }
                else {
                    root.push(node);
                }
            }
            else {
                root.push(node);
            }
            return node;
        };
        // First pass: create folder nodes
        files.filter(f => f.isDirectory).forEach(folder => {
            addNode(folder);
        });
        // Second pass: add files to their folders
        files.filter(f => !f.isDirectory).forEach(file => {
            addNode(file);
        });
        // Sort tree alphabetically and by type (folders first)
        const sortNodes = (nodes) => {
            nodes.sort((a, b) => {
                if (a.metadata.isDirectory !== b.metadata.isDirectory) {
                    return a.metadata.isDirectory ? -1 : 1;
                }
                return a.metadata.name.localeCompare(b.metadata.name);
            });
            nodes.forEach(node => {
                if (node.children.length > 0) {
                    sortNodes(node.children);
                }
            });
        };
        sortNodes(root);
        return root;
    };
    const renderTreeNode = (node) => {
        const { metadata, children } = node;
        if (metadata.isDirectory) {
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.TreeItem, { key: metadata.path, itemType: "branch" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.Tooltip, { relationship: "label", content: metadata.name },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.TreeItemLayout, { iconBefore: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_1__.FolderRegular, null) }, metadata.name)),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__.Tree, null, children.map(child => renderTreeNode(child)))));
        }
        else {
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.TreeItem, { key: metadata.path, itemType: "leaf", onClick: () => onSelectFileCallback(metadata) },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.Tooltip, { relationship: "label", content: metadata.name },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.TreeItemLayout, { className: metadata.isSelected ? "selected" : "", iconBefore: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_2__.Document20Regular, null) }, metadata.name))));
        }
    };
    const fileTree = buildFileTree(allFilesInLakehouse || []);
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, fileTree.map(node => renderTreeNode(node))));
}


/***/ }),

/***/ "./src/components/SampleWorkloadLakehouseExplorer/SampleWorkloadLakehouseExplorer.tsx":
/*!********************************************************************************************!*\
  !*** ./src/components/SampleWorkloadLakehouseExplorer/SampleWorkloadLakehouseExplorer.tsx ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LakehouseExplorerComponent: () => (/* binding */ LakehouseExplorerComponent)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react */ "./node_modules/@fluentui/react/lib/components/Stack/Stack.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-button/lib/components/Button/Button.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-image/lib/components/Image/Image.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-tooltip/lib/components/Tooltip/Tooltip.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-spinner/lib/components/Spinner/Spinner.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-tree/lib/components/Tree/Tree.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-tree/lib/components/TreeItem/TreeItem.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-tree/lib/components/TreeItemLayout/TreeItemLayout.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-text/lib/components/presets/Subtitle2/Subtitle2.js");
/* harmony import */ var _fluentui_react_icons__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @fluentui/react-icons */ "./node_modules/@fluentui/react-icons/lib/sizedIcons/chunk-1.js");
/* harmony import */ var _fluentui_react_icons__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @fluentui/react-icons */ "./node_modules/@fluentui/react-icons/lib/sizedIcons/chunk-3.js");
/* harmony import */ var _controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../controller/SampleWorkloadController */ "./src/controller/SampleWorkloadController.ts");
/* harmony import */ var _styles_scss__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./../../styles.scss */ "./src/styles.scss");
/* harmony import */ var _controller_LakehouseExplorerController__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../controller/LakehouseExplorerController */ "./src/controller/LakehouseExplorerController.ts");
/* harmony import */ var _TableTreeWithSchema__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./TableTreeWithSchema */ "./src/components/SampleWorkloadLakehouseExplorer/TableTreeWithSchema.tsx");
/* harmony import */ var _TableTreeWithoutSchema__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./TableTreeWithoutSchema */ "./src/components/SampleWorkloadLakehouseExplorer/TableTreeWithoutSchema.tsx");
/* harmony import */ var _FileTree__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./FileTree */ "./src/components/SampleWorkloadLakehouseExplorer/FileTree.tsx");
/* harmony import */ var _env__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./../../env */ "./src/env.ts");











function LakehouseExplorerComponent({ workloadClient }) {
    const sampleWorkloadBEUrl = _env__WEBPACK_IMPORTED_MODULE_18__.workloadBEURL;
    const [selectedLakehouse, setSelectedLakehouse] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [tablesInLakehouse, setTablesInLakehouse] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [tableSelected, setTableSelected] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [filesInLakehouse, setFilesInLakehouse] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [fileSelected, setFileSelected] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [loadingStatus, setLoadingStatus] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("idle");
    const [isExplorerVisible, setIsExplorerVisible] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [hasSchema, setHasSchema] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        const fetchData = async () => {
            if (selectedLakehouse) {
                setLoadingStatus("loading");
                let success = false;
                try {
                    success = await setTablesAndFiles(null);
                }
                catch (exception) {
                    success = await setTablesAndFiles(".default");
                }
                setLoadingStatus(success ? "idle" : "error");
            }
        };
        fetchData();
    }, [selectedLakehouse]);
    async function setTablesAndFiles(additionalScopesToConsent) {
        var _a;
        let accessToken = await (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_12__.callAuthAcquireAccessToken)(workloadClient, additionalScopesToConsent);
        const tablePath = (0,_controller_LakehouseExplorerController__WEBPACK_IMPORTED_MODULE_14__.getTablesInLakehousePath)(sampleWorkloadBEUrl, selectedLakehouse.workspaceId, selectedLakehouse.id);
        const filePath = (0,_controller_LakehouseExplorerController__WEBPACK_IMPORTED_MODULE_14__.getFilesInLakehousePath)(sampleWorkloadBEUrl, selectedLakehouse.workspaceId, selectedLakehouse.id);
        let tables = await (0,_controller_LakehouseExplorerController__WEBPACK_IMPORTED_MODULE_14__.getTablesInLakehouse)(tablePath, accessToken.token);
        let files = await (0,_controller_LakehouseExplorerController__WEBPACK_IMPORTED_MODULE_14__.getFilesInLakehouse)(filePath, accessToken.token);
        // Valid response from backend
        if (tables && files) {
            setTablesInLakehouse(tables);
            setFilesInLakehouse(files);
            setHasSchema(((_a = tables[0]) === null || _a === void 0 ? void 0 : _a.schema) != null);
            return true;
        }
        return false;
    }
    async function onDatahubClicked() {
        const result = await (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_12__.callDatahubOpen)(["Lakehouse"], "Select a Lakehouse to use for Sample Workload", false, workloadClient);
        if (!result) {
            return;
        }
        setSelectedLakehouse(result);
        setTableSelected(null);
        setFileSelected(null);
    }
    function toggleExplorer() {
        setIsExplorerVisible(!isExplorerVisible);
    }
    function tableSelectedCallback(tableSelected) {
        setTableSelected(tableSelected);
        // setTablesInLakehouse to rerender the tree
        const updatedTables = tablesInLakehouse.map((table) => {
            return Object.assign(Object.assign({}, table), { isSelected: table.path === tableSelected.path });
        });
        setTablesInLakehouse(updatedTables);
    }
    function fileSelectedCallback(fileSelected) {
        setFileSelected(fileSelected);
        // setFilesInLakehouse to rerender the tree
        const updatedFiles = filesInLakehouse.map((file) => {
            return Object.assign(Object.assign({}, file), { isSelected: file.path === fileSelected.path });
        });
        setFilesInLakehouse(updatedFiles);
    }
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.Stack, { className: `explorer ${isExplorerVisible ? "" : "hidden-explorer"}` },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: `top ${isExplorerVisible ? "" : "vertical-text"}` },
                !isExplorerVisible && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Button, { onClick: toggleExplorer, appearance: "subtle", icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_11__.ChevronDoubleRight20Regular, null) })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h1", null, "Lakehouse explorer"),
                isExplorerVisible && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Button, { onClick: toggleExplorer, appearance: "subtle", icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_11__.ChevronDoubleLeft20Regular, null) }))),
            selectedLakehouse == null && isExplorerVisible && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.Stack, { className: "main-body", verticalAlign: "center", horizontalAlign: "center", tokens: { childrenGap: 5 } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Image, { src: "../../../internalAssets/Page.svg" }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "add" }, "Add a Lakehouse"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.Tooltip, { content: "Open Datahub Explorer", relationship: "label" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Button, { className: "add-button", size: "small", onClick: () => onDatahubClicked(), appearance: "primary" }, "Add")))),
            loadingStatus === "loading" && react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.Spinner, { className: "main-body", label: "Loading Data" }),
            selectedLakehouse && loadingStatus == "idle" && isExplorerVisible && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__.Tree, { "aria-label": "Tables in Lakehouse", className: "selector-body", size: "medium", defaultOpenItems: ["Lakehouse", "Tables", "Files", "Schemas"] },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "tree-container" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_7__.TreeItem, { className: "selector-tree-item", itemType: "branch", value: "Lakehouse" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.Tooltip, { relationship: "label", content: selectedLakehouse.displayName },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_8__.TreeItemLayout, { aside: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Button, { appearance: "subtle", icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_10__.ArrowSwap20Regular, null), onClick: onDatahubClicked }) }, selectedLakehouse.displayName)),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__.Tree, { className: "tree", selectionMode: "single" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_7__.TreeItem, { itemType: "branch", value: "Tables" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_8__.TreeItemLayout, null, "Tables"),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__.Tree, { className: "tree", selectionMode: "single" },
                                    hasSchema &&
                                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_TableTreeWithSchema__WEBPACK_IMPORTED_MODULE_15__.TableTreeWithSchema, { allTablesInLakehouse: tablesInLakehouse, onSelectTableCallback: tableSelectedCallback }),
                                    !hasSchema &&
                                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_TableTreeWithoutSchema__WEBPACK_IMPORTED_MODULE_16__.TableTreeWithoutSchema, { allTablesInLakehouse: tablesInLakehouse, onSelectTableCallback: tableSelectedCallback }))),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_7__.TreeItem, { itemType: "branch", value: "Files" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_8__.TreeItemLayout, null, "Files"),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__.Tree, { className: "tree", selectionMode: "single" },
                                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_FileTree__WEBPACK_IMPORTED_MODULE_17__.FileTree, { allFilesInLakehouse: filesInLakehouse, onSelectFileCallback: fileSelectedCallback })))))))),
            loadingStatus === "error" && isExplorerVisible && react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "main-body" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_9__.Subtitle2, null, "Error loading data"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null, "Do you have permission to view this lakehouse?"))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_9__.Subtitle2, null,
            "Table Selected: ", tableSelected === null || tableSelected === void 0 ? void 0 :
            tableSelected.name),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_9__.Subtitle2, null,
            "File Selected: ", fileSelected === null || fileSelected === void 0 ? void 0 :
            fileSelected.name)));
}


/***/ }),

/***/ "./src/components/SampleWorkloadLakehouseExplorer/TableTreeWithSchema.tsx":
/*!********************************************************************************!*\
  !*** ./src/components/SampleWorkloadLakehouseExplorer/TableTreeWithSchema.tsx ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TableTreeWithSchema: () => (/* binding */ TableTreeWithSchema)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _fluentui_react_icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react-icons */ "./node_modules/@fluentui/react-icons/lib/icons/chunk-0.js");
/* harmony import */ var _fluentui_react_icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @fluentui/react-icons */ "./node_modules/@fluentui/react-icons/lib/sizedIcons/chunk-12.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-tree/lib/components/TreeItem/TreeItem.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-tooltip/lib/components/Tooltip/Tooltip.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-tree/lib/components/TreeItemLayout/TreeItemLayout.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-tree/lib/components/Tree/Tree.js");



function TableTreeWithSchema(props) {
    const { allTablesInLakehouse, onSelectTableCallback } = props;
    // group the tables by schema
    const tablesInLakehouseGroupedBySchema = allTablesInLakehouse.reduce((acc, table) => {
        if (!acc[table.schema]) {
            acc[table.schema] = [];
        }
        acc[table.schema].push(table);
        return acc;
    }, {});
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, tablesInLakehouseGroupedBySchema &&
        Object.keys(tablesInLakehouseGroupedBySchema).map((schema) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.TreeItem, { id: schema, key: schema, itemType: "branch" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.Tooltip, { relationship: "label", content: schema },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.TreeItemLayout, { id: schema, iconBefore: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_1__.ArrowCircleDownSplitRegular, null) }, schema)),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__.Tree, { selectionMode: "single", size: 'medium' }, tablesInLakehouseGroupedBySchema[schema].map((table) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.TreeItem, { key: table.name, accessKey: table.path, itemType: "leaf", onClick: () => onSelectTableCallback(table) },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.Tooltip, { relationship: 'label', content: table.name },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.TreeItemLayout, { className: (table.isSelected ? "selected" : ""), iconBefore: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_2__.Table20Regular, null) }, table.name)))))))))));
}


/***/ }),

/***/ "./src/components/SampleWorkloadLakehouseExplorer/TableTreeWithoutSchema.tsx":
/*!***********************************************************************************!*\
  !*** ./src/components/SampleWorkloadLakehouseExplorer/TableTreeWithoutSchema.tsx ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TableTreeWithoutSchema: () => (/* binding */ TableTreeWithoutSchema)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _fluentui_react_icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react-icons */ "./node_modules/@fluentui/react-icons/lib/sizedIcons/chunk-12.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-tree/lib/components/TreeItem/TreeItem.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-tooltip/lib/components/Tooltip/Tooltip.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-tree/lib/components/TreeItemLayout/TreeItemLayout.js");



function TableTreeWithoutSchema(props) {
    const { allTablesInLakehouse, onSelectTableCallback } = props;
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, allTablesInLakehouse &&
        allTablesInLakehouse.map((table) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.TreeItem, { key: table.name, accessKey: table.path, itemType: "leaf", onClick: () => onSelectTableCallback(table) },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Tooltip, { relationship: "label", content: table.name },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.TreeItemLayout, { className: (table.isSelected ? "selected" : ""), iconBefore: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_1__.Table20Regular, null) }, table.name)))))));
}


/***/ }),

/***/ "./src/components/SampleWorkloadPanel/SampleWorkloadPanel.tsx":
/*!********************************************************************!*\
  !*** ./src/components/SampleWorkloadPanel/SampleWorkloadPanel.tsx ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Panel: () => (/* binding */ Panel),
/* harmony export */   callPanelClose: () => (/* binding */ callPanelClose)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _fluentui_react_icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react-icons */ "./node_modules/@fluentui/react-icons/lib/sizedIcons/chunk-7.js");
/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @fluentui/react */ "./node_modules/@fluentui/react/lib/components/Stack/Stack.js");
/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @fluentui/react */ "./node_modules/@fluentui/react/lib/components/Label/Label.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-button/lib/components/Button/Button.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-radio/lib/components/RadioGroup/RadioGroup.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-radio/lib/components/Radio/Radio.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-utilities/lib/hooks/useId.js");
/* harmony import */ var _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ms-fabric/workload-client */ "./node_modules/@ms-fabric/workload-client/src/workload-client.js");
/* harmony import */ var _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _styles_scss__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./../../styles.scss */ "./src/styles.scss");






async function callPanelClose(workloadClient) {
    await workloadClient.panel.close({ mode: _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_8__.CloseMode.PopOne });
}
// Panel 
function Panel(props) {
    const radioName = (0,_fluentui_react_components__WEBPACK_IMPORTED_MODULE_7__.useId)("radio");
    const labelId = (0,_fluentui_react_components__WEBPACK_IMPORTED_MODULE_7__.useId)("label");
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_2__.Stack, { className: 'panel' },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: 'section' },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.Button, { icon: react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_1__.Lightbulb24Regular, null), appearance: "primary" }, "Button 1")),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: 'section' },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.Button, { icon: react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_1__.Lightbulb24Regular, null), appearance: "primary" }, "Button 2")),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: 'section' },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.Button, { icon: react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_1__.Lightbulb24Regular, null), appearance: "primary" }, "Button 3")),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_3__.Label, { id: labelId }, "Radio group"),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_5__.RadioGroup, { "aria-labelledby": labelId, defaultValue: "option1" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__.Radio, { name: radioName, value: "option1", label: "Option 1" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__.Radio, { name: radioName, value: "option2", label: "Option 2" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_6__.Radio, { name: radioName, value: "option3", label: "Option 3" })),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: 'section' },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.Button, { onClick: () => callPanelClose(props.workloadClient) }, "Close Panel"))));
}
;


/***/ }),

/***/ "./src/components/SampleWorkloadSharedState/SharedStatePage.tsx":
/*!**********************************************************************!*\
  !*** ./src/components/SampleWorkloadSharedState/SharedStatePage.tsx ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SharedStatePage: () => (/* binding */ SharedStatePage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-field/lib/components/Field/Field.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-input/lib/components/Input/Input.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-button/lib/components/Button/Button.js");
/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @fluentui/react */ "./node_modules/@fluentui/react/lib/components/Stack/Stack.js");
/* harmony import */ var _controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../controller/SampleWorkloadController */ "./src/controller/SampleWorkloadController.ts");




function SharedStatePage(props) {
    const { workloadClient } = props;
    // declaring the workload's shared state
    const sharedState = workloadClient.state.sharedState;
    const [localSharedStateMessage, setLocalSharedStateMessage] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(sharedState.message);
    async function onSaveClicked(workloadClient) {
        sharedState.message = localSharedStateMessage;
        (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_5__.callDialogClose)(workloadClient);
    }
    async function onCancelClicked() {
        (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_5__.callDialogClose)(workloadClient);
    }
    // HTML page contents
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_4__.Stack, { className: "shared-state-dialog" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_4__.Stack, { className: "section" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h2", null, "Shared state usage example:"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Field, { label: "New Shared State Message:" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Input, { size: "small", placeholder: "Message", value: localSharedStateMessage, onChange: (e) => setLocalSharedStateMessage(e.target.value), "data-testid": "iframe-shared-state-input" })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_4__.Stack, { className: "shared-state-iframe-buttons", horizontal: true, tokens: { childrenGap: 10 } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Button, { appearance: "primary", onClick: () => onSaveClicked(workloadClient), "data-testid": "save-iframe-shared-state" }, "Save"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.Button, { appearance: "secondary", onClick: () => onCancelClicked() }, "Cancel")))));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SharedStatePage);


/***/ }),

/***/ "./src/components/SettingsPanel/SettingsPanel.tsx":
/*!********************************************************!*\
  !*** ./src/components/SettingsPanel/SettingsPanel.tsx ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SettingsPanel: () => (/* binding */ SettingsPanel),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@griffel/core/index.esm.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-button/lib/components/Button/Button.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@griffel/react/makeStyles.esm.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/tokens/lib/tokens.js");
/* harmony import */ var _fluentui_react_icons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @fluentui/react-icons */ "./node_modules/@fluentui/react-icons/lib/sizedIcons/chunk-4.js");
/* harmony import */ var _CustomItemSettings_CustomWorkspaceSettings__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./../CustomItemSettings/CustomWorkspaceSettings */ "./src/components/CustomItemSettings/CustomWorkspaceSettings.tsx");
/* harmony import */ var _CustomItemSettings_CustomSemanticModelSettings__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./../CustomItemSettings/CustomSemanticModelSettings */ "./src/components/CustomItemSettings/CustomSemanticModelSettings.tsx");
/* harmony import */ var _CustomItemSettings_CustomReportSettings__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./../CustomItemSettings/CustomReportSettings */ "./src/components/CustomItemSettings/CustomReportSettings.tsx");






const useStyles = (0,_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.makeStyles)({
    overlay: {
        position: 'fixed',
        left: 0,
        right: 0,
        backgroundColor: 'rgba(0,0,0,0.35)',
        zIndex: 900,
    },
    panel: {
        position: 'fixed',
        right: 0,
        background: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.tokens.colorNeutralBackground1,
        boxShadow: '0 2px 12px rgba(0,0,0,0.2)',
        transform: 'translateX(100%)',
        transition: 'transform 280ms ease-in-out',
        zIndex: 1000,
        display: 'flex',
        flexDirection: 'column',
        borderLeft: `1px solid ${_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.tokens.colorNeutralStroke2}`,
    },
    panelOpen: {
        transform: 'translateX(0%)',
    },
    header: Object.assign(Object.assign({ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }, _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.shorthands.padding('16px', '20px')), { borderBottom: `1px solid ${_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.tokens.colorNeutralStroke2}` }),
    title: {
        fontSize: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.tokens.fontSizeBase500,
        fontWeight: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.tokens.fontWeightSemibold,
    },
    subtitle: {
        fontSize: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.tokens.fontSizeBase200,
        color: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.tokens.colorNeutralForeground3,
        marginTop: '10px',
    },
    body: {
        display: 'flex',
        flex: 1,
        overflow: 'hidden',
    },
    sidebar: {
        width: '180px',
        borderRight: `1px solid ${_fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.tokens.colorNeutralStroke2}`,
        padding: '16px',
        overflowY: 'auto',
    },
    navItem: {
        padding: '10px 12px',
        borderRadius: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.tokens.borderRadiusMedium,
        marginBottom: '8px',
        cursor: 'pointer',
        selectors: {
            '&:hover': { background: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.tokens.colorSubtleBackgroundHover },
        },
    },
    navItemSelected: {
        background: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_4__.tokens.colorSubtleBackground,
        paddingLeft: '12px',
        borderLeft: `4px solid #0b6a44`,
    },
});
const SettingsPanel = ({ open, onClose, topOffset = 96 }) => {
    const styles = useStyles();
    const [selected, setSelected] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('workspace');
    const panelWidth = 640;
    const topPx = `${topOffset}px`;
    const panelHeight = `calc(100vh - ${topPx})`;
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
        open && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.overlay, style: { top: topPx, height: panelHeight }, onClick: onClose, "aria-hidden": true })),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: open ? `${styles.panel} ${styles.panelOpen}` : styles.panel, style: { top: topPx, height: panelHeight, width: panelWidth }, "aria-hidden": !open },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.header },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.title }, "Settings"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.subtitle }, "Configure automation and notification preferences for workspace management.")),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_2__.Button, { appearance: "subtle", onClick: onClose, icon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_fluentui_react_icons__WEBPACK_IMPORTED_MODULE_5__.Dismiss24Regular, null) })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.body },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: styles.sidebar },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: selected === 'workspace' ? `${styles.navItem} ${styles.navItemSelected}` : styles.navItem, onClick: () => setSelected('workspace') }, "Workspace Settings"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: selected === 'semantic' ? `${styles.navItem} ${styles.navItemSelected}` : styles.navItem, onClick: () => setSelected('semantic') }, "Semantic Model Settings"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: selected === 'report' ? `${styles.navItem} ${styles.navItemSelected}` : styles.navItem, onClick: () => setSelected('report') }, "Report Settings")),
                selected === 'workspace' && react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_CustomItemSettings_CustomWorkspaceSettings__WEBPACK_IMPORTED_MODULE_6__["default"], null),
                selected === 'semantic' && react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_CustomItemSettings_CustomSemanticModelSettings__WEBPACK_IMPORTED_MODULE_7__["default"], null),
                selected === 'report' && react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_CustomItemSettings_CustomReportSettings__WEBPACK_IMPORTED_MODULE_8__["default"], null)))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SettingsPanel);


/***/ }),

/***/ "./src/contexts/FabricFindingsContext.tsx":
/*!************************************************!*\
  !*** ./src/contexts/FabricFindingsContext.tsx ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FabricFindingsProvider: () => (/* binding */ FabricFindingsProvider),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   useFabricFindings: () => (/* binding */ useFabricFindings)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _env__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../env */ "./src/env.ts");


// -------------------------------
// Context Setup
// -------------------------------
const FabricFindingsContext = (0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)(undefined);
// -------------------------------
// Custom Hook
// -------------------------------
const useFabricFindings = () => {
    const context = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(FabricFindingsContext);
    if (!context) {
        throw new Error("useFabricFindings must be used within a FabricFindingsProvider");
    }
    return context;
};
// -------------------------------
// Provider Component
// -------------------------------
const FabricFindingsProvider = ({ children }) => {
    const [sampleData, setSampleData] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({
        capacity_optimization: [],
        performance: [],
        governance: [],
    });
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [lastRefresh, setLastRefresh] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [isInitialized, setIsInitialized] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [refreshVersion, setRefreshVersion] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
    const lastPayloadHashRef = react__WEBPACK_IMPORTED_MODULE_0___default().useRef("");
    const inFlightRef = react__WEBPACK_IMPORTED_MODULE_0___default().useRef(null);
    // -------------------------------
    // Fetch Data Function
    // -------------------------------
    const fetchData = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async (force = false) => {
        var _a, _b, _c, _d, _e;
        if (isInitialized && !force)
            return;
        try {
            // cancel any in-flight request to avoid race conditions
            if (inFlightRef.current) {
                inFlightRef.current.abort();
            }
            const controller = new AbortController();
            inFlightRef.current = controller;
            setLoading(true);
            setError(null);
            // 1) Fetch settings from backend (KQL-backed)
            const settingsResp = await fetch(`${_env__WEBPACK_IMPORTED_MODULE_1__.workloadBEURL}/api/settings`, { signal: controller.signal });
            const settingsJson = await settingsResp.json();
            if (!settingsResp.ok || !(settingsJson === null || settingsJson === void 0 ? void 0 : settingsJson.success) || !(settingsJson === null || settingsJson === void 0 ? void 0 : settingsJson.data)) {
                throw new Error((settingsJson === null || settingsJson === void 0 ? void 0 : settingsJson.message) || "Failed to fetch settings");
            }
            // 2) Build suppressed titles from settings.SuggestedAction (suppressFinding toggles)
            // Map settings keys to human-friendly titles used in suggested actions
            const keyToTitle = {
                notifyWorkspaceAdmins: "Notify Workspace Admins",
                deleteWorkspace: "Delete Workspace",
                deleteSemanticModel: "Delete Semantic Model",
                notifyOwnerSemanticModel: "Notify Owner",
                disableRefreshSemanticModel: "Disable Refresh",
                deleteReport: "Delete Report",
                notifyOwnerReport: "Notify Owner",
            };
            const suggestedAction = (_d = (_b = (_a = settingsJson.data) === null || _a === void 0 ? void 0 : _a.suggestedAction) !== null && _b !== void 0 ? _b : (_c = settingsJson.data) === null || _c === void 0 ? void 0 : _c.SuggestedAction) !== null && _d !== void 0 ? _d : {};
            const suppressedFindings = Object.keys(keyToTitle)
                .filter((k) => (suggestedAction === null || suggestedAction === void 0 ? void 0 : suggestedAction[k]) === true)
                .map((k) => keyToTitle[k]);
            // 3) Call suppressfindings API with payload constructed from settings
            const suppressPayload = {
                suppressedFindings,
                triggeredBy: "client",
                action: "fetch",
                timestamp: new Date().toISOString(),
            };
            // If payload hasn't changed and we're initialized and not forcing, skip network call
            const payloadHash = JSON.stringify(suppressPayload);
            if (!force && isInitialized && lastPayloadHashRef.current === payloadHash) {
                setLoading(false);
                return;
            }
            const response = await fetch(`${_env__WEBPACK_IMPORTED_MODULE_1__.workloadBEURL}/api/FabricFindings/suppressfindings`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(suppressPayload),
                signal: controller.signal,
            });
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const apiResponse = await response.json();
            if (apiResponse.success && apiResponse.data) {
                const findings = (_e = apiResponse.data.findings) !== null && _e !== void 0 ? _e : apiResponse.data;
                const transformedData = {
                    capacity_optimization: [],
                    performance: [],
                    governance: [],
                };
                findings.forEach((finding) => {
                    const transformedItem = {
                        id: finding.id,
                        capacityName: finding.capacityName,
                        workspaceName: finding.workspaceName,
                        artifactName: finding.artifactName,
                        artifactType: finding.artifactType || "-",
                        finding: finding.finding,
                        suggested_actions: finding.suggestedActions || [],
                        suggestedActions: finding.suggestedActions || [],
                        state: finding.state || [],
                        lastUpdatedAt: finding.lastUpdatedAt,
                        category: finding.category,
                    };
                    switch (finding.category) {
                        case "capacity_optimization":
                            transformedData.capacity_optimization.push(transformedItem);
                            break;
                        case "performance":
                            transformedData.performance.push(transformedItem);
                            break;
                        case "governance":
                            transformedData.governance.push(transformedItem);
                            break;
                        default:
                            console.warn(`⚠️ Unknown category "${finding.category}" for finding ID ${finding.id}`);
                    }
                });
                setSampleData(transformedData);
                setLastRefresh(new Date());
                setIsInitialized(true);
                lastPayloadHashRef.current = payloadHash;
            }
            else {
                throw new Error(apiResponse.message || "Failed to fetch findings");
            }
        }
        catch (err) {
            if ((err === null || err === void 0 ? void 0 : err.name) === "AbortError") {
                // silently ignore aborted requests
                return;
            }
            console.error("❌ Error fetching Fabric Findings data:", err);
            setError(err.message);
            if (!isInitialized) {
                // Initialize with empty structure
                setSampleData({
                    capacity_optimization: [],
                    performance: [],
                    governance: [],
                });
                setIsInitialized(true);
            }
        }
        finally {
            if (inFlightRef.current) {
                inFlightRef.current = null;
            }
            setLoading(false);
        }
    }, [isInitialized]);
    const triggerGlobalRefresh = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async () => {
        console.log("🔄 Triggering global refresh from FabricFindingsContext...");
        await fetchData(true); // force re-fetch
        setRefreshVersion((v) => v + 1); // increment global refresh signal
    }, [fetchData]);
    // -------------------------------
    // Auto-fetch on Mount
    // -------------------------------
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (!isInitialized) {
            fetchData();
        }
    }, [fetchData, isInitialized]);
    // -------------------------------
    // Context Value
    // -------------------------------
    const value = {
        sampleData,
        loading,
        error,
        lastRefresh,
        isInitialized,
        fetchData: () => fetchData(true),
        refetch: () => fetchData(true),
        refreshVersion,
        triggerGlobalRefresh
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(FabricFindingsContext.Provider, { value: value }, children));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FabricFindingsContext);


/***/ }),

/***/ "./src/contexts/McpContext.tsx":
/*!*************************************!*\
  !*** ./src/contexts/McpContext.tsx ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   McpProvider: () => (/* binding */ McpProvider),
/* harmony export */   useMcp: () => (/* binding */ useMcp)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

// Create the context with proper type (undefined to enforce checking)
const McpContext = (0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)(undefined);
// Create a typed hook
const useMcp = () => {
    const context = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(McpContext);
    if (!context) {
        throw new Error("useMcp must be used within an McpProvider");
    }
    return context;
};
// Provider component
const McpProvider = ({ children }) => {
    const [mcpAuthenticated, setMcpAuthenticated] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [mcpLoading, setMcpLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [mcpError, setMcpError] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const authenticateWithMcp = async () => {
        setMcpLoading(true);
        setMcpError(null);
        // Authentication will be handled by McpAuthFrame component
    };
    const setMcpAuthSuccess = () => {
        setMcpAuthenticated(true);
        setMcpError(null);
        setMcpLoading(false);
    };
    const setMcpAuthError = (error) => {
        setMcpError(error);
        setMcpLoading(false);
    };
    const disconnectMcp = () => {
        setMcpAuthenticated(false);
        setMcpError(null);
    };
    const value = {
        mcpAuthenticated,
        mcpLoading,
        mcpError,
        authenticateWithMcp,
        disconnectMcp,
        setMcpAuthSuccess,
        setMcpAuthError,
    };
    return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(McpContext.Provider, { value: value }, children);
};


/***/ }),

/***/ "./src/contexts/SettingsContext.tsx":
/*!******************************************!*\
  !*** ./src/contexts/SettingsContext.tsx ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AdminProvider: () => (/* binding */ AdminProvider),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   useAdmin: () => (/* binding */ useAdmin)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _FabricFindingsContext__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./FabricFindingsContext */ "./src/contexts/FabricFindingsContext.tsx");
/* harmony import */ var _env__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../env */ "./src/env.ts");



// ----------------------
// Context Initialization
// ----------------------
const SettingsContext = (0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)(undefined);
// ----------------------
// Provider Component
// ----------------------
const AdminProvider = ({ children }) => {
    const { sampleData } = (0,_FabricFindingsContext__WEBPACK_IMPORTED_MODULE_1__.useFabricFindings)();
    // Dashboard
    const [dashboardStats, setDashboardStats] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({
        totalAdmins: 0,
        totalFindings: 0,
        totalApprovedActions: 0,
        totalRejectedActions: 0,
        uniqueArtifactsCount: 0,
        uniqueWorkspacesCount: 0,
    });
    const [dashboardLoading, setDashboardLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    // Settings
    const [settings, setSettings] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [settingsLoaded, setSettingsLoaded] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    // Event History
    const [eventHistory, setEventHistory] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [eventHistoryLoaded, setEventHistoryLoaded] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [eventHistoryLoading, setEventHistoryLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [eventHistoryError, setEventHistoryError] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [eventHistoryLastLoadedTime, setEventHistoryLastLoadedTime] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    // ----------------------
    // Dashboard Functions
    // ----------------------
    const refreshDashboardStats = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async () => {
        setDashboardLoading(true);
        try {
            let totalFindings = 0;
            let totalApprovedActions = 0;
            let totalRejectedActions = 0;
            const uniqueArtifacts = new Set();
            const uniqueWorkspaces = new Set();
            Object.values(sampleData).forEach((categoryFindings) => {
                if (Array.isArray(categoryFindings)) {
                    totalFindings += categoryFindings.length;
                    categoryFindings.forEach((finding) => {
                        if (finding.artifactName && finding.artifactName !== "-")
                            uniqueArtifacts.add(finding.artifactName);
                        if (finding.workspaceName)
                            uniqueWorkspaces.add(finding.workspaceName);
                    });
                }
            });
            eventHistory.forEach((event) => {
                if (!event || !event.action)
                    return;
                const actionLower = event.action.toLowerCase();
                if (actionLower.includes("approved"))
                    totalApprovedActions++;
                else if (actionLower.includes("rejected"))
                    totalRejectedActions++;
            });
            setDashboardStats({
                totalFindings,
                totalApprovedActions,
                totalRejectedActions,
                uniqueArtifactsCount: uniqueArtifacts.size,
                uniqueWorkspacesCount: uniqueWorkspaces.size,
            });
        }
        catch (err) {
            console.error("Error calculating dashboard stats:", err);
        }
        finally {
            setDashboardLoading(false);
        }
    }, [sampleData, eventHistory]);
    // ----------------------
    // Settings Management
    // ----------------------
    const fetchSettings = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async () => {
        try {
            const response = await fetch(`${_env__WEBPACK_IMPORTED_MODULE_2__.workloadBEURL}/api/settings`);
            const data = await response.json();
            if (response.ok && data.success && data.data) {
                setSettings(data.data);
                setSettingsLoaded(true);
            }
            else {
                console.error("Failed to fetch settings:", data.message);
            }
        }
        catch (err) {
            console.error("Error fetching settings:", err);
        }
    }, []);
    const updateSettings = async (newSettings) => {
        try {
            const response = await fetch(`${_env__WEBPACK_IMPORTED_MODULE_2__.workloadBEURL}/api/settings`, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(newSettings),
            });
            const data = await response.json();
            if (response.ok && data.success) {
                setSettings(newSettings);
                return { success: true };
            }
            else {
                return { success: false, error: data.error || data.message || "Failed to update settings" };
            }
        }
        catch (err) {
            console.error("Error saving settings:", err);
            return { success: false, error: "Failed to save settings" };
        }
    };
    const refreshSettings = async () => {
        setSettingsLoaded(false);
        await fetchSettings();
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (!settingsLoaded)
            fetchSettings();
    }, [settingsLoaded, fetchSettings]);
    // ----------------------
    // Event History
    // ----------------------
    const fetchEventHistory = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async (submittedBy = null, force = false) => {
        if (!force && (eventHistoryLoaded || eventHistoryLoading))
            return;
        setEventHistoryLoading(true);
        setEventHistoryError(null);
        try {
            let url = `${_env__WEBPACK_IMPORTED_MODULE_2__.workloadBEURL}/api/Eventhistory`;
            if (submittedBy)
                url += `?submittedBy=${encodeURIComponent(submittedBy)}`;
            const response = await fetch(url);
            if (!response.ok)
                throw new Error(`HTTP error! status: ${response.status}`);
            const data = await response.json();
            setEventHistory(data.eventHistory || []);
            setEventHistoryLoaded(true);
            setEventHistoryLastLoadedTime(new Date());
        }
        catch (err) {
            console.error("❌ Error fetching event history:", err);
            setEventHistoryError(err.message);
        }
        finally {
            setEventHistoryLoading(false);
        }
    }, [eventHistoryLoaded, eventHistoryLoading]);
    const refreshEventHistory = async (submittedBy = null) => {
        setEventHistoryLoaded(false);
        await fetchEventHistory(submittedBy, true);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (!eventHistoryLoaded && !eventHistoryLoading) {
            fetchEventHistory();
        }
    }, [eventHistoryLoaded, eventHistoryLoading, fetchEventHistory]);
    // ----------------------
    // Context Value
    // ----------------------
    const value = {
        dashboardStats,
        dashboardLoading,
        refreshDashboardStats,
        settings,
        settingsLoaded,
        updateSettings,
        refreshSettings,
        eventHistory,
        eventHistoryLoaded,
        eventHistoryLoading,
        eventHistoryError,
        eventHistoryLastLoadedTime,
        fetchEventHistory,
        refreshEventHistory
    };
    return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(SettingsContext.Provider, { value: value }, children);
};
// ----------------------
// Custom Hook
// ----------------------
const useAdmin = () => {
    const context = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(SettingsContext);
    if (!context)
        throw new Error("useAdmin must be used within an AdminProvider");
    return context;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SettingsContext);


/***/ }),

/***/ "./src/contexts/SuppressedFindingsContext.tsx":
/*!****************************************************!*\
  !*** ./src/contexts/SuppressedFindingsContext.tsx ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SuppressedFindingsProvider: () => (/* binding */ SuppressedFindingsProvider),
/* harmony export */   callSuppressionAPIExternal: () => (/* binding */ callSuppressionAPIExternal),
/* harmony export */   getSuppressedDataValue: () => (/* binding */ getSuppressedDataValue),
/* harmony export */   useSuppressedFindings: () => (/* binding */ useSuppressedFindings)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _env__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../env */ "./src/env.ts");


// -------------------------------
// Context Setup
// -------------------------------
const SuppressedFindingsContext = (0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)(undefined);
const useSuppressedFindings = () => {
    const context = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(SuppressedFindingsContext);
    if (!context) {
        throw new Error("useSuppressedFindings must be used within a SuppressedFindingsProvider");
    }
    return context;
};
// -------------------------------
// Globals for external access
// -------------------------------
let suppressedDataRef = null;
let callSuppressionAPIRef = { current: null };
// let hasInitialFetchCompleted = false;
// -------------------------------
// Provider Component
// -------------------------------
const SuppressedFindingsProvider = ({ children }) => {
    const [suppressedData, setSuppressedData] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({
        capacity_optimization: [],
        performance: [],
        governance: [],
    });
    const suppressedRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(suppressedData);
    suppressedDataRef = suppressedRef;
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [lastRefresh, setLastRefresh] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [isInitialized, setIsInitialized] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const inFlightRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(false);
    const lastSentKeyRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    // Keep latest data & callback in refs for possible external usage
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        suppressedRef.current = suppressedData;
    }, [suppressedData]);
    // -------------------------------
    // Transform Data
    // -------------------------------
    const transformData = async (data) => {
        var _a;
        const findings = (_a = data.findings) !== null && _a !== void 0 ? _a : data;
        const transformedData = {
            capacity_optimization: [],
            performance: [],
            governance: [],
        };
        for (const finding of findings) {
            const transformedItem = {
                id: finding.id,
                capacityName: finding.capacityName,
                workspaceName: finding.workspaceName,
                artifactName: finding.artifactName,
                artifactType: finding.artifactType || "-",
                finding: finding.finding,
                suggested_actions: finding.suggestedActions || [],
                suggestedActions: finding.suggestedActions || [],
                state: finding.state || [],
                lastUpdatedAt: finding.lastUpdatedAt,
                category: finding.category,
            };
            switch (finding.category) {
                case "capacity_optimization":
                    transformedData.capacity_optimization.push(transformedItem);
                    break;
                case "performance":
                    transformedData.performance.push(transformedItem);
                    break;
                case "governance":
                    transformedData.governance.push(transformedItem);
                    break;
                default:
                    console.warn(`⚠️ Unknown category "${finding.category}" for suppressed finding ID ${finding.id}`);
            }
        }
        return transformedData;
    };
    // -------------------------------
    // API Call (with useCallback)
    // -------------------------------
    const callSuppressionAPI = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async (payload) => {
        try {
            setLoading(true);
            setError(null);
            console.log("data before transformation", suppressedData);
            const isInitialFetch = !payload;
            if (isInitialFetch) {
                while (inFlightRef.current) {
                    await new Promise((resolve) => setTimeout(resolve, 50));
                }
            }
            else {
                const currentKey = JSON.stringify(payload);
                if (lastSentKeyRef.current === currentKey || inFlightRef.current)
                    return;
                lastSentKeyRef.current = currentKey;
            }
            let payloadToSend = payload;
            if (!payloadToSend) {
                // On first load, get suppressed titles from localStorage
                const suppressedTitles = [];
                try {
                    if (typeof window !== "undefined") {
                        for (let i = 0; i < window.localStorage.length; i++) {
                            const key = window.localStorage.key(i);
                            if (key && key.startsWith("suppress_")) {
                                const raw = window.localStorage.getItem(key);
                                const val = raw ? JSON.parse(raw) : false;
                                if (val) {
                                    suppressedTitles.push(key.replace("suppress_", ""));
                                }
                            }
                        }
                    }
                }
                catch (err) {
                    console.warn("[SuppressedFindingsProvider] Failed to read localStorage:", err);
                }
                payloadToSend = {
                    suppressedFindings: suppressedTitles,
                    triggeredBy: "system",
                    action: "fetch",
                    timestamp: new Date().toISOString(),
                };
            }
            inFlightRef.current = true;
            const resp = await fetch(`${_env__WEBPACK_IMPORTED_MODULE_1__.workloadBEURL}/api/FabricFindings/suppressfindings`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(payloadToSend),
            });
            const json = await resp.json();
            if (!resp.ok) {
                setError(json.message || "Suppression API error");
                return;
            }
            const transformedData = await transformData(json.data);
            console.log("transformed data", transformedData);
            console.log("previous suppressedData === new?", suppressedRef.current === transformedData);
            setSuppressedData(transformedData);
            setLastRefresh(new Date());
            setIsInitialized(true);
            console.log("current suppressedData", suppressedData);
            // if (isInitialFetch) hasInitialFetchCompleted = true;
        }
        catch (err) {
            setError(err.message);
        }
        finally {
            inFlightRef.current = false;
            setLoading(false);
        }
    }, []);
    // Put the function reference in a global ref for external usage
    // useEffect(() => {
    //   callSuppressionAPIRef.current = callSuppressionAPI;
    // }, [callSuppressionAPI]);
    // -------------------------------
    // Initial fetch
    // -------------------------------
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        callSuppressionAPI();
    }, [callSuppressionAPI]);
    // -------------------------------
    // Clear Data
    // -------------------------------
    const clearSuppressedData = () => {
        setSuppressedData({
            capacity_optimization: [],
            performance: [],
            governance: [],
        });
        setIsInitialized(false);
    };
    // -------------------------------
    // Provide Context
    // -------------------------------
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(SuppressedFindingsContext.Provider, { value: {
            suppressedData,
            loading,
            error,
            lastRefresh,
            isInitialized,
            callSuppressionAPI,
            clearSuppressedData,
        } }, children));
};
// -------------------------------
// External Getter
// -------------------------------
const getSuppressedDataValue = () => {
    if (!suppressedDataRef) {
        throw new Error("SuppressedFindingsProvider is not initialized yet. Wrap your app with it.");
    }
    return suppressedDataRef.current;
};
// EXPORTED FUNCTION FOR EXTERNAL USAGE (not inside React tree)
const callSuppressionAPIExternal = async (payload) => {
    if (!callSuppressionAPIRef.current) {
        throw new Error("SuppressedFindingsProvider is not initialized yet. Wrap your app with it.");
    }
    return callSuppressionAPIRef.current(payload);
};


/***/ }),

/***/ "./src/controller/LakehouseExplorerController.ts":
/*!*******************************************************!*\
  !*** ./src/controller/LakehouseExplorerController.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getFilesInLakehouse: () => (/* binding */ getFilesInLakehouse),
/* harmony export */   getFilesInLakehousePath: () => (/* binding */ getFilesInLakehousePath),
/* harmony export */   getTablesInLakehouse: () => (/* binding */ getTablesInLakehouse),
/* harmony export */   getTablesInLakehousePath: () => (/* binding */ getTablesInLakehousePath)
/* harmony export */ });
const getTablesInLakehousePath = (baseUrl, workspaceObjectId, itemObjectId) => {
    return `${baseUrl}/onelake/${workspaceObjectId}/${itemObjectId}/tables`;
};
async function getTablesInLakehouse(tablesPath, token) {
    try {
        const response = await fetch(tablesPath, { method: `GET`, headers: { 'Authorization': 'Bearer ' + token } });
        const responseBody = await response.text();
        const data = JSON.parse(responseBody);
        if (!data.ErrorCode) {
            return data;
        }
        else {
            return null;
        }
    }
    catch (error) {
        console.error(`Error fetching tables: ${error}`);
        return null;
    }
}
const getFilesInLakehousePath = (baseUrl, workspaceObjectId, itemObjectId) => {
    return `${baseUrl}/onelake/${workspaceObjectId}/${itemObjectId}/files`;
};
async function getFilesInLakehouse(filesPath, token) {
    try {
        const response = await fetch(filesPath, { method: `GET`, headers: { 'Authorization': 'Bearer ' + token } });
        const responseBody = await response.text();
        const data = JSON.parse(responseBody);
        if (!data.ErrorCode) {
            return data;
        }
        else {
            return null;
        }
    }
    catch (error) {
        console.error(`Error fetching files: ${error}`);
        return null;
    }
}


/***/ }),

/***/ "./src/controller/UserDetail.ts":
/*!**************************************!*\
  !*** ./src/controller/UserDetail.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   useUserDetails: () => (/* binding */ useUserDetails)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ms-fabric/workload-client */ "./node_modules/@ms-fabric/workload-client/src/workload-client.js");
/* harmony import */ var _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_1__);


// Custom hook to get user details (UPN from token claims)
const useUserDetails = () => {
    const [upn, setUpn] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [roles, setRoles] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        const fetchGraphUser = async () => {
            try {
                const workloadClient = await (0,_ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_1__.createWorkloadClient)();
                // ✅ Always pass an object
                const tokenResponse = await workloadClient.auth.acquireAccessToken({});
                // Decode JWT
                const base64Url = tokenResponse.token.split(".")[1];
                const base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/");
                const jsonPayload = decodeURIComponent(atob(base64)
                    .split("")
                    .map((c) => "%" + ("00" + c.charCodeAt(0).toString(16)).slice(-2))
                    .join(""));
                const claims = JSON.parse(jsonPayload);
                //console.log("Decoded Claims:", claims);
                const userUpn = claims.upn || claims.preferred_username || null;
                setUpn(userUpn);
                // Handle roles
                if (claims.roles && Array.isArray(claims.roles)) {
                    setRoles(claims.roles);
                    //console.log("User Roles:", claims.roles);
                }
            }
            catch (error) {
                console.error("Error fetching user details:", error);
            }
        };
        fetchGraphUser();
    }, []);
    return { upn, roles };
};


/***/ }),

/***/ "./src/index.ui.tsx":
/*!**************************!*\
  !*** ./src/index.ui.tsx ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   initialize: () => (/* binding */ initialize)
/* harmony export */ });
/* harmony import */ var history__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! history */ "./node_modules/history/esm/history.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_dom_client__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-dom/client */ "./node_modules/react-dom/client.js");
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/react-provider/lib/components/FluentProvider/FluentProvider.js");
/* harmony import */ var _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ms-fabric/workload-client */ "./node_modules/@ms-fabric/workload-client/src/workload-client.js");
/* harmony import */ var _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _theme__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./theme */ "./src/theme.tsx");
/* harmony import */ var _App__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./App */ "./src/App.tsx");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./utils */ "./src/utils.ts");
/* harmony import */ var _controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./controller/SampleWorkloadController */ "./src/controller/SampleWorkloadController.ts");









async function initialize(params) {
    const workloadClient = (0,_ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_4__.createWorkloadClient)();
    const history = (0,history__WEBPACK_IMPORTED_MODULE_0__.createBrowserHistory)();
    workloadClient.navigation.onNavigate((route) => history.replace(route.targetUrl));
    workloadClient.action.onAction(async function ({ action, data }) {
        switch (action) {
            case 'sample.tab.onInit':
                const { id } = data;
                try {
                    const getItemResult = await (0,_controller_SampleWorkloadController__WEBPACK_IMPORTED_MODULE_8__.callItemGet)(id, workloadClient);
                    const item = (0,_utils__WEBPACK_IMPORTED_MODULE_7__.convertGetItemResultToWorkloadItem)(getItemResult);
                    return { title: item.displayName };
                }
                catch (error) {
                    console.error(`Error loading the Item (object ID:${id})`, error);
                    return {};
                }
            case 'sample.tab.canDeactivate':
                return { canDeactivate: true };
            case 'sample.tab.onDeactivate':
                return {};
            case 'sample.tab.canDestroy':
                return { canDestroy: true };
            case 'sample.tab.onDestroy':
                return {};
            case 'sample.tab.onDelete':
                return {};
            default:
                throw new Error('Unknown action received');
        }
    });
    const root = (0,react_dom_client__WEBPACK_IMPORTED_MODULE_2__.createRoot)(document.getElementById('root'));
    root.render(react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_3__.FluentProvider, { theme: _theme__WEBPACK_IMPORTED_MODULE_5__.fabricLightTheme },
        react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_App__WEBPACK_IMPORTED_MODULE_6__.App, { history: history, workloadClient: workloadClient })));
}


/***/ }),

/***/ "./src/styles.scss":
/*!*************************!*\
  !*** ./src/styles.scss ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "./node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/insertBySelector.js */ "./node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "./node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "./node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_node_modules_sass_loader_dist_cjs_js_styles_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../node_modules/css-loader/dist/cjs.js!../node_modules/sass-loader/dist/cjs.js!./styles.scss */ "./node_modules/css-loader/dist/cjs.js!./node_modules/sass-loader/dist/cjs.js!./src/styles.scss");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_node_modules_sass_loader_dist_cjs_js_styles_scss__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_node_modules_sass_loader_dist_cjs_js_styles_scss__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_node_modules_sass_loader_dist_cjs_js_styles_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_node_modules_sass_loader_dist_cjs_js_styles_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ "./src/theme.tsx":
/*!***********************!*\
  !*** ./src/theme.tsx ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fabricLightTheme: () => (/* binding */ fabricLightTheme)
/* harmony export */ });
/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @fluentui/react-components */ "./node_modules/@fluentui/tokens/lib/utils/createLightTheme.js");

const brandFabric = {
    10: `#001919`,
    20: `#012826`,
    30: `#01322E`,
    40: `#033F38`, //button pressed ;
    50: `#054D43`,
    60: `#0A5C50`, // link click
    70: `#0C695A`, // tab/button click
    80: `#117865`, //tab and button
    90: `#1F937E`,
    100: `#2AAC94`,
    110: `#3ABB9F`,
    120: `#52C7AA`,
    130: `#78D3B9`,
    140: `#9EE0CB`,
    150: `#C0ECDD`,
    160: `#E3F7Ef`,
};
const fabricLightTheme = (0,_fluentui_react_components__WEBPACK_IMPORTED_MODULE_0__.createLightTheme)(brandFabric);



/***/ })

}]);
//# sourceMappingURL=src_index_ui_tsx.bundle.87d6c524133f7e6a9122.js.map
"use strict";
(self["webpackChunkfabric_frontend_developer_sample"] = self["webpackChunkfabric_frontend_developer_sample"] || []).push([["src_controller_SampleWorkloadController_ts"],{

/***/ "./src/controller/SampleWorkloadController.ts":
/*!****************************************************!*\
  !*** ./src/controller/SampleWorkloadController.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CallExecuteQuery: () => (/* binding */ CallExecuteQuery),
/* harmony export */   CallOpenInNewBrowserTab: () => (/* binding */ CallOpenInNewBrowserTab),
/* harmony export */   callActionExecute: () => (/* binding */ callActionExecute),
/* harmony export */   callActionOnAction: () => (/* binding */ callActionOnAction),
/* harmony export */   callAuthAcquireAccessToken: () => (/* binding */ callAuthAcquireAccessToken),
/* harmony export */   callCancelItemJob: () => (/* binding */ callCancelItemJob),
/* harmony export */   callDatahubOpen: () => (/* binding */ callDatahubOpen),
/* harmony export */   callDialogClose: () => (/* binding */ callDialogClose),
/* harmony export */   callDialogOpen: () => (/* binding */ callDialogOpen),
/* harmony export */   callDialogOpenMsgBox: () => (/* binding */ callDialogOpenMsgBox),
/* harmony export */   callErrorHandlingOpenDialog: () => (/* binding */ callErrorHandlingOpenDialog),
/* harmony export */   callErrorHandlingRequestFailure: () => (/* binding */ callErrorHandlingRequestFailure),
/* harmony export */   callGetEventhouseItem: () => (/* binding */ callGetEventhouseItem),
/* harmony export */   callGetItem1SupportedOperators: () => (/* binding */ callGetItem1SupportedOperators),
/* harmony export */   callItem1DoubleResult: () => (/* binding */ callItem1DoubleResult),
/* harmony export */   callItemCreate: () => (/* binding */ callItemCreate),
/* harmony export */   callItemDelete: () => (/* binding */ callItemDelete),
/* harmony export */   callItemGet: () => (/* binding */ callItemGet),
/* harmony export */   callItemUpdate: () => (/* binding */ callItemUpdate),
/* harmony export */   callLanguageGet: () => (/* binding */ callLanguageGet),
/* harmony export */   callNavigationAfterNavigateAway: () => (/* binding */ callNavigationAfterNavigateAway),
/* harmony export */   callNavigationBeforeNavigateAway: () => (/* binding */ callNavigationBeforeNavigateAway),
/* harmony export */   callNavigationNavigate: () => (/* binding */ callNavigationNavigate),
/* harmony export */   callNotificationHide: () => (/* binding */ callNotificationHide),
/* harmony export */   callNotificationOpen: () => (/* binding */ callNotificationOpen),
/* harmony export */   callOpenRecentRuns: () => (/* binding */ callOpenRecentRuns),
/* harmony export */   callOpenSettings: () => (/* binding */ callOpenSettings),
/* harmony export */   callPageOpen: () => (/* binding */ callPageOpen),
/* harmony export */   callPanelClose: () => (/* binding */ callPanelClose),
/* harmony export */   callPanelOpen: () => (/* binding */ callPanelOpen),
/* harmony export */   callRunItemJob: () => (/* binding */ callRunItemJob),
/* harmony export */   callSettingsGet: () => (/* binding */ callSettingsGet),
/* harmony export */   callSettingsOnChange: () => (/* binding */ callSettingsOnChange),
/* harmony export */   callThemeGet: () => (/* binding */ callThemeGet),
/* harmony export */   callThemeOnChange: () => (/* binding */ callThemeOnChange),
/* harmony export */   getLastResult: () => (/* binding */ getLastResult),
/* harmony export */   isOneLakeSupported: () => (/* binding */ isOneLakeSupported),
/* harmony export */   settingsToView: () => (/* binding */ settingsToView),
/* harmony export */   themeToView: () => (/* binding */ themeToView)
/* harmony export */ });
/* harmony import */ var _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ms-fabric/workload-client */ "./node_modules/@ms-fabric/workload-client/src/workload-client.js");
/* harmony import */ var _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils */ "./src/utils.ts");
/* harmony import */ var _models_WorkloadExceptionsModel__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../models/WorkloadExceptionsModel */ "./src/models/WorkloadExceptionsModel.ts");
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! uuid */ "./node_modules/uuid/dist/esm-browser/v4.js");




// --- Notification API
/**
 * Calls the 'notification.open' function from the WorkloadClientAPI to display a notification.
 *
 * @param {string} title - The title of the notification.
 * @param {string} message - The message content of the notification.
 * @param {NotificationType} type - The type of the notification (default: NotificationType.Success).
 * @param {NotificationToastDuration} duration - The duration for which the notification should be displayed (default: NotificationToastDuration.Medium).
 * @param {WorkloadClientAPI} workloadClient - An instance of the WorkloadClientAPI.
 * @param {Dispatch<SetStateAction<string>>} setNotificationId - (Optional) A state setter function to update the notification ID.
 */
async function callNotificationOpen(title, message, type = _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_0__.NotificationType.Success, duration = _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_0__.NotificationToastDuration.Medium, workloadClient, setNotificationId) {
    const result = await workloadClient.notification.open({
        notificationType: type,
        title,
        duration,
        message
    });
    if (type == _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_0__.NotificationType.Success && setNotificationId) {
        setNotificationId(result === null || result === void 0 ? void 0 : result.notificationId);
    }
}
/**
 * Calls the 'notification.hide' function from the WorkloadClientAPI to hide a specific notification.
 *
 * @param {string} notificationId - The ID of the notification to hide.
 * @param {WorkloadClientAPI} workloadClient - An instance of the WorkloadClientAPI.
 * @param {Dispatch<SetStateAction<string>>} setNotificationId - A state setter function to update the notification ID after hiding.
 */
async function callNotificationHide(notificationId, workloadClient, setNotificationId) {
    await workloadClient.notification.hide({ notificationId });
    // Clear the notification ID from the state to reflect the hidden notification
    setNotificationId('');
}
// --- Panel API
/**
 * Calls the 'panel.open' function from the WorkloadClientAPI to open a panel.
 *
 * @param {string} workloadName - The name of the workload responsible for the panel.
 * @param {string} path - The path or route within the workload to open.
 * @param {boolean} isLightDismiss - Whether the panel can be dismissed by clicking outside (light dismiss).
 * @param {WorkloadClientAPI} workloadClient - An instance of the WorkloadClientAPI.
 */
async function callPanelOpen(workloadName, path, isLightDismiss, workloadClient) {
    await workloadClient.panel.open({
        workloadName,
        route: { path },
        options: {
            width: window.innerWidth / 3,
            isLightDismiss
        }
    });
}
/**
 * Calls the 'panel.close' function from the WorkloadClientAPI to close a panel.
 *
 * @param {WorkloadClientAPI} workloadClient - An instance of the WorkloadClientAPI.
 */
async function callPanelClose(workloadClient) {
    await workloadClient.panel.close({ mode: _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_0__.CloseMode.PopOne });
}
// --- Page API
/**
 * Calls the 'page.open' function from the WorkloadClientAPI to open a new page.
 *
 * @param {string} workloadName - The name of the workload responsible for the page.
 * @param {string} path - The path or route within the workload to open.
 * @param {WorkloadClientAPI} workloadClient - An instance of the WorkloadClientAPI.
 */
async function callPageOpen(workloadName, path, workloadClient) {
    await workloadClient.page.open({ workloadName, route: { path }, mode: _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_0__.OpenMode.ReplaceAll });
}
// --- Navigation API
/**
 * Calls the 'navigation.navigate' function from the WorkloadClientAPI to navigate to a target (host or workload) and path.
 *
 * @param {T} target - The target location to navigate to ('host' or 'workload').
 * @param {string} path - The path or route to navigate to.
 * @param {WorkloadClientAPI} workloadClient - An instance of the WorkloadClientAPI.
 */
async function callNavigationNavigate(target, path, workloadClient) {
    await workloadClient.navigation.navigate(target, { path });
}
/**
 * Calls acquire access token from the WorkloadClientAPI.
 * @param {WorkloadClientAPI} workloadClient - An instance of the WorkloadClientAPI.
 * @param {string} additionalScopesToConsent - Extra scopes to consent (only provide if you are sure the user is missing a consent)
 * @param {string} claimsForConditionalAccessPolicy - Claims returned from the server indicating that token conversion failed because of some conditional access policy - see https://learn.microsoft.com/en-us/entra/msal/dotnet/acquiring-tokens/web-apps-apis/on-behalf-of-flow#handling-multi-factor-auth-mfa-conditional-access-and-incremental-consent
 * @returns {AccessToken}
 */
async function callAuthAcquireAccessToken(workloadClient, additionalScopesToConsent, claimsForConditionalAccessPolicy, promptFullConsent) {
    return workloadClient.auth.acquireAccessToken({
        additionalScopesToConsent: (additionalScopesToConsent === null || additionalScopesToConsent === void 0 ? void 0 : additionalScopesToConsent.length) > 0 ? additionalScopesToConsent.split(' ') : null,
        claimsForConditionalAccessPolicy: (claimsForConditionalAccessPolicy === null || claimsForConditionalAccessPolicy === void 0 ? void 0 : claimsForConditionalAccessPolicy.length) > 0 ? claimsForConditionalAccessPolicy : null,
        promptFullConsent
    });
}
/**
 * Calls the 'navigation.onBeforeNavigateAway' function from the WorkloadClientAPI
 * to register a callback preventing navigation to a specific URL.
 *
 * @param {WorkloadClientAPI} workloadClient - An instance of the WorkloadClientAPI.
 */
async function callNavigationBeforeNavigateAway(workloadClient) {
    // Define a callback function to prevent navigation to URLs containing 'forbidden-url'
    const callback = async (event) => {
        var _a;
        // Return a result indicating whether the navigation can proceed
        return { canLeave: !((_a = event.nextUrl) === null || _a === void 0 ? void 0 : _a.includes("forbidden-url")) };
    };
    // Register the callback using the 'navigation.onBeforeNavigateAway' function
    await workloadClient.navigation.onBeforeNavigateAway(callback);
}
/**
 * Registers a callback to trigger after navigating away from page
 * using the 'navigation.onAfterNavigateAway' function.
 *
 * @param {(event: AfterNavigateAwayData) => Promise<void>} callback - A call back function that executes after navigation away.
 * @param {WorkloadClientAPI} workloadClient - An instance of the WorkloadClientAPI.
 */
async function callNavigationAfterNavigateAway(callback, workloadClient) {
    // Register the callback using the 'navigation.onAfterNavigateAway' function
    await workloadClient.navigation.onAfterNavigateAway(callback);
}
/**
 * Calls the 'navigation.openBrowserTab' function from the WorkloadClientAPI to navigate to a url in a new tab.
 *
 * @param {string} path - The path or route to navigate to.
 * @param {WorkloadClientAPI} workloadClient - An instance of the WorkloadClientAPI.
 */
async function CallOpenInNewBrowserTab(path, workloadClient) {
    try {
        var params = {
            url: path,
            queryParams: {
                key1: "value1",
            }
        };
        await workloadClient.navigation.openBrowserTab(params);
    }
    catch (err) {
        console.error(err);
    }
}
// --- Action API
/**
 * Registers a callback to be invoked when a workload action is triggered
 * using the 'action.onAction' function.
 *
 * @param {(action: WorkloadAction<unknown>) => Promise<unknown>} callback - The callback function to handle the action.
 * @param {WorkloadClientAPI} workloadClient - An instance of the WorkloadClientAPI.
 */
async function callActionOnAction(callback, workloadClient) {
    await workloadClient.action.onAction(callback);
}
/**
 * Calls the 'action.execute' function from the WorkloadClientAPI to execute a specific action in a workload.
 *
 * @param {string} actionName - The name of the action to execute.
 * @param {string} workloadName - The name of the workload where the action should be executed.
 * @param {WorkloadClientAPI} workloadClient - An instance of the WorkloadClientAPI.
 */
async function callActionExecute(actionName, workloadName, workloadClient) {
    await workloadClient.action.execute({ action: actionName, workloadName });
}
// --- Dialog API
/**
 * Calls the 'dialog.open' function from the WorkloadClientAPI to open a dialog.
 *
 * @param {string} workloadName - The name of the workload responsible for the dialog.
 * @param {string} path - The path or route within the workload to open.
 * @param {number} width - The width of the dialog.
 * @param {number} height - The height of the dialog.
 * @param {boolean} hasCloseButton - Whether the dialog should have a close button.
 * @param {WorkloadClientAPI} workloadClient - An instance of the WorkloadClientAPI.
 *
 * @returns
 * @param {OpenUIResult} result of the dialog
 */
async function callDialogOpen(workloadName, path, width, height, hasCloseButton, workloadClient) {
    return await workloadClient.dialog.open({
        dialogType: _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_0__.DialogType.IFrame,
        route: { path }, // Specify the path within the workload and queryParams
        workloadName,
        options: {
            width,
            height,
            hasCloseButton
        }
    });
}
// --- Datahub API
/**
 * Calls the 'datahub.openDialog' function from the WorkloadClientAPI to open a OneLake data hub dialog to select Lakehouse item(s).
 *
 * @param {ExtendedItemTypeV2[]} supportedTypes - The item types supported by the datahub dialog.
 * @param {string} dialogDescription - The sub-title of the datahub dialog
 * @param {boolean} multiSelectionEnabled - Whether the datahub dialog supports multi selection of datahub items
 * @param {WorkloadClientAPI} workloadClient - An instance of the WorkloadClientAPI.
 * @param {boolean} workspaceNavigationEnabled - Whether the datahub dialog supports workspace navigation bar or not.
 */
async function callDatahubOpen(supportedTypes, dialogDescription, multiSelectionEnabled, workloadClient, workspaceNavigationEnabled = true) {
    const datahubConfig = {
        supportedTypes: supportedTypes,
        multiSelectionEnabled: multiSelectionEnabled,
        dialogDescription: dialogDescription,
        workspaceNavigationEnabled: workspaceNavigationEnabled,
        // not in use in the regular selector, but required to be non-empty for validation
        hostDetails: {
            experience: 'sample experience 3rd party', // Change this to reflect your team's process, e.g., "Build notebook" 
            scenario: 'sample scenario 3rd party', // Adjust this to the specific action, e.g., "Select Lakehouse" 
        }
    };
    const result = await workloadClient.datahub.openDialog(datahubConfig);
    if (!result.selectedDatahubItem) {
        return null;
    }
    const selectedItem = result.selectedDatahubItem[0];
    const { itemObjectId, workspaceObjectId } = selectedItem;
    const { displayName, description } = selectedItem.datahubItemUI;
    return {
        id: itemObjectId,
        workspaceId: workspaceObjectId,
        type: selectedItem.datahubItemUI.itemType,
        displayName,
        description
    };
}
/**
 * Calls the 'dialog.open' function from the WorkloadClientAPI to open a message box dialog.
 *
 * @param {string} title - The title of the message box.
 * @param {string} content - The content or message of the message box.
 * @param {string[]} actionButtonsNames - Names of the action buttons to display in the message box.
 * @param {WorkloadClientAPI} workloadClient - An instance of the WorkloadClientAPI.
 * @returns {string} - Name of the clicked button
 */
async function callDialogOpenMsgBox(title, content, actionButtonsNames, workloadClient, link) {
    var _a;
    // Create an array of ActionButton objects based on the provided action button names
    const actionButtons = actionButtonsNames.map(name => ({ name, label: name }));
    const result = await workloadClient.dialog.open({
        dialogType: _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_0__.DialogType.MessageBox,
        messageBoxOptions: {
            title,
            content,
            link: link ? {
                url: link,
                label: link
            }
                : undefined,
            actionButtons
        }
    });
    return (_a = result.value) === null || _a === void 0 ? void 0 : _a.clickedButton;
}
/**
 * Calls the 'dialog.close' function from the WorkloadClientAPI to close a dialog.
 *
 * @param {WorkloadClientAPI} workloadClient - An instance of the WorkloadClientAPI.
 * @param {CloseMode} mode - (Optional) The mode specifying how the dialog should be closed.
 */
async function callDialogClose(workloadClient, mode, data) {
    await workloadClient.dialog.close({ mode, data });
}
// --- Error Handling API
/**
 * Calls the 'errorHandling.openErrorDialog' function from the WorkloadClientAPI to open an error dialog.
 *
 * @param {string} errorMessage - The error message to display in the error dialog.
 * @param {string} title - The title of the error dialog.
 * @param {string} statusCode - The status code associated with the error.
 * @param {string} stackTrace - The stack trace information of the error.
 * @param {string} requestId - The unique request ID related to the error.
 * @param {WorkloadClientAPI} workloadClient - An instance of the WorkloadClientAPI.
 */
async function callErrorHandlingOpenDialog(errorMessage, title, statusCode, stackTrace, requestId, workloadClient) {
    await workloadClient.errorHandling.openErrorDialog({
        errorMsg: errorMessage,
        errorOptions: {
            title,
            statusCode,
            stackTrace,
            requestId,
            errorTime: Date().toString() // Set the timestamp of the error
        },
        kind: _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_0__.ErrorKind.Error
    });
}
/**
 * Calls the 'errorHandling.handleRequestFailure' function from the WorkloadClientAPI to handle request failures.
 *
 * @param {string} errorMessage - The error message associated with the request failure.
 * @param {number} statusCode - The status code of the failed request.
 * @param {WorkloadClientAPI} workloadClient - An instance of the WorkloadClientAPI.
 */
async function callErrorHandlingRequestFailure(errorMessage, statusCode, workloadClient) {
    // the handleRequestFailure API handles MFA errors coming from Fabric Backend. 
    // Such errors are identified by the inclusion of the below text inside the 'body'.
    const errorCodeMFA = "AdalMultiFactorAuthRequiredErrorCode";
    const result = await workloadClient.errorHandling.handleRequestFailure({ status: statusCode, body: errorMessage + errorCodeMFA });
    callDialogOpenMsgBox("Request Failure handling", `Failure has ${result.handled ? "" : "NOT"} been handled by Fabric`, [], workloadClient);
}
// --- Item CRUD Api
/**
 * Calls the 'itemCrud.createItem function from the WorkloadClientAPI, creating an Item in Fabric
 *
 * @param {string} workspaceObjectId - WorkspaceObjectId where the item will be created
 * @param {string} itemType - Item type, as registered by the BE
 * @param {string} displayName - Name of the item
 * @param {string} description - Description of the item (can be seen in item's Settings in Fabric)
 * @param {T} workloadPayload - Additional metadata payload for the item (e.g., selected Lakehouse details).
 * @param {WorkloadClientAPI} workloadClient - An instance of the WorkloadClientAPI.
 * @returns {GetItemResult} - A wrapper for the item's data, after it has already been saved
 */
async function callItemCreate(workspaceObjectId, itemType, displayName, description, workloadPayload, workloadClient) {
    console.log(`passing payloadString: ${workloadPayload}`);
    const params = {
        workspaceObjectId,
        payload: {
            itemType,
            displayName,
            description,
            workloadPayload: JSON.stringify(workloadPayload),
            payloadContentType: "InlineJson",
        }
    };
    try {
        const result = await workloadClient.itemCrud.createItem(params);
        console.log(`Created item id: ${result.objectId} with name: ${displayName} and payload: ${workloadPayload}`);
        return {
            id: result.objectId,
            workspaceId: workspaceObjectId,
            type: itemType,
            displayName,
            description,
            createdBy: result.createdByUser.name,
            createdDate: result.createdDate,
            lastModifiedBy: result.modifiedByUser.name,
            lastModifiedDate: result.lastUpdatedDate
        };
    }
    catch (exception) {
        console.error(`Failed to create item: ${exception}`);
        throw exception;
    }
}
/**
 * Calls the 'itemCrud.getItem function from the WorkloadClientAPI
 * The result contains data both from Fabric and from the ISV's backend, if configured
 *
 * @param {string} objectId - The ObjectId of the item to fetch
 * @param {WorkloadClientAPI} workloadClient - An instance of the WorkloadClientAPI.
 * @param {boolean} isRetry - Indicates that the call is a retry
 * @returns {GetItemResult} - A wrapper for the item's data
 */
async function callItemGet(objectId, workloadClient, isRetry) {
    try {
        const item = await workloadClient.itemCrud.getItem({ objectId });
        console.log(`Successfully fetched item ${objectId}: ${item}`);
        return item;
    }
    catch (exception) {
        console.error('Failed locating item with ObjectID %s', objectId, exception);
        return await handleException(exception, workloadClient, isRetry, false /* isDirectWorkloadCall */, callItemGet, objectId);
    }
}
/**
 * Calls the 'itemCrud.updateItem function from the WorkloadClientAPI
 *
 * @param {string} objectId - The ObjectId of the item to update
 * @param {T|undefined} - Additional metadata payload for the item (e.g., selected Lakehouse details).
 * @param {WorkloadClientAPI} workloadClient - An instance of the WorkloadClientAPI.
 * @param {boolean} isRetry - Indicates that the call is a retry
 * @returns {GetItemResult} - A wrapper for the item's data
 */
async function callItemUpdate(objectId, payloadData, workloadClient, isRetry) {
    let payloadString;
    if (payloadData) {
        payloadString = JSON.stringify(payloadData);
        console.log(`Updating item ${objectId} with payload: ${payloadString}`);
    }
    else {
        console.log(`Sending an update for item ${objectId} without updating the payload`);
    }
    try {
        return await workloadClient.itemCrud.updateItem({
            objectId,
            etag: undefined,
            payload: { workloadPayload: payloadString, payloadContentType: "InlineJson" }
        });
    }
    catch (exception) {
        console.error(`Failed updating Item ${objectId}`, exception);
        return await handleException(exception, workloadClient, isRetry, false /* isDirectWorkloadCall */, callItemUpdate, objectId, payloadData);
    }
}
/**
 * Calls the 'itemCrud.deleteItem function from the WorkloadClientAPI
 *
 * @param {string} objectId - The ObjectId of the item to delete
 * @param {WorkloadClientAPI} workloadClient - An instance of the WorkloadClientAPI.
 * @param {boolean} isRetry - Indicates that the call is a retry
 */
async function callItemDelete(objectId, workloadClient, isRetry) {
    try {
        const result = await workloadClient.itemCrud.deleteItem({ objectId });
        console.log(`Delete result for item ${objectId}: ${result.success}`);
        return result.success;
    }
    catch (exception) {
        console.error('Failed deleting Item %s', objectId, exception);
        return await handleException(exception, workloadClient, isRetry, false /* isDirectWorkloadCall */, callItemDelete, objectId);
    }
}
// --- Item Jobs related Api
/**
 * Calls the 'itemSchedule.runItemJob' function from the WorkloadClientAPI, starting item job execution
 *
 * @param {string} objectId - The ObjectId of the item which will run the job.
 * @param {string} jobType - The job type to run.
 * @param {string} jobPayload - Payload to be sent as part of the job
 * @param {WorkloadClientAPI} workloadClient - An instance of the WorkloadClientAPI.
 * @param {boolean} showNotification - show pop-up notification.
 * @param {boolean} isRetry - Indicates that the call is a retry
 * @returns {ItemJobInstance} - The executed job instance metadata.
 */
async function callRunItemJob(objectId, jobType, jobPayload, showNotification = false, workloadClient, isRetry) {
    const params = {
        itemObjectId: objectId,
        itemJobType: jobType,
        payload: { jobPayloadJson: jobPayload }
    };
    console.log(`Call Run Item Job. request: ${params}`);
    try {
        const result = await workloadClient.itemSchedule.runItemJob(params);
        console.log(`Executed job id: ${result.itemJobInstanceId}`);
        if (showNotification) {
            callNotificationOpen(`${_utils__WEBPACK_IMPORTED_MODULE_1__.jobTypeDisplayNames[result.itemJobType]} execution has begun.`, `Job instance ID: ${result.itemJobInstanceId}.`, _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_0__.NotificationType.Success, _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_0__.NotificationToastDuration.Medium, workloadClient);
        }
        return result;
    }
    catch (exception) {
        console.error(`Failed running item job ${jobType} for item ${objectId}`);
        console.log(exception);
        return await handleException(exception, workloadClient, isRetry, false /* isDirectWorkloadCall */, callRunItemJob, objectId, jobType, jobPayload, showNotification);
    }
}
/**
 * Calls the 'itemSchedule.cancelItemJob' function from the WorkloadClientAPI, canceling item job execution
 *
 * @param {string} objectId - The ObjectId of the item which will run the job.
 * @param {string} jobInstanceObjectId - The Id of the job instance
 * @param {WorkloadClientAPI} workloadClient - An instance of the WorkloadClientAPI.
 * @param {boolean} showNotification - show pop-up notification.
 * @param {boolean} isRetry - Indicates that the call is a retry
 * @returns {CancelItemJobParams} - The executed job instance metadata.
 */
async function callCancelItemJob(objectId, jobInstanceObjectId, showNotification = false, workloadClient, isRetry) {
    const params = {
        itemObjectId: objectId,
        jobInstanceId: jobInstanceObjectId,
    };
    console.log(`Call cancel Item Job. request: ${params}`);
    try {
        const result = await workloadClient.itemSchedule.cancelItemJob(params);
        console.log(`CancelItemJobResult: ${result}`);
        if (showNotification) {
            const success = result.success;
            const notificationMessage = success
                ? `Job instance ID: ${jobInstanceObjectId} for item: ${objectId} was canceled successfully`
                : `Failed to cancel job instance ID: ${jobInstanceObjectId} for item: ${objectId} `;
            callNotificationOpen('Cancel Job result', notificationMessage, success ? _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_0__.NotificationType.Success : _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_0__.NotificationType.Error, _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_0__.NotificationToastDuration.Medium, workloadClient);
        }
        return result;
    }
    catch (exception) {
        console.error(`Failed to cancel job instance ID: ${jobInstanceObjectId} for item: ${objectId}`);
        console.log(exception);
        return await handleException(exception, workloadClient, isRetry, false /* isDirectWorkloadCall */, callCancelItemJob, objectId, jobInstanceObjectId, showNotification);
    }
}
/**
 * Calls the 'itemRecentRuns.open' function from the WorkloadClientAPI, opening the shared UI component displaying recent runs of item jobs.
 *
 * @param {ItemLikeV2} item - The item for which we want to display recent job runs.
 * @param {WorkloadClientAPI} workloadClient - An instance of the WorkloadClientAPI.
 * @returns {OpenUIResult} - The result of the UI operation.
 */
async function callOpenRecentRuns(item, workloadClient) {
    const config = {
        item: item
    };
    console.log(`Call OpenRecentRuns. request: ${item}`);
    try {
        const result = await workloadClient.itemRecentRuns.open(config);
        console.log(`OpenRecentRuns: ${result}`);
        return result;
    }
    catch (exception) {
        console.error(`Failed to open recent run for item: ${item}`);
        console.log(exception);
    }
    return null;
}
// --- Workload data plane API
/**
 * Calls workload API GetItem1SupportedOperators
 *
 * @param {WorkloadClientAPI} workloadClient - An instance of the WorkloadClientAPI.
 */
async function callGetItem1SupportedOperators(workloadBEUrl, workloadClient, isRetry) {
    const accessToken = await callAuthAcquireAccessToken(workloadClient);
    const response = await fetch(`${workloadBEUrl}/item1SupportedOperators`, { method: `GET`, headers: { 'Authorization': 'Bearer ' + accessToken.token } });
    const responseBody = await response.text();
    if (!response.ok) {
        // Handle non-successful responses here
        console.error(`Error get item1 supported operators API: ${responseBody}`);
        return await handleException(responseBody, workloadClient, isRetry, 
        /* isDirectWorkloadCall */ true, callGetItem1SupportedOperators, workloadBEUrl);
    }
    const operators = JSON.parse(responseBody);
    console.log(`*** Successfully fetched operators supported for Item1: ${operators}`);
    return operators;
}
/**
 * Calls the Item1DoubleResult endpoint of the workload API to double the result.
 *
 * @param {WorkloadClientAPI} workloadClient - An instance of the WorkloadClientAPI.
 * @param {string} workspaceObjectId - The workspace object ID.
 * @param {string} itemObjectId - The item object ID.
 * @param {boolean} isRetry - Indicates that the call is a retry
 * @returns {Promise<{ Operand1: number, Operand2: number }>} A Promise that resolves to an object containing the updated operands.
 */
async function callItem1DoubleResult(workloadBEUrl, workloadClient, workspaceObjectId, itemObjectId, isRetry) {
    try {
        const accessToken = await callAuthAcquireAccessToken(workloadClient);
        const response = await fetch(`${workloadBEUrl}/${workspaceObjectId}/${itemObjectId}/item1DoubleResult`, {
            method: `POST`,
            headers: {
                'Authorization': 'Bearer ' + accessToken.token,
                'Content-Type': 'application/json',
            },
        });
        if (!response.ok) {
            // Handle non-successful responses here
            const errorMessage = await response.text();
            console.error(`Error calling Double API: ${errorMessage}`);
            return await handleException(errorMessage, workloadClient, isRetry, 
            /* isDirectWorkloadCall */ true, callItem1DoubleResult, workloadBEUrl, workloadClient, workspaceObjectId, itemObjectId);
        }
        const result = await response.json();
        console.log('*** Successfully called Double API');
        return result;
    }
    catch (error) {
        console.error('Error in callItem1DoubleResult:', error);
        return null;
    }
}
/**
 * Calls the GetEventhouseDatabases endpoint of the workload API to get the eventhouse item metadata
 *
 * @param {string} workspaceObjectId - The workspace object ID.
 * @param {string} eventhouseObjectId - The Eventhouse object ID.
 * @param {WorkloadClientAPI} workloadClient - An instance of the WorkloadClientAPI.
 * @returns {Promise<EventhouseItemMetadata>} A Promise that resolves to an object containing the eventhouse metadata.
 */
async function callGetEventhouseItem(workloadBEUrl, workspaceObjectId, eventhouseObjectId, workloadClient) {
    try {
        const accessToken = await callAuthAcquireAccessToken(workloadClient);
        const response = await fetch(`${workloadBEUrl}/eventhouse/${workspaceObjectId}/${eventhouseObjectId}`, {
            method: `GET`,
            headers: {
                'Authorization': 'Bearer ' + accessToken.token,
                'Content-Type': 'application/json',
            }
        });
        if (!response.ok) {
            // Handle non-successful responses here
            const errorMessage = await response.text();
            console.error(`Error calling GetEventhouseItem API: ${errorMessage}`);
            return await handleException(errorMessage, workloadClient, false /* isRetry */, true /* isDirectWorkloadCall */, callGetEventhouseItem, workloadBEUrl, workspaceObjectId, eventhouseObjectId);
        }
        const result = await response.json();
        console.log('*** Successfully called GetEventhouseItem API');
        return result;
    }
    catch (error) {
        console.error('Error in GetEventhouseItem:', error);
        return null;
    }
}
/**
 * Calls the CallExecuteQuery endpoint to perform a query on selected Kusto DB.
 *
 * @param {string} queryUrl - The database url.
 * @param {string} databaseName - The database name.
 * @param {string} query - The query to execute.
 * @param {WorkloadClientAPI} workloadClient - An instance of the WorkloadClientAPI.
 * @returns {Promise<object[]>} A Promise that resolves to an object containing the queries result.
 */
async function CallExecuteQuery(workloadBEUrl, queryUrl, databaseName, query, setClientRequestId, workloadClient) {
    try {
        //KqlDatabases/query
        const accessToken = await callAuthAcquireAccessToken(workloadClient);
        const clientRequestId = 'WS-' + (0,uuid__WEBPACK_IMPORTED_MODULE_3__["default"])();
        setClientRequestId(clientRequestId);
        const response = await fetch(`${workloadBEUrl}/KqlDatabases/query`, {
            method: `POST`,
            headers: {
                'Authorization': 'Bearer ' + accessToken.token,
                'Content-Type': 'application/json',
                'x-ms-client-request-id': clientRequestId,
            },
            body: JSON.stringify({
                'QueryServiceUri': queryUrl,
                'DatabaseName': databaseName,
                'Query': query
            })
        });
        setClientRequestId(undefined);
        if (!response.ok) {
            // Handle non-successful responses here
            const errorMessage = await response.text();
            console.error(`Error calling ExecuteQuery API: ${errorMessage}`);
            return await handleException(errorMessage, workloadClient, false /* isRetry */, true /* isDirectWorkloadCall */, CallExecuteQuery, workloadBEUrl, queryUrl, databaseName, query, setClientRequestId);
        }
        const result = await response.json();
        console.log('*** Successfully called ExecuteQuery API');
        return result;
    }
    catch (error) {
        console.error('Error in CallExecuteQuery:', error);
        return null;
    }
}
// --- Theme API
/**
 * Calls the 'theme.get' function from the WorkloadClientAPI to retrieve the current Fabric Theme configuration.
 *
 * @param {WorkloadClientAPI} workloadClient - An instance of the WorkloadClientAPI.
 * @returns {Promise<ThemeConfiguration>} - The retrieved theme configuration.
 */
async function callThemeGet(workloadClient) {
    return await workloadClient.theme.get();
}
function tokensToFormattedString(tokens) {
    return Object.entries(tokens)
        .map(([tokenName, tokenValue]) => `${tokenName}: ${tokenValue}`)
        .join(',\r\n');
}
function themeToView(theme) {
    return `Theme name: ${theme.name},\r\n Tokens: ${tokensToFormattedString(theme.tokens)}`;
}
/**
 * Calls the 'theme.onChange' function from the WorkloadClientAPI to register a callback for theme change events.
 *
 * @param {WorkloadClientAPI} workloadClient - An instance of the WorkloadClientAPI.
 */
async function callThemeOnChange(workloadClient) {
    // Define a callback function to be invoked when the theme changes
    const callback = (_) => {
        {
            // Since this callback is invoked multiple times, log a message to the console
            console.log("Theme On Change invoked");
        }
        ;
    };
    await workloadClient.theme.onChange(callback);
}
// --- Settings API
/**
 * Calls the 'settings.get' function from the WorkloadClientAPI to retrieve the current workload settings.
 *
 * @param {WorkloadClientAPI} workloadClient - An instance of the WorkloadClientAPI.
 * @returns {Promise<WorkloadSettings>} - The retrieved workload settings.
 */
async function callSettingsGet(workloadClient) {
    return await workloadClient.settings.get();
}
async function callLanguageGet(workloadClient) {
    const settings = await callSettingsGet(workloadClient);
    return settings.currentLanguageLocale;
}
function settingsToView(settings) {
    return [`Instance ID: ${settings.instanceId}`, `Host Origin: ${settings.workloadHostOrigin}`, `Current Language Locale: ${settings.currentLanguageLocale}`, `API URI: ${settings.apiUri}`].join('\r\n');
}
/**
 * Calls the 'settings.onChange' function from the WorkloadClientAPI to register a callback for settings change events.
 *
 * @param {WorkloadClientAPI} workloadClient - An instance of the WorkloadClientAPI.
 */
async function callSettingsOnChange(workloadClient, changeLang) {
    // Define a callback function to be invoked when workload settings change
    const callback = (ws) => {
        {
            // Since this callback is invoked multiple times, log a message to the console
            console.log("Settings On Change invoked");
            console.log("CurrentLanguage", ws.currentLanguageLocale);
            changeLang(ws.currentLanguageLocale);
        }
        ;
    };
    await workloadClient.settings.onChange(callback);
}
/**
 * Calls the 'itemSettings.open' function from the WorkloadClientAPI, opening the settings pane shared UI component for the item.
 *
 * @param {ItemLikeV2} item - The item for which we want to show the settings pane.
 * @param {WorkloadClientAPI} workloadClient - An instance of the WorkloadClientAPI.
 * @param {string} selectedSettingId - The ID of the tab we want to show. If no ID is passed, the item settings panel will open in the 'About' Tab.
 * @returns {OpenUIResult} - The result of the UI operation.
 */
async function callOpenSettings(item, workloadClient, selectedSettingId) {
    const config = {
        item,
        selectedSettingId
    };
    console.log(`Call open item settings. request: ${config}`);
    try {
        const result = await workloadClient.itemSettings.open(config);
        console.log(`OpenItemSettings: ${result}`);
        return result;
    }
    catch (exception) {
        console.error(`Failed to open settings for item: ${item}`);
        console.log(exception);
    }
    return null;
}
/**
 * Calls workload API GetLastResult
 *
 * @param {string} workloadBEUrl - The URL of the workload backend.
 * @param {WorkloadClientAPI} workloadClient - An instance of the WorkloadClientAPI.
 * @param {string} itemObjectId - the item object id.
 * @param {boolean} isRetry - Indicates that the call is a retry
 */
async function getLastResult(workloadBEUrl, workloadClient, itemObjectId, isRetry) {
    const accessToken = await callAuthAcquireAccessToken(workloadClient);
    const response = await fetch(`${workloadBEUrl}/${itemObjectId}/getLastResult`, { method: `GET`, headers: { 'Authorization': 'Bearer ' + accessToken.token } });
    const responseBody = await response.text();
    if (!response.ok) {
        // Handle non-successful responses here
        console.error(`Error get getLastResult API: ${responseBody}`);
        return await handleException(responseBody, workloadClient, isRetry, 
        /* isDirectWorkloadCall */ true, getLastResult, workloadBEUrl);
    }
    console.log(`*** Successfully got getLastResult: ${responseBody}`);
    return responseBody;
}
/**
 * Calls workload API isOneLakeSupported
 *
 * @param {WorkloadClientAPI} workloadClient - An instance of the WorkloadClientAPI.
 * @param {string} workspaceObjectId - the workspace object id.
 * @param {string} itemObjectId - the item object id.
 * @param {boolean} isRetry - Indicates that the call is a retry
 */
async function isOneLakeSupported(workloadBEUrl, workloadClient, workspaceObjectId, itemObjectId, isRetry) {
    const accessToken = await callAuthAcquireAccessToken(workloadClient);
    const response = await fetch(`${workloadBEUrl}/${workspaceObjectId}/${itemObjectId}/isOneLakeSupported`, { method: `GET`, headers: { 'Authorization': 'Bearer ' + accessToken.token } });
    const responseBody = await response.text();
    if (!response.ok) {
        // Handle non-successful responses here
        console.error(`Error get item1 isOneLakeSupported API: ${responseBody}`);
        return await handleException(responseBody, workloadClient, isRetry, 
        /* isDirectWorkloadCall */ true, isOneLakeSupported, workloadBEUrl);
    }
    console.log(`*** Successfully got isOneLakeSupported: ${responseBody}`);
    return responseBody == 'true';
}
/**
 * Handles errors propagated from workload backend.
 *
 * @param {any} exception - The exception that we need to handle
 * @param {WorkloadClientAPI} workloadClient - An instance of the WorkloadClientAPI.
 * @param {boolean} isRetry - Indicates that the call is a retry
 * @param {boolean} isDirectWorkloadCall - indicates that the error handling is for a data plane call (from the workload frontend directly to the workload backend)
 * @param {Function} action - The action to retry if the error was handled.
 * @param {...any[]} actionArgs - The arguments to pass to the action.
 * @returns {Promise<any>} - Whether the exception was handled or not.
 */
async function handleException(exception, workloadClient, isRetry = false, isDirectWorkloadCall = false, action, ...actionArgs) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m;
    var parsedException = null;
    if (isDirectWorkloadCall) {
        // exception is the json returned fom the call
        parsedException = JSON.parse(exception);
    }
    else {
        // exception is a JS object that contains the json returned from the workload BE
        parsedException = parseExceptionErrorResponse(exception);
    }
    // If the error is a FabricExternalWorkloadError and we could parse it, check if we can handle it.
    if ((isDirectWorkloadCall /* data plane */ || ((_b = (_a = exception.error) === null || _a === void 0 ? void 0 : _a.message) === null || _b === void 0 ? void 0 : _b.code) === _models_WorkloadExceptionsModel__WEBPACK_IMPORTED_MODULE_2__.FabricExternalWorkloadError /* control plane */)
        && parsedException) {
        const errorHandled = await handleWorkloadError(parsedException, workloadClient);
        if (!isRetry && errorHandled) {
            // error handled, retry the action
            return await action(...actionArgs, workloadClient, true /*isRetry*/);
        }
    }
    // error could not be handled, show the error dialog
    let message = (parsedException === null || parsedException === void 0 ? void 0 : parsedException.Message) || "Unknown error occurred";
    const errorCode = (_c = parsedException === null || parsedException === void 0 ? void 0 : parsedException.ErrorCode) !== null && _c !== void 0 ? _c : (_e = (_d = exception.error) === null || _d === void 0 ? void 0 : _d.message) === null || _e === void 0 ? void 0 : _e.code;
    let title = (_f = getAdditionalParameterValue(parsedException, "title")) !== null && _f !== void 0 ? _f : `Could not handle exception: ${errorCode}`;
    if (((_h = (_g = exception.error) === null || _g === void 0 ? void 0 : _g.message) === null || _h === void 0 ? void 0 : _h.code) === "PowerBICapacityValidationFailed") {
        message = `Your workspace is assigned to invalid capacity.\n` +
            `Please verify that the workspace has a valid and active capacity assigned, and try again.`;
        title = "Power BI Capacity Validation Failed";
    }
    await callErrorHandlingOpenDialog(message, title, (_j = exception.error) === null || _j === void 0 ? void 0 : _j.statusCode, (_k = exception.response) === null || _k === void 0 ? void 0 : _k.stackTrace, (_m = (_l = exception.response) === null || _l === void 0 ? void 0 : _l.headers) === null || _m === void 0 ? void 0 : _m.requestId, workloadClient);
    return null;
}
function getAdditionalParameterValue(parsedException, parameterName) {
    var _a, _b, _c, _d;
    return (_d = (_c = (_b = (_a = parsedException === null || parsedException === void 0 ? void 0 : parsedException.MoreDetails) === null || _a === void 0 ? void 0 : _a[0]) === null || _b === void 0 ? void 0 : _b.AdditionalParameters) === null || _c === void 0 ? void 0 : _c.find(ap => ap.Name == parameterName)) === null || _d === void 0 ? void 0 : _d.Value;
}
async function handleWorkloadError(parsedException, workloadClient) {
    var _a, _b, _c, _d, _e, _f, _g, _h;
    try {
        // handle codes from your choice, the codes are returned from the workload backend.
        switch (parsedException.ErrorCode) {
            case _models_WorkloadExceptionsModel__WEBPACK_IMPORTED_MODULE_2__.AuthUIRequired: {
                let authenticationUIRequiredException = {
                    ClaimsForConditionalAccessPolicy: (_c = (_b = (_a = parsedException.MoreDetails) === null || _a === void 0 ? void 0 : _a[0].AdditionalParameters) === null || _b === void 0 ? void 0 : _b.find(ap => ap.Name == "claimsForCondtionalAccessPolicy")) === null || _c === void 0 ? void 0 : _c.Value,
                    ErrorMessage: parsedException.Message,
                    ScopesToConsent: (_g = (_f = (_e = (_d = parsedException === null || parsedException === void 0 ? void 0 : parsedException.MoreDetails) === null || _d === void 0 ? void 0 : _d[0].AdditionalParameters) === null || _e === void 0 ? void 0 : _e.find(ap => ap.Name == "additionalScopesToConsent")) === null || _f === void 0 ? void 0 : _f.Value) === null || _g === void 0 ? void 0 : _g.split(", ")
                };
                if ((_h = authenticationUIRequiredException === null || authenticationUIRequiredException === void 0 ? void 0 : authenticationUIRequiredException.ErrorMessage) === null || _h === void 0 ? void 0 : _h.includes("AADSTS65001")) { // consent
                    await workloadClient.auth.acquireAccessToken({ additionalScopesToConsent: authenticationUIRequiredException.ScopesToConsent });
                    return true;
                }
                else { // conditional access policy
                    await workloadClient.auth.acquireAccessToken({ claimsForConditionalAccessPolicy: authenticationUIRequiredException.ClaimsForConditionalAccessPolicy });
                    return true;
                }
            }
        }
    }
    catch (_j) {
        console.error("Failed to handle workload error", parsedException);
    }
    return false;
}
function parseExceptionErrorResponse(exception) {
    var _a, _b, _c, _d;
    const errorResponse = (_d = (_c = (_b = (_a = exception === null || exception === void 0 ? void 0 : exception.error) === null || _a === void 0 ? void 0 : _a.message) === null || _b === void 0 ? void 0 : _b["pbi.error"]) === null || _c === void 0 ? void 0 : _c.parameters) === null || _d === void 0 ? void 0 : _d.ErrorResponse;
    if (!errorResponse) {
        return null;
    }
    return JSON.parse(errorResponse);
}


/***/ }),

/***/ "./src/models/WorkloadExceptionsModel.ts":
/*!***********************************************!*\
  !*** ./src/models/WorkloadExceptionsModel.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AuthUIRequired: () => (/* binding */ AuthUIRequired),
/* harmony export */   FabricExternalWorkloadError: () => (/* binding */ FabricExternalWorkloadError),
/* harmony export */   ItemMetadataNotFound: () => (/* binding */ ItemMetadataNotFound)
/* harmony export */ });
// <copyright company="Microsoft">
// Copyright (c) Microsoft. All rights reserved.
// </copyright>
/** Add here error interfaces that are defined in the workload backend and used to propagate exceptions in control plane APIs */
// Error code for errors propagated from the workload backend
const FabricExternalWorkloadError = "FabricExternalWorkloadError";
const AuthUIRequired = "AuthUIRequired";
const ItemMetadataNotFound = "ItemMetadataNotFound";


/***/ }),

/***/ "./src/utils.ts":
/*!**********************!*\
  !*** ./src/utils.ts ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   convertGetItemResultToWorkloadItem: () => (/* binding */ convertGetItemResultToWorkloadItem),
/* harmony export */   getJobDetailsPane: () => (/* binding */ getJobDetailsPane),
/* harmony export */   jobTypeDisplayNames: () => (/* binding */ jobTypeDisplayNames)
/* harmony export */ });
/* harmony import */ var _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ms-fabric/workload-client */ "./node_modules/@ms-fabric/workload-client/src/workload-client.js");
/* harmony import */ var _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! i18next */ "./node_modules/i18next/dist/esm/i18next.js");
/* harmony import */ var _env__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./env */ "./src/env.ts");



function convertGetItemResultToWorkloadItem(item) {
    let payload;
    if (item.workloadPayload) {
        try {
            payload = JSON.parse(item.workloadPayload);
            console.log(`Parsed payload of item ${item.objectId} is`, payload);
        }
        catch (payloadParseError) {
            console.error(`Failed parsing payload for item ${item.objectId}, payloadString: ${item.workloadPayload}`, payloadParseError);
        }
    }
    return {
        id: item.objectId,
        workspaceId: item.folderObjectId,
        type: item.itemType,
        displayName: item.displayName,
        description: item.description,
        extendedMetdata: payload,
        createdBy: item.createdByUser.name,
        createdDate: item.createdDate,
        lastModifiedBy: item.modifiedByUser.name,
        lastModifiedDate: item.lastUpdatedDate
    };
}
const sampleWorkloadName = _env__WEBPACK_IMPORTED_MODULE_2__.workloadName;
const sampleItemType = sampleWorkloadName + ".SampleWorkloadItem";
const calculateAsText = sampleItemType + ".CalculateAsText";
const longRunningCalculateAsText = sampleItemType + ".LongRunningCalculateAsText";
const scheduledJob = sampleItemType + ".ScheduledJob";
const calculateAsParquet = sampleItemType + ".CalculateAsParquet";
const instantJob = sampleItemType + ".InstantJob";
const jobTypeDisplayNames = {
    [scheduledJob]: 'Scheduled Job',
    [calculateAsText]: 'Calculate as Text',
    [longRunningCalculateAsText]: 'Long Running Calculate as Text',
    [calculateAsParquet]: 'Calculate as Parquet',
    [instantJob]: 'Instant Job'
};
function getJobDetailsPane(jobData) {
    var _a, _b;
    const jobDetailsSection = {
        title: 'Job Details',
        data: [
            {
                label: i18next__WEBPACK_IMPORTED_MODULE_1__["default"].t("Job_Type"),
                value: jobTypeDisplayNames[jobData.itemJobType],
                type: 'text',
            },
            {
                label: i18next__WEBPACK_IMPORTED_MODULE_1__["default"].t("Job_Status"),
                value: _ms_fabric_workload_client__WEBPACK_IMPORTED_MODULE_0__.ItemJobStatus[jobData.status],
                type: 'text',
            },
            {
                label: i18next__WEBPACK_IMPORTED_MODULE_1__["default"].t("Job_Start_Time_UTC"),
                value: (_a = jobData.jobStartTimeUtc) === null || _a === void 0 ? void 0 : _a.toString(),
                type: 'text',
            },
            {
                label: i18next__WEBPACK_IMPORTED_MODULE_1__["default"].t("Job_End_Time_UTC"),
                value: (_b = jobData.jobEndTimeUtc) === null || _b === void 0 ? void 0 : _b.toString(),
                type: 'text',
            },
            {
                label: i18next__WEBPACK_IMPORTED_MODULE_1__["default"].t("Job_Instance_ID"),
                value: jobData.itemJobInstanceId,
                type: 'text',
            }
        ]
    };
    const itemDetailsSection = {
        title: 'Item Details',
        data: [
            {
                label: i18next__WEBPACK_IMPORTED_MODULE_1__["default"].t("Item_Type"),
                value: 'Sample Workload Item',
                type: 'text',
            },
            {
                label: i18next__WEBPACK_IMPORTED_MODULE_1__["default"].t("Item_Name"),
                value: jobData.itemName,
                type: 'text',
            },
            {
                label: i18next__WEBPACK_IMPORTED_MODULE_1__["default"].t("Item_ID"),
                value: jobData.itemObjectId,
                type: 'text',
            },
            {
                label: i18next__WEBPACK_IMPORTED_MODULE_1__["default"].t("Workspace_Name"),
                value: jobData.workspaceName,
                type: 'text',
            },
            {
                label: i18next__WEBPACK_IMPORTED_MODULE_1__["default"].t("Workspace_ID"),
                value: jobData.workspaceObjectId,
                type: 'text',
            },
            // IMPORTANT: Use the following item(as is, keeping the label and type) to show the item editor link
            {
                label: 'Item Editor',
                value: 'Open',
                type: 'link',
            },
        ]
    };
    return {
        isSuccess: true,
        data: {
            type: 'default',
            sections: [jobDetailsSection, itemDetailsSection],
        },
    };
}


/***/ })

}]);
//# sourceMappingURL=src_controller_SampleWorkloadController_ts.bundle.87d6c524133f7e6a9122.js.map